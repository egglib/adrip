package com.qmxs.qianmonr.activity;

import android.content.res.ColorStateList;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.TextView;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.CommonPagerAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.fragment.SortListDailyUpdateFragment;
import com.qmxs.qianmonr.fragment.SortListPopularFragment;
import com.qmxs.qianmonr.widget.CustomViewPager;

import java.util.ArrayList;
import java.util.List;

/*
 * File: SortListActivity.java
 * Description: 分类列表页面
 * Author: XiaoTao
 * Create at 2019/2/25 11:37 AM
 */
public class SortListActivity extends BaseCommonTitleActivity {

    private TabLayout mTabLayout;
    private CustomViewPager mViewPager;
    private int[] mTabTitles = new int[]{R.string.popular, R.string.daily_update};

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_sort_list;
    }

    @Override
    protected String getTitleText() {
        return "玄幻";
    }

    @Override
    protected void initView() {
        super.initView();
        mTabLayout = findViewById(R.id.tabLayout);
        mViewPager = findViewById(R.id.viewPager);
    }

    @Override
    protected void pageHandle() {
        addFragments();
    }

    private void addFragments() {
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(new SortListPopularFragment());
        fragments.add(new SortListDailyUpdateFragment());
        CommonPagerAdapter commonPagerAdapter = new CommonPagerAdapter(getSupportFragmentManager(), fragments);
        mViewPager.setAdapter(commonPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        setupTabIcons();
    }

    protected void setupTabIcons() {
        try {
            for (int i = 0; i < mTabTitles.length; i++) {
                mTabLayout.getTabAt(i).setCustomView(getTabView(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private View getTabView(int position) {
        View view = getLayoutInflater().inflate(R.layout.common_tab_item_text, null);
        TextView tv_tab = view.findViewById(R.id.tv_tab_item);
        tv_tab.setText(getResources().getString(mTabTitles[position]));
        //代码需要这样设置
        ColorStateList colorStateList = getResources().getColorStateList(R.color.sort_list_tab_text_color_selector);
        tv_tab.setTextColor(colorStateList);
        return view;
    }
}
