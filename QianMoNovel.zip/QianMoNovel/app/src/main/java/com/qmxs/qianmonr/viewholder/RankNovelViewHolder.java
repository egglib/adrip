package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.NovelBreifModel;
import com.qmxs.qianmonr.model.RankNovelModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: SortBoyViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/22 8:02 PM
 */
public class RankNovelViewHolder extends BaseViewHolder {

    private TextView mNameTv;
    private TextView mIntroTv;
    private TextView mTagTv;
    private TextView mViewsNumberTv;
    private NetworkImageView mCoverImg;
    private RankNovelModel rankNovelModel;

    public RankNovelViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mNameTv = (TextView) itemView.findViewById(R.id.tv_name);
        mIntroTv = (TextView) itemView.findViewById(R.id.tv_intro);
        mTagTv = (TextView) itemView.findViewById(R.id.tv_tag);
        mViewsNumberTv = (TextView) itemView.findViewById(R.id.tv_views_number);
        mCoverImg = (NetworkImageView) itemView.findViewById(R.id.img_cover);
        itemView.setOnClickListener(v -> {
            if (rankNovelModel != null) {
                JumpUtil.forwordToNovelDetail(mContext, rankNovelModel.getBookId());
            }
        });
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        rankNovelModel = (RankNovelModel) objectList.get(position);

        if (rankNovelModel != null) {
            String imgUrl = rankNovelModel.getImg();

            if (!TextUtils.isEmpty(imgUrl)) {
                mCoverImg.setImgUrl(imgUrl);
            }

            String title = rankNovelModel.getTitle();
            if (!TextUtils.isEmpty(title)) {
                mNameTv.setText(title);
            }

            String intro = rankNovelModel.getIntro();
            if (!TextUtils.isEmpty(intro)) {
                mIntroTv.setText(intro);
            }

            String tag = rankNovelModel.getTag();
            if (!TextUtils.isEmpty(tag)) {
                mTagTv.setText(tag);
            }

            String readCount = rankNovelModel.getReadCnt();
            if (!TextUtils.isEmpty(readCount)) {
                mViewsNumberTv.setText(readCount);
            }
        }
    }
}
