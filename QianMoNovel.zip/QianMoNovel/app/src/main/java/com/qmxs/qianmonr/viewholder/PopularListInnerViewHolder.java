package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RankModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;


/*
 * File: PopularListInnerViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 6:26 PM
 */
public class PopularListInnerViewHolder extends BaseViewHolder {

    private NetworkImageView mCoverImg;
    private TextView mNovelNameTv;
    private TextView mNovelAuthorTv;

    public PopularListInnerViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mCoverImg = itemView.findViewById(R.id.img_cover);
        mNovelNameTv = itemView.findViewById(R.id.tv_novel_name);
        mNovelAuthorTv = itemView.findViewById(R.id.tv_novel_author);

        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(68)) / 3;
        int height = width * 3 / 2;
        mCoverImg.setLayoutParams(new FrameLayout.LayoutParams(width, height));
        itemView.setOnClickListener(v -> {
            RankModel.NovelInfo novelInfo = (RankModel.NovelInfo) mObjectList.get(mPosition);
            if (novelInfo != null) {
                JumpUtil.forwordToNovelDetail(mContext, novelInfo.getBookId());
            }

        });
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        RankModel.NovelInfo novelBreifModel = (RankModel.NovelInfo) objectList.get(position);

        if (novelBreifModel != null) {
            String imgUrl = novelBreifModel.getImg();

            if (!TextUtils.isEmpty(imgUrl)) {
                mCoverImg.setImgUrl(novelBreifModel.getImg());
            }

            String title = novelBreifModel.getTitle();

            if (!TextUtils.isEmpty(title)) {
                mNovelNameTv.setText(title);
            }

            String author = novelBreifModel.getAuthor();

            if (!TextUtils.isEmpty(author)) {
                mNovelAuthorTv.setText(author);
            }
        }
    }
}
