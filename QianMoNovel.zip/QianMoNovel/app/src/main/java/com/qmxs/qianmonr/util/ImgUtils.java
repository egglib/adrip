package com.qmxs.qianmonr.util;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * File: ImgUtils.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/15 11:45 AM
 */
public class ImgUtils {

    //保存文件到指定路径
    public static boolean saveImageToGallery(Context context, Bitmap bmp) {

        String sdStatus = Environment.getExternalStorageState();

        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) {
            LogUtil.e("SD *****>> SD卡不存在");
            return false;
        } else {
            LogUtil.e("SD *****>> SD卡 存在");
        }

        // 创建图片保存目录
        File faceImgDir = new File(Environment.getExternalStorageDirectory(), "lsqrcode");
        if (!faceImgDir.exists()) {
            faceImgDir.mkdir();
        }

        // 以系统时间命名文件
        String faceImgName = "ls-" + String.valueOf(System.currentTimeMillis()) + ".jpg";
        File file = new File(faceImgDir, faceImgName);

        try {
            FileOutputStream fos = new FileOutputStream(file);
            //通过io流的方式来压缩保存图片
            boolean isSuccess = bmp.compress(Bitmap.CompressFormat.JPEG, 80, fos);

            if (isSuccess) {
                fos.flush();
                fos.close();

                //及时更新到相册
                Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                Uri uri = Uri.fromFile(file);
                intent.setData(uri);
                context.sendBroadcast(intent);

                ToastUtil.shortShow(context, "保存成功");
                return true;
            } else {
                ToastUtil.shortShow(context, "保存失败");
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        ToastUtil.shortShow(context, "保存失败");
        return false;
    }

}
