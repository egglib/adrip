package com.qmxs.qianmonr.activity;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.NovelCatalogAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.viewholder.CatalogListViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;

import java.util.ArrayList;
import java.util.List;

/*
 * File: NovelCatalogActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 5:40 PM
 */
public class NovelCatalogActivity extends BaseCommonTitleActivity implements SwipeRefreshLayout.OnRefreshListener {

    private TextView mChapterNumTv;
    private Spinner mSpinner;
    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;


    @Override
    protected int getLayoutResId() {
        return R.layout.activity_novel_catalog;
    }

    @Override
    protected void initView() {
        mChapterNumTv = (TextView) findViewById(R.id.tv_chapter_num);
        mSpinner = (Spinner) findViewById(R.id.spinner);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);

        NovelCatalogAdapter novelCatalogAdapter = new NovelCatalogAdapter(this);
        novelCatalogAdapter.register(1, new ItemViewHolderContainer(R.layout.common_item_textview, CatalogListViewHolder.class));
        mRecyclerView.setAdapter(novelCatalogAdapter);

        List<RenderTypeModel> objects = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            objects.add(renderTypeModel);
        }
        novelCatalogAdapter.addData(objects);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        // 建立数据源
        String[] mItems = {"1000", "1001", "1002", "13123", "100232", "4241"};
        // 建立Adapter并且绑定数据源
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, mItems);
        adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item);
        //绑定 Adapter到控件
        mSpinner.setAdapter(adapter);
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.catalog);
    }

    @Override
    public void onRefresh() {
        mSwipeRefreshLayout.setRefreshing(false);
    }
}
