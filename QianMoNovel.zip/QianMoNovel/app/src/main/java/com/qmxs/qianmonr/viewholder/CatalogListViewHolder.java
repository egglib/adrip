package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;

import java.util.List;

/*
 * File: CatalogListViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 6:25 PM
 */
public class CatalogListViewHolder extends BaseViewHolder {

    private TextView mTextView;

    public CatalogListViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mTextView = (TextView) itemView.findViewById(R.id.textView);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        mTextView.setText("1");
    }
}
