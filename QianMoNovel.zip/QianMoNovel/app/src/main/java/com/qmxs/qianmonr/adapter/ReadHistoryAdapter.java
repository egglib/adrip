package com.qmxs.qianmonr.adapter;
import android.content.Context;


/*
 * File: ReadHistoryAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 10:09 AM
 */
public class ReadHistoryAdapter extends BaseRecyclerViewAdapter {


    public ReadHistoryAdapter(Context context) {
        super(context);
    }


}
