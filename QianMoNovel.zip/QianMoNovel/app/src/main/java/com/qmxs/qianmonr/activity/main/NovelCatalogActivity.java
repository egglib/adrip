package com.qmxs.qianmonr.activity.main;

import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.NovelCatalogAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.NovelCatalogModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.viewholder.CatalogListViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.BallPulseFooter;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.List;

/*
 * File: NovelCatalogActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 5:40 PM
 */
public class NovelCatalogActivity extends BaseCommonTitleActivity implements OnLoadMoreListener, OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SmartRefreshLayout mSwipeRefreshLayout;
    private NovelCatalogAdapter novelCatalogAdapter;

    private static final int RENDER_TYPE = 1;
    private boolean isLoading = false;
    private int mPageNum = 1;
    private int bookId;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_novel_catalog;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.catalog);
    }

    @Override
    protected void initView() {
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        bookId = JumpUtil.getBookId(this);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);

        CustomHeaderView header = new CustomHeaderView(this);
        mSwipeRefreshLayout.setRefreshHeader(header);

        BallPulseFooter footer = new BallPulseFooter(this).setSpinnerStyle(SpinnerStyle.Scale);
        mSwipeRefreshLayout.setRefreshFooter(footer);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setOnLoadMoreListener(this);

        novelCatalogAdapter = new NovelCatalogAdapter(this);
        novelCatalogAdapter.register(RENDER_TYPE, new ItemViewHolderContainer(R.layout.common_item_tv_more, CatalogListViewHolder.class));
        mRecyclerView.setAdapter(novelCatalogAdapter);
        setDialogTip("目录数据加载中...");
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        refreshData();
    }

    private void refreshData() {
        if (!isLoading) {
            isLoading = true;
            mPageNum = 1;
            getData();
        }
    }

    private void getData() {
        if (mPageNum == 1) {
            showDialog();
        }
        ApiManager.getChapterListData(this, bookId, mPageNum, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }

                List<NovelCatalogModel> novelCatalogModels = JsonUtil.jsonStrToObjList(response, NovelCatalogModel.class);

                if (novelCatalogModels == null || novelCatalogModels.isEmpty()) {
                    mSwipeRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }

                if (mPageNum == 1) {
                    novelCatalogAdapter.clearData();
                }

                mPageNum++;

                for (NovelCatalogModel novelCatalogModel : novelCatalogModels) {
                    novelCatalogModel.setRenderType(RENDER_TYPE);
                }
                novelCatalogAdapter.addData(novelCatalogModels);
            }

            @Override
            public void onError(Throwable e) {
                isLoading = false;
                dismissDialog();
                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }
            }

            @Override
            public void onComplete() {
                dismissDialog();
                isLoading = false;
            }
        });
    }


    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        getMoreData();
    }

    private void getMoreData() {
        if (!isLoading) {
            isLoading = true;
            getData();
        }
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        refreshData();
    }
}
