package com.qmxs.qianmonr.pagetransformer;

import android.view.View;

/*
 * File: AlphaPageTransformer.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/25 3:10 PM
 */
public class AlphaPageTransformer extends BasePageTransformer {

    @Override
    public void handleInvisiblePage(View view, float position) {
        view.setAlpha(0);
    }

    @Override
    public void handleLeftPage(View view, float position) {
        view.setAlpha(position + 1);
    }

    @Override
    public void handleRightPage(View view, float position) {
        view.setAlpha(1 - position);
    }

}
