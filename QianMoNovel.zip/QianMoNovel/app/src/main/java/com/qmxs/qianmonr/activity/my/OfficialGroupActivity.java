package com.qmxs.qianmonr.activity.my;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: OfficialGroupActivity.java
 * Description:官方群界面
 * Author: XiaoTao
 * Create at 2019/2/19 9:50 PM
 */
public class OfficialGroupActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_online_service;
    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.official_group);
    }
}
