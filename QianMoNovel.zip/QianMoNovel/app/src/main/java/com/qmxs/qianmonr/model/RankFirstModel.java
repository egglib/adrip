package com.qmxs.qianmonr.model;

/*
 * File: RankFirstModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/12 10:25 PM
 */
public class RankFirstModel {

    /**
     * id : 126
     * bookId : 18686
     * created_at : 1550306706
     * updated_at : 1550306706
     * rank_id : 6
     * rank_name : 推荐榜
     * deleted : 0
     * source : 自定义
     * img : http://book.wankouzi.com/book/2210/91DC2C6495E467309F8FEDD4FEF66DAA/91DC2C6495E467309F8FEDD4FEF66DAA.jpg
     * title : 驭房有术
     * author : 铁锁
     */
    private int id;
    private int bookId;
    private int created_at;
    private int updated_at;
    private int rank_id;
    private String rank_name;
    private int deleted;
    private String source;
    private String img;
    private String title;
    private String author;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

    public int getRank_id() {
        return rank_id;
    }

    public void setRank_id(int rank_id) {
        this.rank_id = rank_id;
    }

    public String getRank_name() {
        return rank_name;
    }

    public void setRank_name(String rank_name) {
        this.rank_name = rank_name;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
}
