package com.qmxs.qianmonr.fragment.featured;

import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.FFeaturedRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.model.AdBannerInfoModel;
import com.qmxs.qianmonr.model.AdBannerModel;
import com.qmxs.qianmonr.model.FSortModel;
import com.qmxs.qianmonr.model.FeaturedAuthorModel;
import com.qmxs.qianmonr.model.FeaturedNovelModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.viewholder.AuthorViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedBannerViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedSortViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType1ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType2ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType3ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType4ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType6ViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.qmxs.qianmonr.widget.LoadingDialog;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;

/*
 * File: FeaturedFFragment.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/21 4:34 PM
 */
public class FeaturedFFragment extends BaseLazyFragment implements OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SmartRefreshLayout mSwipeRefreshLayout;
    private FFeaturedRecyclerViewAdapter adapter;

    private static final int TYPE_ITEM_BANNER = -1;
    private static final int TYPE_ITEM_SORT = -2;
    private static final int TYPE_ITEM_FEATURED_0 = 0;
    private static final int TYPE_ITEM_FEATURED_1 = 1;
    private static final int TYPE_ITEM_FEATURED_2 = 2;
    private static final int TYPE_ITEM_FEATURED_3 = 3;
    private static final int TYPE_ITEM_FEATURED_4 = 4;
    private static final int TYPE_ITEM_FEATURED_5 = 5;
    private static final int TYPE_ITEM_FEATURED_6 = 6;

    @Override
    protected int setLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview_outside;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);

        mRecyclerView = view.findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        CustomHeaderView header = new CustomHeaderView(getContext());
        mSwipeRefreshLayout.setRefreshHeader(header);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setFocusableInTouchMode(true);
        mRecyclerView.setFocusable(true);
        mRecyclerView.requestFocus();
        mRecyclerView.setNestedScrollingEnabled(false);

        if (mRecyclerView.getAdapter() == null) {
            adapter = new FFeaturedRecyclerViewAdapter(getContext());
        }

        adapter.register(TYPE_ITEM_BANNER, new ItemViewHolderContainer(R.layout.item_banner_view, FeaturedBannerViewHolder.class));
        adapter.register(TYPE_ITEM_SORT, new ItemViewHolderContainer(R.layout.item_featuredf_sort, FeaturedSortViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_0, new ItemViewHolderContainer(R.layout.item_featured_author, AuthorViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_1, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType1ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_2, new ItemViewHolderContainer(R.layout.item_featured_type_2, FeaturedType2ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_3, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType3ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_4, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType4ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_5, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType6ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_6, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType6ViewHolder.class));

        mRecyclerView.setAdapter(adapter);

        setDialogTip("精选数据加载中...");
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        getData();
    }

    private void getData() {
        adapter.clearData();
        showDialog();
        ApiManager.getAdBannerFeaturedData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                List<AdBannerModel> adBannerModels = JsonUtil.jsonStrToObjList(response, AdBannerModel.class);

                AdBannerInfoModel adBannerInfoModel = new AdBannerInfoModel();
                adBannerInfoModel.setRenderType(TYPE_ITEM_BANNER);
                adBannerInfoModel.setAdBannerModels(adBannerModels);
                adapter.getDataList().add(0, adBannerInfoModel);

                FSortModel fSortModel = new FSortModel();
                fSortModel.setRenderType(TYPE_ITEM_SORT);
                adapter.getDataList().add(1, fSortModel);

            }

            @Override
            public void onError(Throwable e) {
                mSwipeRefreshLayout.finishRefresh();
            }

            @Override
            public void onComplete() {
                mSwipeRefreshLayout.finishRefresh();
            }
        });

        ApiManager.getRecommendData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                //Json的解析类对象
                JsonParser parser = new JsonParser();
                //将JSON的String 转成一个JsonArray对象
                JsonArray jsonArray = parser.parse(response).getAsJsonArray();

                Gson gson = new Gson();

                ArrayList<RenderTypeModel> renderTypeModels = new ArrayList<>();

                //加强for循环遍历JsonArray
                for (JsonElement element : jsonArray) {

                    JsonObject jsonObject = element.getAsJsonObject();
                    int type = jsonObject.get("type").getAsInt();

                    if (type == 0) {
                        FeaturedAuthorModel featuredAuthorModel = gson.fromJson(element, FeaturedAuthorModel.class);
                        featuredAuthorModel.setRenderType(0);
                        renderTypeModels.add(featuredAuthorModel);
                    } else {
                        FeaturedNovelModel featuredNovelModel = gson.fromJson(element, FeaturedNovelModel.class);
                        featuredNovelModel.setRenderType(type);
                        renderTypeModels.add(featuredNovelModel);
                    }
                }
                adapter.addData(renderTypeModels);
            }

            @Override
            public void onError(Throwable e) {
                mSwipeRefreshLayout.finishRefresh();
                dismissDialog();
            }

            @Override
            public void onComplete() {
                dismissDialog();
                mSwipeRefreshLayout.finishRefresh();
            }
        });
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        getData();
    }



    @Override
    protected void onLazyLoad() {

    }


}
