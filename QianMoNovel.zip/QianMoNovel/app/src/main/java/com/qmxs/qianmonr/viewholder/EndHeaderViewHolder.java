package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.AdBannerModel;
import com.qmxs.qianmonr.model.BannerSimpleModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;
import com.qmxs.qianmonr.widget.banner.DefaultPageTransformer;
import com.qmxs.qianmonr.widget.banner.XBanner;

import java.util.ArrayList;
import java.util.List;


/*
 * File: EndHeaderViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 11:21 AM
 */
public class EndHeaderViewHolder extends BaseViewHolder {

    private XBanner xBanner;

    public EndHeaderViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        xBanner = itemView.findViewById(R.id.netImageView);


        ApiManager.getAdBannerEndData(mContext, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<AdBannerModel> adBannerModels = JsonUtil.jsonStrToObjList(response, AdBannerModel.class);

                List<BannerSimpleModel> bannerSimpleModels = new ArrayList<>();

                for (int i = 0; i < adBannerModels.size(); i++) {
                    BannerSimpleModel simpleBannerInfo = new BannerSimpleModel();
                    bannerSimpleModels.add(simpleBannerInfo);
                }

                xBanner.setBannerData(bannerSimpleModels);
                xBanner.setCustomPageTransformer(new DefaultPageTransformer());
                xBanner.loadImage((banner, model, view, position) ->
                        ((NetworkImageView) view).setImgUrl(adBannerModels.get(position).getAttach_name()));
                xBanner.setOnItemClickListener((banner, model, view, position) -> {
                    JumpUtil.forwordToBannerContent(mContext, adBannerModels.get(position));
                });
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

}
