package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.FeaturedType31Adapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.GridSpacingItemDecoration;
import com.qmxs.qianmonr.util.ScreenUtil;

import java.util.ArrayList;
import java.util.List;

/*
 * File: FeaturedType3ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 9:17 PM
 */
public class FeaturedType3ViewHolder extends BaseViewHolder {

    private ImageView mMoreImg;
    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private static final int TYPE_ITEM_FEATURED_31 = 31;


    public FeaturedType3ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mMoreImg = (ImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.requestFocus();
        mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(3, ScreenUtil.dp2px(18), true, false, true));

        FeaturedType31Adapter type31Adapter = new FeaturedType31Adapter(mContext);
        type31Adapter.register(TYPE_ITEM_FEATURED_31, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, FeaturedType31ViewHolder.class));
        mRecyclerView.setAdapter(type31Adapter);

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();

        for (int i = 0; i < 6; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(TYPE_ITEM_FEATURED_31);
            renderTypeModels.add(renderTypeModel);
        }

        type31Adapter.addData(renderTypeModels);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
    }
}
