package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.FeaturedType31Adapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.FeaturedNovelModel;
import com.qmxs.qianmonr.model.NovelBreifModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.GridSpacingItemDecoration;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: FeaturedType3ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 9:17 PM
 */
public class FeaturedType3ViewHolder extends BaseViewHolder {

    private NetworkImageView mMoreImg;
    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private static final int TYPE_ITEM_FEATURED_31 = 31;
    private FeaturedType31Adapter type31Adapter;


    public FeaturedType3ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mMoreImg = (NetworkImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }

            @Override
            public boolean canScrollHorizontally() {
                return false;
            }
        };
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.setFocusable(false);
        mRecyclerView.requestFocus();
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(3, ScreenUtil.dp2px(18), true, false, true));
        if (mRecyclerView.getAdapter() == null)
            type31Adapter = new FeaturedType31Adapter(mContext);
        type31Adapter.register(TYPE_ITEM_FEATURED_31, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, FeaturedType31ViewHolder.class));
        mRecyclerView.setAdapter(type31Adapter);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        FeaturedNovelModel featruredModel = (FeaturedNovelModel) objectList.get(position);

        if (featruredModel != null) {
            String title = featruredModel.getTitle();
            String id = featruredModel.getTopicId();

            mMoreLayout.setOnClickListener(v -> {
                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(id)) {
                    JumpUtil.forwordToRecommendList(mContext, title, id);
                }
            });
            String imgUrl = featruredModel.getIcon();

            if (!TextUtils.isEmpty(imgUrl)) {
                mMoreImg.setImgUrl(imgUrl);
            }

            if (!TextUtils.isEmpty(title)) {
                mMoreTitleTv.setText(title);
            }

            List<NovelBreifModel> novelBreifModels = featruredModel.getData();
            for (NovelBreifModel novelBreifModel : novelBreifModels) {
                novelBreifModel.setRenderType(TYPE_ITEM_FEATURED_31);
            }
            type31Adapter.clearData();
            type31Adapter.addData(novelBreifModels);
        }

    }
}
