package com.qmxs.qianmonr.activity.main;

import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.gyf.barlibrary.ImmersionBar;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.MayLikeRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.NovelDetailModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.DateUtil;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.MayLikeViewHolder;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

import jp.wasabeef.glide.transformations.BlurTransformation;

import static com.bumptech.glide.request.RequestOptions.bitmapTransform;

/*
 * File: NovelDetailIntroActivity.java
 * Description: 小说详情界面
 * Author: XiaoTao
 * Create at 2019/2/25 10:12 PM
 */
public class NovelDetailIntroActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private ImageView mBgHeaderImg;
    private TextView mNovelNameTv;
    private TextView mNovelSortTv;
    private TextView mWordCountTv;
    private TextView mAutherTv;
    private TextView mUpdateTimeTv;
    private TextView mFullFlagTv;
    private NetworkImageView mNovelCoverImg;
    private TextView mFreeReadBtn;
    private TextView mAddInBookshelfBtn;
    private TextView mBookshelfNumTv;
    private TextView mDownloadNumTv;
    private TextView mReadNumTv;
    private TextView mBriefIntroTv;
    private TextView mCatalogTv;
    private LinearLayout mCatalogLayout;
    private RecyclerView mRecyclerView;
    private LinearLayout mMoreLayout;
    private MayLikeRecyclerViewAdapter adapter;
    private static final int RENDER_TYPE = 1;
    private int bookId;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_novel_detail_intro;
    }

    @Override
    protected int getTitleBackgroundColor() {
        return android.R.color.transparent;
    }

    @Override
    protected int getLayoutType() {
        return TYPE_LAYOUT_FRAME;
    }

    @Override
    protected void initView() {
        super.initView();
        bookId = JumpUtil.getBookId(this);
        ImmersionBar.with(this).reset().statusBarDarkFont(false).navigationBarColor(R.color.white).init();
//        View view = createActionBarRightIcon(R.mipmap.ic_download);
//        view.setOnClickListener(v -> {
//            Toast.makeText(NovelDetailIntroActivity.this, "开始下载", Toast.LENGTH_SHORT).show();
//        });
        mBgHeaderImg = findViewById(R.id.img_bg_header);
        Glide.with(NovelDetailIntroActivity.this).load("").apply(bitmapTransform(new BlurTransformation(20, 3))).into(mBgHeaderImg);

        mNovelNameTv = (TextView) findViewById(R.id.tv_novel_name);
        mNovelSortTv = (TextView) findViewById(R.id.tv_novel_sort);
        mWordCountTv = (TextView) findViewById(R.id.tv_word_count);
        mAutherTv = (TextView) findViewById(R.id.tv_auther);
        mUpdateTimeTv = (TextView) findViewById(R.id.tv_update_time);
        mFullFlagTv = (TextView) findViewById(R.id.tv_full_flag);
        mNovelCoverImg = (NetworkImageView) findViewById(R.id.img_novel_cover);
        mFreeReadBtn = (TextView) findViewById(R.id.btn_free_read);
        mFreeReadBtn.setOnClickListener(this);
        mAddInBookshelfBtn = (TextView) findViewById(R.id.btn_add_in_bookshelf);
        mAddInBookshelfBtn.setOnClickListener(this);
        mBookshelfNumTv = (TextView) findViewById(R.id.tv_bookshelf_num);
        mDownloadNumTv = (TextView) findViewById(R.id.tv_download_num);
        mReadNumTv = (TextView) findViewById(R.id.tv_read_num);
        mBriefIntroTv = (TextView) findViewById(R.id.tv_brief_intro);
        mCatalogTv = (TextView) findViewById(R.id.tv_catalog);
        mCatalogLayout = (LinearLayout) findViewById(R.id.layout_catalog);
        mCatalogLayout.setOnClickListener(this);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(15), ScreenUtil.dp2px(15), ScreenUtil.dp2px(5), ScreenUtil.dp2px(15)));
        adapter = new MayLikeRecyclerViewAdapter(this);
        adapter.register(RENDER_TYPE, new ItemViewHolderContainer(R.layout.common_item_imgview_textview, MayLikeViewHolder.class));
        mRecyclerView.setAdapter(adapter);
        mMoreLayout = findViewById(R.id.layout_more);
        mMoreLayout.setOnClickListener(this);
        setDialogTip("小说详情加载中...");
    }

    private NovelDetailModel novelDetailModel;

    @Override
    protected void pageHandle() {
        super.pageHandle();
        getNovelDetailInfo();
    }

    private void getNovelDetailInfo() {
        showDialog();
        ApiManager.getNovelInfoData(this, bookId, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                novelDetailModel = JsonUtil.jsonStrToObj(response, NovelDetailModel.class);
                if (novelDetailModel == null || novelDetailModel.getNovelInfo() == null)
                    return;

                String title = novelDetailModel.getNovelInfo().getTitle();
                if (!TextUtils.isEmpty(title)) {
                    mNovelNameTv.setText(title);
                }
                String clsName = novelDetailModel.getNovelInfo().getClsName();
                if (!TextUtils.isEmpty(clsName)) {
                    mNovelSortTv.setText("分类：" + clsName);
                }

                String wordCount = novelDetailModel.getNovelInfo().getWordCnt();
                if (!TextUtils.isEmpty(wordCount)) {
                    mWordCountTv.setText("字数：" + wordCount);
                }

                String imgUrl = novelDetailModel.getNovelInfo().getAttach_name();
                mNovelCoverImg.setImgUrl(imgUrl);
                Glide.with(NovelDetailIntroActivity.this).load(imgUrl).placeholder(R.mipmap.img_default)
                        .error(R.mipmap.img_default).apply(bitmapTransform(new BlurTransformation(20, 3))).into(mBgHeaderImg);

                String author = novelDetailModel.getNovelInfo().getAuthor();
                if (!TextUtils.isEmpty(author)) {
                    mAutherTv.setText("作者：" + author);
                }

                int time = novelDetailModel.getNovelInfo().getCreated_at();
                String updateStr = novelDetailModel.getNovelInfo().getStrLastCharpterTime();
                if (!TextUtils.isEmpty(updateStr)) {
                    mUpdateTimeTv.setText("更新时间：" + updateStr);
                } else {
                    mUpdateTimeTv.setText("更新时间：" + DateUtil.format10ToYMD(time));
                }

                boolean isShelf = novelDetailModel.getNovelInfo().isShelf();
                if (isShelf) {
                    mAddInBookshelfBtn.setText("已加入书架");
                    mAddInBookshelfBtn.setClickable(false);
                } else {
                    mAddInBookshelfBtn.setText("加入书架");
                    mAddInBookshelfBtn.setClickable(true);
                }

                String fullFlag = novelDetailModel.getNovelInfo().getFullFlag();
                if (!TextUtils.isEmpty(fullFlag)) {
                    mFullFlagTv.setVisibility(View.VISIBLE);
                    mFullFlagTv.setText(fullFlag);
                }

                int loveCnt = novelDetailModel.getNovelInfo().getLoveCnt();
                if (loveCnt > 0)
                    mBookshelfNumTv.setText(String.valueOf(loveCnt));

                int downCnt = novelDetailModel.getNovelInfo().getDownCnt();
                if (downCnt > 0)
                    mDownloadNumTv.setText(String.valueOf(downCnt));

                int readCnt = novelDetailModel.getNovelInfo().getReadCnt();
                if (readCnt > 0)
                    mReadNumTv.setText(String.valueOf(readCnt));

                String intro = novelDetailModel.getNovelInfo().getIntro();
                if (!TextUtils.isEmpty(intro)) {
                    mBriefIntroTv.setText(intro);
                }

                int chapterCount = novelDetailModel.getNovelInfo().getChapterCnt();
                if (chapterCount > 0) {
                    mCatalogTv.setText("共" + chapterCount + "章(在线阅读)");
                }

                if (novelDetailModel.getGuess() == null || novelDetailModel.getGuess().

                        isEmpty())
                    return;

                List<NovelDetailModel.GuessModel> guessModels = novelDetailModel.getGuess();
                for (
                        NovelDetailModel.GuessModel guessModel : guessModels) {
                    guessModel.setRenderType(RENDER_TYPE);
                }
                adapter.clearData();
                adapter.addData(guessModels);
            }

            @Override
            public void onError(Throwable e) {
                dismissDialog();
            }

            @Override
            public void onComplete() {
                dismissDialog();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_free_read:
                JumpUtil.forwordToReadPage(this, novelDetailModel.getNovelInfo());
                break;
            case R.id.btn_add_in_bookshelf:
                addBookshelf();
                break;
            case R.id.layout_catalog:
                JumpUtil.forwordToNovelCatalog(this, bookId);
                break;
            default:
                break;
        }
    }

    private void addBookshelf() {
        ApiManager.addBookshelf(this, bookId, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                mAddInBookshelfBtn.setText("已加入书架");
                mAddInBookshelfBtn.setClickable(false);
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }
}
