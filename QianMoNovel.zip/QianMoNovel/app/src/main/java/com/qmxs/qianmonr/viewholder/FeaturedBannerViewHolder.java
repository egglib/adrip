package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.widget.NetworkImageView;


/*
 * File: FeaturedBannerViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 6:18 PM
 */
public class FeaturedBannerViewHolder extends BaseViewHolder {

    private NetworkImageView networkImageView;

    public FeaturedBannerViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        networkImageView = itemView.findViewById(R.id.netImageView);
        networkImageView.setImgUrl("http://imgcache.qq.com/fm/photo/album/rmid_album_720/s/f/001euqOX2xXEsf.jpg");
    }
}
