package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.AdBannerInfoModel;
import com.qmxs.qianmonr.model.AdBannerModel;
import com.qmxs.qianmonr.model.BannerSimpleModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;
import com.qmxs.qianmonr.widget.banner.ScalePageTransformer;
import com.qmxs.qianmonr.widget.banner.XBanner;

import java.util.ArrayList;
import java.util.List;


/*
 * File: FeaturedBannerViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 6:18 PM
 */
public class FeaturedBannerViewHolder extends BaseViewHolder {

    private XBanner xBanner;

    public FeaturedBannerViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        xBanner = itemView.findViewById(R.id.netImageView);
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        AdBannerInfoModel adBannerInfoModel = (AdBannerInfoModel) objectList.get(position);

        if (adBannerInfoModel != null) {

            List<AdBannerModel> adBannerModels = adBannerInfoModel.getAdBannerModels();

            if (adBannerModels != null && !adBannerModels.isEmpty()) {

                List<BannerSimpleModel> bannerSimpleModels = new ArrayList<>();

                for (int i = 0; i < adBannerModels.size(); i++) {
                    BannerSimpleModel simpleBannerInfo = new BannerSimpleModel();
                    bannerSimpleModels.add(simpleBannerInfo);
                }
                xBanner.setBannerData(bannerSimpleModels);
                xBanner.setCustomPageTransformer(new ScalePageTransformer());
                xBanner.loadImage((banner, model, view, index) ->
                        ((NetworkImageView) view).setImgUrl(adBannerModels.get(index).getAttach_name()));

                xBanner.setOnItemClickListener((banner, model, view, index) -> {
                    JumpUtil.forwordToBannerContent(mContext, adBannerModels.get(index));
                });
            }
        }

    }
}
