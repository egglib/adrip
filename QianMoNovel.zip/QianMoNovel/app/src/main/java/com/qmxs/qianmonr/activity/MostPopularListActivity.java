package com.qmxs.qianmonr.activity;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.SortListPopularAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.NovelBriefIntroViewHolder;

import java.util.ArrayList;
import java.util.List;

/*
 * File: PopularListActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 10:06 PM
 */
public class MostPopularListActivity extends BaseCommonTitleActivity implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview;
    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.most_popular_list);
    }

    @Override
    protected void initView() {
        View view = createActionBarRightIcon(R.mipmap.ic_search);
        view.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);

        mSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);
        SortListPopularAdapter sortListPopularAdapter = new SortListPopularAdapter(this);

        sortListPopularAdapter.register(1, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, NovelBriefIntroViewHolder.class));
        List<RenderTypeModel> objects = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            objects.add(renderTypeModel);
        }
        sortListPopularAdapter.addData(objects);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(sortListPopularAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(0, 0, ScreenUtil.dp2px(15), 0));

    }

    @Override
    public void onRefresh() {

    }
}
