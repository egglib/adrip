package com.qmxs.qianmonr.activity.my;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: RepalceBindingActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/23 4:00 PM
 */
public class RepalceBindingActivity extends BaseCommonTitleActivity {


    @Override
    protected int getLayoutResId() {
        return R.layout.activity_repalce_binding;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.replace_binding);
    }
}

