package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: BookshelfNovelContainer.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 3:28 PM
 */
public class BookshelfNovelContainer extends RenderTypeModel{

    private List<RenderTypeModel> renderTypeModels;

    public List<RenderTypeModel> getRenderTypeModels() {
        return renderTypeModels;
    }

    public void setRenderTypeModels(List<RenderTypeModel> renderTypeModels) {
        this.renderTypeModels = renderTypeModels;
    }
}
