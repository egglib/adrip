package com.qmxs.qianmonr.activity.my;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: RepalcePasswordActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/23 4:04 PM
 */
public class RepalcePasswordActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_repalce_password;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.replace_password);
    }
}
