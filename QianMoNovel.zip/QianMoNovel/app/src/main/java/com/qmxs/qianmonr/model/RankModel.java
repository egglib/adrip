package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: RankModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/12 9:04 PM
 */
public class RankModel extends RenderTypeModel{

    /**
     * rankId : 1
     * rankName : 人气榜
     * icon : http://x.lanshu.me/storage/7278ed4c042f14e627dbad0d1ffd176d.jpg
     * start : 1
     * data : [{"bookId":18686,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/2210/91DC2C6495E467309F8FEDD4FEF66DAA/91DC2C6495E467309F8FEDD4FEF66DAA.jpg","title":"驭房有术","author":"铁锁","intro":"进城闯荡的小阿姨衣锦还乡，张禹的老妈心动了，决定让儿子前去投奔。不曾想，所谓的豪宅就是一个三十平米的出租屋，更为要命的是，小阿姨经营的房产中介都快交不上房租了。风水卖房、风水装修\u2026\u2026张禹从乡下棺材铺王老头那里学来的奇门玄术竟然派上了用场，摇身一变成了王牌经纪人\u2026\u2026兄弟、美女，买房吗？阴宅阳宅都有，包装修！\r\n","readCnt":"881.08万字","tag":"历史 | 铁锁"},{"bookId":15401,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/575/C7D80BDE2BEAE3CC5328FA4B26054A31/C7D80BDE2BEAE3CC5328FA4B26054A31.jpg","title":"无限升级之最强武魂","author":"热血辣椒","intro":"平凡学生楚炎，异世觉醒逆天武魂、且看他如何一路逆袭、邂逅仙姿美女，碾压九界天才。天才高手，在我面前，都是用来踩的。打爆一切不服者！狂虐各路高手！踏九宵、破苍穹、逆乾坤！祭炼神鼎丹方，踏武道巅峰！执掌万界，开创无上神通，成就一代传奇，傲视古今。这一世，我要不留遗憾！九天十地！唯我独尊！为所欲为！\n","readCnt":"677.25万字","tag":"玄幻 | 热血辣椒"},{"bookId":401350,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/33/35fbc24c0e6e2085fbf2169096c2fd44.png","title":"超极品太子","author":"原始罪孽","intro":"市委书记的儿子是太子？省委书记的儿子算太子？统统弱爆了。家族拥有挥霍不尽的金钱，能给世界来一场金融风暴，爷爷的神秘能让世界头号霸权国家颤抖，外公是一个富裕国家的开国太祖，母亲公主根正苗红，父亲是副国级领导，有希望进军常委\u2026\u2026他们的子孙，才叫太子！简单而言，这是一个太子的征战史，风流史，和牛逼史\u2026\u2026他将掀起史无前例飓风般的香艳狂潮！","readCnt":"318.81万字","tag":"都市 | 原始罪孽"},{"bookId":371238,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/3819/BDBC7E2DF3B04E288484DBFE065F3341/BDBC7E2DF3B04E288484DBFE065F3341.jpg","title":"万古神帝","author":"飞天鱼","intro":"八百年前，明帝之子张若尘，被他的未婚妻池瑶公主杀死，一代天骄，就此陨落。八百年后，张若尘重新活了过来，却发现曾经杀死他的未婚妻，已经统一昆仑界，开辟出第一中央帝国，号称\u201c池瑶女皇\u201d。池瑶女皇\u2014\u2014统御天下，威临八方；青春永驻，不死不灭。张若尘站在诸皇祠堂外，望着池瑶女皇的神像，心中燃烧起熊熊的仇恨烈焰，\u201c待我重修十三年，敢叫女皇下黄泉\u201d。\r\n","readCnt":"836.44万字","tag":"玄幻 | 飞天鱼"},{"bookId":17488,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/2636/7BE6A6AB810792AD705C6066B71FEAA3/7BE6A6AB810792AD705C6066B71FEAA3.jpg","title":"重生之神帝归来","author":"马甲千万","intro":"神帝归来，傲绝都市！那一年，陈潇高考失利，女友分手，父母更是遭遇车祸，双双身亡。绝望之中他跃下山崖，试图了结一生，不想却穿越到了一个神奇宏大的武道世界！三千年后，陈潇已是镇压当世、横扫无敌的绝世大帝，但他却舍毅然舍弃万劫不灭的元始之躯，带着三千年的记忆重回少年时代！这一世，他只求红尘佳人，无愧于心！\r\n","readCnt":"451.28万字","tag":"玄幻 | 马甲千万"},{"bookId":20339,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/2561/888F0929959E8D1EC3A84884CCBEE022/888F0929959E8D1EC3A84884CCBEE022.jpg","title":"房术","author":"跑盘","intro":"房产中介公司的经纪人张伟，在一次意外受伤中拥有了\u201c读心术\u201d的异能。\r\n    \u201c读心术\u201d让他可以看清房产行业中的尔虞我诈，判断出客户的真实想法，在房产行业混的风生水起。\r\n    明星、贵妇、女强人等各式各样的客户，都将粉墨登场\u2026\u2026\r\n","readCnt":"525.7万字","tag":"都市 | 跑盘"},{"bookId":20366,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/95/3cf31f87112f1cf0edace77a37d55c2e.jpg","title":"网游之奴役众神","author":"一夜狂醉","intro":"举刀称霸世无双，\r\n不求游戏战无敌，\r\n只求无愧于兄弟！\r\n苏牧，一个游戏界的神话，传奇。因兄弟之死回国，不料住进了一个全部都是女孩子的公寓，不知其身份的女孩子们全屏嘲讽，而在游戏中的他却是奴役着整个游戏的神灵！","readCnt":"817.8万字","tag":"游戏 | 一夜狂醉"},{"bookId":302319,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/19/d2ca3782af1155f3e39704db4c04f053.jpg","title":"斗破苍穹","author":"天蚕土豆","intro":"这里是属于斗气的世界，没有花俏艳丽的魔法，有的，仅仅是繁衍到巅峰的斗气！       \r\n 新书等级制度：斗者，斗师，大斗师，斗灵，斗王，斗皇，斗宗，斗尊，斗圣，斗帝。     \r\n","readCnt":"529.97万字","tag":"玄幻 | 天蚕土豆"},{"bookId":371063,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/95/44ded82d6698eb6e0038094785ae50c4.jpg","title":"仙帝归来","author":"风无极光","intro":"三年前，云青岩从凡人界意外坠入仙界。三千年后，他成为叱咤仙界的云帝。破开虚空，回到凡人界的云青岩发现这里的时间只过了三年。;曾经，我没有实力守护心爱之人，如今，我要整个世界匍匐在我脚下。\r\n","readCnt":"538.14万字","tag":"玄幻 - 东方玄幻 | 风无极光"},{"bookId":17785,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/704/FEF7039C459E17C8509AB4B6F7EDEE6D/FEF7039C459E17C8509AB4B6F7EDEE6D.jpg","title":"大王饶命","author":"会说话的肘子","intro":"灵气复苏了，吕树眼瞅着一个个大能横空出世。然后再看一眼自己不太正经的能力，倒吸一口冷气。玩狗蛋啊！\u2026\u2026这是一个吕树依靠毒鸡汤成为大魔王的故事。\n","readCnt":"321.75万字","tag":"玄幻 | 会说话的肘子"},{"bookId":12475,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/3968/2098EC2B69F933BBBCF6B464908873AE/2098EC2B69F933BBBCF6B464908873AE.jpg","title":"网游之逆天戒指","author":"上古圣贤","intro":"  一枚神奇的戒指不仅能让你在游戏中驰骋，还能把游戏内的物品带到现实！\r\n    一个被迫转职生活职业没有战斗技能的少年，却拥有了战斗玩家都无法比拟的战斗力！\r\n    装备碾压，刷本杀怪夺宝，纵横游戏，从此成就高手之路\r\n    \u201c如果低调也无法掩饰我自身的光芒，那就让我用张扬向世界炫耀我的存在！\u201d蒋飞如是说道！\r\n","readCnt":"710.67万字","tag":"游戏 | 上古圣贤"},{"bookId":15290,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/2510/A1101035F93592D974AACA095D742EDF/A1101035F93592D974AACA095D742EDF.jpg","title":"超级神基因","author":"十二翼黑暗炽天使","intro":"未来波澜壮阔的星际时代，人类终于攻克了空间传送技术，可是当人类传送到另一端的时候，却发现那里并不是过去未来，也不是星空下的任何一片土地\u2026\u2026","readCnt":"810.39万字","tag":"玄幻 | 十二翼黑暗炽天使"},{"bookId":19095,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/83/17f517842b52cbf16c4b0352b98f29eb.jpg","title":"牧神记","author":"宅猪","intro":"大墟的祖训说，天黑，别出门。大墟残老村的老弱病残们从江边捡到了一个婴儿，取名秦牧，含辛茹苦将他养大。这一天夜幕降临，黑暗笼罩大墟，秦牧走出了家门\u2026\u2026做个春风中荡漾的反派吧！瞎子对他说。秦牧的反派之路，正在崛起！\r\n","readCnt":"480.35万字","tag":"玄幻 - 东方玄幻 | 宅猪"},{"bookId":365732,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/3503/660AFCCC467A522B520CA26A388BEF43/660AFCCC467A522B520CA26A388BEF43.jpg","title":"都市最强装逼系统","author":"必火","intro":"    叶秋重生获得装逼系统，当最萌萝莉的奶爸，教美女大明星唱歌，做宗师级美食大餐，写最畅销的小说，装最牛的逼\u2026\u2026不服你也装逼啊？只不过别装逼不成反被草！我一天不装逼就浑身不舒服，各种姿势装逼通通都来。打电话给我没接，对不起我肯定正在装逼。如果我不是在装逼，就是在去往装逼的路上，人活着若是不装逼，和咸鱼又有什么区别呢\r\n","readCnt":"475.34万字","tag":"都市 | 必火"},{"bookId":366072,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/85/7e61cdc74553d24ba464258a00420aec.jpg","title":"和嫂子同居的日子","author":"秦长青","intro":"    一场坍塌事故将唐宾原本美满的家庭一下子破碎殆尽，仅留下他和即将临盆的嫂子，以及一贫如洗的家，生活该如何继续？\r\n    那一晚，唐宾看到嫂子居然在自我抚慰，然后就有了他和嫂子的荡人故事。\r\n    且看唐宾在\u201c嫂子控\u201d这种终极心理影响下，如何一步一步实现心目中他的美好新生活\u2026\u2026 可是，面对美女\u201c们\u201d的逆袭，他又该如何反抗呢？ \r\n","readCnt":"180.34万字","tag":"都市 | 秦长青"},{"bookId":618078,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/1370/E2623ADE145C4D31E7BAF6E1C0566761/E2623ADE145C4D31E7BAF6E1C0566761.jpg","title":"全职法师","author":"乱","intro":"心潮澎湃，无限幻想，迎风挥击千层浪，少年不败热血！","readCnt":"672.56万字","tag":"玄幻 - 异世大陆 | 乱"},{"bookId":302316,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/49/7a38dc98b08e54e4d62b2f9d541dc918.jpg","title":"凡人修仙传","author":"忘语","intro":"一个普通山村小子，偶然下进入到当地江湖小门派，成了一名记名弟子。他以这样身份，如何在门派中立足,如何以平庸的资质进入到修仙者的行列，从而笑傲三界之中！\r\n","readCnt":"731.48万字","tag":"仙侠 | 忘语"},{"bookId":366340,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/2217/BA31CA3B3C6A828EC5FDE7F50287FD86/BA31CA3B3C6A828EC5FDE7F50287FD86.jpg","title":"透视小村医","author":"小萌狼","intro":"    妩媚总裁想和他睡，火辣女警花要他做男朋友，长腿白富美逼他当未婚夫，还有个可爱邻家女孩在长期性发花痴。身怀绝技的狡猾乡村小神医，顿时头疼了起来，不过还好，我是个博爱的人，让别人没妞可泡的事情我特喜欢。身怀绝技踏出小山村，赚最多的钱，泡最美的妞，吊打各种不服，成就一段牛叉人生。\r\n","readCnt":"1030.89万字","tag":"都市 | 小萌狼"},{"bookId":364269,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/36/994f5097a251f99937bc8faf54891e59.jpg","title":"遮天","author":"辰东","intro":"    冰冷与黑暗并存的宇宙深处，九具庞大的龙尸拉着一口青铜古棺，亘古长存。\r\n    这是太空探测器在枯寂的宇宙中捕捉到的一幅极其震撼的画面。\r\n    九龙拉棺，究竟是回到了上古，还是来到了星空的彼岸？\r\n    一个浩大的仙侠世界，光怪陆离，神秘无尽。热血似火山沸腾，激情若瀚海汹涌，欲望如深渊无止境\u2026\u2026\r\n    登天路，踏歌行，弹指遮天。\r\n","readCnt":"713.39万字","tag":"武侠 | 辰东"},{"bookId":614026,"rank_name":"人气榜","rank_id":1,"img":"http://book.wankouzi.com/book/56/4a17938e8e0cd6ef582a929affc96d8d.jpg","title":"帝霸","author":"厌笔萧生","intro":"天若逆我，我必封之，神若挡我，我必屠之\u2014\u2014站在万族之巅的李七夜立下豪言！\r\n    这是属于一个平凡小子崛起的故事，一个牧童走向万族之巅的征程。\r\n    在这里充满神话与奇迹，天魔建起古国，石人筑就天城，鬼族铺成仙路，魅灵修补神府\u2026\u2026\r\n","readCnt":"1136.28万字","tag":"玄幻 - 东方玄幻 | 厌笔萧生"}]
     */
    private int rankId;
    private String rankName;
    private String icon;
    private int start;

    private List<NovelInfo> data;

    public int getRankId() {
        return rankId;
    }

    public void setRankId(int rankId) {
        this.rankId = rankId;
    }

    public String getRankName() {
        return rankName;
    }

    public void setRankName(String rankName) {
        this.rankName = rankName;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public List<NovelInfo> getData() {
        return data;
    }

    public void setData(List<NovelInfo> data) {
        this.data = data;
    }

    public  class NovelInfo extends RenderTypeModel{
        /**
         * bookId : 18686
         * rank_name : 人气榜
         * rank_id : 1
         * img : http://book.wankouzi.com/book/2210/91DC2C6495E467309F8FEDD4FEF66DAA/91DC2C6495E467309F8FEDD4FEF66DAA.jpg
         * title : 驭房有术
         * author : 铁锁
         * intro : 进城闯荡的小阿姨衣锦还乡，张禹的老妈心动了，决定让儿子前去投奔。不曾想，所谓的豪宅就是一个三十平米的出租屋，更为要命的是，小阿姨经营的房产中介都快交不上房租了。风水卖房、风水装修……张禹从乡下棺材铺王老头那里学来的奇门玄术竟然派上了用场，摇身一变成了王牌经纪人……兄弟、美女，买房吗？阴宅阳宅都有，包装修！
         * readCnt : 881.08万字
         * tag : 历史 | 铁锁
         */

        private int bookId;
        private String rank_name;
        private int rank_id;
        private String img;
        private String title;
        private String author;
        private String intro;
        private String readCnt;
        private String tag;

        public int getBookId() {
            return bookId;
        }

        public void setBookId(int bookId) {
            this.bookId = bookId;
        }

        public String getRank_name() {
            return rank_name;
        }

        public void setRank_name(String rank_name) {
            this.rank_name = rank_name;
        }

        public int getRank_id() {
            return rank_id;
        }

        public void setRank_id(int rank_id) {
            this.rank_id = rank_id;
        }

        public String getImg() {
            return img;
        }

        public void setImg(String img) {
            this.img = img;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public String getIntro() {
            return intro;
        }

        public void setIntro(String intro) {
            this.intro = intro;
        }

        public String getReadCnt() {
            return readCnt;
        }

        public void setReadCnt(String readCnt) {
            this.readCnt = readCnt;
        }

        public String getTag() {
            return tag;
        }

        public void setTag(String tag) {
            this.tag = tag;
        }
    }
}
