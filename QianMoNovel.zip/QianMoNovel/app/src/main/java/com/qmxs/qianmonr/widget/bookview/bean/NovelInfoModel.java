package com.qmxs.qianmonr.widget.bookview.bean;

import android.os.Parcel;
import android.os.Parcelable;

/*
 * File: NovelInfoModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/9 5:34 PM
 */
public class NovelInfoModel implements Parcelable {
    /**
     * id : 60021
     * bookId : 16499
     * title : 怎么又是天谴圈
     * cover : /2921/C418B0F90ED0DC220AFAB7A5D80C4AB9/C418B0F90ED0DC220AFAB7A5D80C4AB9.jpg
     * author : 诸葛婉君
     * intro : 偶得吐槽系统，一个被绝地求生诅咒的男人。落地自带天谴圈，洗头全靠轰炸区，资源只有十字弩，载具从来一格油。轰炸如风，常伴吾身。长路漫漫，唯毒相伴。什么？落地98k，枪枪都爆头？我怂还不行嘛！什么？落地天命圈，开枪落空投？我怂还不行嘛！什么，你说这么惨这么怂都忍不住要吐槽？这就对了！“叮，吐槽值+1，系统已激活！”
     * chapterCnt : 932
     * loveCnt : 91
     * wordCnt : 232.65万字
     * score : 0
     * fullFlag : 连载
     * readCnt : 17290
     * downCnt : 10
     * postDate : 0
     * retention : 4949
     * status : 1
     * created_at : 1548417505
     * lastUpdate : 1541437662
     * updated_at : 1548417505
     * deleted : 0
     * list_id : 66901
     * clsId : 4
     * clsName : 仙侠
     * is_rec : 0
     * cover_id : 0
     * strLastCharpterTime :
     * pid : 1
     * attach_name : http://book.wankouzi.com/book/2921/C418B0F90ED0DC220AFAB7A5D80C4AB9/C418B0F90ED0DC220AFAB7A5D80C4AB9.jpg
     * tag : 仙侠 | 诸葛婉君
     * isShelf : false
     */

    private int id;
    private int bookId;
    private String title;
    private String cover;
    private String author;
    private String intro;
    private int chapterCnt;
    private int loveCnt;
    private String wordCnt;
    private int score;
    private String fullFlag;
    private int readCnt;
    private int downCnt;
    private int postDate;
    private int retention;
    private int status;
    private int created_at;
    private int lastUpdate;
    private int updated_at;
    private int deleted;
    private int list_id;
    private int clsId;
    private String clsName;
    private int is_rec;
    private int cover_id;
    private String strLastCharpterTime;
    private int pid;
    private String attach_name;
    private String tag;
    private boolean isShelf;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public int getChapterCnt() {
        return chapterCnt;
    }

    public void setChapterCnt(int chapterCnt) {
        this.chapterCnt = chapterCnt;
    }

    public int getLoveCnt() {
        return loveCnt;
    }

    public void setLoveCnt(int loveCnt) {
        this.loveCnt = loveCnt;
    }

    public String getWordCnt() {
        return wordCnt;
    }

    public void setWordCnt(String wordCnt) {
        this.wordCnt = wordCnt;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getFullFlag() {
        return fullFlag;
    }

    public void setFullFlag(String fullFlag) {
        this.fullFlag = fullFlag;
    }

    public int getReadCnt() {
        return readCnt;
    }

    public void setReadCnt(int readCnt) {
        this.readCnt = readCnt;
    }

    public int getDownCnt() {
        return downCnt;
    }

    public void setDownCnt(int downCnt) {
        this.downCnt = downCnt;
    }

    public int getPostDate() {
        return postDate;
    }

    public void setPostDate(int postDate) {
        this.postDate = postDate;
    }

    public int getRetention() {
        return retention;
    }

    public void setRetention(int retention) {
        this.retention = retention;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(int lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public int getList_id() {
        return list_id;
    }

    public void setList_id(int list_id) {
        this.list_id = list_id;
    }

    public int getClsId() {
        return clsId;
    }

    public void setClsId(int clsId) {
        this.clsId = clsId;
    }

    public String getClsName() {
        return clsName;
    }

    public void setClsName(String clsName) {
        this.clsName = clsName;
    }

    public int getIs_rec() {
        return is_rec;
    }

    public void setIs_rec(int is_rec) {
        this.is_rec = is_rec;
    }

    public int getCover_id() {
        return cover_id;
    }

    public void setCover_id(int cover_id) {
        this.cover_id = cover_id;
    }

    public String getStrLastCharpterTime() {
        return strLastCharpterTime;
    }

    public void setStrLastCharpterTime(String strLastCharpterTime) {
        this.strLastCharpterTime = strLastCharpterTime;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getAttach_name() {
        return attach_name;
    }

    public void setAttach_name(String attach_name) {
        this.attach_name = attach_name;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public boolean isShelf() {
        return isShelf;
    }

    public void setShelf(boolean shelf) {
        isShelf = shelf;
    }

    protected NovelInfoModel(Parcel in) {
        id = in.readInt();
        bookId = in.readInt();
        title = in.readString();
        cover = in.readString();
        author = in.readString();
        intro = in.readString();
        chapterCnt = in.readInt();
        loveCnt = in.readInt();
        wordCnt = in.readString();
        score = in.readInt();
        fullFlag = in.readString();
        readCnt = in.readInt();
        downCnt = in.readInt();
        postDate = in.readInt();
        retention = in.readInt();
        status = in.readInt();
        created_at = in.readInt();
        lastUpdate = in.readInt();
        updated_at = in.readInt();
        deleted = in.readInt();
        list_id = in.readInt();
        clsId = in.readInt();
        clsName = in.readString();
        is_rec = in.readInt();
        cover_id = in.readInt();
        strLastCharpterTime = in.readString();
        pid = in.readInt();
        attach_name = in.readString();
        tag = in.readString();
        isShelf = in.readByte() != 0;
    }

    public static final Creator<NovelInfoModel> CREATOR = new Creator<NovelInfoModel>() {
        @Override
        public NovelInfoModel createFromParcel(Parcel in) {
            return new NovelInfoModel(in);
        }

        @Override
        public NovelInfoModel[] newArray(int size) {
            return new NovelInfoModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(bookId);
        dest.writeString(title);
        dest.writeString(cover);
        dest.writeString(author);
        dest.writeString(intro);
        dest.writeInt(chapterCnt);
        dest.writeInt(loveCnt);
        dest.writeString(wordCnt);
        dest.writeInt(score);
        dest.writeString(fullFlag);
        dest.writeInt(readCnt);
        dest.writeInt(downCnt);
        dest.writeInt(postDate);
        dest.writeInt(retention);
        dest.writeInt(status);
        dest.writeInt(created_at);
        dest.writeInt(lastUpdate);
        dest.writeInt(updated_at);
        dest.writeInt(deleted);
        dest.writeInt(list_id);
        dest.writeInt(clsId);
        dest.writeString(clsName);
        dest.writeInt(is_rec);
        dest.writeInt(cover_id);
        dest.writeString(strLastCharpterTime);
        dest.writeInt(pid);
        dest.writeString(attach_name);
        dest.writeString(tag);
        dest.writeByte((byte) (isShelf ? 1 : 0));
    }
}
