package com.qmxs.qianmonr.model;

import android.os.Parcel;
import android.os.Parcelable;

/*
 * File: AdBannerModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 5:58 PM
 */
public class AdBannerModel implements Parcelable {

    /**
     * name : 精选玄幻
     * site : 1
     * cover_id : 154166
     * jump_address : channelId_6
     * type : 3  广告类型 跳转的界面也不一样  '0'=>'跳转广告','1'=>'下载广告', '2'=>'单本推荐', '3'=>'列表推荐'
     * attach_name : http://x.lanshu.me/storage/b9d19d2492b0c9674e66dbe1869067bf.jpg
     */

    private String name;
    private int site;
    private int cover_id;
    private String jump_address;
    private int type;
    private String attach_name;

    protected AdBannerModel(Parcel in) {
        name = in.readString();
        site = in.readInt();
        cover_id = in.readInt();
        jump_address = in.readString();
        type = in.readInt();
        attach_name = in.readString();
    }

    public static final Creator<AdBannerModel> CREATOR = new Creator<AdBannerModel>() {
        @Override
        public AdBannerModel createFromParcel(Parcel in) {
            return new AdBannerModel(in);
        }

        @Override
        public AdBannerModel[] newArray(int size) {
            return new AdBannerModel[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSite() {
        return site;
    }

    public void setSite(int site) {
        this.site = site;
    }

    public int getCover_id() {
        return cover_id;
    }

    public void setCover_id(int cover_id) {
        this.cover_id = cover_id;
    }

    public String getJump_address() {
        return jump_address;
    }

    public void setJump_address(String jump_address) {
        this.jump_address = jump_address;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getAttach_name() {
        return attach_name;
    }

    public void setAttach_name(String attach_name) {
        this.attach_name = attach_name;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeInt(site);
        dest.writeInt(cover_id);
        dest.writeString(jump_address);
        dest.writeInt(type);
        dest.writeString(attach_name);
    }
}
