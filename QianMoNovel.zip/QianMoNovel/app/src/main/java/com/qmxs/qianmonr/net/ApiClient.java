package com.qmxs.qianmonr.net;

import android.content.Context;
import android.text.TextUtils;

import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import com.qmxs.qianmonr.config.Constants;
import com.qmxs.qianmonr.model.ResponseModel;
import com.qmxs.qianmonr.util.Cfb_256crypt;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.LogUtil;
import com.qmxs.qianmonr.widget.LoadingDialog;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/*
 * File: ApiClient.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/5 12:30 PM
 */
public class ApiClient {

    private static ApiClient mApiClient;
    private Retrofit mRetrofit;
    private Context mContext;
    private LoadingDialog mDialog;

    /**
     * 是否显示加载对话框
     */
    private boolean isShowTip = false;


    private ApiClient() {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .build();

        mRetrofit = new Retrofit.Builder()
                .baseUrl(ApiConfig.BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())// 添加Gson转换工厂
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())//添加RxJava2调用适配工厂
                .build();
    }

    static ApiClient getInstance() {
        if (mApiClient == null) {
            synchronized (ApiClient.class) {
                if (mApiClient == null) {
                    mApiClient = new ApiClient();
                }
            }
        }
        return mApiClient;
    }

    public <T> T getRequestService(Class<T> service) {
        return mRetrofit.create(service);
    }

    public void request(Context context, Observable<ResponseModel> observable, RetrofitCallback retrofitCallback) {
        mContext = context;
        // 发送网络请求(异步)
        observable
                .subscribeOn(Schedulers.io()) // 在IO线程进行网络请求
                .observeOn(AndroidSchedulers.mainThread())// 回到主线程 处理请求结果
                .subscribe(new Observer<ResponseModel>() {

                    // 发送请求后调用该复写方法（无论请求成功与否）
                    @Override
                    public void onSubscribe(Disposable d) {
                        // 初始化工作

                        LogUtil.e("---request subscribe---");
                    }

                    // 发送请求成功后调用该复写方法
                    @Override
                    public void onNext(ResponseModel responseModel) {
                        LogUtil.e("=====success response=====" + JsonUtil.objToJsonStr(responseModel));

                        String data = "";
                        if (responseModel != null && !TextUtils.isEmpty((responseModel).getData())) {
                            data = Cfb_256crypt.decrypt(Constants.ENCRYPT_KEY, (responseModel).getData());
                        }
                        LogUtil.e("=====response data=====" + data);
                        // 对返回结果实体类对象 进行处理
                        retrofitCallback.onSuccess(data);
                    }

                    // 发送请求失败后调用该复写方法
                    @Override
                    public void onError(Throwable e) {
                        LogUtil.e("--->request error--->" + e.toString());
                        retrofitCallback.onError(e);
                    }

                    // 发送请求成功后，先调用onNext（）再调用该复写方法
                    @Override
                    public void onComplete() {
                        LogUtil.e("---request complete---");
                        retrofitCallback.onComplete();
                    }
                });
    }
}
