package com.qmxs.qianmonr.config;

/*
 * File: Global.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/21 12:18 PM
 */
public class Global {

    public static int STUTAS_BAR_HEIGHT = 0;


}
