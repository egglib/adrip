package com.qmxs.qianmonr.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;

import com.gyf.barlibrary.ImmersionBar;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.util.InputMethodUtil;


/*
 * File: BaseActivity.java
 * Description: 基类
 * Author: XiaoTao
 * Create at 2019/2/18 9:44 PM
 */
public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ImmersionBar.with(this).reset().navigationBarColor(R.color.white).statusBarDarkFont(true, 0.2f).init();
        setContentView(setContentViewId());
        afterSetContentView();
        initView();
        pageHandle();
    }

    /**
     * 设置视图之后的操作
     */
    protected void afterSetContentView() {

    }


    protected abstract int setContentViewId();

    /**
     * 初始化工作
     */
    protected void initView() {
    }

    /**
     * 界面处理工作
     */
    protected void pageHandle() {
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                View view = getCurrentFocus();
                InputMethodUtil.hideSoftKeyboard(this, view, ev);
                break;

            default:
                break;
        }
        return super.dispatchTouchEvent(ev);

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        ImmersionBar.with(this).destroy(); //必须调用该方法，防止内存泄漏
    }
}
