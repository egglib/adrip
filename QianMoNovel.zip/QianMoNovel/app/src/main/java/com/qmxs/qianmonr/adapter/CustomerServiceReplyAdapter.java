package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: CustomerServiceReplyAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 11:23 AM
 */
public class CustomerServiceReplyAdapter  extends BaseRecyclerViewAdapter{
    public CustomerServiceReplyAdapter(Context context) {
        super(context);
    }
}
