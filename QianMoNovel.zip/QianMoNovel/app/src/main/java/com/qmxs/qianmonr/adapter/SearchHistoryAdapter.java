package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: SearchHistoryAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 9:20 PM
 */
public class SearchHistoryAdapter  extends BaseRecyclerViewAdapter{
    public SearchHistoryAdapter(Context context) {
        super(context);
    }
}
