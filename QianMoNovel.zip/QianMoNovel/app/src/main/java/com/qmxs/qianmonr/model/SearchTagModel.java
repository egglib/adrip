package com.qmxs.qianmonr.model;

/*
 * File: SearchTagModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/13 5:49 PM
 */
public class SearchTagModel {
    /**
     * id : 1
     * keywords : 重生
     * type : 3
     * created_at : 0
     * updated_at : 0
     * deleted : 0
     */

    private int id;
    private String keywords;
    private int type;
    private int created_at;
    private int updated_at;
    private int deleted;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }
}
