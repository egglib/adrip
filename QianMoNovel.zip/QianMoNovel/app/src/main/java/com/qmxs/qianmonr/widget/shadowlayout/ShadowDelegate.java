package  com.qmxs.qianmonr.widget.shadowlayout;

import android.graphics.Canvas;
import android.support.annotation.ColorInt;
import android.view.View;

/*
 * File: ShadowDelegate.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/20 2:57 PM
 */
public interface ShadowDelegate {

    void onLayout(boolean changed, int left, int top, int right, int bottom);

    void onAttachToWindow();

    void onDetachedFromWindow();

    void onDraw(Canvas canvas);

    void onDrawOver(Canvas canvas);

    boolean onClipCanvas(Canvas canvas, View child);

    void invalidateShadow();

    void setShadowColor(@ColorInt int color);

}