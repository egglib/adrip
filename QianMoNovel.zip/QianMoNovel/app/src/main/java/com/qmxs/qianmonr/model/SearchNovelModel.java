package com.qmxs.qianmonr.model;

/*
 * File: SearchNovelModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/15 9:48 PM
 */
public class SearchNovelModel extends RenderTypeModel{
    /**
     * readCnt : 0.09万字
     * clsName : 都市
     * author : 方达明
     * title : 大傻
     * intro : 方达明，在文学期刊发表中短篇小说几十篇。短篇小说《出走》获第八届美国新语丝文学奖三等奖。小说《婶婶》获第九届美国新语丝文学奖，短篇小说《我的土豆》获第四届林语堂文学创作奖。短篇小说《气球》获台湾第33届联合报文学奖小说评审奖。
     * cover_id : 0
     * bookId : 721498
     * wordCnt : 932
     * img : http://book.wankouzi.com/book/2141/16660FCE746BA1B0B5DED39CA948594C/t5_215327.jpg
     * tag : 都市 | 方达明
     */

    private String readCnt;
    private String clsName;
    private String author;
    private String title;
    private String intro;
    private int cover_id;
    private int bookId;
    private int wordCnt;
    private String img;
    private String tag;

    public String getReadCnt() {
        return readCnt;
    }

    public void setReadCnt(String readCnt) {
        this.readCnt = readCnt;
    }

    public String getClsName() {
        return clsName;
    }

    public void setClsName(String clsName) {
        this.clsName = clsName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public int getCover_id() {
        return cover_id;
    }

    public void setCover_id(int cover_id) {
        this.cover_id = cover_id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getWordCnt() {
        return wordCnt;
    }

    public void setWordCnt(int wordCnt) {
        this.wordCnt = wordCnt;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
