package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: RankFirstInfoModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/12 10:26 PM
 */
public class RankFirstInfoModel extends RenderTypeModel {

    private List<RankFirstModel> rankFirstModels;

    public List<RankFirstModel> getRankFirstModels() {
        return rankFirstModels;
    }

    public void setRankFirstModels(List<RankFirstModel> rankFirstModels) {
        this.rankFirstModels = rankFirstModels;
    }
}
