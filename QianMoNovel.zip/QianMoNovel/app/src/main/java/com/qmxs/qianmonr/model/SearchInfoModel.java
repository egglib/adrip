package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: SearchInfoModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/15 9:46 PM
 */
public class SearchInfoModel {

    /**
     * start : 1
     * limit : 20
     * data : [{"readCnt":"0.09万字","clsName":"都市","author":"方达明","title":"大傻","intro":"方达明，在文学期刊发表中短篇小说几十篇。短篇小说《出走》获第八届美国新语丝文学奖三等奖。小说《婶婶》获第九届美国新语丝文学奖，短篇小说《我的土豆》获第四届林语堂文学创作奖。短篇小说《气球》获台湾第33届联合报文学奖小说评审奖。","cover_id":0,"bookId":721498,"wordCnt":932,"img":"http://book.wankouzi.com/book/2141/16660FCE746BA1B0B5DED39CA948594C/t5_215327.jpg","tag":"都市 | 方达明"},{"readCnt":"4.92万字","clsName":"都市","author":"太阳下的乌鸦","title":"小疯子和大傻缺","intro":"每个人都有自己的世界。我疯是因为在我的世界里无所顾忌。我傻是因为在我的世界里背负的枷锁太重。\n","cover_id":0,"bookId":581134,"wordCnt":49199,"img":"http://x.lanshu.me/storage/def3.jpg","tag":"都市 | 太阳下的乌鸦"},{"readCnt":"8.62万字","clsName":"都市","author":"马大傻","title":"任务启示录","intro":"林浩只是个芸芸众生的一员，一个古币改变人生的轨迹，一个神秘人一个系统精灵，开始作死的任务人生。\r\n任务不息，作死不止。","cover_id":0,"bookId":513000,"wordCnt":86201,"img":"http://x.lanshu.me/storage/def3.jpg","tag":"都市 | 马大傻"},{"readCnt":"2.91万字","clsName":"都市","author":"我是大傻蛋","title":"我是大悍匪","intro":"这是一个平凡的小人物，崛起成大悍匪的故事。","cover_id":0,"bookId":385009,"wordCnt":29119,"img":"http://book.wankouzi.com/book/3693/62BFA38CEC52A5D25F74739AB9F956E9/2523285-1496921453000.jpg","tag":"都市 | 我是大傻蛋"},{"readCnt":"2.27万字","clsName":"游戏","author":"小南国和大傻子","title":"末日罪人","intro":"小南国和大傻子的力作《末日罪人》","cover_id":0,"bookId":70511,"wordCnt":22683,"img":"http://book.wankouzi.com/book/1388/DED5ABB25CA3BB244CFB99DEB366C941/2499676-1495157362000.jpg","tag":"游戏 | 小南国和大傻子"},{"readCnt":"38.95万字","clsName":"仙侠","author":"不抽烟的烟民","title":"大傻偷妻记","intro":"","cover_id":0,"bookId":395438,"wordCnt":389482,"img":"http://book.wankouzi.com/book/3785/06AB9460041A6C357E90040DCA8A4113/06AB9460041A6C357E90040DCA8A4113.jpg","tag":"仙侠 | 不抽烟的烟民"}]
     */

    private String start;
    private int limit;
    private List<SearchNovelModel> data;

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public List<SearchNovelModel> getData() {
        return data;
    }

    public void setData(List<SearchNovelModel> data) {
        this.data = data;
    }
}
