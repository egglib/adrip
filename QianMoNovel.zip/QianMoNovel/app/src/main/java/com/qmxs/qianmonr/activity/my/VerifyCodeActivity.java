package com.qmxs.qianmonr.activity.my;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: VerifyCodeActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 10:11 PM
 */
public class VerifyCodeActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_verify_code;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.verify_code);
    }
}
