package  com.qmxs.qianmonr.widget.scrollview;

import android.widget.ScrollView;

/*
 * File: ScrollListener.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/23 6:50 PM
 */
public interface ScrollListener {
    void onScrollChanged(ScrollView scrollView, int scrollX, int scrollY, int oldScrollX, int oldScrollY);
}
