package  com.qmxs.qianmonr.widget.scrollview;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.NestedScrollView;
import android.util.AttributeSet;

/*
 * File: CommonNestedScrollView.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/23 7:30 PM
 */
public class CommonNestedScrollView extends NestedScrollView {

    private NestedScrollListener scrollListener;

    public CommonNestedScrollView(@NonNull Context context) {
        super(context);
    }

    public CommonNestedScrollView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CommonNestedScrollView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setNestedScrollListener(NestedScrollListener scrollListener) {
        this.scrollListener = scrollListener;
    }

    @Override
    protected void onScrollChanged(int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
        super.onScrollChanged(scrollX, scrollY, oldScrollX, oldScrollY);
        if (scrollListener != null) {
            scrollListener.onScrollChanged(this, scrollX, scrollY, oldScrollX, oldScrollY);
        }
    }

}
