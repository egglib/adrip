package com.qmxs.qianmonr.adapter;
import android.content.Context;


/*
 * File: NovelCatalogAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 6:19 PM
 */
public class NovelCatalogAdapter extends BaseRecyclerViewAdapter {

    public NovelCatalogAdapter(Context context) {
        super(context);
    }
}
