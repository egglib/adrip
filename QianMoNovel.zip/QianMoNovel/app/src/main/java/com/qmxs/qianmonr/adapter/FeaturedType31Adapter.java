package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: FeaturedType31Adapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 5:04 PM
 */
public class FeaturedType31Adapter extends BaseRecyclerViewAdapter {

    public FeaturedType31Adapter(Context context) {
        super(context);
    }
}
