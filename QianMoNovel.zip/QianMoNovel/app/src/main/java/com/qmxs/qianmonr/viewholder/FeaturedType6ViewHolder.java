package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.FeaturedType61Adapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.FeaturedNovelModel;
import com.qmxs.qianmonr.model.NovelBreifModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: FeaturedType6ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 9:17 PM
 */
public class FeaturedType6ViewHolder extends BaseViewHolder {

    private NetworkImageView mMoreImg;
    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private static final int TYPE_ITEM_FEATURED_61 = 61;
    private FeaturedType61Adapter type61Adapter;

    public FeaturedType6ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mMoreImg = (NetworkImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext) {
            @Override
            public boolean canScrollHorizontally() {
                return false;
            }
        };
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.setFocusable(false);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.setFocusable(false);
        mRecyclerView.requestFocus();
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(0, 0, ScreenUtil.dp2px(10), 0));

        if (mRecyclerView.getAdapter() == null) {
            type61Adapter = new FeaturedType61Adapter(mContext);
        }
        type61Adapter.register(TYPE_ITEM_FEATURED_61, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, NovelBriefIntroViewHolder.class));
        mRecyclerView.setAdapter(type61Adapter);
        type61Adapter.setOnItemClickListener((view, mObjectList, mPosition) -> {
            JumpUtil.forwordToNovelDetail(mContext, ((NovelBreifModel) mObjectList.get(mPosition)).getBookId());
        });
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        FeaturedNovelModel featruredModel = (FeaturedNovelModel) objectList.get(position);

        if (featruredModel != null) {
            String title = featruredModel.getTitle();
            String id = featruredModel.getTopicId();

            mMoreLayout.setOnClickListener(v -> {
                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(id)) {
                    JumpUtil.forwordToRecommendList(mContext, title, id);
                }
            });

            String imgUrl = featruredModel.getIcon();

            if (!TextUtils.isEmpty(imgUrl)) {
                mMoreImg.setImgUrl(imgUrl);
            }

            if (!TextUtils.isEmpty(title)) {
                mMoreTitleTv.setText(title);
            }

            List<NovelBreifModel> novelBreifModels = featruredModel.getData();

            for (int i = 0; i < novelBreifModels.size(); i++) {
                NovelBreifModel novelBreifModel = novelBreifModels.get(i);
                novelBreifModel.setRenderType(TYPE_ITEM_FEATURED_61);
            }

            type61Adapter.clearData();
            type61Adapter.addData(novelBreifModels);
        }
    }
}
