package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.FeaturedType61Adapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;

import java.util.ArrayList;
import java.util.List;

/*
 * File: FeaturedType6ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 9:17 PM
 */
public class FeaturedType6ViewHolder extends BaseViewHolder {

    private ImageView mMoreImg;
    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private static final int TYPE_ITEM_FEATURED_61 = 61;

    public FeaturedType6ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mMoreImg = (ImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.requestFocus();
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(0, 0, ScreenUtil.dp2px(10), 0));

        FeaturedType61Adapter type61Adapter = new FeaturedType61Adapter(mContext);

        type61Adapter.register(TYPE_ITEM_FEATURED_61, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, FeaturedType61ViewHolder.class));
        mRecyclerView.setAdapter(type61Adapter);

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();

        for (int i = 0; i < 15; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(TYPE_ITEM_FEATURED_61);
            renderTypeModels.add(renderTypeModel);
        }

        type61Adapter.addData(renderTypeModels);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
    }
}
