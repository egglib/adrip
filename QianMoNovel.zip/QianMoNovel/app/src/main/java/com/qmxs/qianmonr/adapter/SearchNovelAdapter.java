package com.qmxs.qianmonr.adapter;

import android.content.Context;

import com.qmxs.qianmonr.activity.main.SearchActivity;

/*
 * File: SearchNovelAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/15 9:54 PM
 */
public class SearchNovelAdapter extends BaseRecyclerViewAdapter{


    public SearchNovelAdapter(Context context) {
        super(context);
    }
}
