package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: SortInfoModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/13 12:09 PM
 */
public class SortInfoModel {

    /**
     * type : 1
     * list : [{"_id":1,"name":"玄幻","tag":"东方玄幻/斗气世界","icon":"http://img.uzhiya.com/img/38/2b3b7b9ad9e024bbd5501263e3dc78c0.png"},{"_id":2,"name":"奇幻","tag":"西方奇幻/异世大陆","icon":"http://img.uzhiya.com/img/126/dacbf0aea3207789ba5a1575f6d989c9.png"},{"_id":3,"name":"武侠","tag":"传统武侠/现代武侠","icon":"http://img.uzhiya.com/img/120/dde50373f7d5f2d27212287167266638.png"},{"_id":4,"name":"仙侠","tag":"奇异修真/古典仙侠","icon":"http://img.uzhiya.com/img/46/de7d2f41a1e2558081537a74ae6bc341.png"},{"_id":5,"name":"都市","tag":"都市激战/都市生活","icon":"http://img.uzhiya.com/img/74/0647b913a54eee5acbcd11f23ed6256f.png"},{"_id":6,"name":"校园","tag":"校园生活/校园修真","icon":"http://img.uzhiya.com/img/89/97748ea19ac52aaafd2dc9182281d808.png"},{"_id":7,"name":"历史","tag":"历史传记/架空历史","icon":"http://img.uzhiya.com/img/39/8b034ede4609e75a71c7ebe34bb695c5.jpg"},{"_id":8,"name":"军事","tag":"现代军事/军旅生涯","icon":"http://img.uzhiya.com/img/2/2635dabaacde759935910df5af5f4a29.png"},{"_id":9,"name":"游戏","tag":"虚拟网游/肥仔宅男","icon":"http://img.uzhiya.com/img/116/3bfb5a756d5840173a343197a669cc6d.png"},{"_id":10,"name":"竞技","tag":"足球天下/篮球风云","icon":"http://img.uzhiya.com/img/127/7a909665518abf1bd896b1d99a648705.jpg"},{"_id":11,"name":"科幻","tag":"未来世界/时空穿梭","icon":"http://img.uzhiya.com/img/122/6d40fcab3928866b88a0ebecd10a4519.jpg"},{"_id":112,"name":"东方怪谈","tag":"","icon":"http://img.uzhiya.com/img/108/5d5275bf34839bb1fb3b7f905a5bea2d.jpg"}]
     */

    private int type;

    private List<SortModel> list;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public List<SortModel> getList() {
        return list;
    }

    public void setList(List<SortModel> list) {
        this.list = list;
    }
}
