package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.BookshelfNovelModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: BookshelfNovelViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 5:17 PM
 */
public class BookshelfNovelViewHolder extends BaseViewHolder {
    private TextView mNovelNameTv;
    private NetworkImageView mCoverImg;
    private BookshelfNovelModel bookshelfNovelModel;

    public BookshelfNovelViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mNovelNameTv = (TextView) itemView.findViewById(R.id.tv_novel_name);
        mCoverImg = (NetworkImageView) itemView.findViewById(R.id.img_cover);

        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(80)) / 3;
        int height = width * 3 / 2;
        mCoverImg.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        itemView.setOnClickListener(v -> {
            JumpUtil.forwordToNovelDetail(mContext,bookshelfNovelModel.getBookId());
        });
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        bookshelfNovelModel = (BookshelfNovelModel) objectList.get(position);

        if (bookshelfNovelModel != null) {
            String url = bookshelfNovelModel.getImg();
            if (!TextUtils.isEmpty(url)) {
                mCoverImg.setImgUrl(url);
            }

            String title = bookshelfNovelModel.getTitle();
            if (!TextUtils.isEmpty(title)) {
                mNovelNameTv.setText(title);
            }
        }

    }
}
