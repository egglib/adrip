package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.util.ScreenUtil;

/*
 * File: BookshelfNovelViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 5:17 PM
 */
public class BookshelfNovelViewHolder extends BaseViewHolder {
    private TextView mNovelNameTv;
    private ImageView mCoverImg;

    public BookshelfNovelViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mNovelNameTv = (TextView) itemView.findViewById(R.id.tv_novel_name);
        mCoverImg = (ImageView) itemView.findViewById(R.id.img_cover);

        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(80)) / 3;
        int height = width * 3 / 2;
        mCoverImg.setLayoutParams(new LinearLayout.LayoutParams(width, height));
    }
}
