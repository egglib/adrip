package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.ReadHistoryAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.ReadHistoryModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.DateUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;


/*
 * File: ReadHistoryViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 10:12 AM
 */
public class ReadHistoryViewHolder extends BaseViewHolder implements View.OnClickListener {

    private NetworkImageView mCoverImg;
    private TextView mNameTv;
    private TextView mReadTimeTv;
    private ImageView mJoinBookshelfStatusImg;
    private ImageView mDelImg;
    private ReadHistoryModel readHistoryModel;
    private ReadHistoryAdapter readHistoryAdapter;

    public ReadHistoryViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        readHistoryAdapter = (ReadHistoryAdapter) adapter;
        mCoverImg = (NetworkImageView) itemView.findViewById(R.id.img_cover);
        mNameTv = (TextView) itemView.findViewById(R.id.tv_name);
        mReadTimeTv = (TextView) itemView.findViewById(R.id.tv_read_time);
        mJoinBookshelfStatusImg = (ImageView) itemView.findViewById(R.id.img_join_bookshelf_status);
        mDelImg = (ImageView) itemView.findViewById(R.id.img_del);
        mJoinBookshelfStatusImg.setOnClickListener(this);
        mDelImg.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_join_bookshelf_status:
                joinBookshelf();
                break;

            case R.id.img_del:
                delHistory();
                break;
        }

    }

    private void joinBookshelf() {
        if (readHistoryModel.isIsShelf()) {
            delBookShelf();
        } else {
            addBookShelf();
        }
    }

    private void addBookShelf() {
        ApiManager.addBookshelf(mContext, readHistoryModel.getBookId(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                readHistoryModel.setIsShelf(true);
                readHistoryAdapter.notifyItemChanged(mPosition);
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    private void delBookShelf() {
        String id = String.valueOf(readHistoryModel.getBookId());
        ApiManager.bookshelfDelData(mContext, id, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                readHistoryModel.setIsShelf(false);
                readHistoryAdapter.notifyItemChanged(mPosition);
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    private void delHistory() {
        String id = String.valueOf(readHistoryModel.getBookId());
        ApiManager.delReadHistoryData(mContext, id, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                readHistoryAdapter.notifyItemRemoved(mPosition);
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        readHistoryModel = (ReadHistoryModel) objectList.get(position);

        if (readHistoryModel != null) {
            String url = readHistoryModel.getImg();

            if (!TextUtils.isEmpty(url)) {
                mCoverImg.setImgUrl(url);
            }

            String title = readHistoryModel.getTitle();

            if (!TextUtils.isEmpty(title)) {
                mNameTv.setText(title);
            }

            int time = readHistoryModel.getUpdated_time();

            String date = DateUtil.format10ToYMDLong(time);
            mReadTimeTv.setText(date + " 阅读过");

            if (readHistoryModel.isIsShelf()) {
                mJoinBookshelfStatusImg.setImageResource(R.mipmap.ic_joined_bookshelf);
            } else {
                mJoinBookshelfStatusImg.setImageResource(R.mipmap.ic_join_bookshelf);
            }
        }
    }


}
