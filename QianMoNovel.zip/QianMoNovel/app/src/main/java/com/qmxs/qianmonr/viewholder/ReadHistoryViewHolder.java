package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;

import java.util.List;


/*
 * File: ReadHistoryViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 10:12 AM
 */
public class ReadHistoryViewHolder extends BaseViewHolder {

    private TextView mNameTv;
    private TextView mReadTimeTv;
    private ImageView mJoinBookshelfStatusImg;

    public ReadHistoryViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mNameTv = (TextView) itemView.findViewById(R.id.tv_name);
        mReadTimeTv = (TextView) itemView.findViewById(R.id.tv_read_time);
        mJoinBookshelfStatusImg = (ImageView) itemView.findViewById(R.id.img_join_bookshelf_status);


    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        if (position % 2 == 0) {
            mJoinBookshelfStatusImg.setImageResource(R.mipmap.ic_join_bookshelf);
        } else {
            mJoinBookshelfStatusImg.setImageResource(R.mipmap.ic_joined_bookshelf);
        }
    }
}
