package com.qmxs.qianmonr.model;

import android.os.Parcel;
import android.os.Parcelable;

/*
 * File: PersonInfoModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 10:18 PM
 */
public class PersonInfoModel implements Parcelable {
    /**
     * aff : u8
     * invited_num : 1
     * score : 100
     * tgNum : https://hitik.me/lsbook
     * aff_url : http://a.lanshu.me?aff=u8
     * invited_page : http://a.lanshu.me/invited/?aff=u8
     * id : 27
     * phone :
     * invited_by : h
     * is_login : 0
     * nick : 游客
     * username :
     */

    private String aff;
    private int invited_num;
    private int score;
    private String tgNum;
    private String aff_url;
    private String invited_page;
    private int id;
    private String phone;
    private String invited_by;
    private int is_login;
    private String nick;
    private String username;

    protected PersonInfoModel(Parcel in) {
        aff = in.readString();
        invited_num = in.readInt();
        score = in.readInt();
        tgNum = in.readString();
        aff_url = in.readString();
        invited_page = in.readString();
        id = in.readInt();
        phone = in.readString();
        invited_by = in.readString();
        is_login = in.readInt();
        nick = in.readString();
        username = in.readString();
    }

    public static final Creator<PersonInfoModel> CREATOR = new Creator<PersonInfoModel>() {
        @Override
        public PersonInfoModel createFromParcel(Parcel in) {
            return new PersonInfoModel(in);
        }

        @Override
        public PersonInfoModel[] newArray(int size) {
            return new PersonInfoModel[size];
        }
    };

    public String getAff() {
        return aff;
    }

    public void setAff(String aff) {
        this.aff = aff;
    }

    public int getInvited_num() {
        return invited_num;
    }

    public void setInvited_num(int invited_num) {
        this.invited_num = invited_num;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getTgNum() {
        return tgNum;
    }

    public void setTgNum(String tgNum) {
        this.tgNum = tgNum;
    }

    public String getAff_url() {
        return aff_url;
    }

    public void setAff_url(String aff_url) {
        this.aff_url = aff_url;
    }

    public String getInvited_page() {
        return invited_page;
    }

    public void setInvited_page(String invited_page) {
        this.invited_page = invited_page;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getInvited_by() {
        return invited_by;
    }

    public void setInvited_by(String invited_by) {
        this.invited_by = invited_by;
    }

    public int getIs_login() {
        return is_login;
    }

    public void setIs_login(int is_login) {
        this.is_login = is_login;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(aff);
        dest.writeInt(invited_num);
        dest.writeInt(score);
        dest.writeString(tgNum);
        dest.writeString(aff_url);
        dest.writeString(invited_page);
        dest.writeInt(id);
        dest.writeString(phone);
        dest.writeString(invited_by);
        dest.writeInt(is_login);
        dest.writeString(nick);
        dest.writeString(username);
    }
}
