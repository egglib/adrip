package com.qmxs.qianmonr.activity;

import android.content.Intent;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.gyf.barlibrary.ImmersionBar;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.MayLikeRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.MayLikeViewHolder;

import java.util.ArrayList;
import java.util.List;

import jp.wasabeef.glide.transformations.BlurTransformation;

import static com.bumptech.glide.request.RequestOptions.bitmapTransform;

/*
 * File: NovelDetailIntroActivity.java
 * Description: 小说详情界面
 * Author: XiaoTao
 * Create at 2019/2/25 10:12 PM
 */
public class NovelDetailIntroActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private ImageView mBgHeaderImg;
    private TextView mNovelNameTv;
    private TextView mNovelSortTv;
    private TextView mWordCountTv;
    private TextView mAutherTv;
    private ImageView mNovelCoverImg;
    private TextView mFreeReadBtn;
    private TextView mAddInBookshelfBtn;
    private TextView mBookshelfNumTv;
    private TextView mDownloadNumTv;
    private TextView mReadNumTv;
    private TextView mBriefIntroTv;
    private TextView mCatalogTv;
    private LinearLayout mCatalogLayout;
    private RecyclerView mRecyclerView;
    private LinearLayout mMoreLayout;


    @Override
    protected int getLayoutResId() {
        return R.layout.activity_novel_detail_intro;
    }

    @Override
    protected int getTitleBackgroundColor() {
        return android.R.color.transparent;
    }

    @Override
    protected int getLayoutType() {
        return TYPE_LAYOUT_FRAME;
    }

    @Override
    protected void initView() {
        super.initView();
        ImmersionBar.with(this).reset().statusBarDarkFont(false).navigationBarColor(R.color.white).init();
        View view = createActionBarRightIcon(R.mipmap.ic_download);
        view.setOnClickListener(v -> {
            Toast.makeText(NovelDetailIntroActivity.this, "开始下载", Toast.LENGTH_SHORT).show();
        });
        mBgHeaderImg = findViewById(R.id.img_bg_header);
        Glide.with(this).load(R.mipmap.ic_cover_test).apply(bitmapTransform(
                new BlurTransformation(20, 3))).into(mBgHeaderImg);

        mNovelNameTv = (TextView) findViewById(R.id.tv_novel_name);
        mNovelSortTv = (TextView) findViewById(R.id.tv_novel_sort);
        mWordCountTv = (TextView) findViewById(R.id.tv_word_count);
        mAutherTv = (TextView) findViewById(R.id.tv_auther);
        mNovelCoverImg = (ImageView) findViewById(R.id.img_novel_cover);
        mFreeReadBtn = (TextView) findViewById(R.id.btn_free_read);
        mFreeReadBtn.setOnClickListener(this);
        mAddInBookshelfBtn = (TextView) findViewById(R.id.btn_add_in_bookshelf);
        mAddInBookshelfBtn.setOnClickListener(this);
        mBookshelfNumTv = (TextView) findViewById(R.id.tv_bookshelf_num);
        mDownloadNumTv = (TextView) findViewById(R.id.tv_download_num);
        mReadNumTv = (TextView) findViewById(R.id.tv_read_num);
        mBriefIntroTv = (TextView) findViewById(R.id.tv_brief_intro);
        mCatalogTv = (TextView) findViewById(R.id.tv_catalog);
        mCatalogLayout = (LinearLayout) findViewById(R.id.layout_catalog);
        mCatalogLayout.setOnClickListener(this);

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(15), ScreenUtil.dp2px(15), ScreenUtil.dp2px(0), ScreenUtil.dp2px(15)));
        MayLikeRecyclerViewAdapter adapter = new MayLikeRecyclerViewAdapter(this);
        adapter.register(1, new ItemViewHolderContainer(R.layout.common_item_imgview_textview, MayLikeViewHolder.class));
        mRecyclerView.setAdapter(adapter);

        List<RenderTypeModel> objects = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            objects.add(renderTypeModel);
        }
        adapter.addData(objects);

        mMoreLayout = findViewById(R.id.layout_more);
        mMoreLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_free_read:

                break;
            case R.id.btn_add_in_bookshelf:

                break;
            case R.id.layout_catalog:
                startActivity(new Intent(this, NovelCatalogActivity.class));
                break;
            case R.id.layout_more:
                break;
            default:
                break;
        }
    }
}
