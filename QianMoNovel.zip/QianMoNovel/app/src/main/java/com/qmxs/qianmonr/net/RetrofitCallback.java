package com.qmxs.qianmonr.net;

/*
 * File: RetrofitCallback.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/5 3:47 PM
 */
public interface RetrofitCallback {

    void onSuccess(String response);

    void onError(Throwable e);

    void onComplete();
}
