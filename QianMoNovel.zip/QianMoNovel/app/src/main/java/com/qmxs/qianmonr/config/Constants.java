package com.qmxs.qianmonr.config;

/*
 * File: Constants.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/6 12:19 PM
 */
public class Constants {

    public static String APP_KEY = "fUEiFMvyzrizttZF5wjyGKHyUZHJGeD8";//数据签名key

    public static String ENCRYPT_KEY = "1UIuDpxrbP7NuE4vyEh1e2d3lHx50itS";//数据加密key

}
