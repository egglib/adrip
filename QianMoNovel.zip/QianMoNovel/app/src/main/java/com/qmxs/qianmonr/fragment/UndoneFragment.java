package com.qmxs.qianmonr.fragment;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.DownloadManagementAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.GridSpacingItemDecoration;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.viewholder.DownloadManagementViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;

import java.util.ArrayList;
import java.util.List;

/*
 * File: UndoneFragment.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 11:41 AM
 */
public class UndoneFragment extends BaseLazyFragment implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;


    @Override
    protected void onLazyLoad() {
    }

    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_swiperefreshlayout_recyclerview;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefreshLayout);

        mSwipeRefreshLayout.setColorSchemeColors(getContext().getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);

        DownloadManagementAdapter adapter = new DownloadManagementAdapter(getContext());
        adapter.register(1, new ItemViewHolderContainer(R.layout.item_download_management_undone, DownloadManagementViewHolder.class));

        List<RenderTypeModel> objects = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            objects.add(renderTypeModel);
        }
        adapter.addData(objects);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 3);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(3, ScreenUtil.dp2px(20), true, true, true));

    }

    @Override
    public void onRefresh() {

    }
}
