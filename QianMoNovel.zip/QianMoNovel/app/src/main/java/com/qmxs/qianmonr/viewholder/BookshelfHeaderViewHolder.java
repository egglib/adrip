package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.BookshelfHeaderInfoModel;
import com.qmxs.qianmonr.model.BookshelfHeaderNovelModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.DateUtil;
import com.qmxs.qianmonr.util.JumpUtil;

import java.util.List;


/*
 * File: BookshelfHeaderViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 5:08 PM
 */
public class BookshelfHeaderViewHolder extends BaseViewHolder {

    private TextView mDayTv;
    private TextView mMonthTv;
    private TextView mTopicTv;
    private TextView mAuthorTv;
    private CardView mHeaderCard;
    private BookshelfHeaderNovelModel bookshelfHeaderNovelModel;

    public BookshelfHeaderViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mDayTv = (TextView) itemView.findViewById(R.id.tv_day);
        mMonthTv = (TextView) itemView.findViewById(R.id.tv_month);
        mTopicTv = (TextView) itemView.findViewById(R.id.tv_topic);
        mAuthorTv = (TextView) itemView.findViewById(R.id.tv_author);
        mHeaderCard = (CardView) itemView.findViewById(R.id.card_header);
        mHeaderCard.setOnClickListener(v -> {
            if (bookshelfHeaderNovelModel != null)
                JumpUtil.forwordToNovelDetail(mContext, bookshelfHeaderNovelModel.getBookId());
        });

        mDayTv.setText(DateUtil.getCurDay());
        String month = DateUtil.getCurMonth();
        int monthInt = Integer.parseInt(month);
        mMonthTv.setText(monthInt + "月");
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        BookshelfHeaderInfoModel bookshelfHeaderInfoModel = (BookshelfHeaderInfoModel) objectList.get(position);
        if (bookshelfHeaderInfoModel != null && bookshelfHeaderInfoModel.getData() != null
                && !bookshelfHeaderInfoModel.getData().isEmpty()
                && bookshelfHeaderInfoModel.getData().get(0) != null) {

            bookshelfHeaderNovelModel = bookshelfHeaderInfoModel.getData().get(0);

            String topic = bookshelfHeaderNovelModel.getTopic_intro();

            if (!TextUtils.isEmpty(topic)) {
                mTopicTv.setText(topic);
            }

            String author = bookshelfHeaderNovelModel.getAuthor();
            if (!TextUtils.isEmpty(author)) {
                mAuthorTv.setText("—— " + author);
            }
        }
    }
}
