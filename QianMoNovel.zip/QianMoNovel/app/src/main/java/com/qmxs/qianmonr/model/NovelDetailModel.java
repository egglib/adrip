package com.qmxs.qianmonr.model;

import com.qmxs.qianmonr.widget.bookview.bean.NovelInfoModel;

import java.util.List;

/*
 * File: NovelDetailModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 10:56 PM
 */
public class NovelDetailModel {

    /**
     * guess : [{"title":"最强装逼打脸系统","author":"太上布衣","attach_name":"http://book.wankouzi.com/book/3187/BE03D02722D21B31B9EEDEF0E7975A02/BE03D02722D21B31B9EEDEF0E7975A02.jpg","bookId":13073},{"title":"凡人修仙之仙界篇","author":"忘语","attach_name":"http://book.wankouzi.com/book/1663/855CE8A5DB1ACA993C3E125F3A0B0E55/855CE8A5DB1ACA993C3E125F3A0B0E55.jpg","bookId":624448},{"title":"异世邪君","author":"风凌天下","attach_name":"http://book.wankouzi.com/book/3445/9A7183C955AE210545B2CEA9B99C45D6/9A7183C955AE210545B2CEA9B99C45D6.jpg","bookId":621520},{"title":"飞剑问道","author":"我吃西红柿","attach_name":"http://book.wankouzi.com/book/829/985B0624DF0F54B2D015F02CB8D06A8F/985B0624DF0F54B2D015F02CB8D06A8F.jpg","bookId":618076},{"title":"最强反套路系统","author":"太上布衣","attach_name":"http://book.wankouzi.com/book/2021/C081C20FA7E5E3DD2B209CBE5217CFAB/C081C20FA7E5E3DD2B209CBE5217CFAB.jpg","bookId":626097},{"title":"凡人修仙传","author":"忘语","attach_name":"http://book.wankouzi.com/book/49/7a38dc98b08e54e4d62b2f9d541dc918.jpg","bookId":302316}]
     * info : {"id":60021,"bookId":16499,"title":"怎么又是天谴圈","cover":"/2921/C418B0F90ED0DC220AFAB7A5D80C4AB9/C418B0F90ED0DC220AFAB7A5D80C4AB9.jpg","author":"诸葛婉君","intro":"偶得吐槽系统，一个被绝地求生诅咒的男人。落地自带天谴圈，洗头全靠轰炸区，资源只有十字弩，载具从来一格油。轰炸如风，常伴吾身。长路漫漫，唯毒相伴。什么？落地98k，枪枪都爆头？我怂还不行嘛！什么？落地天命圈，开枪落空投？我怂还不行嘛！什么，你说这么惨这么怂都忍不住要吐槽？这就对了！\u201c叮，吐槽值+1，系统已激活！\u201d\r\n","chapterCnt":932,"loveCnt":91,"wordCnt":"232.65万字","score":0,"fullFlag":"连载","readCnt":17290,"downCnt":10,"postDate":0,"retention":4949,"status":1,"created_at":1548417505,"lastUpdate":1541437662,"updated_at":1548417505,"deleted":0,"list_id":66901,"clsId":4,"clsName":"仙侠","is_rec":0,"cover_id":0,"strLastCharpterTime":"","pid":1,"attach_name":"http://book.wankouzi.com/book/2921/C418B0F90ED0DC220AFAB7A5D80C4AB9/C418B0F90ED0DC220AFAB7A5D80C4AB9.jpg","tag":"仙侠 | 诸葛婉君","isShelf":false}
     * isShelf : false
     * aff_url : http://a.lanshu.me?aff=u8
     * chapterId : 1820997
     */

    private NovelInfoModel info;
    private boolean isShelf;
    private String aff_url;
    private int chapterId;
    private List<GuessModel> guess;

    public NovelInfoModel getNovelInfo() {
        return info;
    }

    public void setNovelInfo(NovelInfoModel novelInfo) {
        this.info = novelInfo;
    }

    public boolean isShelf() {
        return isShelf;
    }

    public void setShelf(boolean shelf) {
        isShelf = shelf;
    }

    public String getAff_url() {
        return aff_url;
    }

    public void setAff_url(String aff_url) {
        this.aff_url = aff_url;
    }

    public int getChapterId() {
        return chapterId;
    }

    public void setChapterId(int chapterId) {
        this.chapterId = chapterId;
    }

    public List<GuessModel> getGuess() {
        return guess;
    }

    public void setGuess(List<GuessModel> guess) {
        this.guess = guess;
    }

    public class GuessModel extends RenderTypeModel {
        /**
         * title : 最强装逼打脸系统
         * author : 太上布衣
         * attach_name : http://book.wankouzi.com/book/3187/BE03D02722D21B31B9EEDEF0E7975A02/BE03D02722D21B31B9EEDEF0E7975A02.jpg
         * bookId : 13073
         */

        private String title;
        private String author;
        private String attach_name;
        private int bookId;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public String getAttach_name() {
            return attach_name;
        }

        public void setAttach_name(String attach_name) {
            this.attach_name = attach_name;
        }

        public int getBookId() {
            return bookId;
        }

        public void setBookId(int bookId) {
            this.bookId = bookId;
        }
    }
}
