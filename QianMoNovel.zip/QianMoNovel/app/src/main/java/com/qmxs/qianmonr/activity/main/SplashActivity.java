package com.qmxs.qianmonr.activity.main;

import android.content.Intent;
import android.os.Handler;
import android.view.View;

import com.gyf.barlibrary.BarHide;
import com.gyf.barlibrary.ImmersionBar;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseActivity;
import com.qmxs.qianmonr.util.PageJumpUtil;

/*
 * File: SplashActivity.java
 * Description: 闪屏界面
 * Author: XiaoTao
 * Create at 2019/2/19 9:53 AM
 */
public class SplashActivity extends BaseActivity {

    @Override
    protected int setContentViewId() {
        return R.layout.activity_splash;
    }


    @Override
    protected void initView() {
        Handler handler = new Handler();
        SplashRunnable splashRunnable = new SplashRunnable();
        ImmersionBar.with(this).reset().hideBar(BarHide.FLAG_HIDE_BAR).init();
        handler.postDelayed(splashRunnable, 3000);
    }


    public void skip(View view) {
        startActivity(new Intent(this, MainActivity.class));
        this.finish();
    }

    private class SplashRunnable implements Runnable {
        @Override
        public void run() {
            PageJumpUtil.forwordToPage(SplashActivity.this, MainActivity.class);
            SplashActivity.this.finish();
        }
    }
}
