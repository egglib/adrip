package com.qmxs.qianmonr.widget.bookview;

/*
 * File: PageMode.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/8 10:13 PM
 */
public enum PageMode {
    SIMULATION, COVER, SLIDE, NONE, SCROLL
}
