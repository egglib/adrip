package com.qmxs.qianmonr.activity.my;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: FeedbackRecordActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 10:29 AM
 */
public class FeedbackRecordActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_feedback_record;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.feedback_record);
    }
}
