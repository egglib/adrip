package com.qmxs.qianmonr.model;

/*
 * File: ReadHistoryModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 6:00 PM
 */
public class ReadHistoryModel extends RenderTypeModel {


    /**
     * id : 60556
     * bookId : 17488
     * title : 重生之神帝归来
     * cover : /2636/7BE6A6AB810792AD705C6066B71FEAA3/7BE6A6AB810792AD705C6066B71FEAA3.jpg
     * author : 马甲千万
     * intro : 神帝归来，傲绝都市！那一年，陈潇高考失利，女友分手，父母更是遭遇车祸，双双身亡。绝望之中他跃下山崖，试图了结一生，不想却穿越到了一个神奇宏大的武道世界！三千年后，陈潇已是镇压当世、横扫无敌的绝世大帝，但他却舍毅然舍弃万劫不灭的元始之躯，带着三千年的记忆重回少年时代！这一世，他只求红尘佳人，无愧于心！
     * chapterCnt : 1737
     * loveCnt : 3209
     * wordCnt : 4512780
     * score : 0
     * fullFlag : 连载
     * readCnt : 1065230
     * downCnt : 522
     * postDate : 0
     * retention : 5360
     * status : 2
     * created_at : 1548417533
     * lastUpdate : 1541442275
     * updated_at : 1551916800
     * deleted : 0
     * list_id : 67436
     * clsId : 1
     * clsName : 玄幻
     * is_rec : 0
     * cover_id : 0
     * strLastCharpterTime :
     * img : http://book.wankouzi.com/book/2636/7BE6A6AB810792AD705C6066B71FEAA3/7BE6A6AB810792AD705C6066B71FEAA3.jpg
     * attach_name : http://book.wankouzi.com/book/2636/7BE6A6AB810792AD705C6066B71FEAA3/7BE6A6AB810792AD705C6066B71FEAA3.jpg
     * realChapterNum : 1737
     * tag : 玄幻 | 马甲千万
     * lastChapter : 第1739章 巫咒大帝的赌约
     * isShelf : false
     * updated_time : 1551929546
     */

    private int id;
    private int bookId;
    private String title;
    private String cover;
    private String author;
    private String intro;
    private int chapterCnt;
    private int loveCnt;
    private int wordCnt;
    private int score;
    private String fullFlag;
    private int readCnt;
    private int downCnt;
    private int postDate;
    private int retention;
    private int status;
    private int created_at;
    private int lastUpdate;
    private int updated_at;
    private int deleted;
    private int list_id;
    private int clsId;
    private String clsName;
    private int is_rec;
    private int cover_id;
    private String strLastCharpterTime;
    private String img;
    private String attach_name;
    private int realChapterNum;
    private String tag;
    private String lastChapter;
    private boolean isShelf;
    private int updated_time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public int getChapterCnt() {
        return chapterCnt;
    }

    public void setChapterCnt(int chapterCnt) {
        this.chapterCnt = chapterCnt;
    }

    public int getLoveCnt() {
        return loveCnt;
    }

    public void setLoveCnt(int loveCnt) {
        this.loveCnt = loveCnt;
    }

    public int getWordCnt() {
        return wordCnt;
    }

    public void setWordCnt(int wordCnt) {
        this.wordCnt = wordCnt;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getFullFlag() {
        return fullFlag;
    }

    public void setFullFlag(String fullFlag) {
        this.fullFlag = fullFlag;
    }

    public int getReadCnt() {
        return readCnt;
    }

    public void setReadCnt(int readCnt) {
        this.readCnt = readCnt;
    }

    public int getDownCnt() {
        return downCnt;
    }

    public void setDownCnt(int downCnt) {
        this.downCnt = downCnt;
    }

    public int getPostDate() {
        return postDate;
    }

    public void setPostDate(int postDate) {
        this.postDate = postDate;
    }

    public int getRetention() {
        return retention;
    }

    public void setRetention(int retention) {
        this.retention = retention;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(int lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public int getList_id() {
        return list_id;
    }

    public void setList_id(int list_id) {
        this.list_id = list_id;
    }

    public int getClsId() {
        return clsId;
    }

    public void setClsId(int clsId) {
        this.clsId = clsId;
    }

    public String getClsName() {
        return clsName;
    }

    public void setClsName(String clsName) {
        this.clsName = clsName;
    }

    public int getIs_rec() {
        return is_rec;
    }

    public void setIs_rec(int is_rec) {
        this.is_rec = is_rec;
    }

    public int getCover_id() {
        return cover_id;
    }

    public void setCover_id(int cover_id) {
        this.cover_id = cover_id;
    }

    public String getStrLastCharpterTime() {
        return strLastCharpterTime;
    }

    public void setStrLastCharpterTime(String strLastCharpterTime) {
        this.strLastCharpterTime = strLastCharpterTime;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getAttach_name() {
        return attach_name;
    }

    public void setAttach_name(String attach_name) {
        this.attach_name = attach_name;
    }

    public int getRealChapterNum() {
        return realChapterNum;
    }

    public void setRealChapterNum(int realChapterNum) {
        this.realChapterNum = realChapterNum;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getLastChapter() {
        return lastChapter;
    }

    public void setLastChapter(String lastChapter) {
        this.lastChapter = lastChapter;
    }

    public boolean isIsShelf() {
        return isShelf;
    }

    public void setIsShelf(boolean isShelf) {
        this.isShelf = isShelf;
    }

    public int getUpdated_time() {
        return updated_time;
    }

    public void setUpdated_time(int updated_time) {
        this.updated_time = updated_time;
    }
}
