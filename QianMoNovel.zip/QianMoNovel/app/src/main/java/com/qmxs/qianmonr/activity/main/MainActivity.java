package com.qmxs.qianmonr.activity.main;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gyf.barlibrary.ImmersionBar;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.CommonPagerAdapter;
import com.qmxs.qianmonr.base.BaseActivity;
import com.qmxs.qianmonr.fragment.BookshelfFragment;
import com.qmxs.qianmonr.fragment.MyFragment;
import com.qmxs.qianmonr.fragment.featured.FeaturedFragment;
import com.qmxs.qianmonr.fragment.sort.SortFragment;
import com.qmxs.qianmonr.widget.CustomViewPager;

import java.util.ArrayList;
import java.util.List;

/*
 * File: MainActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/19 11:35 AM
 */
public class MainActivity extends BaseActivity {

    private CustomViewPager mViewPager;
    private TabLayout mTabLayout;

    private int[] mTabTitles = new int[]{
            R.string.bookshelf,
            R.string.featured,
            R.string.sort,
            R.string.my};

    private int[] mTabIcons = new int[]{
            R.drawable.ic_bookshelf_selector,
            R.drawable.ic_featured_selector,
            R.drawable.ic_sort_selector,
            R.drawable.ic_my_selector
    };

    @Override
    protected int setContentViewId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView() {
        mViewPager = findViewById(R.id.viewPager);
        mViewPager.setCanScroll(true);
        mTabLayout = findViewById(R.id.tabLayout);
    }

    @Override
    protected void pageHandle() {
        addFragments();
    }

    private void addFragments() {
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(new BookshelfFragment());
        fragments.add(new FeaturedFragment());
        fragments.add(new SortFragment());
        fragments.add(new MyFragment());
        CommonPagerAdapter commonPagerAdapter = new CommonPagerAdapter(getSupportFragmentManager(), fragments);
        mViewPager.setAdapter(commonPagerAdapter);
        mViewPager.setCanScroll(false);
        mTabLayout.setupWithViewPager(mViewPager);
        setupTabIcons();
        addImmersionBar();
    }

    private void addImmersionBar() {
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                ImmersionBar.with(MainActivity.this).reset().statusBarColorTransformEnable(true)
                        .keyboardEnable(false)
                        .navigationBarColor(R.color.white)
                        .statusBarDarkFont(true, 0.2f)
                        .init();
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    protected void setupTabIcons() {
        try {
            for (int i = 0; i < mTabTitles.length; i++) {
                mTabLayout.getTabAt(i).setCustomView(getTabView(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private View getTabView(int position) {
        View view = LayoutInflater.from(this).inflate(R.layout.main_tab_item, null);

        ImageView img_tab = view.findViewById(R.id.img_tab_item);
        img_tab.setImageResource(mTabIcons[position]);

        TextView tv_tab = view.findViewById(R.id.tv_tab_item);
        tv_tab.setText(getResources().getString(mTabTitles[position]));

        return view;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exit();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private long exitTime = 0;

    public void exit() {
        if ((System.currentTimeMillis() - exitTime) > 2000) {
            Toast.makeText(this, "再按一次退出程序",
                    Toast.LENGTH_SHORT).show();
            exitTime = System.currentTimeMillis();
        } else {
            finish();
            System.exit(0);
        }
    }
}
