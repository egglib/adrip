package com.qmxs.qianmonr.model;

/*
 * File: SearchHistoryModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/15 10:40 PM
 */
public class SearchHistoryModel extends RenderTypeModel {


    /**
     * keywords : 斗破苍穹
     * type : 3
     */

    private String keywords;
    private int type;

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
