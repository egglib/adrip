package com.qmxs.qianmonr.fragment.sort;


import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.SearchActivity;
import com.qmxs.qianmonr.adapter.CommonPagerAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.config.Global;
import com.qmxs.qianmonr.widget.CustomViewPager;

import java.util.ArrayList;
import java.util.List;

/*
 * File: SortFragment.java
 * Description: 分类界面
 * Author: XiaoTao
 * Create at 2019/2/19 4:02 PM
 */
public class SortFragment extends BaseLazyFragment {

    private View mTopView;
    private TabLayout mTabLayout;
    private ImageView mImgSearch;
    private CustomViewPager mViewPager;
    private int[] mTabTitles = new int[]{R.string.boy, R.string.girl};
    public LinearLayout mTitleLayout;

    @Override
    protected int setLayoutResId() {
        return R.layout.sort_layout_tablayout_viewpager_search;
    }

    @Override
    protected void initView(View view) {
        mTopView = view.findViewById(R.id.topView);
        mTopView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Global.STUTAS_BAR_HEIGHT));
        mTabLayout = view.findViewById(R.id.tabLayout);
        mImgSearch = view.findViewById(R.id.imgSearch);
        mViewPager = view.findViewById(R.id.viewPager);
        mTitleLayout = view.findViewById(R.id.titleLayout);
        addFragments();
    }

    @Override
    protected void onLazyLoad() {

    }

    @Override
    protected void pageHandle() {
        mImgSearch.setOnClickListener(v -> startActivity(new Intent(getContext(), SearchActivity.class)));
    }

    private void addFragments() {
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(new SBoyFragment());
        fragments.add(new SGirlFragment());
        CommonPagerAdapter commonPagerAdapter = new CommonPagerAdapter(getChildFragmentManager(), fragments);
        mViewPager.setAdapter(commonPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        setupTabIcons();
    }

    protected void setupTabIcons() {
        try {
            for (int i = 0; i < mTabTitles.length; i++) {
                mTabLayout.getTabAt(i).setCustomView(getTabView(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private View getTabView(int position) {
        View view = getLayoutInflater().inflate(R.layout.featured_sort_tab_item_text, null);
        TextView tv_tab = view.findViewById(R.id.tv_tab_item);
        tv_tab.setText(getResources().getString(mTabTitles[position]));

        if (position == 0) {
            tv_tab.setBackgroundResource(R.drawable.boy_item_bg_selector);
        } else {
            tv_tab.setBackgroundResource(R.drawable.red_item_bg_selector);
        }

        return view;
    }
}
