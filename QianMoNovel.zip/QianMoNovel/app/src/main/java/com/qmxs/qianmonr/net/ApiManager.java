package com.qmxs.qianmonr.net;

import android.content.Context;

import org.json.JSONObject;

/*
 * File: ApiManager.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/5 4:25 PM
 */
public class ApiManager {

    private static final String KEY_METHOD = "method";

    private static final String KEY_VER = "ver";

    private static final String VERSION_1_1 = "1.1";

    private static final String KEY_CODE = "code";

    /**
     * 获取分类数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getSortData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "category");
            jsonObject.put(KEY_VER, VERSION_1_1);//接口版本号
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取分类列表数据
     *
     * @param context
     * @param retrofitCallback code list
     */
    public static void getSortListData(Context context, int id, int start, String code, String listType, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("_id", id);
            jsonObject.put("start", start);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("listType", "hot");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取小说信息
     *
     * @param context
     * @param bookId
     * @param retrofitCallback
     */
    public static void getNovelInfoData(Context context, long bookId, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "info");
            jsonObject.put("bookId", bookId);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取章节数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getChapterData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("bookId", 20339);
            jsonObject.put(KEY_CODE, "chapter");
            jsonObject.put("start", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取章节内容
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getChapterContentData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "content");
            jsonObject.put("chapterId", 5125751);
            jsonObject.put("bookId", 624963);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取推荐数据
     * channel 1 精选  2 男生  3 女生
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRecommendData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "info");
            jsonObject.put("channel", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取推荐列表
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRecommendListData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("topId", "channelId_1");
            jsonObject.put("start", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取banner数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getAdBannerData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "ad");
            jsonObject.put("site", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取搜索列表数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getSearchListData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "search");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("keyword", "武动乾坤");
            jsonObject.put("type", 3);
            jsonObject.put("start", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取搜索标签数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getSearchTagData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "search");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "getSearchData");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取搜索历史数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getSearchHistory(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "search");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "history");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取排行榜数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRankData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "rank");
            jsonObject.put(KEY_VER, VERSION_1_1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取排行榜列表界面
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRankListData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "rank");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("type", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取作家作品数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getAuthorWorksListData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "author");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("id", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 加入书架
     *
     * @param context
     * @param retrofitCallback
     */
    public static void addBookshelf(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "shelf");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "add");
            jsonObject.put("bookId", 400828);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取书架列表
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getBookshelfListData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "shelf");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "list");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除书架上的书籍
     * 批量删除用,分割
     *
     * @param context
     * @param retrofitCallback
     */
    public static void bookshelfDelData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "shelf");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "del");
            jsonObject.put("bookId", "400828");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 提交反馈数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void submitFeedbackData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "feed");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("content", "hahahaha");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取公告数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getNoticeData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("start", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 公告消息已读
     *
     * @param context
     * @param retrofitCallback bid 消息id
     */
    public static void readNoticeData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "read");
            jsonObject.put("bid", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除公告消息
     *
     * @param context
     * @param retrofitCallback
     */
    public static void delNoticeData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "del");
            jsonObject.put("bid", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 阅读历史数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getReadHistoryListData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "readH");
            jsonObject.put("start", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param context
     * @param retrofitCallback
     */
    public static void delReadHistoryData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "delhistorys");
            jsonObject.put("bookIds", "10120");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取个人信息
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getPersonInfoData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "userInfo");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取邀请信息
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getInviteData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "invited");
            jsonObject.put("aff", "h");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取验证码
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getVerifyCode(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "sms");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "send");
            jsonObject.put("mobile", "13643836633");
            jsonObject.put("type", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 验证验证码
     *
     * @param context
     * @param retrofitCallback
     */
    public static void verifyCode(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "sms");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "val");
            jsonObject.put("mobile", "13643836693");
            jsonObject.put("type", 1);
            jsonObject.put("v", "242379");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取排行榜榜首
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getLeaderboardTop(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "rank");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "first");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取文学数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getLiteratureData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "letter");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 推荐自定义
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRecommendCustomData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "custom");
            jsonObject.put("name", "shelf");
            jsonObject.put("start", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 探测线路
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRrobeLineData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "AreaCheck");
            jsonObject.put(KEY_VER, VERSION_1_1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 判断手机号是否存在
     *
     * @param context
     * @param retrofitCallback
     */
    public static void isPhoneNumExist(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 8);
            jsonObject.put("mobile", "13643836555");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 切换账号
     *
     * @param context
     * @param retrofitCallback
     */
    public static void switchAccount(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 7);
            jsonObject.put("new_uuid", "c09ba05fb4a00f50afb3aa0757307438");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 书籍下载章节列表
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getNovelChapterDownloadList(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "downList");
            jsonObject.put("bookId", 20339);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取完结或是日更列表数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getEndDailyUpdateListData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "booklist");
            jsonObject.put("type", 2);
            jsonObject.put("gender", 1);
            jsonObject.put("start", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 注册
     *
     * @param context
     * @param retrofitCallback
     */
    public static void register(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 1);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("anthCode", "1234124");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void changePhoneNumber(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 2);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("anthCode", "1234124");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void login(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 3);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void changePassword(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 4);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("password", "1234556");
            jsonObject.put("newPassword", "123123");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void retrievePassword(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 5);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("anthCode", "1234124");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 注销登录
     *
     * @param context
     * @param retrofitCallback
     */
    public static void logout(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 6);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
