package com.qmxs.qianmonr.net;

import android.content.Context;

import org.json.JSONObject;

/*
 * File: ApiManager.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/5 4:25 PM
 */
public class ApiManager {

    private static final String KEY_METHOD = "method";

    private static final String KEY_VER = "ver";

    private static final String VERSION_1_1 = "1.1";

    private static final String KEY_CODE = "code";

    /**
     * 获取分类数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getSortData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "category");
            jsonObject.put(KEY_VER, VERSION_1_1);//接口版本号
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取分类列表数据
     *
     * @param context
     * @param retrofitCallback code list
     */
    public static void getSortHotListData(Context context, int id, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("_id", id);
            jsonObject.put("start", start);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("listType", "hot");
            RequestHelper.getNetworkRequest(context, "分类数据加载中...", jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param context
     * @param id
     * @param start
     * @param retrofitCallback
     */
    public static void getSortUpdateListData(Context context, int id, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("_id", id);
            jsonObject.put("start", start);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("listType", "update");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取小说信息
     *
     * @param context
     * @param bookId
     * @param retrofitCallback
     */
    public static void getNovelInfoData(Context context, int bookId, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "info");
            jsonObject.put("bookId", bookId);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取章节列表数据
     *
     * @param context
     * @param bookId
     * @param start
     * @param retrofitCallback
     */
    public static void getChapterListData(Context context, int bookId, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("bookId", bookId);
            jsonObject.put(KEY_CODE, "chapter");
            jsonObject.put("start", start);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取章节内容
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getChapterContentData(Context context, int bookId, int chapterId, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "content");
            jsonObject.put("bookId", bookId);
            jsonObject.put("chapterId", chapterId);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取推荐数据
     * channel 1 精选  2 男生  3 女生
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRecommendData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "info");
            jsonObject.put("channel", 1);
            RequestHelper.getNetworkRequest(context, "精选数据加载中...", jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 精选--男频
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRecommendBoyData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "info");
            jsonObject.put("channel", 2);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 精选--女频
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRecommendGirlData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "info");
            jsonObject.put("channel", 3);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取推荐列表
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRecommendListData(Context context, String channelId, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("topId", channelId);
            jsonObject.put("start", start);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取banner数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getAdBannerFeaturedData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "ad");
            jsonObject.put("site", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 精选男频广告
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getAdBannerFeaturedBoyData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "ad");
            jsonObject.put("site", 2);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 精选女频界面
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getAdBannerFeaturedGirlData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "ad");
            jsonObject.put("site", 3);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 完结界面banner数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getAdBannerEndData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "ad");
            jsonObject.put("site", 6);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取搜索列表数据
     *
     * @param context
     * @param keyword
     * @param type
     * @param start
     * @param retrofitCallback
     */
    public static void getSearchListData(Context context, String keyword, int type, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "search");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("keyword", keyword);
            jsonObject.put("type", type);
            jsonObject.put("start", start);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取搜索标签数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getSearchTagData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "search");
            jsonObject.put(KEY_VER, VERSION_1_1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取搜索历史数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getSearchHistory(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "search");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "history");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取排行榜数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRankData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "rank");
            jsonObject.put(KEY_VER, VERSION_1_1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param context
     * @param retrofitCallback
     */
    public static void getRankFirst(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "rank");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "first");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取排行榜列表界面
     *
     * @param context
     * @param type
     * @param retrofitCallback
     */
    public static void getRankListData(Context context, int type, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "rank");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "list");
            jsonObject.put("type", type);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取作家作品数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getAuthorWorksListData(Context context, int id, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "author");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("id", id);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 加入书架
     *
     * @param context
     * @param bookId
     * @param retrofitCallback
     */
    public static void addBookshelf(Context context, int bookId, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "shelf");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "add");
            jsonObject.put("bookId", bookId);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取书架列表
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getBookshelfListData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "shelf");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "list");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除书架上的书籍
     * 批量删除用,分割
     *
     * @param context
     * @param retrofitCallback
     */
    public static void bookshelfDelData(Context context, String ids, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "shelf");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "del");
            jsonObject.put("bookId", ids);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 提交反馈数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void submitFeedbackData(Context context, String content, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "feed");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("content", content);
            RequestHelper.getNetworkRequest(context, "意见提交中...", jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取公告数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getNoticeData(Context context, int start, int type, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("start", start);
            jsonObject.put("type", type);
            jsonObject.put("apptype", "lanshu");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 公告消息已读
     *
     * @param context
     * @param retrofitCallback bid 消息id
     */
    public static void readNoticeData(Context context, int id, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "read");
            jsonObject.put("bid", id);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除公告消息
     *
     * @param context
     * @param retrofitCallback
     */
    public static void delNoticeData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "del");
            jsonObject.put("bid", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 阅读历史数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getReadHistoryListData(Context context, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "readH");
            jsonObject.put("start", start);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param context
     * @param retrofitCallback
     */
    public static void delReadHistoryData(Context context, String ids, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "delhistorys");
            jsonObject.put("bookIds", ids);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取个人信息
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getPersonInfoData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "userInfo");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取邀请信息
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getInviteData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "invited");
            jsonObject.put("aff", "h");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取验证码
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getVerifyCode(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "sms");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "send");
            jsonObject.put("mobile", "13643836633");
            jsonObject.put("type", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 验证验证码
     *
     * @param context
     * @param retrofitCallback
     */
    public static void verifyCode(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "sms");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "val");
            jsonObject.put("mobile", "13643836693");
            jsonObject.put("type", 1);
            jsonObject.put("v", "242379");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取排行榜榜首
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getLeaderboardTop(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "rank");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "first");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取文学数据
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getLiteratureData(Context context, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "letter");
            jsonObject.put("start", start);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 推荐自定义
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRecommendCustomData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "recommend");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "custom");
            jsonObject.put("name", "shelf");
            jsonObject.put("start", 1);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 探测线路
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getRrobeLineData(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "AreaCheck");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put("apptype", "lanshu");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 判断手机号是否存在
     *
     * @param context
     * @param retrofitCallback
     */
    public static void isPhoneNumExist(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 8);
            jsonObject.put("mobile", "13643836555");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 切换账号
     *
     * @param context
     * @param retrofitCallback
     */
    public static void switchAccount(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 7);
            jsonObject.put("new_uuid", "c09ba05fb4a00f50afb3aa0757307438");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 书籍下载章节列表
     *
     * @param context
     * @param retrofitCallback
     */
    public static void getNovelChapterDownloadList(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "downList");
            jsonObject.put("bookId", 20339);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获得日更界面数据
     *
     * @param context
     * @param start
     * @param retrofitCallback
     */
    public static void getDailyUpdateListData(Context context, int gender, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "booklist");
            jsonObject.put("type", 2);
            jsonObject.put("gender", gender);
            jsonObject.put("start", start);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取完结数据
     *
     * @param context
     * @param start
     * @param retrofitCallback
     */
    public static void getEndListData(Context context, int gender, int start, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "bookInfo");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "booklist");
            jsonObject.put("type", 1);
            jsonObject.put("gender", gender);
            jsonObject.put("start", start);
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 注册
     *
     * @param context
     * @param retrofitCallback
     */
    public static void register(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 1);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("anthCode", "1234124");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void changePhoneNumber(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 2);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("anthCode", "1234124");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void login(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 3);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void changePassword(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 4);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("password", "1234556");
            jsonObject.put("newPassword", "123123");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void retrievePassword(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 5);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("anthCode", "1234124");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 注销登录
     *
     * @param context
     * @param retrofitCallback
     */
    public static void logout(Context context, RetrofitCallback retrofitCallback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(KEY_METHOD, "manages");
            jsonObject.put(KEY_VER, VERSION_1_1);
            jsonObject.put(KEY_CODE, "auth");
            jsonObject.put("type", 6);
            jsonObject.put("mobile", "13643832222");
            jsonObject.put("password", "1234556");
            RequestHelper.getNetworkRequest(context, jsonObject, retrofitCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
