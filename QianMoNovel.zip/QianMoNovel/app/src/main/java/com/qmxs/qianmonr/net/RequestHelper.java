package com.qmxs.qianmonr.net;

import android.content.Context;

import com.qmxs.qianmonr.config.Constants;
import com.qmxs.qianmonr.model.ResponseModel;
import com.qmxs.qianmonr.util.Cfb_256crypt;
import com.qmxs.qianmonr.util.MD5Util;
import com.qmxs.qianmonr.util.SystemUtil;

import org.json.JSONException;
import org.json.JSONObject;

import io.reactivex.Observable;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/*
 * File: RequestHelper.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/6 12:25 PM
 */
class RequestHelper {

    private static final String OAUTH_ID = "oauth_id";
    private static final String OAUTH_TYPE = "oauth_type";
    private static final String VERSION = "version";
    private static final String OS_VERSION = "os_version";
    private static final String ANDROID = "android";
    private static final String DATA = "data";
    private static final String SIGN = "sign";
    private static final String TIMESTAMP = "timestamp";

    static void getNetworkRequest(Context context, JSONObject jsonObject, RetrofitCallback retrofitCallback) throws JSONException {
        ApiClient apiClient = ApiClient.getInstance();
        GetRequestService requestService = apiClient.getRequestService(GetRequestService.class);
        RequestBody requestBody = getRequestBody(jsonObject);
        Observable<ResponseModel> requestObservable = requestService.getRequestObservable(requestBody);
        apiClient.request(context, requestObservable, retrofitCallback);
    }

    private static RequestBody getRequestBody(JSONObject jsonObject) throws JSONException {

        JSONObject totalJsonData = getTotalJsonData(jsonObject);
        String data = Cfb_256crypt.encrypt(Constants.ENCRYPT_KEY, totalJsonData.toString());//data加密

        long timestamp = System.currentTimeMillis();
        String sign = sign(data, timestamp);//数据签名

        JSONObject resultJsonData = new JSONObject();
        resultJsonData.put(DATA, data);
        resultJsonData.put(SIGN, sign);
        resultJsonData.put(TIMESTAMP, timestamp);

        return RequestBody.create(MediaType.parse("application/json"), resultJsonData.toString());
    }


    private static JSONObject getTotalJsonData(JSONObject jsonObject) throws JSONException {
        jsonObject.put(OAUTH_ID, SystemUtil.getUniqueId());//设备id
        jsonObject.put(OAUTH_TYPE, ANDROID);
        jsonObject.put(OS_VERSION, SystemUtil.getSystemVersion());//Android系统版本号
        jsonObject.put(VERSION, SystemUtil.getVersionCode());//APP版本号
        return jsonObject;
    }

    /**
     * 签名
     *
     * @param data 密文
     * @param time 时间
     * @return 签名文
     */
    private static String sign(String data, long time) {
        String combination = "data=" + data + "&timestamp=" + time + Constants.APP_KEY;
        return MD5Util.getMD5(Cfb_256crypt.getSHA256StrJava(combination));
    }
}
