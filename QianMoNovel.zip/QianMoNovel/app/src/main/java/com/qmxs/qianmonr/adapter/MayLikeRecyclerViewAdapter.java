package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: MayLikeRecyclerViewAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 4:15 PM
 */
public class MayLikeRecyclerViewAdapter extends BaseRecyclerViewAdapter {

    public MayLikeRecyclerViewAdapter(Context context) {
        super(context);
    }
}
