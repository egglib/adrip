package com.qmxs.qianmonr.activity;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.PopularListAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.BannerModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.viewholder.FeaturedBannerViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.PopularListViewHolder;

import java.util.ArrayList;
import java.util.List;

/*
 * File: PopularListActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 10:06 PM
 */
public class PopularListActivity extends BaseCommonTitleActivity implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private static final int TYPE_ITEM_BANNER = -1;
    private static final int TYPE_ITEM_POPULAR_1 = 1;
    private static final int TYPE_ITEM_POPULAR_2 = 2;
    private static final int TYPE_ITEM_POPULAR_3 = 3;
    private static final int TYPE_ITEM_POPULAR_4 = 4;
    private static final int TYPE_ITEM_POPULAR_5 = 5;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview;
    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.popular_list);
    }

    @Override
    protected void initView() {
        View view = createActionBarRightIcon(R.mipmap.ic_search);
        view.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        mSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);

        PopularListAdapter adapter = new PopularListAdapter(this);
        adapter.register(TYPE_ITEM_BANNER, new ItemViewHolderContainer(R.layout.item_banner_view, FeaturedBannerViewHolder.class));

        adapter.register(TYPE_ITEM_POPULAR_1, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        adapter.register(TYPE_ITEM_POPULAR_2, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        adapter.register(TYPE_ITEM_POPULAR_3, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        adapter.register(TYPE_ITEM_POPULAR_4, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        adapter.register(TYPE_ITEM_POPULAR_5, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));

        mRecyclerView.setAdapter(adapter);

        List<RenderTypeModel> objects = new ArrayList<>();

        BannerModel bannerModel = new BannerModel();
        bannerModel.setRenderType(TYPE_ITEM_BANNER);

        RenderTypeModel renderTypeModel1 = new RenderTypeModel();
        renderTypeModel1.setRenderType(TYPE_ITEM_POPULAR_1);

        RenderTypeModel renderTypeModel2 = new RenderTypeModel();
        renderTypeModel2.setRenderType(TYPE_ITEM_POPULAR_2);

        RenderTypeModel renderTypeModel3 = new RenderTypeModel();
        renderTypeModel3.setRenderType(TYPE_ITEM_POPULAR_3);

        RenderTypeModel renderTypeModel4 = new RenderTypeModel();
        renderTypeModel4.setRenderType(TYPE_ITEM_POPULAR_4);

        RenderTypeModel renderTypeModel5 = new RenderTypeModel();
        renderTypeModel5.setRenderType(TYPE_ITEM_POPULAR_5);

        objects.add(bannerModel);
        objects.add(renderTypeModel1);
        objects.add(renderTypeModel2);
        objects.add(renderTypeModel3);
        objects.add(renderTypeModel4);
        objects.add(renderTypeModel5);
        adapter.addData(objects);

    }

    @Override
    public void onRefresh() {

    }
}
