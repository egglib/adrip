package com.qmxs.qianmonr.util;

import android.content.Context;
import android.widget.Toast;

import com.qmxs.qianmonr.widget.CustomToast;


public class ToastUtil {

    /**
     * show long time
     *
     * @param msg
     */
    public static void longShow(Context context, CharSequence msg) {
        CustomToast.makeText(context, msg == null ? "" : msg, Toast.LENGTH_LONG).show();
    }


    /**
     * show short time
     *
     * @param msg
     */
    public static void shortShow(Context context, CharSequence msg) {
        CustomToast.makeText(context, msg == null ? "" : msg, Toast.LENGTH_SHORT).show();
    }

}
