package com.qmxs.qianmonr.model;

import com.qmxs.qianmonr.widget.banner.SimpleBannerInfo;

/*
 * File: BannerSimpleModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 7:19 PM
 */
public class BannerSimpleModel extends SimpleBannerInfo {

    @Override
    public Object getXBannerUrl() {
        return null;
    }
}
