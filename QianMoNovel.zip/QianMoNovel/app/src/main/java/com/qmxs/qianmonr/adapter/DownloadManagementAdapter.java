package com.qmxs.qianmonr.adapter;
import android.content.Context;


/*
 * File: DownloadManagementAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 11:57 AM
 */
public class DownloadManagementAdapter extends BaseRecyclerViewAdapter {

    public DownloadManagementAdapter(Context context) {
        super(context);
    }


}
