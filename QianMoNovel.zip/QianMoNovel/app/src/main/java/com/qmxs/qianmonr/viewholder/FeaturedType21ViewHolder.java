package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.NovelBreifModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: FeaturedType21ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 4:10 PM
 */
class FeaturedType21ViewHolder extends BaseViewHolder {

    private NetworkImageView mCoverImg;
    private TextView mNovelNameTv;
    private TextView mNovelAuthorTv;
    private LinearLayout mLayoutItem;

    public FeaturedType21ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mCoverImg = (NetworkImageView) itemView.findViewById(R.id.img_cover);
        mNovelNameTv = (TextView) itemView.findViewById(R.id.tv_novel_name);
        mNovelAuthorTv = (TextView) itemView.findViewById(R.id.tv_novel_author);
        mLayoutItem = (LinearLayout) itemView.findViewById(R.id.item_layout);
        mNovelNameTv.setTextColor(mContext.getResources().getColor(R.color.white));
        mNovelAuthorTv.setTextColor(mContext.getResources().getColor(R.color.white));

        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(72)) / 3;
        int height = width * 3 / 2;
        mCoverImg.setLayoutParams(new FrameLayout.LayoutParams(width, height));
        itemView.setOnClickListener(v -> {
            JumpUtil.forwordToNovelDetail(mContext, ((NovelBreifModel) mObjectList.get(mPosition)).getBookId());
        });
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        NovelBreifModel novelBreifModel = (NovelBreifModel) objectList.get(position);

        if (novelBreifModel != null) {

            String imgUrl = novelBreifModel.getImg();
            if (!TextUtils.isEmpty(imgUrl)) {
                mCoverImg.setImgUrl(novelBreifModel.getImg());
            }

            String title = novelBreifModel.getTitle();
            if (!TextUtils.isEmpty(title)) {
                mNovelNameTv.setText(title);
            }

            String author = novelBreifModel.getAuthor();
            if (!TextUtils.isEmpty(author)) {
                mNovelAuthorTv.setText(author);
            }
        }
    }
}
