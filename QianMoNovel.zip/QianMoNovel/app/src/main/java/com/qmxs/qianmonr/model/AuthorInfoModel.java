package com.qmxs.qianmonr.model;

/*
 * File: AuthorInfoModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 10:45 AM
 */
public class AuthorInfoModel extends RenderTypeModel {

    /**
     * id : 1
     * name : 唐家三少
     * introduction : 唐家三少是最具号召力的网络作家之一，也是最为成功的职业网络作家之一。唐家三少自2003年在起点进行创作以来，已在起点连载了《天珠变》、《斗罗大陆》、《琴帝》等多部作品，他的《斗罗大陆》仅在起点中文网上就超过5500万点击量，并已被改编成网页游戏和漫画。
     * 2011年，唐家三少与余华、刘震云、贾平凹等百余名传统作家一道当选为中国作家协会第八届全国委员会委员，成为第一位当选作协委员的网络作家。在2011年12月《人民文学》主办的“未来大家”评选中，唐家三少与张悦然、蔡骏等作家一起入围20强。
     * 2012年5月初，唐家三少以连续100个月“不断更”、总阅读人次达2.6亿的惊人数字申请了吉尼斯世界纪录。唐家三少也是起点中文网年收入过千万的顶尖作家之一。
     * is_rec : 1
     * updated_at : 1552041667
     * created_at : 1549445804
     * deleted : 0
     * num : 16
     * cover_id : 1
     * attach_name : a298ec6aa12f621a0d1be7aa2344d54d.jpg
     * img_url : http://x.lanshu.me/storage/a298ec6aa12f621a0d1be7aa2344d54d.jpg
     */

    private int id;
    private String name;
    private String introduction;
    private int is_rec;
    private int updated_at;
    private int created_at;
    private int deleted;
    private int num;
    private int cover_id;
    private String attach_name;
    private String img_url;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public int getIs_rec() {
        return is_rec;
    }

    public void setIs_rec(int is_rec) {
        this.is_rec = is_rec;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getCover_id() {
        return cover_id;
    }

    public void setCover_id(int cover_id) {
        this.cover_id = cover_id;
    }

    public String getAttach_name() {
        return attach_name;
    }

    public void setAttach_name(String attach_name) {
        this.attach_name = attach_name;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }
}
