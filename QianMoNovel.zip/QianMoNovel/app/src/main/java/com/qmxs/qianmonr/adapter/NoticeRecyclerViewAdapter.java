package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: NoticeRecyclerViewAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 8:40 PM
 */
public class NoticeRecyclerViewAdapter extends BaseRecyclerViewAdapter {

    public NoticeRecyclerViewAdapter(Context context) {
        super(context);
    }
}
