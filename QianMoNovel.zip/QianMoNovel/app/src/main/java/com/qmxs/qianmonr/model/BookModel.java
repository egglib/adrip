package com.qmxs.qianmonr.model;

/*
 * File: BookModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/11 12:45 PM
 */
public class BookModel {
    public int bookId;
    public int chapterId;
}
