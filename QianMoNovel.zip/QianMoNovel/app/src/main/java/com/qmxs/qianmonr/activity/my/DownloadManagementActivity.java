package com.qmxs.qianmonr.activity.my;

import android.content.res.ColorStateList;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.TextView;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.CommonPagerAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.fragment.CompleteFragment;
import com.qmxs.qianmonr.fragment.UndoneFragment;
import com.qmxs.qianmonr.widget.CustomViewPager;

import java.util.ArrayList;
import java.util.List;

/*
 * File: DownloadManagementActivity.java
 * Description:下载管理界面
 * Author: XiaoTao
 * Create at 2019/2/23 1:34 PM
 */
public class DownloadManagementActivity extends BaseCommonTitleActivity {
    private TabLayout mTabLayout;
    private CustomViewPager mViewPager;

    private int[] mTabTitles = new int[]{R.string.undone, R.string.complete};

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_download_management;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.download_management);
    }

    @Override
    protected void initView() {
        super.initView();
        mTabLayout = (TabLayout) findViewById(R.id.tabLayout);
        mViewPager = (CustomViewPager) findViewById(R.id.viewPager);
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        addFragments();
    }

    private void addFragments() {
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(new UndoneFragment());
        fragments.add(new CompleteFragment());
        CommonPagerAdapter commonPagerAdapter = new CommonPagerAdapter(getSupportFragmentManager(), fragments);
        mViewPager.setAdapter(commonPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        setupTabIcons();
    }

    protected void setupTabIcons() {
        try {
            for (int i = 0; i < mTabTitles.length; i++) {
                mTabLayout.getTabAt(i).setCustomView(getTabView(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private View getTabView(int position) {
        View view = getLayoutInflater().inflate(R.layout.common_tab_item_text, null);
        TextView tv_tab = view.findViewById(R.id.tv_tab_item);
        tv_tab.setText(getResources().getString(mTabTitles[position]));
        //代码需要这样设置
        ColorStateList colorStateList = getResources().getColorStateList(R.color.sort_list_tab_text_color_selector);
        tv_tab.setTextColor(colorStateList);
        return view;
    }
}
