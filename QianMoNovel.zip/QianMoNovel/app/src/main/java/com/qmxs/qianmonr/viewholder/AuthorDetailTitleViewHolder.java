package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.NovelCountModel;
import com.qmxs.qianmonr.model.RenderTypeModel;

import java.util.List;


/*
 * File: AuthorDetailTitleViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 11:52 AM
 */
public class AuthorDetailTitleViewHolder extends BaseViewHolder {

    private TextView mTitleTv;
    private TextView mCountTv;


    public AuthorDetailTitleViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mTitleTv = (TextView) itemView.findViewById(R.id.tv_title);
        mCountTv = (TextView) itemView.findViewById(R.id.tv_count);
        mTitleTv.setText("作家佳作");
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        NovelCountModel novelCountModel = (NovelCountModel) objectList.get(position);
        if (novelCountModel != null) {
            int count = novelCountModel.getCount();
            if (count > 0) {
                mCountTv.setText("共" + count + "部");
            }
        }
    }
}
