package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: FeaturedNovelModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 11:26 AM
 */
public class FeaturedNovelModel extends RenderTypeModel {

    /**
     * topicId : channelId_1
     * type : 1
     * title : 2019从这里开始
     * data : [{"readCnt":"13.32万字","clsName":"仙侠","author":"何须无为","title":"斧逆天祖","intro":"一道神秘的流星划过天空，带着机遇和灾祸降临！\r\n   看少年方玄以一己之力，凭靠着一把残破斧头，踏仙途，\r\n报血仇，灭鬼宗。\r\n   再看他如何为了个承诺，斩修，斩仙，斩道祖！\r\n   然后一步步走上巅峰！！！\r\n          \r\n              本书群号:308921265\r\n      &lt;欢迎各位书友涌加此群，讨论一些列问题！！！&gt;\r\n                  &lt;斧逆天祖 值得期待！！！&gt;","cover_id":0,"bookId":3,"fullFlag":"完结","lastUpdate":1416833320,"wordCnt":133244,"img":"http://172.104.106.185:5761/storage/def.jpg","tag":"仙侠 | 何须无为","lastChapter":""},{"readCnt":"23.33万字","clsName":"仙侠","author":"枯雪城","title":"三世离缘","intro":"如果没有遇见你，那该有多好。","cover_id":0,"bookId":12,"fullFlag":"完结","lastUpdate":1511976362,"wordCnt":233288,"img":"http://172.104.106.185:5761/storage/def.jpg","tag":"仙侠 | 枯雪城","lastChapter":""},{"readCnt":"53.68万字","clsName":"仙侠","author":"赤练龙尊","title":"新仙剑奇侠传","intro":"十年仙剑，十年辉煌。\r\n古龙已经离世，金庸也已远去，陪伴我们的，只有永远的仙剑奇侠传\u2026\u2026\r\n本文根据游戏改编，非电视剧本，非游戏攻略！\r\n有人说这书是抄袭的，这的确是冤枉我了.我并没有抄袭这书的意思,抄袭了也对不起仙剑.\r\n这种类型的书在网上版本有很多，类似的地方肯定会有。\r\n还请各位读者见谅，俗话说的好天下文章一大抄，更何况我这不是抄，\r\n只是仙剑的情节在哪，再怎么改也是一样的！","cover_id":0,"bookId":33,"fullFlag":"完结","lastUpdate":1391092162,"wordCnt":536788,"img":"http://book.wankouzi.com/book/2164/1273C2AF6C2E36227918AD51994D2C26/123620.jpg","tag":"仙侠 | 赤练龙尊","lastChapter":""},{"readCnt":"59.85万字","clsName":"武侠","author":"圭木桂","title":"情剑花痕录","intro":"本是一曲高歌，从头至尾皆是高亢。\r\n本是一段佳话，由始至终皆是姻缘。\r\n本是一对股剑，拿起放下皆是恩怨。\r\n管他什么恩怨情仇，算他什么名家大家。\r\n一声豪言正当时，喝酒便拿碗来干。\r\n不醉不罢休，不醉不罢休。\r\n长路漫漫终有尽头，欢聚一刻当相拥，离别之时当相送。","cover_id":0,"bookId":492,"fullFlag":"完结","lastUpdate":1528648762,"wordCnt":598501,"img":"http://172.104.106.185:5761/storage/def.jpg","tag":"武侠 | 圭木桂","lastChapter":""}]
     * icon : http://172.104.106.185:5761/storage/c413de53a0e6369ff767eaf371569ef7.jpg
     */

    private String topicId;
    private int type;
    private String title;
    private String icon;

    private List<NovelBreifModel> data;

    public String getTopicId() {
        return topicId;
    }

    public void setTopicId(String topicId) {
        this.topicId = topicId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
        setRenderType(type);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public List<NovelBreifModel> getData() {
        return data;
    }

    public void setData(List<NovelBreifModel> data) {
        this.data = data;
    }

}
