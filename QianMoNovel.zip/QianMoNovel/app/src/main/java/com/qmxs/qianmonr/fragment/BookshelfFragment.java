package com.qmxs.qianmonr.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.main.SearchActivity;
import com.qmxs.qianmonr.adapter.BookshelfAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.config.Global;
import com.qmxs.qianmonr.model.AddNovelRenderType;
import com.qmxs.qianmonr.model.BookshelfHeaderInfoModel;
import com.qmxs.qianmonr.model.BookshelfNovelContainer;
import com.qmxs.qianmonr.model.BookshelfNovelModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.ColorUtil;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.viewholder.BookshelfHeaderViewHolder;
import com.qmxs.qianmonr.viewholder.BookshelfNovelContainerViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;

import java.util.ArrayList;
import java.util.List;

import static com.qmxs.qianmonr.viewholder.BookshelfNovelContainerViewHolder.TYPE_BOOKSHELF_NOVEL_INNER;
import static com.qmxs.qianmonr.viewholder.BookshelfNovelContainerViewHolder.TYPE_BOOKSHELF_NOVEL_INNER_ADD;

/*
 * File: BookshelfFragment.java
 * Description:书架界面
 * Author: XiaoTao
 * Create at 2019/2/19 3:50 PM
 */
public class BookshelfFragment extends BaseLazyFragment implements SwipeRefreshLayout.OnRefreshListener {

    private LinearLayout mTitleLayout;
    private View mTopView;
    private ImageView mSearchImg;
    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private int mDistance = 0;
    private float flagHight = ScreenUtil.dp2px(130);
    private float alpha;
    private static final int TYPE_BOOKSHELF_HEADER = 1;
    private static final int TYPE_BOOKSHELF_NOVEL = 2;
    private BookshelfAdapter bookshelfAdapter;


    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_bookshelf;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mTitleLayout = view.findViewById(R.id.titleLayout);
        mTopView = view.findViewById(R.id.topView);
        mTopView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Global.STUTAS_BAR_HEIGHT));
        mSearchImg = view.findViewById(R.id.img_search);
        mSearchImg.setOnClickListener((v) -> startActivity(new Intent(getContext(), SearchActivity.class)));
        mRecyclerView = view.findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mDistance += dy;
                int scrolledY = mDistance < 0 ? 0 : mDistance;

                if (scrolledY < flagHight) {
                    alpha = scrolledY / flagHight;
                } else {
                    alpha = 1f;
                }
                mTitleLayout.setBackgroundColor(Color.parseColor("#" + ColorUtil.getColorHexStr(alpha) + "FFFFFF"));
            }
        });

        mSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setProgressViewEndTarget(false, 330);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.setFocusableInTouchMode(true);
        mRecyclerView.setFocusable(true);
        mRecyclerView.requestFocus();

        bookshelfAdapter = new BookshelfAdapter(getContext());
        bookshelfAdapter.register(TYPE_BOOKSHELF_HEADER, new ItemViewHolderContainer(R.layout.item_bookshelf_header, BookshelfHeaderViewHolder.class));
        bookshelfAdapter.register(TYPE_BOOKSHELF_NOVEL, new ItemViewHolderContainer(R.layout.item_bookshelf_novel_container, BookshelfNovelContainerViewHolder.class));
        mRecyclerView.setAdapter(bookshelfAdapter);
        setDialogTip("书架数据加载中...");
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        getData();
    }

    private void getData() {
        bookshelfAdapter.clearData();
        showDialog();
        ApiManager.getRecommendCustomData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                BookshelfHeaderInfoModel bookshelfHeaderInfoModel = JsonUtil.jsonStrToObj(response, BookshelfHeaderInfoModel.class);
                if (bookshelfHeaderInfoModel != null) {
                    bookshelfHeaderInfoModel.setRenderType(TYPE_BOOKSHELF_HEADER);
                    bookshelfAdapter.getDataList().add(0, bookshelfHeaderInfoModel);
                    bookshelfAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onError(Throwable e) {
                mSwipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onComplete() {
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        ApiManager.getBookshelfListData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<BookshelfNovelModel> bookshelfNovelModels = JsonUtil.jsonStrToObjList(response, BookshelfNovelModel.class);
                for (BookshelfNovelModel bookshelfNovelModel : bookshelfNovelModels) {
                    bookshelfNovelModel.setRenderType(TYPE_BOOKSHELF_NOVEL_INNER);
                }

                AddNovelRenderType addNovelRenderType = new AddNovelRenderType();
                addNovelRenderType.setRenderType(TYPE_BOOKSHELF_NOVEL_INNER_ADD);

                List<RenderTypeModel> renderTypeModels = new ArrayList<>();

                if (!bookshelfNovelModels.isEmpty()) {
                    renderTypeModels.addAll(bookshelfNovelModels);
                }

                renderTypeModels.add(addNovelRenderType);

                int size = renderTypeModels.size();

                int time;
                if (size % 3 == 0) {
                    time = size / 3;
                } else {
                    time = size / 3 + 1;
                }
                int count = 1;

                List<BookshelfNovelContainer> bookshelfNovelContainers = new ArrayList<>();
                while (count <= time) {
                    BookshelfNovelContainer bookshelfNovelContainer = new BookshelfNovelContainer();
                    bookshelfNovelContainer.setRenderType(TYPE_BOOKSHELF_NOVEL);

                    List<RenderTypeModel> renderTypeModelList = new ArrayList<>();

                    for (int i = (count - 1) * 3; i < Math.min(size, count * 3); i++) {
                        renderTypeModelList.add(renderTypeModels.get(i));
                    }
                    bookshelfNovelContainer.setRenderTypeModels(renderTypeModelList);
                    bookshelfNovelContainers.add(bookshelfNovelContainer);
                    count++;
                }

                bookshelfAdapter.addData(bookshelfNovelContainers);
            }

            @Override
            public void onError(Throwable e) {
                dismissDialog();
                mSwipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onComplete() {
                dismissDialog();
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    @Override
    protected void onLazyLoad() {

    }

    @Override
    public void onRefresh() {
        getData();
    }
}
