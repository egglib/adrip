package com.qmxs.qianmonr.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.SearchActivity;
import com.qmxs.qianmonr.adapter.BookshelfAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.config.Global;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ColorUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.viewholder.BookshelfHeaderViewHolder;
import com.qmxs.qianmonr.viewholder.BookshelfNovelContainerViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;

import java.util.ArrayList;
import java.util.List;

/*
 * File: BookshelfFragment.java
 * Description:书架界面
 * Author: XiaoTao
 * Create at 2019/2/19 3:50 PM
 */
public class BookshelfFragment extends BaseLazyFragment implements SwipeRefreshLayout.OnRefreshListener {

    private LinearLayout mTitleLayout;
    private View mTopView;
    private ImageView mSearchImg;
    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private int mDistance = 0;
    private float flagHight = ScreenUtil.dp2px(130);
    private float alpha;

    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_bookshelf;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mTitleLayout = view.findViewById(R.id.titleLayout);
        mTopView = view.findViewById(R.id.topView);
        mTopView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Global.STUTAS_BAR_HEIGHT));
        mSearchImg = view.findViewById(R.id.img_search);
        mSearchImg.setOnClickListener((v) -> startActivity(new Intent(getContext(), SearchActivity.class)));
        mRecyclerView = view.findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                mDistance += dy;
                int scrolledY = mDistance < 0 ? 0 : mDistance;

                if (scrolledY < flagHight) {
                    alpha = scrolledY / flagHight;
                } else {
                    alpha = 1f;
                }
                mTitleLayout.setBackgroundColor(Color.parseColor("#" + ColorUtil.getColorHexStr(alpha) + "FFFFFF"));
            }
        });

        mSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setProgressViewEndTarget(false, 400);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.setFocusableInTouchMode(true);
        mRecyclerView.requestFocus();

        BookshelfAdapter bookshelfAdapter = new BookshelfAdapter(getContext());
        bookshelfAdapter.register(1, new ItemViewHolderContainer(R.layout.item_bookshelf_header, BookshelfHeaderViewHolder.class));
        bookshelfAdapter.register(2, new ItemViewHolderContainer(R.layout.item_bookshelf_novel_container, BookshelfNovelContainerViewHolder.class));
        mRecyclerView.setAdapter(bookshelfAdapter);

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();

        RenderTypeModel renderTypeModel = new RenderTypeModel();
        renderTypeModel.setRenderType(1);
        renderTypeModels.add(renderTypeModel);

        for (int i = 0; i < 3; i++) {
            RenderTypeModel renderTypeModel1 = new RenderTypeModel();
            renderTypeModel1.setRenderType(2);
            renderTypeModels.add(renderTypeModel1);
        }


        bookshelfAdapter.addData(renderTypeModels);

    }

    @Override
    protected void onLazyLoad() {

    }

    @Override
    public void onRefresh() {

    }
}
