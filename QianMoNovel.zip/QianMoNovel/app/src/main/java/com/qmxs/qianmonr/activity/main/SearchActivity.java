package com.qmxs.qianmonr.activity.main;

import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.SearchHistoryAdapter;
import com.qmxs.qianmonr.adapter.SearchNovelAdapter;
import com.qmxs.qianmonr.base.BaseActivity;
import com.qmxs.qianmonr.config.Global;
import com.qmxs.qianmonr.model.SearchHistoryModel;
import com.qmxs.qianmonr.model.SearchInfoModel;
import com.qmxs.qianmonr.model.SearchNovelModel;
import com.qmxs.qianmonr.model.SearchTagModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.util.ToastUtil;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.SearchHistoryClearViewHolder;
import com.qmxs.qianmonr.viewholder.SearchHistoryViewHolder;
import com.qmxs.qianmonr.viewholder.SearchNovelIntroViewHolder;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.qmxs.qianmonr.dialog.LoadingDialog;
import com.qmxs.qianmonr.widget.flowlayout.FlowLayout;
import com.qmxs.qianmonr.widget.flowlayout.TagAdapter;
import com.qmxs.qianmonr.widget.flowlayout.TagFlowLayout;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.BallPulseFooter;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;

/*
 * File: SearchActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/21 7:38 PM
 */
public class SearchActivity extends BaseActivity implements OnLoadMoreListener, OnRefreshListener, TextWatcher {

    private View mTopView;
    private ImageView mBackImg;
    private EditText mSearchEt;
    private LinearLayout mTitleLayout;
    private RecyclerView mRecyclerView;
    private TagFlowLayout mFlowLayout;
    private List<String> tags = new ArrayList<>();
    private TextView mSearchBtn;
    private int type = 3;
    private int mPageNum = 1;
    private LinearLayout mHotSearchLayout;
    private LinearLayout mDefaultLayout;
    private RecyclerView mNovelRv;
    private SmartRefreshLayout mSmartRefreshLayout;
    private SearchNovelAdapter searchNovelAdapter;
    private String keyword;
    private SearchHistoryAdapter searchHistoryAdapter;

    private static final int TYPE_SEARCH_NOVEL = 3;
    private boolean isLoading = false;
    private LinearLayout mHistoryLayout;


    @Override
    protected int setContentViewId() {
        return R.layout.activity_search;
    }

    @Override
    protected void initView() {
        mTopView = (View) findViewById(R.id.topView);
        mTopView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Global.STUTAS_BAR_HEIGHT));
        mBackImg = (ImageView) findViewById(R.id.img_back);
        mSearchEt = (EditText) findViewById(R.id.et_search);
        mTitleLayout = (LinearLayout) findViewById(R.id.layout_title);
        mHistoryLayout = (LinearLayout) findViewById(R.id.layout_history);
        mHistoryLayout.setVisibility(View.GONE);
        mBackImg.setOnClickListener(v -> {
            finish();
        });
        mRecyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        searchHistoryAdapter = new SearchHistoryAdapter(this);
        searchHistoryAdapter.register(1, new ItemViewHolderContainer(R.layout.item_search_history, SearchHistoryViewHolder.class));
        searchHistoryAdapter.register(2, new ItemViewHolderContainer(R.layout.item_search_history_clear, SearchHistoryClearViewHolder.class));
        mRecyclerView.setAdapter(searchHistoryAdapter);

        mFlowLayout = findViewById(R.id.flowLayout);

        mFlowLayout.setOnTagClickListener((view, position, parent) -> {
            String text = tags.get(position);
            mSearchEt.setText(text);
            mSearchEt.setSelection(text.length());
            return false;
        });

        mSearchBtn = findViewById(R.id.btn_search);
        mSearchBtn.setOnClickListener(v -> {
            keyword = mSearchEt.getText().toString();
            if (TextUtils.isEmpty(keyword)) {
                ToastUtil.shortShow(this, "请先输入关键字");
                return;
            }
            mDefaultLayout.setVisibility(View.GONE);
            mSmartRefreshLayout.setVisibility(View.VISIBLE);
            searchData(keyword);
            getSearchHistory();
        });

        mHotSearchLayout = (LinearLayout) findViewById(R.id.layout_hot_search);
        mHotSearchLayout.setVisibility(View.GONE);
        mDefaultLayout = (LinearLayout) findViewById(R.id.layout_default);
        mDefaultLayout.setVisibility(View.VISIBLE);

        mNovelRv = (RecyclerView) findViewById(R.id.rv_novel);
        mNovelRv.setLayoutManager(new LinearLayoutManager(this));
        mNovelRv.setItemAnimator(new DefaultItemAnimator());
        mNovelRv.setHasFixedSize(true);

        mSmartRefreshLayout = (SmartRefreshLayout) findViewById(R.id.smartRefreshLayout);
        mSmartRefreshLayout.setVisibility(View.GONE);

        CustomHeaderView header = new CustomHeaderView(this);
        mSmartRefreshLayout.setRefreshHeader(header);

        BallPulseFooter footer = new BallPulseFooter(this).setSpinnerStyle(SpinnerStyle.Scale);
        mSmartRefreshLayout.setRefreshFooter(footer);

        mSmartRefreshLayout.setOnRefreshListener(this);
        mSmartRefreshLayout.setOnLoadMoreListener(this);

        searchNovelAdapter = new SearchNovelAdapter(this);
        searchNovelAdapter.register(TYPE_SEARCH_NOVEL, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, SearchNovelIntroViewHolder.class));
        mNovelRv.addItemDecoration(new SpacesItemDecoration(0, 0, ScreenUtil.dp2px(15), 0));
        mNovelRv.setAdapter(searchNovelAdapter);
        setDialogTip("搜索数据加载中...");
        mSearchEt.addTextChangedListener(this);
        getSearchHistory();
        searchHistoryAdapter.setOnItemClickListener((view, mObjectList, mPosition) -> {
            SearchHistoryModel searchHistoryModel = (SearchHistoryModel) mObjectList.get(mPosition);
            if (searchHistoryModel != null) {
                String keyword = searchHistoryModel.getKeywords();
                if (!TextUtils.isEmpty(keyword)) {
                    mSearchEt.setText(keyword);
                    mSearchEt.setSelection(keyword.length());
                }
            }
        });
    }

    private void getSearchHistory() {
//        ApiManager.getSearchHistory(this, new RetrofitCallback() {
//            @Override
//            public void onSuccess(String response) {
//                List<SearchHistoryModel> searchHistoryModels = JsonUtil.jsonStrToObjList(response, SearchHistoryModel.class);
//
//                if (searchHistoryModels == null || searchHistoryModels.isEmpty()) {
//                    return;
//                }
//                mHistoryLayout.setVisibility(View.VISIBLE);
//                for (SearchHistoryModel searchHistoryModel : searchHistoryModels) {
//                    searchHistoryModel.setRenderType(1);
//                }
//                RenderTypeModel renderTypeModel = new RenderTypeModel();
//                renderTypeModel.setRenderType(2);
//                List<RenderTypeModel> renderTypeModels = new ArrayList<>();
//                renderTypeModels.addAll(searchHistoryModels);
//                renderTypeModels.add(renderTypeModel);
//                searchHistoryAdapter.clearData();
//                searchHistoryAdapter.addData(renderTypeModels);
//            }
//
//            @Override
//            public void onError(Throwable e) {
//
//            }
//
//            @Override
//            public void onComplete() {
//
//            }
//        });
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        getMoreData();
    }

    private void getMoreData() {
        if (!isLoading) {
            isLoading = true;
            searchData(keyword);
        }
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        refreshData();
    }

    private void refreshData() {
        if (!isLoading) {
            isLoading = true;
            mPageNum = 1;
            searchData(keyword);
        }
    }


    private void searchData(String keyword) {
        if (mPageNum == 1)
            showDialog();
        ApiManager.getSearchListData(this, keyword, type, mPageNum, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                if (mPageNum == 1) {
                    mSmartRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSmartRefreshLayout.finishLoadMore();
                }

                SearchInfoModel searchInfoModel = JsonUtil.jsonStrToObj(response, SearchInfoModel.class);
                if (searchInfoModel == null) {
                    mSmartRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }
                List<SearchNovelModel> searchNovelModels = searchInfoModel.getData();

                if (searchNovelModels == null || searchNovelModels.isEmpty()) {
                    mSmartRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }

                if (mPageNum == 1) {
                    searchNovelAdapter.clearData();
                }

                mPageNum++;

                for (SearchNovelModel searchNovelModel : searchNovelModels) {
                    searchNovelModel.setRenderType(TYPE_SEARCH_NOVEL);
                }
                searchNovelAdapter.addData(searchNovelModels);

            }

            @Override
            public void onError(Throwable e) {
                isLoading = false;
                dismissDialog();
                if (mPageNum == 1) {
                    mSmartRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSmartRefreshLayout.finishLoadMore();
                }
            }

            @Override
            public void onComplete() {
                dismissDialog();
                isLoading = false;
            }
        });
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        getTagData();
    }

    private void getTagData() {
        ApiManager.getSearchTagData(this, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<SearchTagModel> searchTagModels = JsonUtil.jsonStrToObjList(response, SearchTagModel.class);
                if (searchTagModels != null && !searchTagModels.isEmpty()) {
                    mHotSearchLayout.setVisibility(View.VISIBLE);
                    for (SearchTagModel searchTagModel : searchTagModels) {
                        tags.add(searchTagModel.getKeywords());
                    }
                    mFlowLayout.setAdapter(new TagAdapter<String>(tags) {
                        @Override
                        public View getView(FlowLayout parent, int position, String str) {
                            TextView textView = (TextView) LayoutInflater.from(SearchActivity.this).inflate(R.layout.item_tag, mFlowLayout, false);
                            textView.setText(str);
                            return textView;
                        }
                    });
                }
            }

            @Override
            public void onError(Throwable e) {
                mHotSearchLayout.setVisibility(View.GONE);
            }

            @Override
            public void onComplete() {

            }
        });
    }


    private LoadingDialog mDialog;

    /**
     * 设置对话框的提示信息
     *
     * @param tip
     */
    protected void setDialogTip(String tip) {
        if (TextUtils.isEmpty(tip)) {
            return;
        }
        if (mDialog == null)
            mDialog = new LoadingDialog(this);
        mDialog.setTipText(tip);
        mDialog.setOnCancelListener(dialogInterface -> {
            dismissDialog();
        });

    }


    protected void showDialog() {
        if (mDialog != null && !mDialog.isShowing()) {
            mDialog.show();
        }
    }


    protected void dismissDialog() {
        if (mDialog != null && mDialog.isShowing() && !this.isFinishing()) {
            mDialog.dismiss();
        }
    }


    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        if (mSearchEt.getText().toString().length() == 0) {
            mDefaultLayout.setVisibility(View.VISIBLE);
            mSmartRefreshLayout.setVisibility(View.GONE);
            searchNovelAdapter.clearData();
            mPageNum = 1;
            isLoading = false;
        }
    }
}
