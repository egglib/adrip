package  com.qmxs.qianmonr.widget.shadowlayout;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

/*
 * File: Shadow.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/20 3:10 PM
 */
public interface Shadow {
    public void setParameter(int colorTopShadow, int colorBottomShadow, float offsetTopShadow, float offsetBottomShadow, float blurTopShadow, float blurBottomShadow,
                             Rect rect);

    public void onDraw(Canvas canvas);

    public void onDrawOver(Canvas canvas);

    boolean onClipChildCanvas(Canvas canvas, View child);

    void onLayout(View parent, int left, int top, int right, int bottom);
}
