package com.qmxs.qianmonr.adapter;

import android.content.Context;

/*
 * File: FeaturedType61Adapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 5:36 PM
 */
public class FeaturedType61Adapter extends BaseRecyclerViewAdapter {


    public FeaturedType61Adapter(Context context) {
        super(context);
    }
}
