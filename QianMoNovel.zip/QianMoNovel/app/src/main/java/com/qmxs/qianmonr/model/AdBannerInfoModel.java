package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: AdBannerInfoModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/13 10:15 AM
 */
public class AdBannerInfoModel extends RenderTypeModel {

    private List<AdBannerModel> adBannerModels;

    public List<AdBannerModel> getAdBannerModels() {
        return adBannerModels;
    }

    public void setAdBannerModels(List<AdBannerModel> adBannerModels) {
        this.adBannerModels = adBannerModels;
    }
}
