package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.util.ScreenUtil;

/*
 * File: MayLikeViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 4:36 PM
 */
public class MayLikeViewHolder extends BaseViewHolder {

    private ImageView mImgView;
    private TextView mTextView;

    public MayLikeViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mImgView = itemView.findViewById(R.id.imgView);
        mTextView = itemView.findViewById(R.id.textView);
        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(60)) / 3;
        int height = width * 3 / 2;
        mImgView.setLayoutParams(new FrameLayout.LayoutParams(width, height));
    }
}
