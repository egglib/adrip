package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.NovelDetailModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: MayLikeViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 4:36 PM
 */
public class MayLikeViewHolder extends BaseViewHolder {

    private NetworkImageView mImgView;
    private TextView mTitleTv;
    private TextView mAuthorTv;

    public MayLikeViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mImgView = itemView.findViewById(R.id.imgView);
        mTitleTv = itemView.findViewById(R.id.tv_title);
        mAuthorTv = itemView.findViewById(R.id.tv_author);

        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(68)) / 3;
        int height = width * 3 / 2;
        mImgView.setLayoutParams(new FrameLayout.LayoutParams(width, height));

        itemView.setOnClickListener(v -> {
            int bookId = ((NovelDetailModel.GuessModel) mObjectList.get(mPosition)).getBookId();
            JumpUtil.forwordToNovelDetail(mContext, bookId);
        });
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        NovelDetailModel.GuessModel guessModel = (NovelDetailModel.GuessModel) objectList.get(position);
        if (guessModel != null) {
            String url = guessModel.getAttach_name();
            if (!TextUtils.isEmpty(url)) {
                mImgView.setImgUrl(url);
            }

            String title = guessModel.getTitle();
            if (!TextUtils.isEmpty(title)) {
                mTitleTv.setText(title);
            }

            String author = guessModel.getAuthor();
            if (!TextUtils.isEmpty(author)) {
                mAuthorTv.setText(author);
            }

        }

    }
}
