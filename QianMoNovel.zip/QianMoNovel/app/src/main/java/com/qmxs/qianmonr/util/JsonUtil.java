package com.qmxs.qianmonr.util;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/*
 * File: JsonUtil.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 11:36 AM
 */
public class JsonUtil {

    /**
     * 变成了private 如果想使用这个变量请使用 getInstance 方法
     * 方便以后重新封装，如果以前直接使用的请做修改
     */
    private static Gson gson = null;

    /**
     * 获取Gson实例
     *
     * @return
     */
    public static Gson getInstance() {
        if (gson == null) {
            gson = new Gson();
        }
        return gson;
    }


    /**
     * 将json的字符串转成List对象
     *
     * @param jsonStr
     * @param cls
     * @param <T>
     * @return
     */
    public static <T> List<T> jsonStrToObjList(String jsonStr, Class<T> cls) {
        Type type = new TypeToken<ArrayList<JsonObject>>() {
        }.getType();

        ArrayList<JsonObject> jsonObjs = getInstance().fromJson(jsonStr, type);

        List<T> objList = new ArrayList<>();

        if (jsonObjs != null && !jsonObjs.isEmpty()) {
            for (JsonObject jsonObject : jsonObjs) {
                T obj = getInstance().fromJson(jsonObject, cls);
                if (obj != null) {
                    objList.add(obj);
                }
            }
        }
        return objList;
    }

    /**
     * 对象转为string
     *
     * @param data
     * @return
     */
    public static <T> String objToJsonStr(T data) {
        try {
            return getInstance().toJson(data);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }


    /**
     * @param json
     * @param typeOfT
     * @param <T>
     * @return
     */
    public static <T> T jsonStrToObj(String json, Type typeOfT) {
        try {
            return getInstance().fromJson(json, typeOfT);
        } catch (Throwable e) {
            return null;
        }
    }

}
