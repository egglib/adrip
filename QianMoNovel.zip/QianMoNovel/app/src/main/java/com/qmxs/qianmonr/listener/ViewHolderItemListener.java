package com.qmxs.qianmonr.listener;

import android.view.View;

import com.qmxs.qianmonr.model.RenderTypeModel;

import java.util.List;

/*
 * File: ViewHolderItemListener.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 11:21 AM
} */
public interface ViewHolderItemListener {

    void onItemClick(View view, List<? extends RenderTypeModel> mObjectList, int mPosition);
}
