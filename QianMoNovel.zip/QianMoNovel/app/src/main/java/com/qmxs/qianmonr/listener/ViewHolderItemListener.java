package com.qmxs.qianmonr.listener;

import android.view.View;

/*
 * File: ViewHolderItemListener.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 11:21 AM
} */
public interface ViewHolderItemListener {
    void onItemClick(View view);
}
