package com.qmxs.qianmonr.model;

/*
 * File: BannerModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 6:40 PM
 */
public class BannerModel extends RenderTypeModel {
}
