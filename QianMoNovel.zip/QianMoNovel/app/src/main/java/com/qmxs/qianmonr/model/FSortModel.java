package com.qmxs.qianmonr.model;

/*
 * File: FSortModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 6:55 PM
 */
public class FSortModel extends RenderTypeModel {
}
