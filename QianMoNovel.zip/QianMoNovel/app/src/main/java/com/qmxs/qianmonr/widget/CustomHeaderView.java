package com.qmxs.qianmonr.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qmxs.qianmonr.R;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.internal.InternalAbstract;

/*
 * File: CustomHeaderView.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/8 5:04 PM
 */
public class CustomHeaderView extends InternalAbstract implements RefreshHeader {

    public CustomHeaderView(Context context) {
        this(context, null);
    }

    public CustomHeaderView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomHeaderView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        View view = LayoutInflater.from(context).inflate(R.layout.layout_header_view, this);
        NetworkImageView imageView = view.findViewById(R.id.imgView);
        Glide.with(context).asGif().load(R.drawable.refresh).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(imageView);
    }

}
