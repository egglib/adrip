package com.qmxs.qianmonr.model;

/*
 * File: NovelBreifModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 12:24 PM
 */
public class NovelBreifModel extends RenderTypeModel {

    /**
     * readCnt : 13.32万字
     * clsName : 仙侠
     * author : 何须无为
     * title : 斧逆天祖
     * intro : 一道神秘的流星划过天空，带着机遇和灾祸降临！
     * 看少年方玄以一己之力，凭靠着一把残破斧头，踏仙途，
     * 报血仇，灭鬼宗。
     * 再看他如何为了个承诺，斩修，斩仙，斩道祖！
     * 然后一步步走上巅峰！！！
     * <p>
     * 本书群号:308921265
     * &lt;欢迎各位书友涌加此群，讨论一些列问题！！！&gt;
     * &lt;斧逆天祖 值得期待！！！&gt;
     * cover_id : 0
     * bookId : 3
     * fullFlag : 完结
     * lastUpdate : 1416833320
     * wordCnt : 133244
     * img : http://172.104.106.185:5761/storage/def.jpg
     * tag : 仙侠 | 何须无为
     * lastChapter :
     */
    private String readCnt;
    private String clsName;
    private String author;
    private String title;
    private String intro;
    private int cover_id;
    private int bookId;
    private String fullFlag;
    private int lastUpdate;
    private int wordCnt;
    private String img;
    private String tag;
    private String lastChapter;

    public String getReadCnt() {
        return readCnt;
    }

    public void setReadCnt(String readCnt) {
        this.readCnt = readCnt;
    }

    public String getClsName() {
        return clsName;
    }

    public void setClsName(String clsName) {
        this.clsName = clsName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public int getCover_id() {
        return cover_id;
    }

    public void setCover_id(int cover_id) {
        this.cover_id = cover_id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getFullFlag() {
        return fullFlag;
    }

    public void setFullFlag(String fullFlag) {
        this.fullFlag = fullFlag;
    }

    public int getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(int lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getWordCnt() {
        return wordCnt;
    }

    public void setWordCnt(int wordCnt) {
        this.wordCnt = wordCnt;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getLastChapter() {
        return lastChapter;
    }

    public void setLastChapter(String lastChapter) {
        this.lastChapter = lastChapter;
    }
}
