package com.qmxs.qianmonr.activity.my;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: NoticeDetailActivity.java
 * Description: 公告详情
 * Author: XiaoTao
 * Create at 2019/2/26 9:44 PM
 */
public class NoticeDetailActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_notice_detail;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.notice_detail);
    }
}
