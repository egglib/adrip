package com.qmxs.qianmonr.activity.my;


import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.NoticeModel;
import com.qmxs.qianmonr.util.DateUtil;
import com.qmxs.qianmonr.util.JumpUtil;

/*
 * File: NoticeDetailActivity.java
 * Description: 公告详情
 * Author: XiaoTao
 * Create at 2019/2/26 9:44 PM
 */
public class NoticeDetailActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_notice_detail;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.notice_detail);
    }

    @Override
    protected void initView() {
        super.initView();
        NoticeModel noticeModel = JumpUtil.getNoticeInfo(this);

        TextView mTitleTv = (TextView) findViewById(R.id.tv_title);
        TextView mContentTv = (TextView) findViewById(R.id.tv_content);
        TextView mDateTv = (TextView) findViewById(R.id.tv_date);

        mTitleTv.setText(noticeModel.getTitle());
        mContentTv.setText(noticeModel.getContent());
        String date = DateUtil.format10ToYMD(noticeModel.getUpdated_at());
        mDateTv.setText(date);
    }
}
