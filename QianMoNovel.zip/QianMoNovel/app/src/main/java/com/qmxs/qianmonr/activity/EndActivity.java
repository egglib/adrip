package com.qmxs.qianmonr.activity;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.EndRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.viewholder.EndHeaderViewHolder;
import com.qmxs.qianmonr.viewholder.EndTitleViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.NovelBriefIntroViewHolder;

import java.util.ArrayList;
import java.util.List;

/*
 * File: EndActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 10:49 AM
 */
public class EndActivity extends BaseCommonTitleActivity implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview;
    }

    @Override
    protected void initView() {
        View view = createActionBarRightIcon(R.mipmap.ic_search);
        view.setOnClickListener(v -> startActivity(new Intent(EndActivity.this, SearchActivity.class)));
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        mSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);

        EndRecyclerViewAdapter endRecyclerViewAdapter = new EndRecyclerViewAdapter(this);
        mRecyclerView.setAdapter(endRecyclerViewAdapter);

        endRecyclerViewAdapter.register(1, new ItemViewHolderContainer(R.layout.item_end_header, EndHeaderViewHolder.class));
        endRecyclerViewAdapter.register(2, new ItemViewHolderContainer(R.layout.item_end_title, EndTitleViewHolder.class));
        endRecyclerViewAdapter.register(3, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, NovelBriefIntroViewHolder.class));

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();

        RenderTypeModel renderTypeModel = new RenderTypeModel();
        renderTypeModel.setRenderType(1);
        renderTypeModels.add(renderTypeModel);

        RenderTypeModel renderTypeModel1 = new RenderTypeModel();
        renderTypeModel1.setRenderType(2);
        renderTypeModels.add(renderTypeModel1);

        for (int i = 0; i < 20; i++) {
            RenderTypeModel renderTypeModel2 = new RenderTypeModel();
            renderTypeModel2.setRenderType(3);
            renderTypeModels.add(renderTypeModel2);
        }
        endRecyclerViewAdapter.addData(renderTypeModels);
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.str_end);
    }

    @Override
    public void onRefresh() {

    }
}
