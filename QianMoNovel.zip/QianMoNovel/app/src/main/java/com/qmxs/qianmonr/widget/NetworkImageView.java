package com.qmxs.qianmonr.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.load.resource.bitmap.FitCenter;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.qmxs.qianmonr.R;

import java.io.File;

/*
 * File: NetworkImageView.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/4 9:08 PM
 */
public class NetworkImageView extends AppCompatImageView {

    private Context mContext;
    private int mDefaultImageId;
    private int mErrorImageId;
    private int mRadius;
    private int mType;

    private static final int TYPE_CORNER = 0;

    private static final int TYPE_CIRCLE = 1;

    public NetworkImageView(Context context) {
        this(context, null);
    }

    public NetworkImageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public NetworkImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        mContext = context;

        if (attrs != null) {
            TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.NetworkImageView);
            mDefaultImageId = typedArray.getResourceId(R.styleable.NetworkImageView_defaultImg, 0);
            mErrorImageId = typedArray.getResourceId(R.styleable.NetworkImageView_errorImg, 0);
            mRadius = typedArray.getDimensionPixelOffset(R.styleable.NetworkImageView_radius, 0);
            mType = typedArray.getInt(R.styleable.NetworkImageView_type, -1);
            typedArray.recycle();
        }
        setImgUrl("");
    }

    /**
     * 设置默认图片
     *
     * @param defaultImageId
     */
    public void setDefaultImageId(int defaultImageId) {
        mDefaultImageId = defaultImageId;
    }

    /**
     * 设置错误图片
     *
     * @param errorImageId
     */
    public void setErrorImageId(int errorImageId) {
        mErrorImageId = errorImageId;
    }


    /**
     * 设置圆角
     *
     * @param radius
     */
    public void setRadius(int radius) {
        mRadius = radius;
    }

    /**
     * 设置类型
     *
     * @param type
     */
    public void setType(int type) {
        mType = type;
    }

    /**
     * @param url
     */
    public void setImgUrl(String url) {

        if (url == null)
            url = "";

        String newUrl = url;

        if (!newUrl.equals("")) {
            newUrl = url.replace("\\", "/");
        }

        RequestOptions requestOptions = new RequestOptions();

        if (getScaleType() == ScaleType.CENTER_CROP) {
            if (mType == TYPE_CORNER)
                requestOptions.transform(new CenterCrop(), new RoundedCorners(mRadius));
            else if (mType == TYPE_CIRCLE)
                requestOptions.transform(new CenterCrop(), new CircleCrop());
        } else {
            if (mType == TYPE_CORNER)
                requestOptions.transform(new FitCenter(), new RoundedCorners(mRadius));
            else if (mType == TYPE_CIRCLE)
                requestOptions.transform(new FitCenter(), new CircleCrop());
        }

        if (mDefaultImageId != 0)
            requestOptions.placeholder(mDefaultImageId);

        if (mErrorImageId != 0)
            requestOptions.error(mErrorImageId);

        RequestManager requestManager = Glide.with(mContext);

        String lastStr = "";

        if (newUrl.length() > 4) {
            lastStr = newUrl.substring(newUrl.length() - 4).toLowerCase();
        }

        if (lastStr.equals(".gif"))
            requestManager.asGif();
        else
            requestManager.asBitmap();

        requestManager.load(url).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).apply(requestOptions).dontAnimate().into(this);
    }

    public void setFile(File file) {

        RequestManager requestManager = Glide.with(mContext);
        RequestOptions requestOptions = new RequestOptions();

        if (getScaleType() == ScaleType.CENTER_CROP)
            requestOptions.centerCrop();
        else
            requestOptions.fitCenter();

        requestManager.load(file).apply(requestOptions).into(this);
    }

}
