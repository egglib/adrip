package com.qmxs.qianmonr.adapter;

import android.content.Context;

/*
 * File: RecommendListAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/12 3:35 PM
 */
public class RecommendListAdapter extends BaseRecyclerViewAdapter{

    public RecommendListAdapter(Context context) {
        super(context);
    }
}
