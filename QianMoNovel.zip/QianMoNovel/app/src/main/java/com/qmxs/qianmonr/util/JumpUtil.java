package com.qmxs.qianmonr.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.qmxs.qianmonr.activity.main.AuthorDetailActivity;
import com.qmxs.qianmonr.activity.main.DailyUpdateListActivity;
import com.qmxs.qianmonr.activity.main.EndActivity;
import com.qmxs.qianmonr.activity.main.NovelCatalogActivity;
import com.qmxs.qianmonr.activity.main.NovelDetailIntroActivity;
import com.qmxs.qianmonr.activity.main.RankListActivity;
import com.qmxs.qianmonr.activity.main.ReadActivity;
import com.qmxs.qianmonr.activity.main.RecommendListActivity;
import com.qmxs.qianmonr.activity.main.SortListActivity;
import com.qmxs.qianmonr.activity.my.MyShareActivity;
import com.qmxs.qianmonr.activity.my.NoticeDetailActivity;
import com.qmxs.qianmonr.model.AdBannerModel;
import com.qmxs.qianmonr.model.NoticeModel;
import com.qmxs.qianmonr.model.PersonInfoModel;
import com.qmxs.qianmonr.widget.bookview.bean.NovelInfoModel;

/*
 * File: JumpUtil.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/8 10:37 AM
 */
public class JumpUtil {

    private static final String KEY_BOOK_ID = "bookId";

    private static final String KEY_BOOK = "book";

    private static final String KEY_NOTICE = "notice";

    private static final String KEY_TITLE = "title";

    private static final String KEY_CHANNEL_ID = "channel_id";

    private static final String KEY_RANK_ID = "rank_id";

    private static final String KEY_GENDER = "gender";

    private static final String KEY_SORT_ID = "sort_id";

    private static final String KEY_AUTHOR_ID = "author_id";

    private static final String KEY_PERSON = "person";

    /**
     * 跳转到日更界面
     *
     * @param mContext
     * @param gender
     */
    public static void forwordToDailyUpdate(Context mContext, int gender) {
        PageJumpUtil.forwordToPageWithIntValue(mContext, DailyUpdateListActivity.class, KEY_GENDER, gender);
    }

    /**
     * 跳转到完结界面
     *
     * @param mContext
     * @param gender
     */
    public static void forwordToEnd(Context mContext, int gender) {
        PageJumpUtil.forwordToPageWithIntValue(mContext, EndActivity.class, KEY_GENDER, gender);
    }

    public static int getGender(Activity activity) {
        return activity.getIntent().getIntExtra(KEY_GENDER, -1);
    }

    /**
     * 跳转到小说详情界面
     *
     * @param context
     * @param bookId
     */
    public static void forwordToNovelDetail(Context context, int bookId) {
        PageJumpUtil.forwordToPageWithIntValue(context, NovelDetailIntroActivity.class, KEY_BOOK_ID, bookId);
    }

    /**
     * @param context
     * @param bookId
     */
    public static void forwordToNovelCatalog(Context context, int bookId) {
        PageJumpUtil.forwordToPageWithIntValue(context, NovelCatalogActivity.class, KEY_BOOK_ID, bookId);
    }

    /**
     * 获取bookid
     *
     * @param activity
     * @return
     */
    public static int getBookId(Activity activity) {
        return activity.getIntent().getIntExtra(KEY_BOOK_ID, -1);
    }

    /**
     * 跳转到阅读界面
     *
     * @param context
     * @param novelInfoModel
     */
    public static void forwordToReadPage(Context context, NovelInfoModel novelInfoModel) {
        PageJumpUtil.forwordToPageWithObject(context, ReadActivity.class, KEY_BOOK, novelInfoModel);
    }

    public static void forwordToNoticeDetail(Context context, NoticeModel noticeModel) {
        PageJumpUtil.forwordToPageWithObject(context, NoticeDetailActivity.class, KEY_NOTICE, noticeModel);
    }

    public static NoticeModel getNoticeInfo(Activity activity) {
        return activity.getIntent().getParcelableExtra(KEY_NOTICE);
    }

    /**
     * 跳转到作家详情界面
     *
     * @param mContext
     * @param id
     */
    public static void forwordToAuthorDetail(Context mContext, int id) {
        PageJumpUtil.forwordToPageWithIntValue(mContext, AuthorDetailActivity.class, KEY_AUTHOR_ID, id);
    }


    /**
     * @param activity
     * @return
     */
    public static NovelInfoModel getNovelInfo(Activity activity) {
        return activity.getIntent().getParcelableExtra(KEY_BOOK);
    }

    /**
     * 跳转到推荐列表界面
     *
     * @param context
     * @param title
     * @param id
     */
    public static void forwordToRecommendList(Context context, String title, String id) {
        Intent intent = new Intent(context, RecommendListActivity.class);
        intent.putExtra(KEY_TITLE, title);
        intent.putExtra(KEY_CHANNEL_ID, id);
        context.startActivity(intent);
    }


    public static void forwordToRankList(Context context, String title, int id) {
        Intent intent = new Intent(context, RankListActivity.class);
        intent.putExtra(KEY_TITLE, title);
        intent.putExtra(KEY_RANK_ID, id);
        context.startActivity(intent);
    }

    public static int getRankId(Activity activity) {
        return activity.getIntent().getIntExtra(KEY_RANK_ID, -1);
    }

    /**
     * 跳转到分类列表界面
     *
     * @param context
     * @param title
     * @param id
     */
    public static void forwordToSortList(Context context, String title, int id) {
        Intent intent = new Intent(context, SortListActivity.class);
        intent.putExtra(KEY_TITLE, title);
        intent.putExtra(KEY_SORT_ID, id);
        context.startActivity(intent);
    }

    /**
     * 获取到分类的id
     *
     * @param activity
     * @return
     */
    public static int getSortId(Activity activity) {
        return activity.getIntent().getIntExtra(KEY_SORT_ID, -1);
    }

    public static int getAuthorId(Activity activity) {
        return activity.getIntent().getIntExtra(KEY_AUTHOR_ID, -1);
    }

    /**
     * @param activity
     * @return
     */
    public static String getTitleStr(Activity activity) {
        return activity.getIntent().getStringExtra(KEY_TITLE);
    }

    /**
     * @param activity
     * @return
     */
    public static String getChannelIdStr(Activity activity) {
        return activity.getIntent().getStringExtra(KEY_CHANNEL_ID);
    }

    public static void forwordToBannerContent(Context context, AdBannerModel adBannerModel) {
        if (adBannerModel != null) {
            if (adBannerModel.getType() == 3) {
                String title = adBannerModel.getName();
                String id = adBannerModel.getJump_address();
                JumpUtil.forwordToRecommendList(context, title, id);
            } else if (adBannerModel.getType() == 2) {
                String id = adBannerModel.getJump_address();
                JumpUtil.forwordToNovelDetail(context, Integer.parseInt(id));
            }
        }
    }

    /**
     *
     */
    public static void forwordToMyShare(Context context, PersonInfoModel personInfoModel) {
        PageJumpUtil.forwordToPageWithObject(context, MyShareActivity.class, KEY_PERSON, personInfoModel);
    }

    /**
     *
     * @param activity
     * @return
     */
    public static  PersonInfoModel getPersonInfo(Activity activity){
        return activity.getIntent().getParcelableExtra(KEY_PERSON);
    }

}
