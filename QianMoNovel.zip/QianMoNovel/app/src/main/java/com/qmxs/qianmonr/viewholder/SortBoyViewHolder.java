package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.model.SortModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: SortBoyViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/22 8:02 PM
 */
public class SortBoyViewHolder extends BaseViewHolder {

    private TextView mTitleTv;
    private TextView mSubTitleTv;
    private TextView mNumberTv;
    private NetworkImageView networkImageView;
    private SortModel sortModel;

    public SortBoyViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mTitleTv = (TextView) itemView.findViewById(R.id.tv_title);
        mSubTitleTv = (TextView) itemView.findViewById(R.id.tv_sub_title);
        mNumberTv = (TextView) itemView.findViewById(R.id.tv_number);
        networkImageView = (NetworkImageView) itemView.findViewById(R.id.img_sort_header);
        itemView.setOnClickListener(v -> {
            if (sortModel != null && !TextUtils.isEmpty(sortModel.getName())) {
                JumpUtil.forwordToSortList(mContext, sortModel.getName(), sortModel.get_id());
            }
        });
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        mTitleTv.setTextColor(mContext.getResources().getColor(R.color.color_6fa6b8));
        mNumberTv.setTextColor(mContext.getResources().getColor(R.color.color_6fa6b8));
        sortModel = (SortModel) objectList.get(position);

        if (sortModel != null) {
            String title = sortModel.getName();
            if (!TextUtils.isEmpty(title)) {
                mTitleTv.setText(title);
            }

            String subTitle = sortModel.getTag();
            if (!TextUtils.isEmpty(subTitle)) {
                mSubTitleTv.setText(subTitle);
            }

            String url = sortModel.getIcon();
            if (!TextUtils.isEmpty(url)) {
                networkImageView.setImgUrl(url);
            }
        }
    }
}
