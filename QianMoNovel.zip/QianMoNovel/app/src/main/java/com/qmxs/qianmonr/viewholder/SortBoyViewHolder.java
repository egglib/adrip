package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.SortListActivity;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;

import java.util.List;

/*
 * File: SortBoyViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/22 8:02 PM
 */
public class SortBoyViewHolder extends BaseViewHolder {

    private TextView mTitleTv;
    private TextView mSubTitleTv;
    private TextView mNumberTv;
    private CardView mItemLayout;

    public SortBoyViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mTitleTv = (TextView) itemView.findViewById(R.id.tv_title);
        mSubTitleTv = (TextView) itemView.findViewById(R.id.tv_sub_title);
        mNumberTv = (TextView) itemView.findViewById(R.id.tv_number);
        mItemLayout = (CardView) itemView.findViewById(R.id.card_item);
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        mTitleTv.setTextColor(mContext.getResources().getColor(R.color.color_6fa6b8));
        mNumberTv.setTextColor(mContext.getResources().getColor(R.color.color_6fa6b8));
        mItemLayout.setOnClickListener(v -> mContext.startActivity(new Intent(mContext, SortListActivity.class)));
    }
}
