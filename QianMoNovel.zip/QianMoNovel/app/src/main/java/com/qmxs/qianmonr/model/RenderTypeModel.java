package com.qmxs.qianmonr.model;

/*
 * File: RenderTypeModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 5:24 PM
 */
public class RenderTypeModel {

    private int renderType = 0;

    public int getRenderType() {
        return renderType;
    }

    public void setRenderType(int renderType) {
        this.renderType = renderType;
    }
}
