package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;

import java.util.List;


/*
 * File: SortGirlViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/23 7:54 PM
 */
public class SortGirlViewHolder extends BaseViewHolder {

    private TextView mTitleTv;
    private TextView mSubTitleTv;
    private TextView mNumberTv;

    public SortGirlViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mTitleTv = (TextView) itemView.findViewById(R.id.tv_title);
        mSubTitleTv = (TextView) itemView.findViewById(R.id.tv_sub_title);
        mNumberTv = (TextView) itemView.findViewById(R.id.tv_number);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        mTitleTv.setTextColor(mContext.getResources().getColor(R.color.color_red_fd5e54));
        mNumberTv.setTextColor(mContext.getResources().getColor(R.color.color_red_fd5e54));
    }
}
