package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;

import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;


/*
 * File: BookshelfDesksViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 5:38 PM
 */
public class BookshelfDesksViewHolder extends BaseViewHolder {
    public BookshelfDesksViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
    }
}
