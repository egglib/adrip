package com.qmxs.qianmonr.activity.my;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: RegisterActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/16 12:08 AM
 */

public class RegisterActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_register;
    }
}
