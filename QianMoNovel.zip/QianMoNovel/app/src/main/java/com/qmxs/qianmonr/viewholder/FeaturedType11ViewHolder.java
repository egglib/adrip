package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;

import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;

/*
 * File: FeaturedType11ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 9:40 PM
 */
public class FeaturedType11ViewHolder extends BaseViewHolder {

    public FeaturedType11ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
    }
}
