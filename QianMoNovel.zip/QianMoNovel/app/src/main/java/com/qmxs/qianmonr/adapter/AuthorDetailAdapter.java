package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: AuthorDetailAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 11:45 AM
 */
public class AuthorDetailAdapter extends BaseRecyclerViewAdapter{
    public AuthorDetailAdapter(Context context) {
        super(context);
    }
}
