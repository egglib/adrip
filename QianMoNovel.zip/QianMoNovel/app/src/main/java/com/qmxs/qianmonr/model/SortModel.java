package com.qmxs.qianmonr.model;

/*
 * File: SortModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/13 12:17 PM
 */
public class SortModel extends RenderTypeModel {
    /**
     * _id : 1
     * name : 玄幻
     * tag : 东方玄幻/斗气世界
     * icon : http://img.uzhiya.com/img/38/2b3b7b9ad9e024bbd5501263e3dc78c0.png
     */

    private int _id;
    private String name;
    private String tag;
    private String icon;

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
