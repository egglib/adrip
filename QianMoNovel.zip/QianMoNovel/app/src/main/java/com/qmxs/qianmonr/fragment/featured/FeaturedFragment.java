package com.qmxs.qianmonr.fragment.featured;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.main.SearchActivity;
import com.qmxs.qianmonr.adapter.CommonPagerAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.config.Global;
import com.qmxs.qianmonr.widget.CustomViewPager;

import java.util.ArrayList;
import java.util.List;

/*
 * File: FeaturedFragment.java
 * Description:精选界面
 * Author: XiaoTao
 * Create at 2019/2/19 4:00 PM
 */
public class FeaturedFragment extends BaseLazyFragment {

    private View mTopView;

    private int[] mTabTitles = new int[]{R.string.featured, R.string.boy, R.string.girl};
    private TabLayout mTabLayout;
    private CustomViewPager mViewPager;
    private ImageView mImgSearch;

    @Override
    protected int setLayoutResId() {
        return R.layout.common_layout_tablayout_viewpager_search;
    }


    @Override
    protected void initView(View view) {
        super.initView(view);
        mTopView = view.findViewById(R.id.topView);
        mTopView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Global.STUTAS_BAR_HEIGHT));
        mTabLayout = (TabLayout) view.findViewById(R.id.tabLayout);
        mViewPager = (CustomViewPager) view.findViewById(R.id.viewPager);
        mImgSearch = (ImageView) view.findViewById(R.id.imgSearch);
        addFragments();
    }

    @Override
    protected void pageHandle() {
        mImgSearch.setOnClickListener(v -> startActivity(new Intent(getContext(), SearchActivity.class)));
    }

    private void addFragments() {
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(new FeaturedFFragment());
        fragments.add(new FeaturedBoyFragment());
        fragments.add(new FeaturedGirlFragment());

        CommonPagerAdapter commonPagerAdapter = new CommonPagerAdapter(getChildFragmentManager(), fragments);
        mViewPager.setAdapter(commonPagerAdapter);
        mViewPager.setOffscreenPageLimit(3);
        mTabLayout.setupWithViewPager(mViewPager);
        setupTabIcons();
    }

    protected void setupTabIcons() {
        try {
            for (int i = 0; i < mTabTitles.length; i++) {
                mTabLayout.getTabAt(i).setCustomView(getTabView(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private View getTabView(int position) {
        View view = getLayoutInflater().inflate(R.layout.featured_sort_tab_item_text, null);

        TextView tv_tab = view.findViewById(R.id.tv_tab_item);
        tv_tab.setText(getResources().getString(mTabTitles[position]));

        if (position == 1) {
            tv_tab.setBackgroundResource(R.drawable.boy_item_bg_selector);
        } else {
            tv_tab.setBackgroundResource(R.drawable.red_item_bg_selector);
        }

        return view;
    }

    @Override
    protected void onLazyLoad() {

    }
}
