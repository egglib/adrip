package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: FeaturedType2Adapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 4:05 PM
 */
public class FeaturedType2Adapter extends BaseRecyclerViewAdapter {

    public FeaturedType2Adapter(Context context) {
        super(context);
    }
}
