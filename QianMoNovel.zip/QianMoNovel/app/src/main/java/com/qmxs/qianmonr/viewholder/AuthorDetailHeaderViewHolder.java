package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.AuthorInfoModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;


/*
 * File: AuthorDetailHeaderViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 11:54 AM
 */
public class AuthorDetailHeaderViewHolder extends BaseViewHolder {

    private TextView mAuthorTv;
    private TextView mBriefIntroTv;
    private NetworkImageView mAuhtorAvatarImg;

    public AuthorDetailHeaderViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mAuhtorAvatarImg = (NetworkImageView) itemView.findViewById(R.id.img_auhtor_avatar);
        mAuthorTv = (TextView) itemView.findViewById(R.id.tv_author);
        mBriefIntroTv = (TextView) itemView.findViewById(R.id.tv_brief_intro);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        AuthorInfoModel authorInfoModel = (AuthorInfoModel) objectList.get(position);

        if (authorInfoModel != null) {
            String url = authorInfoModel.getImg_url();
            if (!TextUtils.isEmpty(url)) {
                mAuhtorAvatarImg.setImgUrl(url);
            }

            String name = authorInfoModel.getName();

            if (!TextUtils.isEmpty(name)) {
                mAuthorTv.setText(name);
            }

            String intro = authorInfoModel.getIntroduction();

            if (!TextUtils.isEmpty(intro)) {
                mBriefIntroTv.setText(intro);
            }

        }
    }
}
