package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;


/*
 * File: AuthorDetailHeaderViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 11:54 AM
 */
public class AuthorDetailHeaderViewHolder extends BaseViewHolder {
    private TextView mAuthorTv;
    private TextView mBriefIntroTv;

    public AuthorDetailHeaderViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mAuthorTv = (TextView) itemView.findViewById(R.id.tv_author);
        mBriefIntroTv = (TextView) itemView.findViewById(R.id.tv_brief_intro);
    }
}
