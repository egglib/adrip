package com.qmxs.qianmonr.widget.bookview.helper;

/**
 * Created by newbiechen on 17-5-27.
 */

public final class Void {
}
