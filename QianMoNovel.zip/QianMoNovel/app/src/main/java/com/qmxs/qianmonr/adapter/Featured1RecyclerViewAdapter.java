package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: Featured1RecyclerViewAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 9:38 PM
 */
public class Featured1RecyclerViewAdapter extends BaseRecyclerViewAdapter {

    public Featured1RecyclerViewAdapter(Context context) {
        super(context);
    }
}
