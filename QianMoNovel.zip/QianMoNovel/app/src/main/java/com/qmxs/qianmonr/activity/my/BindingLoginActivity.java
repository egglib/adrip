package com.qmxs.qianmonr.activity.my;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.QRCodeScanActivity;
import com.qmxs.qianmonr.activity.main.MainActivity;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;

/*
 * File: BindingLoginActivity.java
 * Description:登陆界面
 * Author: XiaoTao
 * Create at 2019/2/19 9:59 AM
 */
public class BindingLoginActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    @Override
    protected int getLayoutType() {
        return TYPE_LAYOUT_FRAME;
    }

    @Override
    protected int getTitleBackgroundColor() {
        return android.R.color.transparent;
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_binding_login;
    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.binding_login);
    }

    @Override
    protected void initView() {
        TextView mLoginBtn = findViewById(R.id.btn_login);
        mLoginBtn.setOnClickListener(this);
        View view = createActionBarRightIcon(R.mipmap.ic_scan);
        view.setOnClickListener((View v) -> startActivity(new Intent(this, QRCodeScanActivity.class)));
    }

    public void forceCrash(View view) {
        ApiManager.logout(this, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onComplete() {
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login:
                startActivity(new Intent(this, MainActivity.class));
                finish();
                break;
            default:
                break;
        }
    }
}
