package com.qmxs.qianmonr.activity.my;

import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.main.QRCodeScanActivity;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.util.PageJumpUtil;
import com.qmxs.qianmonr.util.ToastUtil;

/*
 * File: BindingLoginActivity.java
 * Description:登陆界面
 * Author: XiaoTao
 * Create at 2019/2/19 9:59 AM
 */
public class BindingLoginActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private EditText mPhoneNumberEt;
    private TextView mNextStepBtn;

    @Override
    protected int getLayoutType() {
        return TYPE_LAYOUT_FRAME;
    }

    @Override
    protected int getTitleBackgroundColor() {
        return android.R.color.transparent;
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_binding_login;
    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.binding_login);
    }

    @Override
    protected void initView() {
        View view = createActionBarRightIcon(R.mipmap.ic_scan);
        view.setOnClickListener((View v) -> startActivity(new Intent(this, QRCodeScanActivity.class)));
        mPhoneNumberEt = (EditText) findViewById(R.id.et_phone_number);
        mNextStepBtn = (TextView) findViewById(R.id.btn_next_step);
        mNextStepBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_next_step:
                nextStep();
                break;
            default:
                break;
        }
    }

    private void nextStep() {
        String phoneStr = mPhoneNumberEt.getText().toString();
        if (phoneStr.isEmpty()) {
            ToastUtil.shortShow(this, "请输入手机号码");
            return;
        }

        if (phoneStr.length() < 11) {
            ToastUtil.shortShow(this, "请输入11位手机号码");
            return;
        }
        PageJumpUtil.forwordToPage(this, RegisterActivity.class);
    }
}
