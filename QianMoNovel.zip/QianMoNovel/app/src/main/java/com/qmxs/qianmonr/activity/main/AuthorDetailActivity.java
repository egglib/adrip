package com.qmxs.qianmonr.activity.main;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.AuthorDetailAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.AuthorDetailModel;
import com.qmxs.qianmonr.model.AuthorInfoModel;
import com.qmxs.qianmonr.model.NovelBreifModel;
import com.qmxs.qianmonr.model.NovelCountModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.viewholder.AuthorDetailHeaderViewHolder;
import com.qmxs.qianmonr.viewholder.AuthorDetailTitleViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.NovelBriefIntroViewHolder;

import java.util.ArrayList;
import java.util.List;

/*
 * File: AuthorDetailActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 11:39 AM
 */
public class AuthorDetailActivity extends BaseCommonTitleActivity implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private int authorId;
    private AuthorDetailAdapter authorDetailAdapter;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview;
    }

    @Override
    protected int getLayoutType() {
        return TYPE_LAYOUT_FRAME;
    }

    @Override
    protected int getTitleBackgroundColor() {
        return R.color.color_transparent;
    }

    @Override
    protected void initView() {

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);

        //最后刷新的位置
        mSwipeRefreshLayout.setProgressViewEndTarget(false, 220);
        mSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);


        authorDetailAdapter = new AuthorDetailAdapter(this);
        mRecyclerView.setAdapter(authorDetailAdapter);

        authorDetailAdapter.register(1, new ItemViewHolderContainer(R.layout.item_author_detail_header, AuthorDetailHeaderViewHolder.class));
        authorDetailAdapter.register(2, new ItemViewHolderContainer(R.layout.item_author_detail_title, AuthorDetailTitleViewHolder.class));
        authorDetailAdapter.register(3, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, NovelBriefIntroViewHolder.class));
        authorId = JumpUtil.getAuthorId(this);
        setDialogTip("作家详情加载中...");
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        getData();
    }

    private void getData() {
        showDialog();
        ApiManager.getAuthorWorksListData(this, authorId, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                AuthorDetailModel authorDetailModel = JsonUtil.jsonStrToObj(response, AuthorDetailModel.class);

                if (authorDetailModel == null
                        || authorDetailModel.getInfo() == null
                        || authorDetailModel.getData() == null
                        || authorDetailModel.getData().getData() == null) {
                    return;
                }

                authorDetailAdapter.clearData();

                List<RenderTypeModel> renderTypeModels = new ArrayList<>();

                AuthorInfoModel authorInfoModel = authorDetailModel.getInfo();
                authorInfoModel.setRenderType(1);
                renderTypeModels.add(authorInfoModel);

                List<NovelBreifModel> novelBreifModels = authorDetailModel.getData().getData();
                int size = novelBreifModels.size();

                NovelCountModel novelCountModel = new NovelCountModel();
                novelCountModel.setRenderType(2);
                novelCountModel.setCount(size);
                renderTypeModels.add(novelCountModel);

                for (NovelBreifModel novelBreifModel : novelBreifModels) {
                    novelBreifModel.setRenderType(3);
                }
                renderTypeModels.addAll(novelBreifModels);

                authorDetailAdapter.addData(renderTypeModels);

            }

            @Override
            public void onError(Throwable e) {
                mSwipeRefreshLayout.setRefreshing(false);
                dismissDialog();
            }

            @Override
            public void onComplete() {
                dismissDialog();
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    @Override
    public void onRefresh() {
        getData();
    }
}
