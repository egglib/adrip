package com.qmxs.qianmonr.adapter;

import android.content.Context;

/*
 * File: BookshelfAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 5:05 PM
 */
public class BookshelfAdapter extends BaseRecyclerViewAdapter {


    public BookshelfAdapter(Context context) {
        super(context);
    }
}
