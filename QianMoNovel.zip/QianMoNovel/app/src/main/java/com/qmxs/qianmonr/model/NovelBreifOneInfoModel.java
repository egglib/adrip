package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: NovelBreifModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 12:24 PM
 */
public class NovelBreifOneInfoModel extends RenderTypeModel {

    /**
     * start : 1
     * limit : 20
     * data : [{"title":"驭房有术","bookId":18686,"intro":"进城闯荡的小阿姨衣锦还乡，张禹的老妈心动了，决定让儿子前去投奔。不曾想，所谓的豪宅就是一个三十平米的出租屋，更为要命的是，小阿姨经营的房产中介都快交不上房租了。风水卖房、风水装修\u2026\u2026张禹从乡下棺材铺王老头那里学来的奇门玄术竟然派上了用场，摇身一变成了王牌经纪人\u2026\u2026兄弟、美女，买房吗？阴宅阳宅都有，包装修！\r\n","author":"铁锁","readCnt":"881.08万字","clsName":"历史","lastUpdate":1541403432,"wordCnt":8810814,"tag":"历史 | 铁锁","attach_name":"http://book.wankouzi.com/book/2210/91DC2C6495E467309F8FEDD4FEF66DAA/91DC2C6495E467309F8FEDD4FEF66DAA.jpg"},{"title":"天道图书馆","bookId":626119,"intro":"心潮澎湃，无限幻想，迎风挥击千层浪，少年不败热血！","author":"横扫天涯","readCnt":"585.97万字","clsName":"玄幻","lastUpdate":1550232000,"wordCnt":5859681,"tag":"玄幻 | 横扫天涯","attach_name":"http://book.wankouzi.com/book/2462/B876DD8FB3FA120F9F980B32F36376F1/B876DD8FB3FA120F9F980B32F36376F1.jpg"},{"title":"神级龙卫","bookId":625971,"intro":"神秘高手龙潜花都，与冰山美女总裁签订婚约，但无奈被嫌弃。可怜的沈浪，只得外出觅食。不料一个个美女接踵而至，沈浪陷入各种桃运漩涡。当然，最主要的还是征服冰山女总裁。老婆大人霸道嚣张？我有法宝还不快快臣服在我的西装裤下。","author":"花幽山月","readCnt":"727.48万字","clsName":"都市","lastUpdate":1548149979,"wordCnt":7274847,"tag":"都市 | 花幽山月","attach_name":"http://book.wankouzi.com/book/69/b5a6fd2edf1f6e37b624b2bd26d1b774.jpg"},{"title":"驭房有术","bookId":626128,"intro":"你说我一个乡下进城的务工人员，怎么就成道观的观主了？青梅竹马，医生，警花，校花，环肥燕瘦，秀外慧中......这女律师竟然是拉拉？什么，已经被掰直了，我什么也没做呀？玄门有五术，山医命相卜，看张禹揭秘真正的玄门九流！一枝美人箭，隐藏着旷世奇谋......推荐票单周破5oo张，下周每天加更一张。【都市风水秘术类小说，欢迎各位大大拜读！】","author":"铁锁","readCnt":"904.59万字","clsName":"玄幻","lastUpdate":1550252696,"wordCnt":9045854,"tag":"玄幻 | 铁锁","attach_name":"http://book.wankouzi.com/book/1254/AC5C9DC77104BE2CA96BDA8A43DAB671/AC5C9DC77104BE2CA96BDA8A43DAB671.jpg"},{"title":"牧神记","bookId":19095,"intro":"大墟的祖训说，天黑，别出门。大墟残老村的老弱病残们从江边捡到了一个婴儿，取名秦牧，含辛茹苦将他养大。这一天夜幕降临，黑暗笼罩大墟，秦牧走出了家门\u2026\u2026做个春风中荡漾的反派吧！瞎子对他说。秦牧的反派之路，正在崛起！\r\n","author":"宅猪","readCnt":"482.96万字","clsName":"玄幻 - 东方玄幻","lastUpdate":1541505780,"wordCnt":4829608,"tag":"玄幻 - 东方玄幻 | 宅猪","attach_name":"http://book.wankouzi.com/book/83/17f517842b52cbf16c4b0352b98f29eb.jpg"},{"title":"全职法师","bookId":618078,"intro":"心潮澎湃，无限幻想，迎风挥击千层浪，少年不败热血！","author":"乱","readCnt":"673.9万字","clsName":"玄幻 - 异世大陆","lastUpdate":1546793522,"wordCnt":6739015,"tag":"玄幻 - 异世大陆 | 乱","attach_name":"http://book.wankouzi.com/book/1370/E2623ADE145C4D31E7BAF6E1C0566761/E2623ADE145C4D31E7BAF6E1C0566761.jpg"},{"title":"极品全能学生","bookId":400336,"intro":"夏天躺在病床上，他感觉自己就像是在做梦一样，这是一个美梦，面前站着一个女护士，透过女护士的白大褂，里面是青色的短袖、黑色的蕾丝胸罩清晰可见，白色的连体丝袜，粉色的哈喽kitty内裤。","author":"花都大少","readCnt":"1797.08万字","clsName":"校园","lastUpdate":1541579580,"wordCnt":17970846,"tag":"校园 | 花都大少","attach_name":"http://book.wankouzi.com/book/53/a18aa1edb5a93285f1d66f58c62af973.jpg"},{"title":"万古神帝","bookId":371238,"intro":"八百年前，明帝之子张若尘，被他的未婚妻池瑶公主杀死，一代天骄，就此陨落。八百年后，张若尘重新活了过来，却发现曾经杀死他的未婚妻，已经统一昆仑界，开辟出第一中央帝国，号称\u201c池瑶女皇\u201d。池瑶女皇\u2014\u2014统御天下，威临八方；青春永驻，不死不灭。张若尘站在诸皇祠堂外，望着池瑶女皇的神像，心中燃烧起熊熊的仇恨烈焰，\u201c待我重修十三年，敢叫女皇下黄泉\u201d。\r\n","author":"飞天鱼","readCnt":"836.44万字","clsName":"玄幻","lastUpdate":1541549740,"wordCnt":8364367,"tag":"玄幻 | 飞天鱼","attach_name":"http://book.wankouzi.com/book/3819/BDBC7E2DF3B04E288484DBFE065F3341/BDBC7E2DF3B04E288484DBFE065F3341.jpg"},{"title":"大王饶命","bookId":17785,"intro":"灵气复苏了，吕树眼瞅着一个个大能横空出世。然后再看一眼自己不太正经的能力，倒吸一口冷气。玩狗蛋啊！\u2026\u2026这是一个吕树依靠毒鸡汤成为大魔王的故事。\n","author":"会说话的肘子","readCnt":"321.75万字","clsName":"玄幻","lastUpdate":1541593812,"wordCnt":3217513,"tag":"玄幻 | 会说话的肘子","attach_name":"http://book.wankouzi.com/book/704/FEF7039C459E17C8509AB4B6F7EDEE6D/FEF7039C459E17C8509AB4B6F7EDEE6D.jpg"},{"title":"无限升级之最强武魂","bookId":15401,"intro":"平凡学生楚炎，异世觉醒逆天武魂、且看他如何一路逆袭、邂逅仙姿美女，碾压九界天才。天才高手，在我面前，都是用来踩的。打爆一切不服者！狂虐各路高手！踏九宵、破苍穹、逆乾坤！祭炼神鼎丹方，踏武道巅峰！执掌万界，开创无上神通，成就一代传奇，傲视古今。这一世，我要不留遗憾！九天十地！唯我独尊！为所欲为！\n","author":"热血辣椒","readCnt":"677.25万字","clsName":"玄幻","lastUpdate":1541463180,"wordCnt":6772486,"tag":"玄幻 | 热血辣椒","attach_name":"http://book.wankouzi.com/book/575/C7D80BDE2BEAE3CC5328FA4B26054A31/C7D80BDE2BEAE3CC5328FA4B26054A31.jpg"},{"title":"帝霸","bookId":614026,"intro":"天若逆我，我必封之，神若挡我，我必屠之\u2014\u2014站在万族之巅的李七夜立下豪言！\r\n    这是属于一个平凡小子崛起的故事，一个牧童走向万族之巅的征程。\r\n    在这里充满神话与奇迹，天魔建起古国，石人筑就天城，鬼族铺成仙路，魅灵修补神府\u2026\u2026\r\n","author":"厌笔萧生","readCnt":"1137.54万字","clsName":"玄幻 - 东方玄幻","lastUpdate":1541505480,"wordCnt":11375386,"tag":"玄幻 - 东方玄幻 | 厌笔萧生","attach_name":"http://book.wankouzi.com/book/56/4a17938e8e0cd6ef582a929affc96d8d.jpg"},{"title":"透视小保安","bookId":400358,"intro":"自从眼睛可以透视，在女生宿舍当保安的王皓，就过上了没羞没臊的幸福生活！\r\n","author":"元旦快乐","readCnt":"522.48万字","clsName":"都市","lastUpdate":1541964720,"wordCnt":5224755,"tag":"都市 | 元旦快乐","attach_name":"http://book.wankouzi.com/book/2480/7F4E3FEDC3BCA09A984EECC668DD57C7/7F4E3FEDC3BCA09A984EECC668DD57C7.jpg"},{"title":"最强升级系统","bookId":624452,"intro":"你见过杀鸡爆出神级血脉的没有？你见过杀蛤蟆爆出神品武技的没有？你见过整个世界的女人为他一个人男人疯狂的没有？肩扛屠龙刀，手握诸神剑，哥就问一句，\u201c妈的，还有谁？\u201d宅男龙飞带着一款狂暴系统穿越而来，杀怪升级，杀人也升级，碾压三界，打爆一切不服者！","author":"大海好多水","readCnt":"1100.17万字","clsName":"玄幻","lastUpdate":1547742655,"wordCnt":11001652,"tag":"玄幻 | 大海好多水","attach_name":"http://book.wankouzi.com/book/1547/A7422E227F22802052AB015AE35DA439/A7422E227F22802052AB015AE35DA439.jpg"},{"title":"超级神基因","bookId":15290,"intro":"未来波澜壮阔的星际时代，人类终于攻克了空间传送技术，可是当人类传送到另一端的时候，却发现那里并不是过去未来，也不是星空下的任何一片土地\u2026\u2026","author":"十二翼黑暗炽天使","readCnt":"810.39万字","clsName":"玄幻","lastUpdate":1541441633,"wordCnt":8103948,"tag":"玄幻 | 十二翼黑暗炽天使","attach_name":"http://book.wankouzi.com/book/2510/A1101035F93592D974AACA095D742EDF/A1101035F93592D974AACA095D742EDF.jpg"},{"title":"无限升级之最强武魂","bookId":626109,"intro":"平凡学生楚炎，异世觉醒逆天武魂、且看他如何一路逆袭、邂逅仙姿美女，碾压九界天才。天才高手，在我面前，都是用来踩的。打爆一切不服者！狂虐各路高手！踏九宵、破苍穹、逆乾坤！祭炼神鼎丹方，踏武道巅峰！执掌万界，开创无上神通，成就一代传奇，傲视古今。这一世，我要不留遗憾！九天十地！唯我独尊！为所欲为！","author":"热血辣椒","readCnt":"705.28万字","clsName":"玄幻","lastUpdate":1550163838,"wordCnt":7052801,"tag":"玄幻 | 热血辣椒","attach_name":"http://book.wankouzi.com/book/2177/F0CDED01D3FE72341ABF36EA51D564B7/F0CDED01D3FE72341ABF36EA51D564B7.jpg"},{"title":"明朝败家子","bookId":618077,"intro":"醒掌天下权，醉卧美人膝，五千年风华烟雨，是非成败转头空！","author":"上山打老虎额","readCnt":"373.84万字","clsName":"历史","lastUpdate":1546686164,"wordCnt":3738437,"tag":"历史 | 上山打老虎额","attach_name":"http://book.wankouzi.com/book/2995/848DC3A03D8F026ED08F544D5EAB5962/848DC3A03D8F026ED08F544D5EAB5962.jpg"},{"title":"万古天帝","bookId":394370,"intro":"天界第一战神，却因功高震主，遭挚爱背叛，死于洞房之夜。\r\n    聂天重生百年之后，再不做殿下之臣！\r\n    破苍穹，逆乾坤，凌万天，踏万界！\r\n    开启一场与当世天才争锋角逐的逆天之旅。\r\n    这一世，我要创造我的世界！\r\n    这一世，我要成为万古天帝！\r\n    这一世，我要主宰天界神域！\r\n ","author":"第一神","readCnt":"920.85万字","clsName":"玄幻 - 东方玄幻","lastUpdate":1541989500,"wordCnt":9208462,"tag":"玄幻 - 东方玄幻 | 第一神","attach_name":"http://book.wankouzi.com/book/74/83e9659c397c9bd08062ccb014326b06.jpg"},{"title":"元尊","bookId":624454,"intro":"吾有一口玄黄气，可吞天地日月星。天蚕土豆最新鼎力大作，2017年度必看玄幻小说。","author":"天蚕土豆","readCnt":"216.95万字","clsName":"玄幻","lastUpdate":1547744842,"wordCnt":2169469,"tag":"玄幻 | 天蚕土豆","attach_name":"http://book.wankouzi.com/book/322/EB365BEE44E67FDE57F76A15C46C8DEE/EB365BEE44E67FDE57F76A15C46C8DEE.jpg"},{"title":"圣墟","bookId":618116,"intro":"在破败中崛起，在寂灭中复苏。沧海成尘，雷电枯竭\u2026\u2026","author":"辰东","readCnt":"527.69万字","clsName":"玄幻","lastUpdate":1546638300,"wordCnt":5276938,"tag":"玄幻 | 辰东","attach_name":"http://book.wankouzi.com/book/2143/A83ECF124168DB8A6523FFDCCC7A4D03/A83ECF124168DB8A6523FFDCCC7A4D03.jpg"},{"title":"修真聊天群","bookId":625128,"intro":"某天，宋书航意外加入了一个仙侠中二病资深患者的交流群，里面的群友们都以\u2018道友\u2019相称，群名片都是各种府主、洞主、真人、天师。连群主走失的宠物犬都称为大妖犬离家出走。整天聊的是炼丹、闯秘境、炼功经验啥的。突然有一天，潜水良久的他突然现\u2026\u2026群里每一个群员，竟然全部是修真者，能移山倒海、长生千年的那种！啊啊啊啊，世界观在一夜间彻底崩碎啦！","author":"圣骑士的传说","readCnt":"817.66万字","clsName":"都市 - 异术超能","lastUpdate":1548454725,"wordCnt":8176605,"tag":"都市 - 异术超能 | 圣骑士的传说","attach_name":"http://book.wankouzi.com/book/1702/EE8738D6F95DB0C0B75A5C235EE1D575/EE8738D6F95DB0C0B75A5C235EE1D575.jpg"}]
     */

    private int start;
    private int limit;
    private List<NovelBreifOneModel> data;

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public List<NovelBreifOneModel> getData() {
        return data;
    }

    public void setData(List<NovelBreifOneModel> data) {
        this.data = data;
    }
}
