package com.qmxs.qianmonr.model;

/*
 * File: BookshelfHeaderNovelModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 11:57 AM
 */
public class BookshelfHeaderNovelModel {
    /**
     * id : 269686
     * bookId : 19095
     * title : 牧神记
     * cover :
     * author : 宅猪
     * intro : 大墟的祖训说，天黑，别出门。大墟残老村的老弱病残们从江边捡到了一个婴儿，取名秦牧，含辛茹苦将他养大。这一天夜幕降临，黑暗笼罩大墟，秦牧走出了家门……做个春风中荡漾的反派吧！瞎子对他说。秦牧的反派之路，正在崛起！
     * chapterCnt : 1513
     * loveCnt : 9381
     * wordCnt : 4829608
     * score : 0
     * fullFlag : 连载
     * readCnt : 482.96万字
     * downCnt : 2376
     * postDate : 0
     * retention : 6899
     * status : 1
     * created_at : 1549360993
     * lastUpdate : 1541505780
     * updated_at : 1552348800
     * deleted : 0
     * list_id : 276566
     * clsId : 1
     * clsName : 玄幻 - 东方玄幻
     * is_rec : 0
     * cover_id : 0
     * strLastCharpterTime : 3小时前更新
     * img : http://book.wankouzi.com/book/83/17f517842b52cbf16c4b0352b98f29eb.jpg
     * attach_name : http://book.wankouzi.com/book/83/17f517842b52cbf16c4b0352b98f29eb.jpg
     * realChapterNum : 1510
     * tag : 玄幻 - 东方玄幻 | 宅猪
     * lastChapter : 第一四八五章 太易沦落
     * topic_intro : 做个春风中荡漾的反派吧
     */

    private int id;
    private int bookId;
    private String title;
    private String cover;
    private String author;
    private String intro;
    private int chapterCnt;
    private int loveCnt;
    private int wordCnt;
    private int score;
    private String fullFlag;
    private String readCnt;
    private int downCnt;
    private int postDate;
    private int retention;
    private int status;
    private int created_at;
    private int lastUpdate;
    private int updated_at;
    private int deleted;
    private int list_id;
    private int clsId;
    private String clsName;
    private int is_rec;
    private int cover_id;
    private String strLastCharpterTime;
    private String img;
    private String attach_name;
    private int realChapterNum;
    private String tag;
    private String lastChapter;
    private String topic_intro;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public int getChapterCnt() {
        return chapterCnt;
    }

    public void setChapterCnt(int chapterCnt) {
        this.chapterCnt = chapterCnt;
    }

    public int getLoveCnt() {
        return loveCnt;
    }

    public void setLoveCnt(int loveCnt) {
        this.loveCnt = loveCnt;
    }

    public int getWordCnt() {
        return wordCnt;
    }

    public void setWordCnt(int wordCnt) {
        this.wordCnt = wordCnt;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getFullFlag() {
        return fullFlag;
    }

    public void setFullFlag(String fullFlag) {
        this.fullFlag = fullFlag;
    }

    public String getReadCnt() {
        return readCnt;
    }

    public void setReadCnt(String readCnt) {
        this.readCnt = readCnt;
    }

    public int getDownCnt() {
        return downCnt;
    }

    public void setDownCnt(int downCnt) {
        this.downCnt = downCnt;
    }

    public int getPostDate() {
        return postDate;
    }

    public void setPostDate(int postDate) {
        this.postDate = postDate;
    }

    public int getRetention() {
        return retention;
    }

    public void setRetention(int retention) {
        this.retention = retention;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(int lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public int getList_id() {
        return list_id;
    }

    public void setList_id(int list_id) {
        this.list_id = list_id;
    }

    public int getClsId() {
        return clsId;
    }

    public void setClsId(int clsId) {
        this.clsId = clsId;
    }

    public String getClsName() {
        return clsName;
    }

    public void setClsName(String clsName) {
        this.clsName = clsName;
    }

    public int getIs_rec() {
        return is_rec;
    }

    public void setIs_rec(int is_rec) {
        this.is_rec = is_rec;
    }

    public int getCover_id() {
        return cover_id;
    }

    public void setCover_id(int cover_id) {
        this.cover_id = cover_id;
    }

    public String getStrLastCharpterTime() {
        return strLastCharpterTime;
    }

    public void setStrLastCharpterTime(String strLastCharpterTime) {
        this.strLastCharpterTime = strLastCharpterTime;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getAttach_name() {
        return attach_name;
    }

    public void setAttach_name(String attach_name) {
        this.attach_name = attach_name;
    }

    public int getRealChapterNum() {
        return realChapterNum;
    }

    public void setRealChapterNum(int realChapterNum) {
        this.realChapterNum = realChapterNum;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getLastChapter() {
        return lastChapter;
    }

    public void setLastChapter(String lastChapter) {
        this.lastChapter = lastChapter;
    }

    public String getTopic_intro() {
        return topic_intro;
    }

    public void setTopic_intro(String topic_intro) {
        this.topic_intro = topic_intro;
    }
}
