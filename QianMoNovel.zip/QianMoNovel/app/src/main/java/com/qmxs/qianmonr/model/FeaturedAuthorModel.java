package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: FeaturedAuthorModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/13 10:43 PM
 */
public class FeaturedAuthorModel extends RenderTypeModel {

    /**
     * topicId : 0
     * type : 0
     * title : 那些年追过的大神
     * data : [{"id":1,"name":"唐家三少","introduction":"唐家三少是最具号召力的网络作家之一，也是最为成功的职业网络作家之一。唐家三少自2003年在起点进行创作以来，已在起点连载了《天珠变》、《斗罗大陆》、《琴帝》等多部作品，他的《斗罗大陆》仅在起点中文网上就超过5500万点击量，并已被改编成网页游戏和漫画。\r\n2011年，唐家三少与余华、刘震云、贾平凹等百余名传统作家一道当选为中国作家协会第八届全国委员会委员，成为第一位当选作协委员的网络作家。在2011年12月《人民文学》主办的\u201c未来大家\u201d评选中，唐家三少与张悦然、蔡骏等作家一起入围20强。\r\n2012年5月初，唐家三少以连续100个月\u201c不断更\u201d、总阅读人次达2.6亿的惊人数字申请了吉尼斯世界纪录。唐家三少也是起点中文网年收入过千万的顶尖作家之一。","is_rec":1,"cover_id":1,"num":16,"img":"http://x.lanshu.me/storage/a298ec6aa12f621a0d1be7aa2344d54d.jpg"},{"id":2,"name":"我吃西红柿","introduction":"我吃西红柿，原名朱洪志，起点专栏作家，原是苏州大学数学系05级学生，在校两年多时间发表了600多万字的网络小说，大三上学期退学从事专职写作，已出版1000多万字的小说，仅一年的收入就超过100万元。2011年5月1日与网络作家九穗禾结婚。从高中时代起就在起点中文网著有《星峰传说》。我吃西红柿自《星辰变》起，分别打破了起点中文网的收藏、点击、订阅等记录，而在订阅这项起点最重要的记录上，更是达到了4万人次订阅。随后，我吃西红柿创作的《盘龙》打破了自已《星辰变》所创下的记录。《盘龙》在13个月内创造了超过8000万点击数，是起点常规经典网络小说点击数的8倍。收藏数量最高峰时曾达到40万人次","is_rec":1,"cover_id":2,"num":10,"img":"http://x.lanshu.me/storage/c325083216655eb24212293432f8403d.jpg"},{"id":3,"name":"忘语","introduction":"忘语，原名丁凌滔，江苏省徐州市人。毕业于无锡机械制造学校，后自学完成大学法律专业，现为起点白金作家之一。曾在徐州某企业供职，现已辞职，专职网络小说创作。小说人物塑造代入感强、所涉世界磅礴恢弘、故事框架庞大精密、情节跌宕起伏扣人心悬。","is_rec":1,"cover_id":3,"num":5,"img":"http://x.lanshu.me/storage/d19e430b4c5db8e275d6ea101fd5d883.jpg"}]
     */

    private int topicId;
    private int type;
    private String title;

    private List<AuthorBreifModel> data;

    public int getTopicId() {
        return topicId;
    }

    public void setTopicId(int topicId) {
        this.topicId = topicId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<AuthorBreifModel> getData() {
        return data;
    }

    public void setData(List<AuthorBreifModel> data) {
        this.data = data;
    }

}
