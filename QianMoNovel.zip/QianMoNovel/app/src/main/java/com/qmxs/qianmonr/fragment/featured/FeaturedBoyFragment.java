package com.qmxs.qianmonr.fragment.featured;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.FFeaturedRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseFragment;
import com.qmxs.qianmonr.model.BannerModel;
import com.qmxs.qianmonr.model.FSortModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.viewholder.AuthorViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedBannerViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedBoySortViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType1ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType2ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType3ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType4ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType6ViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;

import java.util.ArrayList;
import java.util.List;

/*
 * File: FeaturedBoyFragment.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/21 4:27 PM
 */
public class FeaturedBoyFragment extends BaseFragment implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private FFeaturedRecyclerViewAdapter adapter;

    private static final int TYPE_ITEM_BANNER = -1;
    private static final int TYPE_ITEM_SORT_BOY = -3;

    private static final int TYPE_ITEM_FEATURED_0 = 0;
    private static final int TYPE_ITEM_FEATURED_1 = 1;
    private static final int TYPE_ITEM_FEATURED_2 = 2;
    private static final int TYPE_ITEM_FEATURED_3 = 3;
    private static final int TYPE_ITEM_FEATURED_4 = 4;
    private static final int TYPE_ITEM_FEATURED_6 = 6;


    @Override
    protected int setLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mRecyclerView = view.findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);

        mSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.setFocusableInTouchMode(true);
        mRecyclerView.requestFocus();

        adapter = new FFeaturedRecyclerViewAdapter(getContext());

        adapter.register(TYPE_ITEM_BANNER, new ItemViewHolderContainer(R.layout.item_banner_view, FeaturedBannerViewHolder.class));
        adapter.register(TYPE_ITEM_SORT_BOY, new ItemViewHolderContainer(R.layout.item_featuredboy_sort, FeaturedBoySortViewHolder.class));

        adapter.register(TYPE_ITEM_FEATURED_0, new ItemViewHolderContainer(R.layout.item_featured_type_1, AuthorViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_1, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType1ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_2, new ItemViewHolderContainer(R.layout.item_featured_type_2, FeaturedType2ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_3, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType3ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_4, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType4ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_6, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType6ViewHolder.class));
        mRecyclerView.setAdapter(adapter);

        List<RenderTypeModel> objects = new ArrayList<>();

        BannerModel bannerModel = new BannerModel();
        bannerModel.setRenderType(TYPE_ITEM_BANNER);

        FSortModel fSortModel = new FSortModel();
        fSortModel.setRenderType(TYPE_ITEM_SORT_BOY);

        RenderTypeModel renderTypeModel = new RenderTypeModel();
        renderTypeModel.setRenderType(TYPE_ITEM_FEATURED_0);

        RenderTypeModel renderTypeModel1 = new RenderTypeModel();
        renderTypeModel1.setRenderType(TYPE_ITEM_FEATURED_1);

        RenderTypeModel renderTypeModel2 = new RenderTypeModel();
        renderTypeModel2.setRenderType(TYPE_ITEM_FEATURED_2);

        RenderTypeModel renderTypeModel3 = new RenderTypeModel();
        renderTypeModel3.setRenderType(TYPE_ITEM_FEATURED_3);

        RenderTypeModel renderTypeModel4 = new RenderTypeModel();
        renderTypeModel4.setRenderType(TYPE_ITEM_FEATURED_4);

        RenderTypeModel renderTypeModel6 = new RenderTypeModel();
        renderTypeModel6.setRenderType(TYPE_ITEM_FEATURED_6);

        objects.add(bannerModel);
        objects.add(fSortModel);
        objects.add(renderTypeModel);
        objects.add(renderTypeModel1);
        objects.add(renderTypeModel2);
        objects.add(renderTypeModel3);
        objects.add(renderTypeModel2);
        objects.add(renderTypeModel4);
        objects.add(renderTypeModel6);
        adapter.addData(objects);

    }

    @Override
    public void onRefresh() {

    }
}
