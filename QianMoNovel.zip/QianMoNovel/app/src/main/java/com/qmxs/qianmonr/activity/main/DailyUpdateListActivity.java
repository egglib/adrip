package com.qmxs.qianmonr.activity.main;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.SortListPopularAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.NovelBreifOneModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.NovelBriefIntroOneViewHolder;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.BallPulseFooter;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.List;

/*
 * File: DailyUpdateListActivity.java
 * Description: 日更界面
 * Author: XiaoTao
 * Create at 2019/2/28 9:48 PM
 */
public class DailyUpdateListActivity extends BaseCommonTitleActivity implements OnLoadMoreListener, OnRefreshListener {

    private SmartRefreshLayout mSwipeRefreshLayout;
    private SortListPopularAdapter sortListPopularAdapter;

    private static final int RENDER_TYPE = 1;
    private boolean isLoading = false;
    private int mPageNum = 1;
    private int gender = 0;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview_outside;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.daily_update);
    }

    @Override
    protected void initView() {
        super.initView();
        View view = createActionBarRightIcon(R.mipmap.ic_search);
        view.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        RecyclerView mRecyclerView = findViewById(R.id.recyclerView);

        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        CustomHeaderView header = new CustomHeaderView(this);
        mSwipeRefreshLayout.setRefreshHeader(header);

        BallPulseFooter footer = new BallPulseFooter(this).setSpinnerStyle(SpinnerStyle.Scale);
        mSwipeRefreshLayout.setRefreshFooter(footer);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setOnLoadMoreListener(this);

        sortListPopularAdapter = new SortListPopularAdapter(this);
        sortListPopularAdapter.register(RENDER_TYPE, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, NovelBriefIntroOneViewHolder.class));

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(sortListPopularAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(0, 0, ScreenUtil.dp2px(15), 0));
        gender = JumpUtil.getGender(this);
        setDialogTip("日更数据加载中...");
    }


    private void getData() {
        if (mPageNum == 1) {
            showDialog();
        }
        ApiManager.getDailyUpdateListData(this, gender, mPageNum, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }

                List<NovelBreifOneModel> novelBreifOneModels = JsonUtil.jsonStrToObjList(response, NovelBreifOneModel.class);

                if (novelBreifOneModels == null && novelBreifOneModels.isEmpty()) {
                    mSwipeRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }

                if (mPageNum == 1) {
                    sortListPopularAdapter.clearData();
                }
                mPageNum++;

                for (int i = 0; i < novelBreifOneModels.size(); i++) {
                    NovelBreifOneModel novelBreifOneModel = novelBreifOneModels.get(i);
                    novelBreifOneModel.setRenderType(RENDER_TYPE);
                }
                sortListPopularAdapter.addData(novelBreifOneModels);
            }

            @Override
            public void onError(Throwable e) {
                isLoading = false;
                dismissDialog();
                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }
            }

            @Override
            public void onComplete() {
                isLoading = false;
                dismissDialog();
            }
        });
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        refreshData();
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        getMoreData();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        refreshData();
    }

    private void getMoreData() {
        if (!isLoading) {
            isLoading = true;
            getData();
        }
    }

    private void refreshData() {
        if (!isLoading) {
            isLoading = true;
            mPageNum = 1;
            getData();
        }
    }
}
