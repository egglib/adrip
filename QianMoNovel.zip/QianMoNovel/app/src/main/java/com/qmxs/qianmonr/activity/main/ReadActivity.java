package com.qmxs.qianmonr.activity.main;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.CategoryAdapter;
import com.qmxs.qianmonr.dialog.ReadSettingDialog;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.BrightnessUtils;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.LogUtil;
import com.qmxs.qianmonr.util.StringUtils;
import com.qmxs.qianmonr.widget.bookview.PageView;
import com.qmxs.qianmonr.widget.bookview.bean.BookChapterBean;
import com.qmxs.qianmonr.widget.bookview.bean.ChapterContentModel;
import com.qmxs.qianmonr.widget.bookview.bean.CollBookBean;
import com.qmxs.qianmonr.widget.bookview.bean.NovelInfoModel;
import com.qmxs.qianmonr.widget.bookview.bean.TxtChapter;
import com.qmxs.qianmonr.widget.bookview.helper.BookRepository;
import com.qmxs.qianmonr.widget.bookview.helper.ReadSettingManager;
import com.qmxs.qianmonr.widget.bookview.loader.PageLoader;

import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/*
 * File: ReadActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 10:23 PM
 */
public class ReadActivity extends AppCompatActivity implements View.OnClickListener, PageLoader.OnPageChangeListener, PageView.TouchListener, SeekBar.OnSeekBarChangeListener {

    private PageView mPageView;
    private PageLoader mPageLoader;
    private NovelInfoModel novelInfoModel;
    private int bookId;
    private static final int WHAT_CHAPTER = 1;

    private LinearLayout mMenuTopLl;
    private TextView mPreTv;
    private TextView mNextTv;
    private LinearLayout mCatalogLl;
    private LinearLayout mDayNightLl;
    private LinearLayout mFontLl;
    private LinearLayout mSettingLl;
    private LinearLayout mMenuBottomLl;
    private Animation mTopInAnim;
    private Animation mTopOutAnim;
    private Animation mBottomInAnim;
    private Animation mBottomOutAnim;
    private TextView mTitleTv;
    private SeekBar mChapterProgressSeekBar;
    private ImageView mDayNightImg;
    private TextView mDayNightTv;
    private boolean isNightMode = false;
    private ReadSettingDialog mSettingDialog;
    private TextView mTvPageTipRead;
    //控制屏幕常亮
    private PowerManager.WakeLock mWakeLock;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case WHAT_CHAPTER:
                    mPageLoader.openChapter();
                    break;
            }
        }
    };
    private ListView mLvCategory;
    private DrawerLayout mDrawerLayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read);
        initView();
        pageHandle();
    }

    protected void initView() {
        novelInfoModel = JumpUtil.getNovelInfo(this);

        if (novelInfoModel == null) {
            finish();
            return;
        }
        bookId = novelInfoModel.getBookId();

        LogUtil.e("novelInfoModel=bookid==" + bookId);

        mPageView = findViewById(R.id.pageView);
        CollBookBean collBookBean = new CollBookBean();
        collBookBean.setAuthor(novelInfoModel.getAuthor());
        collBookBean.setTitle(novelInfoModel.getTitle());
        collBookBean.setShortIntro(novelInfoModel.getIntro());
        collBookBean.set_id(novelInfoModel.getBookId() + "");
        collBookBean.setIsLocal(false);
        mPageLoader = mPageView.getPageLoader(collBookBean);

        mPreTv = (TextView) findViewById(R.id.tv_pre);
        mPreTv.setOnClickListener(this);

        mNextTv = (TextView) findViewById(R.id.tv_next);
        mNextTv.setOnClickListener(this);

        mCatalogLl = (LinearLayout) findViewById(R.id.ll_catalog);
        mCatalogLl.setOnClickListener(this);

        mDayNightLl = (LinearLayout) findViewById(R.id.ll_day_night);
        mDayNightLl.setOnClickListener(this);

        mFontLl = (LinearLayout) findViewById(R.id.ll_font);
        mFontLl.setOnClickListener(this);

        mSettingLl = (LinearLayout) findViewById(R.id.ll_setting);
        mSettingLl.setOnClickListener(this);

        mMenuBottomLl = (LinearLayout) findViewById(R.id.ll_menu_bottom);
        mMenuTopLl = (LinearLayout) findViewById(R.id.ll_menu_top);


        mMenuBottomLl.setVisibility(GONE);
        mMenuTopLl.setVisibility(GONE);

        mPageLoader.setOnPageChangeListener(this);
        mPageView.setTouchListener(this);
        registerBatteryTimeReceiver();
        ImageView mBackImg = (ImageView) findViewById(R.id.img_back);
        mBackImg.setOnClickListener(this);
        mTitleTv = (TextView) findViewById(R.id.tv_title);
        String title = novelInfoModel.getTitle();
        if (!TextUtils.isEmpty(title)) {
            mTitleTv.setText(title);
        }
        mChapterProgressSeekBar = (SeekBar) findViewById(R.id.seek_bar_chapter_progress);
        mChapterProgressSeekBar.setOnSeekBarChangeListener(this);

        mDayNightImg = (ImageView) findViewById(R.id.img_day_night);
        mDayNightTv = (TextView) findViewById(R.id.tv_day_night);
        mDayNightImg.setImageResource(R.mipmap.ic_night_mode);
        mDayNightTv.setText(getString(R.string.night_mode));

        mSettingDialog = new ReadSettingDialog(this, mPageLoader);

        //设置当前Activity的Brightness
        if (ReadSettingManager.getInstance().isBrightnessAuto()) {
            BrightnessUtils.setDefaultBrightness(this);
        } else {
            BrightnessUtils.setBrightness(this, ReadSettingManager.getInstance().getBrightness());
        }

        //初始化屏幕常亮类
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "keep bright");
        mTvPageTipRead = (TextView) findViewById(R.id.read_tv_page_tip);
        mLvCategory = (ListView) findViewById(R.id.read_iv_category);
        setUpAdapter();
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);

        //禁止滑动展示DrawerLayout
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        //侧边打开后，返回键能够起作用
        mDrawerLayout.setFocusableInTouchMode(false);

        mLvCategory.setOnItemClickListener(
                (parent, view, position, id) -> {
                    mDrawerLayout.closeDrawer(Gravity.START);
                    mPageLoader.skipToChapter(position);
                }
        );
    }

    private CategoryAdapter mCategoryAdapter;

    private void setUpAdapter() {
        mCategoryAdapter = new CategoryAdapter();
        mLvCategory.setAdapter(mCategoryAdapter);
        mLvCategory.setFastScrollEnabled(true);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (mMenuBottomLl.getVisibility() == VISIBLE) {
            //显示标题
            mTvPageTipRead.setText((progress + 1) + "/" + (mChapterProgressSeekBar.getMax() + 1));
            mTvPageTipRead.setVisibility(VISIBLE);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        //进行切换
        int pagePos = mChapterProgressSeekBar.getProgress();
        if (pagePos != mPageLoader.getPagePos()) {
            mPageLoader.skipToPage(pagePos);
        }

        mTvPageTipRead.setVisibility(GONE);
    }

    //初始化菜单动画
    private void initMenuAnim() {

        if (mTopInAnim == null) {
            mTopInAnim = AnimationUtils.loadAnimation(this, R.anim.slide_top_in);
        }

        if (mTopOutAnim == null) {
            mTopOutAnim = AnimationUtils.loadAnimation(this, R.anim.slide_top_out);
        }

        if (mBottomInAnim == null) {
            mBottomInAnim = AnimationUtils.loadAnimation(this, R.anim.slide_bottom_in);
        }

        if (mBottomOutAnim == null) {
            mBottomOutAnim = AnimationUtils.loadAnimation(this, R.anim.slide_bottom_out);
        }

    }


    private void toggleMenu() {
        initMenuAnim();
        if (mMenuBottomLl.getVisibility() == View.VISIBLE) {
            //关闭
            mMenuTopLl.startAnimation(mTopOutAnim);
            mMenuBottomLl.startAnimation(mBottomOutAnim);

            mMenuTopLl.setVisibility(GONE);
            mMenuBottomLl.setVisibility(GONE);
            mTvPageTipRead.setVisibility(GONE);

        } else {

            mMenuTopLl.setVisibility(View.VISIBLE);
            mMenuBottomLl.setVisibility(View.VISIBLE);

            mMenuTopLl.startAnimation(mTopInAnim);
            mMenuBottomLl.startAnimation(mBottomInAnim);

        }
    }


    private void registerBatteryTimeReceiver() {
        //注册广播
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        registerReceiver(mReceiver, intentFilter);
    }

    // 接收电池信息和时间更新的广播
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (!TextUtils.isEmpty(action)) {
                if (action.equals(Intent.ACTION_BATTERY_CHANGED)) {
                    int level = intent.getIntExtra("level", 0);
                    mPageLoader.updateBattery(level);
                }
                // 监听分钟的变化
                else if (intent.getAction().equals(Intent.ACTION_TIME_TICK)) {
                    mPageLoader.updateTime();
                }
            }
        }
    };

    private void loadChapter(int bookId, List<TxtChapter> requestChapters) {
        for (int i = 0; i < requestChapters.size(); i++) {
            String title = requestChapters.get(i).title;
            ApiManager.getChapterContentData(this, bookId, requestChapters.get(0).getBookChapterId(), new RetrofitCallback() {
                @Override
                public void onSuccess(String response) {
                    ChapterContentModel chapterContentModel = JsonUtil.jsonStrToObj(response, ChapterContentModel.class);
                    if (chapterContentModel != null) {
                        BookRepository.getInstance().saveChapterInfo(String.valueOf(bookId), title, chapterContentModel.getContent());
                    }
                }

                @Override
                public void onError(Throwable e) {

                }

                @Override
                public void onComplete() {
                    if (mPageLoader.getPageStatus() == PageLoader.STATUS_LOADING) {
                        mHandler.sendEmptyMessage(WHAT_CHAPTER);
                    }
                }
            });
        }
    }

    protected void pageHandle() {
        getChapterList();
    }

    private void getChapterList() {
        ApiManager.getChapterListData(this, novelInfoModel.getBookId(), 1, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<BookChapterBean> bookChapterBeans = JsonUtil.jsonStrToObjList(response, BookChapterBean.class);
                for (BookChapterBean bookChapter : bookChapterBeans) {
                    bookChapter.setBookId(String.valueOf(bookId));
                }
                mPageLoader.getCollBook().setBookChapters(bookChapterBeans);
                mPageLoader.refreshChapterList();
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_pre:
                if (mPageLoader != null) {
                    if (mPageLoader.skipPreChapter()) {
                        mCategoryAdapter.setChapter(mPageLoader.getChapterPos());
                    }
                }
                break;
            case R.id.tv_next:
                if (mPageLoader != null) {
                    if (mPageLoader.skipNextChapter()) {
                        mCategoryAdapter.setChapter(mPageLoader.getChapterPos());
                    }
                }
                break;
            case R.id.ll_catalog:
                //移动到指定位置
                if (mCategoryAdapter.getCount() > 0) {
                    mLvCategory.setSelection(mPageLoader.getChapterPos());
                }
                //切换菜单
                toggleMenu();
                //打开侧滑动栏
                mDrawerLayout.openDrawer(Gravity.START);
                break;
            case R.id.ll_day_night:
                if (isNightMode) {
                    isNightMode = false;
                } else {
                    isNightMode = true;
                }
                mPageLoader.setNightMode(isNightMode);
                toggleNightMode();
                break;
            case R.id.ll_font:

                break;
            case R.id.ll_setting:
                toggleMenu();
                mSettingDialog.show();
                break;
            case R.id.img_back:
                this.finish();
                break;
            default:
                break;
        }
    }

    private void toggleNightMode() {
        if (isNightMode) {
            mDayNightTv.setText(StringUtils.getString(R.string.day_mode));
            mDayNightImg.setImageResource(R.mipmap.ic_day_mode);
        } else {
            mDayNightTv.setText(StringUtils.getString(R.string.night_mode));
            mDayNightImg.setImageResource(R.mipmap.ic_night_mode);
        }
    }

    @Override
    public void onChapterChange(int pos) {
        LogUtil.e("=======onChapterChange=======");
        mCategoryAdapter.setChapter(pos);
    }

    @Override
    public void requestChapters(List<TxtChapter> requestChapters) {
        LogUtil.e("requestChapters====" + requestChapters.size());
        loadChapter(bookId, requestChapters);
        //隐藏提示
        mTvPageTipRead.setVisibility(GONE);
    }

    @Override
    public void onCategoryFinish(List<TxtChapter> chapters) {
        LogUtil.e("=======onCategoryFinish=======");
        for (TxtChapter chapter : chapters) {
            chapter.setTitle(StringUtils.convertCC(chapter.getTitle(), mPageView.getContext()));
        }
        mCategoryAdapter.refreshItems(chapters);
    }

    @Override
    public void onPageCountChange(int count) {
        LogUtil.e("=======onPageCountChange=======");
        mChapterProgressSeekBar.setMax(Math.max(0, count - 1));
        mChapterProgressSeekBar.setProgress(0);
        // 如果处于错误状态，那么就冻结使用
        if (mPageLoader.getPageStatus() == PageLoader.STATUS_LOADING
                || mPageLoader.getPageStatus() == PageLoader.STATUS_ERROR) {
            mChapterProgressSeekBar.setEnabled(false);
        } else {
            mChapterProgressSeekBar.setEnabled(true);
        }
    }

    @Override
    public void onPageChange(int pos) {
        LogUtil.e("=======onPageChange=======");
        mChapterProgressSeekBar.post(() -> mChapterProgressSeekBar.setProgress(pos));
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mReceiver != null) {
            unregisterReceiver(mReceiver);
        }
        if (mPageLoader != null) {
            mPageLoader.closeBook();
            mPageLoader = null;
        }
        if (mHandler != null) {
            mHandler.removeMessages(WHAT_CHAPTER);
        }
    }

    /**
     * 隐藏阅读界面的菜单显示
     *
     * @return 是否隐藏成功
     */
    private boolean showReadMenu() {
        if (mMenuTopLl.getVisibility() == VISIBLE) {
            toggleMenu();
            return true;
        } else if (mSettingDialog.isShowing()) {
            mSettingDialog.dismiss();
            return true;
        }
        return false;
    }

    @Override
    public boolean onTouch() {
        return !showReadMenu();
    }

    @Override
    public void center() {
        toggleMenu();
    }

    @Override
    public void prePage() {

    }

    @Override
    public void nextPage() {

    }

    @Override
    public void cancel() {

    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        boolean isVolumeTurnPage = ReadSettingManager
//                .getInstance().isVolumeTurnPage();
        boolean isVolumeTurnPage = true;
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (isVolumeTurnPage) {
                    return mPageLoader.skipToPrePage();
                }
                break;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (isVolumeTurnPage) {
                    return mPageLoader.skipToNextPage();
                }
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

}
