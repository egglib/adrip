package com.qmxs.qianmonr.activity.main;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.LogUtil;
import com.qmxs.qianmonr.util.StringUtils;
import com.qmxs.qianmonr.widget.bookview.PageView;
import com.qmxs.qianmonr.widget.bookview.bean.BookChapterBean;
import com.qmxs.qianmonr.widget.bookview.bean.ChapterContentModel;
import com.qmxs.qianmonr.widget.bookview.bean.CollBookBean;
import com.qmxs.qianmonr.widget.bookview.bean.NovelInfoModel;
import com.qmxs.qianmonr.widget.bookview.bean.TxtChapter;
import com.qmxs.qianmonr.widget.bookview.helper.BookRepository;
import com.qmxs.qianmonr.widget.bookview.loader.PageLoader;

import java.util.List;

/*
 * File: ReadActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 10:23 PM
 */
public class ReadActivity extends AppCompatActivity {

    private PageView mPageView;
    private PageLoader mPageLoader;
    private NovelInfoModel novelInfoModel;
    private int bookId;
    private static final int WHAT_CHAPTER = 1;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case WHAT_CHAPTER:
                    mPageLoader.openChapter();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read);
        initView();
        pageHandle();
    }

    protected void initView() {
        novelInfoModel = JumpUtil.getNovelInfo(this);
        if (novelInfoModel == null)
            return;
        bookId = novelInfoModel.getBookId();

        LogUtil.e("novelInfoModel=bookid==" + bookId);

        mPageView = findViewById(R.id.pageView);
        CollBookBean collBookBean = new CollBookBean();
        collBookBean.setAuthor(novelInfoModel.getAuthor());
        collBookBean.setTitle(novelInfoModel.getTitle());
        collBookBean.setShortIntro(novelInfoModel.getIntro());
        collBookBean.set_id(novelInfoModel.getBookId() + "");
        collBookBean.setIsLocal(false);
        mPageLoader = mPageView.getPageLoader(collBookBean);

        mPageLoader.setOnPageChangeListener(new PageLoader.OnPageChangeListener() {
            @Override
            public void onChapterChange(int pos) {
                LogUtil.e("=======onChapterChange=======");
            }

            @Override
            public void requestChapters(List<TxtChapter> requestChapters) {
                LogUtil.e("requestChapters====" + requestChapters.size());
                loadChapter(bookId, requestChapters);
            }

            @Override
            public void onCategoryFinish(List<TxtChapter> chapters) {
                LogUtil.e("=======onCategoryFinish=======");
                for (TxtChapter chapter : chapters) {
                    chapter.setTitle(StringUtils.convertCC(chapter.getTitle(), mPageView.getContext()));
                }
            }

            @Override
            public void onPageCountChange(int count) {
                LogUtil.e("=======onPageCountChange=======");
            }

            @Override
            public void onPageChange(int pos) {
                LogUtil.e("=======onPageChange=======");
            }
        });

        mPageView.setTouchListener(new PageView.TouchListener() {
            @Override
            public boolean onTouch() {
                return true;
            }

            @Override
            public void center() {

            }

            @Override
            public void prePage() {

            }

            @Override
            public void nextPage() {

            }

            @Override
            public void cancel() {

            }
        });
    }

    private void loadChapter(int bookId, List<TxtChapter> requestChapters) {
        for (int i = 0; i < requestChapters.size(); i++) {
            String title = requestChapters.get(i).title;
            ApiManager.getChapterContentData(this, bookId, requestChapters.get(0).getBookChapterId(), new RetrofitCallback() {
                @Override
                public void onSuccess(String response) {
                    ChapterContentModel chapterContentModel = JsonUtil.jsonStrToObj(response, ChapterContentModel.class);
                    if (chapterContentModel != null) {
                        BookRepository.getInstance().saveChapterInfo(String.valueOf(bookId), title, chapterContentModel.getContent());
                    }
                }

                @Override
                public void onError(Throwable e) {

                }

                @Override
                public void onComplete() {
                    if (mPageLoader.getPageStatus() == PageLoader.STATUS_LOADING) {
                        mHandler.sendEmptyMessage(WHAT_CHAPTER);
                    }
                }
            });
        }
    }

    protected void pageHandle() {

        ApiManager.getChapterListData(this, novelInfoModel.getBookId(), 1, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<BookChapterBean> bookChapterBeans = JsonUtil.jsonStrToObjList(response, BookChapterBean.class);
                for (BookChapterBean bookChapter : bookChapterBeans) {
                    bookChapter.setBookId(String.valueOf(bookId));
                }
                mPageLoader.getCollBook().setBookChapters(bookChapterBeans);
                mPageLoader.refreshChapterList();
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }
}
