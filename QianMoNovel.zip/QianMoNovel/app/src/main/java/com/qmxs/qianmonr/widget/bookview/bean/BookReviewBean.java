package com.qmxs.qianmonr.widget.bookview.bean;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Index;
import org.greenrobot.greendao.annotation.ToOne;

/**
 * 书籍类别讨论
 */
@Entity
public class BookReviewBean {
    /**
     * _id : 58f8f3efedaa9fe3624a87bb
     * title : 为你写一个中肯的书评，我的访客
     * book : {"_id":"530f3912651881e60d04deb3","cover":"/agent/http://img.17k.com/images/bookcover/2014/3769/18/753884-1399818238000.jpg","title":"我的26岁女房客","site":"zhuishuvip","type":"dsyn","latelyFollower":null,"retentionRatio":null}
     * helpful : {"total":1,"no":5,"yes":6}
     * likeCount : 0
     * haveImage : false
     * state : distillate
     * updated : 2017-04-21T08:20:15.991Z
     * created : 2017-04-20T17:46:23.366Z
     */
    @Id
    private String _id;
    //获取Book的外键
    private String bookId;


    private String title;
    @ToOne(joinProperty = "bookId")
    private ReviewBookBean book;
    @ToOne(joinProperty = "_id")
    private BookHelpfulBean helpful;
    private int likeCount;
    private boolean haveImage;
    @Index
    private String state;
    private String updated;
    private String created;

    @Generated(hash = 765371588)
    public BookReviewBean(String _id, String bookId, String title, int likeCount, boolean haveImage, String state, String updated, String created) {
        this._id = _id;
        this.bookId = bookId;
        this.title = title;
        this.likeCount = likeCount;
        this.haveImage = haveImage;
        this.state = state;
        this.updated = updated;
        this.created = created;
    }

    @Generated(hash = 356564766)
    public BookReviewBean() {
    }

    @Generated(hash = 168832412)
    private transient String helpful__resolvedKey;
    @Generated(hash = 1195315420)
    private transient String book__resolvedKey;
    
    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public boolean isHaveImage() {
        return haveImage;
    }

    public void setHaveImage(boolean haveImage) {
        this.haveImage = haveImage;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public boolean getHaveImage() {
        return this.haveImage;
    }

    public String getBookId() {
        return this.bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

}