package com.qmxs.qianmonr.activity.my;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.WebViewActivity;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.PersonInfoModel;
import com.qmxs.qianmonr.util.ImgUtils;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.PageJumpUtil;
import com.qmxs.qianmonr.util.QRCodeUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.ToastUtil;

import static com.qmxs.qianmonr.activity.WebViewActivity.KEY_URL;

/*
 * File: MyShareActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/19 8:35 PM
 */
public class MyShareActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private ImageView mPromotionCodeImg;
    private TextView mSavePromotionCodeBtn;
    private PersonInfoModel personInfoModel;
    private TextView mPromotionCodeTv;
    private TextView mCopyLinkBtn;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_my_share;
    }


    @Override
    protected int getTitleBackgroundColor() {
        return android.R.color.transparent;
    }

    @Override
    protected int getLayoutType() {
        return TYPE_LAYOUT_FRAME;
    }

    @Override
    protected void initView() {
        super.initView();
        mPromotionCodeImg = (ImageView) findViewById(R.id.img_promotion_code);
        mSavePromotionCodeBtn = (TextView) findViewById(R.id.btn_save_promotion_code);
        mSavePromotionCodeBtn.setOnClickListener(this);
        personInfoModel = JumpUtil.getPersonInfo(this);
        if (personInfoModel == null) {
            finish();
            return;
        }

        View view = createActionBarRightText("邀请记录");
        view.setOnClickListener(v -> {
            PageJumpUtil.forwordToPageWithStrinValue(this, WebViewActivity.class, KEY_URL, personInfoModel.getInvited_page());
        });
        mPromotionCodeTv = findViewById(R.id.tv_promotion_code);
        mPromotionCodeTv.setText(personInfoModel.getAff());

        String codeUrl = personInfoModel.getAff_url();

        if (!TextUtils.isEmpty(codeUrl)) {
            createQrcode(codeUrl);
        }

        mCopyLinkBtn = (TextView) findViewById(R.id.btn_copy_link);
        mCopyLinkBtn.setOnClickListener(this);
    }

    private Bitmap bitmap;

    private void createQrcode(String codeUrl) {
        new Thread(() -> {
            bitmap = QRCodeUtil.createQRCode(codeUrl, ScreenUtil.dp2px(150), ScreenUtil.dp2px(150), BitmapFactory.decodeResource(getResources(), R.mipmap.ic_my_login));
            if (bitmap != null) {
                runOnUiThread(() -> mPromotionCodeImg.setImageBitmap(bitmap));
            }
        }).start();
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.my_share);
    }

    @Override
    public boolean isShowTitle() {
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_copy_link:
                copyLink();
                break;
            case R.id.btn_save_promotion_code:
                //申请权限
                if (bitmap != null)
                    ImgUtils.saveImageToGallery(this, bitmap);
                break;
            default:
                break;
        }
    }

    private void copyLink() {
        String url = personInfoModel.getAff_url();
        if (!TextUtils.isEmpty(url)) {
            //获取剪贴板管理器：
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            // 创建普通字符型ClipData
            ClipData mClipData = ClipData.newPlainText("Label", url);
            // 将ClipData内容放到系统剪贴板里。
            cm.setPrimaryClip(mClipData);
            ToastUtil.shortShow(this, "复制成功,快去分享吧");
        }

    }
}
