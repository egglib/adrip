package com.qmxs.qianmonr.activity.my;

import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: MyShareActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/19 8:35 PM
 */
public class MyShareActivity extends BaseCommonTitleActivity {

    private ImageView mPromotionCodeImg;
    private TextView mSavePromotionCodeBtn;
    private TextView mShareBtn;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_my_share;
    }


    @Override
    protected int getTitleBackgroundColor() {
        return android.R.color.transparent;
    }

    @Override
    protected int getLayoutType() {
        return TYPE_LAYOUT_FRAME;
    }

    @Override
    protected void initView() {
        super.initView();
        mPromotionCodeImg = (ImageView) findViewById(R.id.img_promotion_code);
        mSavePromotionCodeBtn = (TextView) findViewById(R.id.btn_save_promotion_code);
        mShareBtn = (TextView) findViewById(R.id.btn_share);
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.my_share);
    }

    @Override
    public boolean isShowTitle() {
        return true;
    }
}
