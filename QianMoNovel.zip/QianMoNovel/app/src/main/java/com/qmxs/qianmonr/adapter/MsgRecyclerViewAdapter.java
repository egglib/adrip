package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: MsgRecyclerViewAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 9:36 PM
 */
public class MsgRecyclerViewAdapter extends BaseRecyclerViewAdapter {

    public MsgRecyclerViewAdapter(Context context) {
        super(context);
    }
}
