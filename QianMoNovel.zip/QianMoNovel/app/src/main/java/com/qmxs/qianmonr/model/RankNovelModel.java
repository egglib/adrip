package com.qmxs.qianmonr.model;

/*
 * File: RankNovelModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/13 4:29 PM
 */
public class RankNovelModel  extends RenderTypeModel{

    /**
     * bookId : 18686
     * rank_name : 人气榜
     * rank_id : 1
     * img : http://book.wankouzi.com/book/2210/91DC2C6495E467309F8FEDD4FEF66DAA/91DC2C6495E467309F8FEDD4FEF66DAA.jpg
     * title : 驭房有术
     * author : 铁锁
     * intro : 进城闯荡的小阿姨衣锦还乡，张禹的老妈心动了，决定让儿子前去投奔。不曾想，所谓的豪宅就是一个三十平米的出租屋，更为要命的是，小阿姨经营的房产中介都快交不上房租了。风水卖房、风水装修……张禹从乡下棺材铺王老头那里学来的奇门玄术竟然派上了用场，摇身一变成了王牌经纪人……兄弟、美女，买房吗？阴宅阳宅都有，包装修！
     * readCnt : 881.08万字
     * tag : 历史 | 铁锁
     */

    private int bookId;
    private String rank_name;
    private int rank_id;
    private String img;
    private String title;
    private String author;
    private String intro;
    private String readCnt;
    private String tag;

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getRank_name() {
        return rank_name;
    }

    public void setRank_name(String rank_name) {
        this.rank_name = rank_name;
    }

    public int getRank_id() {
        return rank_id;
    }

    public void setRank_id(int rank_id) {
        this.rank_id = rank_id;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public String getReadCnt() {
        return readCnt;
    }

    public void setReadCnt(String readCnt) {
        this.readCnt = readCnt;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
