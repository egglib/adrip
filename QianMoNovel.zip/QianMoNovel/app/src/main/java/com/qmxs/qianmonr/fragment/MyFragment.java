package com.qmxs.qianmonr.fragment;

import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.my.AccountManagementActivity;
import com.qmxs.qianmonr.activity.my.DownloadManagementActivity;
import com.qmxs.qianmonr.activity.my.FeedbackActivity;
import com.qmxs.qianmonr.activity.my.MyShareActivity;
import com.qmxs.qianmonr.activity.my.NoticeMsgActivity;
import com.qmxs.qianmonr.activity.my.OfficialGroupActivity;
import com.qmxs.qianmonr.activity.my.ReadHistoryActivity;
import com.qmxs.qianmonr.base.BaseFragment;
import com.qmxs.qianmonr.util.StringUtil;

/*
 * File: MyFragment.java
 * Description:我的界面
 * Author: XiaoTao
 * Create at 2019/2/19 4:04 PM
 */
public class MyFragment extends BaseFragment implements View.OnClickListener {

    private LinearLayout mMyShareLayout;
    private LinearLayout mReadHistoryLayout;
    private LinearLayout mMsgLayout;
    private LinearLayout mFeedbackLayout;
    private TextView mLoginStatusTv;
    private TextView mPhoneNumberTv;
    private TextView mReadDurationTv;
    private LinearLayout mOfficialGroupLayout;
    private LinearLayout mDownloadManagementLayout;
    private LinearLayout mCurVersionLayout;
    private LinearLayout mClearCacheLayout;
    private LinearLayout mAccountManagementLayout;

    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_my;
    }

    @Override
    protected void initView(View itemView) {
        mMyShareLayout = itemView.findViewById(R.id.layout_my_share);
        mMyShareLayout.setOnClickListener(this);
        mReadHistoryLayout = (LinearLayout) itemView.findViewById(R.id.layout_read_history);
        mReadHistoryLayout.setOnClickListener(this);
        mMsgLayout = (LinearLayout) itemView.findViewById(R.id.layout_msg);
        mMsgLayout.setOnClickListener(this);
        mFeedbackLayout = (LinearLayout) itemView.findViewById(R.id.layout_feedback);
        mFeedbackLayout.setOnClickListener(this);
        mLoginStatusTv = (TextView) itemView.findViewById(R.id.tv_login_status);
        mPhoneNumberTv = (TextView) itemView.findViewById(R.id.tv_phone_number);
        mReadDurationTv = (TextView) itemView.findViewById(R.id.tv_read_duration);
        mPhoneNumberTv.setText(StringUtil.getHidePhoneNumber("13568676969"));
        mOfficialGroupLayout = (LinearLayout) itemView.findViewById(R.id.layout_official_group);
        mOfficialGroupLayout.setOnClickListener(this);
        mDownloadManagementLayout = (LinearLayout) itemView.findViewById(R.id.layout_download_management);
        mDownloadManagementLayout.setOnClickListener(this);
        mCurVersionLayout = (LinearLayout) itemView.findViewById(R.id.layout_cur_version);
        mCurVersionLayout.setOnClickListener(this);
        mClearCacheLayout = (LinearLayout) itemView.findViewById(R.id.layout_clear_cache);
        mClearCacheLayout.setOnClickListener(this);
        mAccountManagementLayout = (LinearLayout) itemView.findViewById(R.id.layout_account_management);
        mAccountManagementLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_my_share:
                startActivity(new Intent(getActivity(), MyShareActivity.class));
                break;
            case R.id.layout_read_history:
                startActivity(new Intent(getActivity(), ReadHistoryActivity.class));
                break;
            case R.id.layout_msg:
                startActivity(new Intent(getActivity(), NoticeMsgActivity.class));
                break;
            case R.id.layout_official_group:
                startActivity(new Intent(getActivity(), OfficialGroupActivity.class));
                break;
            case R.id.layout_feedback:
                startActivity(new Intent(getActivity(), FeedbackActivity.class));
                break;
            case R.id.layout_download_management:
                startActivity(new Intent(getActivity(), DownloadManagementActivity.class));
                break;
            case R.id.layout_cur_version:
                break;
            case R.id.layout_clear_cache:
                Toast.makeText(getContext(), "清理完成", Toast.LENGTH_SHORT).show();
                break;
            case R.id.layout_account_management:
                startActivity(new Intent(getActivity(), AccountManagementActivity.class));
                break;
            default:
                break;
        }
    }

}
