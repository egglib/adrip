package com.qmxs.qianmonr.fragment;

import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.my.AccountManagementActivity;
import com.qmxs.qianmonr.activity.my.FeedbackActivity;
import com.qmxs.qianmonr.activity.my.NoticeMsgActivity;
import com.qmxs.qianmonr.activity.my.ReadHistoryActivity;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.model.PersonInfoModel;
import com.qmxs.qianmonr.model.RrobeLineModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.CacheUtil;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.LogUtil;
import com.qmxs.qianmonr.util.PageJumpUtil;
import com.qmxs.qianmonr.util.StringUtil;
import com.qmxs.qianmonr.util.SystemUtil;
import com.qmxs.qianmonr.util.ToastUtil;
import com.qmxs.qianmonr.widget.UpdateDialog;

/*
 * File: MyFragment.java
 * Description:我的界面
 * Author: XiaoTao
 * Create at 2019/2/19 4:04 PM
 */
public class MyFragment extends BaseLazyFragment implements View.OnClickListener {

    private TextView mLoginNameTv;
    private TextView mPhoneNumberTv;
    private TextView mReadDurationTv;
    private LinearLayout mOfficialGroupLayout;
    private LinearLayout mDownloadManagementLayout;
    private LinearLayout mCurVersionLayout;
    private LinearLayout mClearCacheLayout;
    private LinearLayout mAccountManagementLayout;

    private TextView mVersionNameTv;
    private TextView mCacheSizeTv;
    private ImageView mLoginStatusImg;

    private PersonInfoModel personInfoModel;
    private String cacheSize;

    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_my;
    }

    @Override
    protected void initView(View itemView) {
        LinearLayout mMyShareLayout = itemView.findViewById(R.id.layout_my_share);
        mMyShareLayout.setOnClickListener(this);
        LinearLayout mReadHistoryLayout = (LinearLayout) itemView.findViewById(R.id.layout_read_history);
        mReadHistoryLayout.setOnClickListener(this);
        LinearLayout mMsgLayout = (LinearLayout) itemView.findViewById(R.id.layout_msg);
        mMsgLayout.setOnClickListener(this);
        LinearLayout mFeedbackLayout = (LinearLayout) itemView.findViewById(R.id.layout_feedback);
        mFeedbackLayout.setOnClickListener(this);
        mLoginNameTv = (TextView) itemView.findViewById(R.id.tv_login_name);
        mPhoneNumberTv = (TextView) itemView.findViewById(R.id.tv_phone_number);
        mReadDurationTv = (TextView) itemView.findViewById(R.id.tv_read_duration);

        mOfficialGroupLayout = (LinearLayout) itemView.findViewById(R.id.layout_official_group);
        mOfficialGroupLayout.setOnClickListener(this);
//        mDownloadManagementLayout = (LinearLayout) itemView.findViewById(R.id.layout_download_management);
//        mDownloadManagementLayout.setOnClickListener(this);
        mCurVersionLayout = (LinearLayout) itemView.findViewById(R.id.layout_cur_version);
        mCurVersionLayout.setOnClickListener(this);
        mClearCacheLayout = (LinearLayout) itemView.findViewById(R.id.layout_clear_cache);
        mClearCacheLayout.setOnClickListener(this);
        mAccountManagementLayout = (LinearLayout) itemView.findViewById(R.id.layout_account_management);
        mAccountManagementLayout.setOnClickListener(this);

        mVersionNameTv = (TextView) itemView.findViewById(R.id.tv_version_name);
        mCacheSizeTv = (TextView) itemView.findViewById(R.id.tv_cache_size);

        mVersionNameTv.setText("V" + SystemUtil.getVersionName());
        mLoginStatusImg = (ImageView) itemView.findViewById(R.id.img_login_status);
        mLoginStatusImg.setImageResource(R.mipmap.ic_my_unlogin);
    }

    @Override
    protected void onLazyLoad() {

    }


    private void getCacheData() {
        new Thread(() -> {
            try {
                cacheSize = CacheUtil.getTotalCacheSize(getContext());

                if (!TextUtils.isEmpty(cacheSize)) {
                    getActivity().runOnUiThread(() -> mCacheSizeTv.setText(cacheSize));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        getData();
    }

    @Override
    public void onResume() {
        super.onResume();
        getCacheData();
    }

    private void getData() {
        ApiManager.getPersonInfoData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                personInfoModel = JsonUtil.jsonStrToObj(response, PersonInfoModel.class);

                if (personInfoModel != null) {
                    String nick = personInfoModel.getNick();

                    if (!TextUtils.isEmpty(nick)) {
                        mLoginNameTv.setText(nick);
                    }

                    String phone = personInfoModel.getPhone();

                    if (!TextUtils.isEmpty(phone)) {
                        mPhoneNumberTv.setText(StringUtil.getHidePhoneNumber(phone));
                    }
                    int loginCode = personInfoModel.getIs_login();
                    if (loginCode == 0) {
                        mLoginStatusImg.setImageResource(R.mipmap.ic_my_unlogin);
                        mLoginNameTv.setTextColor(getResources().getColor(R.color.color_79));
                    } else {
                        mLoginStatusImg.setImageResource(R.mipmap.ic_my_login);
                        mLoginNameTv.setTextColor(getResources().getColor(R.color.color_red_fd5e54));
                    }
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_my_share:
                JumpUtil.forwordToMyShare(getContext(), personInfoModel);
                break;

            case R.id.layout_read_history:
                PageJumpUtil.forwordToPage(getContext(), ReadHistoryActivity.class);
                break;
            case R.id.layout_msg:
                PageJumpUtil.forwordToPage(getContext(), NoticeMsgActivity.class);
                break;
            case R.id.layout_official_group:
                PageJumpUtil.forwordToWebBrowser(getContext(), personInfoModel.getTgNum());
                break;
            case R.id.layout_feedback:
                PageJumpUtil.forwordToPage(getContext(), FeedbackActivity.class);
                break;
//            case R.id.layout_download_management:
//                startActivity(new Intent(getActivity(), DownloadManagementActivity.class));
//                break;
            case R.id.layout_cur_version:
                checkUpdate();
                break;
            case R.id.layout_clear_cache:
                clearAppCache();
                ToastUtil.shortShow(getContext(), "清理完成");
                mCacheSizeTv.setText("");
                break;
            case R.id.layout_account_management:
                PageJumpUtil.forwordToPage(getContext(), AccountManagementActivity.class);
                break;
            default:
                break;
        }
    }

    private void clearAppCache() {
        new Thread(() -> {
            if (getContext() != null)
                CacheUtil.clearAllCache(getContext());
        }).start();

    }

    private void checkUpdate() {

        ApiManager.getRrobeLineData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                RrobeLineModel robeLineModel = JsonUtil.jsonStrToObj(response, RrobeLineModel.class);
                String version = robeLineModel.getVersion();
                if (version.equals(SystemUtil.getVersionName())) {
                    UpdateDialog dialog = new UpdateDialog(getContext());
                    String updateMsg = robeLineModel.getUpdateNotice();

                    if (!TextUtils.isEmpty(updateMsg)) {
                        dialog.setVersionContentStr(updateMsg);
                    }

                    if (!TextUtils.isEmpty(version)) {
                        dialog.setVersionNameStr("V"+version);
                    }
                    dialog.show();
                }

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });

    }

}
