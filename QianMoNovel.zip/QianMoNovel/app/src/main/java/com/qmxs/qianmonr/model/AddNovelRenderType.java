package com.qmxs.qianmonr.model;

/*
 * File: AddNovelRenderType.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 3:33 PM
 */
public class AddNovelRenderType extends RenderTypeModel {
}
