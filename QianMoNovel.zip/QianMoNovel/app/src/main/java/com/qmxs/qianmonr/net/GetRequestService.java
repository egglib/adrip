package com.qmxs.qianmonr.net;

import com.qmxs.qianmonr.model.ResponseModel;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

/*
 * File: GetRequestService.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/5 4:24 PM
 */
public interface GetRequestService {

    @POST("api")
    Observable<ResponseModel> getRequestObservable(@Body RequestBody requestBody);
}
