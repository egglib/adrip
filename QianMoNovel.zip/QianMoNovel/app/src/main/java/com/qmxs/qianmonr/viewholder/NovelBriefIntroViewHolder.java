package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.NovelDetailIntroActivity;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;

import java.util.List;

/*
 * File: SortBoyViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/22 8:02 PM
 */
public class NovelBriefIntroViewHolder extends BaseViewHolder {

    private TextView mNameTv;
    private TextView mIntroTv;
    private TextView mSortTv;
    private TextView mViewsNumberTv;
    private FrameLayout mLayoutItem;

    public NovelBriefIntroViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mNameTv = (TextView) itemView.findViewById(R.id.tv_name);
        mIntroTv = (TextView) itemView.findViewById(R.id.tv_intro);
        mSortTv = (TextView) itemView.findViewById(R.id.tv_sort);
        mViewsNumberTv = (TextView) itemView.findViewById(R.id.tv_views_number);
        mLayoutItem = (FrameLayout) itemView.findViewById(R.id.layout_item);
        mLayoutItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.startActivity(new Intent(mContext, NovelDetailIntroActivity.class));
            }
        });
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
    }
}
