package com.qmxs.qianmonr.activity.main;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.RankListAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RankInfoModel;
import com.qmxs.qianmonr.model.RankNovelModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.RankNovelViewHolder;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.List;

/*
 * File: PopularListActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 10:06 PM
 */
public class RankListActivity extends BaseCommonTitleActivity implements OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SmartRefreshLayout mSwipeRefreshLayout;
    private static final int RENDER_TYPE = 1;
    private int rankId;
    private boolean isLoading = false;
    private RankListAdapter rankListAdapter;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview_outside;
    }

    @Override
    protected void initView() {
        View view = createActionBarRightIcon(R.mipmap.ic_search);
        view.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        mRecyclerView = findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        CustomHeaderView header = new CustomHeaderView(this);
        mSwipeRefreshLayout.setRefreshHeader(header);

        String title = JumpUtil.getTitleStr(this);
        setTitleStr(title);

        rankId = JumpUtil.getRankId(this);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(0, 0, ScreenUtil.dp2px(15), 0));

        rankListAdapter = new RankListAdapter(this);
        rankListAdapter.register(RENDER_TYPE, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, RankNovelViewHolder.class));
        mRecyclerView.setAdapter(rankListAdapter);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        setDialogTip("排行榜数据加载中...");
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        refreshData();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        refreshData();
    }

    private void refreshData() {
        if (!isLoading) {
            isLoading = true;
            getData();
        }
    }

    private void getData() {
        showDialog();
        ApiManager.getRankListData(this, rankId, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                RankInfoModel rankInfoModel = JsonUtil.jsonStrToObj(response, RankInfoModel.class);
                if (rankInfoModel == null)
                    return;
                List<RankNovelModel> rankNovels = rankInfoModel.getData();
                if (rankNovels == null || rankNovels.isEmpty()) {
                    return;
                }
                for (RankNovelModel rankNovelModel : rankNovels) {
                    rankNovelModel.setRenderType(RENDER_TYPE);
                }
                rankListAdapter.addData(rankNovels);
            }

            @Override
            public void onError(Throwable e) {
                isLoading = false;
                mSwipeRefreshLayout.finishRefresh();
                dismissDialog();
            }

            @Override
            public void onComplete() {
                isLoading = false;
                mSwipeRefreshLayout.finishRefresh();
                dismissDialog();
            }
        });
    }
}
