package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;

import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;


/*
 * File: CustomerServiceReplyViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 11:32 AM
 */
public class CustomerServiceReplyViewHolder extends BaseViewHolder {

    public CustomerServiceReplyViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
    }
}
