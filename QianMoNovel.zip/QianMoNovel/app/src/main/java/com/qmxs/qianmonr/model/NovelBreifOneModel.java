package com.qmxs.qianmonr.model;

/*
 * File: NovelBreifModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/7 12:24 PM
 */
public class NovelBreifOneModel extends RenderTypeModel {

    /**
     * title : 上门女婿
     * bookId : 720508
     * intro : 韩东本身是一个“被”退伍的军人。回到都市后，被迫成为了夏家的上门女婿……
     * author : 貌似纯洁
     * readCnt : 272.93万字
     * clsName : 都市
     * lastUpdate : 1551530123
     * wordCnt : 2729269
     * tag : 都市 | 貌似纯洁
     * attach_name : http://book.wankouzi.com/book/3594/EFF1742F1112AC473E91C7099B9774A4/EFF1742F1112AC473E91C7099B9774A4.jpg
     */

    private String title;
    private int bookId;
    private String intro;
    private String author;
    private String readCnt;
    private String clsName;
    private int lastUpdate;
    private int wordCnt;
    private String tag;
    private String attach_name;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getReadCnt() {
        return readCnt;
    }

    public void setReadCnt(String readCnt) {
        this.readCnt = readCnt;
    }

    public String getClsName() {
        return clsName;
    }

    public void setClsName(String clsName) {
        this.clsName = clsName;
    }

    public int getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(int lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getWordCnt() {
        return wordCnt;
    }

    public void setWordCnt(int wordCnt) {
        this.wordCnt = wordCnt;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getAttach_name() {
        return attach_name;
    }

    public void setAttach_name(String attach_name) {
        this.attach_name = attach_name;
    }
}
