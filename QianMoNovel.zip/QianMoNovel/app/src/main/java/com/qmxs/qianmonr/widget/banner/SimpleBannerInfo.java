package com.qmxs.qianmonr.widget.banner;

/**
 * author: xiaohaibin.
 * time: 2018/11/28
 * mail:xhb_199409@163.com
 * github:https://github.com/xiaohaibin
 * describe: SimpleBannerInfo
 */
public abstract class SimpleBannerInfo implements BaseBannerInfo {
    @Override
    public String getXBannerTitle() {
        return null;
    }
}
