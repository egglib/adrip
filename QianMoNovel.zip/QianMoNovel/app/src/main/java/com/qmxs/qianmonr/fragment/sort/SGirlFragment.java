package com.qmxs.qianmonr.fragment.sort;

import android.graphics.Color;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.model.SortInfoModel;
import com.qmxs.qianmonr.model.SortModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.ColorUtil;
import com.qmxs.qianmonr.util.GridSpacingItemDecoration;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.SortGirlViewHolder;
import com.qmxs.qianmonr.widget.scrollview.CommonNestedScrollView;

import java.util.List;

/*
 * File: SGirlFragment.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/21 6:10 PM
 */
public class SGirlFragment extends BaseLazyFragment implements SwipeRefreshLayout.OnRefreshListener {

    private ImageView mBgSortHeaderImg;
    private RecyclerView mRecyclerView;
    private CommonNestedScrollView mScrollView;
    private BaseRecyclerViewAdapter baseRecyclerViewAdapter;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private static final int RENDER_TYPE = 1;

    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_sort_inner;
    }


    @Override
    protected void initView(View view) {
        super.initView(view);
        mBgSortHeaderImg = (ImageView) view.findViewById(R.id.img_bg_sort_header);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mBgSortHeaderImg.setImageResource(R.mipmap.bg_sort_girl_header);

        baseRecyclerViewAdapter = new BaseRecyclerViewAdapter(getContext());
        baseRecyclerViewAdapter.register(RENDER_TYPE, new ItemViewHolderContainer(R.layout.item_sort, SortGirlViewHolder.class));

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(baseRecyclerViewAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(2, ScreenUtil.dp2px(15), true, true, true));

        mScrollView = view.findViewById(R.id.scrollView);
        mScrollView.setNestedScrollListener((nestedScrollView, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            float alpha;
            float flagHight = 220f;
            int scrolledY = scrollY < 0 ? 0 : scrollY;

            if (scrolledY < flagHight) {
                alpha = scrolledY / flagHight;
            } else {
                alpha = 1f;
            }
            if (getParentFragment() != null) {
                ((SortFragment) getParentFragment()).mTitleLayout.setBackgroundColor(Color.parseColor("#" + ColorUtil.getColorHexStr(alpha) + "FFFFFF"));
            }
        });

        mSwipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        //最后刷新的位置
        mSwipeRefreshLayout.setProgressViewEndTarget(false, 400);
        mSwipeRefreshLayout.setColorSchemeColors(getContext().getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);
        setDialogTip("分类数据加载中...");
    }

    @Override
    protected void onLazyLoad() {
        getData();
    }

    private void getData() {
        showDialog();
        ApiManager.getSortData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<SortInfoModel> sortInfoModels = JsonUtil.jsonStrToObjList(response, SortInfoModel.class);
                if (sortInfoModels != null && !sortInfoModels.isEmpty()) {
                    List<SortModel> sortModels = sortInfoModels.get(1).getList();
                    if (sortModels != null && !sortModels.isEmpty()) {
                        for (SortModel sortModel : sortModels) {
                            sortModel.setRenderType(RENDER_TYPE);
                        }
                        baseRecyclerViewAdapter.clearData();
                        baseRecyclerViewAdapter.addData(sortModels);
                    }
                }
            }

            @Override
            public void onError(Throwable e) {
                dismissDialog();
                mSwipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onComplete() {
                dismissDialog();
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    @Override
    public void onRefresh() {
        getData();
    }
}
