package com.qmxs.qianmonr.fragment.sort;

import android.graphics.Color;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseFragment;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ColorUtil;
import com.qmxs.qianmonr.util.GridSpacingItemDecoration;
import com.qmxs.qianmonr.util.LogUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.SortGirlViewHolder;
import com.qmxs.qianmonr.widget.scrollview.CommonNestedScrollView;

import java.util.ArrayList;
import java.util.List;

/*
 * File: SGirlFragment.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/21 6:10 PM
 */
public class SGirlFragment extends BaseLazyFragment {

    private ImageView mBgSortHeaderImg;
    private RecyclerView mRecyclerView;
    private CommonNestedScrollView mScrollView;
    private BaseRecyclerViewAdapter baseRecyclerViewAdapter;

    @Override
    protected int setLayoutResId() {
        return R.layout.fragment_sort_inner;
    }


    @Override
    protected void initView(View view) {
        super.initView(view);
        mBgSortHeaderImg = (ImageView) view.findViewById(R.id.img_bg_sort_header);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mBgSortHeaderImg.setImageResource(R.mipmap.bg_sort_girl_header);

        baseRecyclerViewAdapter  = new BaseRecyclerViewAdapter(getContext());
        baseRecyclerViewAdapter.register(1, new ItemViewHolderContainer(R.layout.item_sort, SortGirlViewHolder.class));

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(baseRecyclerViewAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(2, ScreenUtil.dp2px(15), true, true,true));

        mScrollView = view.findViewById(R.id.scrollView);
        mScrollView.setNestedScrollListener((nestedScrollView, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            float alpha;
            float flagHight = 220f;
            int scrolledY = scrollY < 0 ? 0 : scrollY;

            if (scrolledY < flagHight) {
                alpha = scrolledY / flagHight;
            } else {
                alpha = 1f;
            }
            if (getParentFragment() != null) {
                ((SortFragment) getParentFragment()).mTitleLayout.setBackgroundColor(Color.parseColor("#" + ColorUtil.getColorHexStr(alpha) + "FFFFFF"));
            }
        });
    }

    @Override
    protected void onLazyLoad() {
        LogUtil.e("========girl========");
        List<RenderTypeModel> objects = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            objects.add(renderTypeModel);
        }
        baseRecyclerViewAdapter.addData(objects);
    }
}
