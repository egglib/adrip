package com.qmxs.qianmonr.activity.my;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.CustomerServiceReplyAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.viewholder.CustomerServiceReplyViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;

import java.util.ArrayList;
import java.util.List;

/*
 * File: CustomerServiceReplyActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 10:57 AM
 */
public class CustomerServiceReplyActivity extends BaseCommonTitleActivity implements SwipeRefreshLayout.OnRefreshListener {
    private RecyclerView mRecyclerView;
    private SmartRefreshLayout mSwipeRefreshLayout;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }

    @Override
    protected void initView() {
        View view = createActionBarRightText(getResources().getString(R.string.reply));
        view.setOnClickListener(v -> {
            startActivity(new Intent(this, ReplyActivity.class));
        });
        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

        mRecyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);

        CustomerServiceReplyAdapter customerServiceReplyAdapter = new CustomerServiceReplyAdapter(this);
        customerServiceReplyAdapter.register(1, new ItemViewHolderContainer(R.layout.item_customer_service_reply, CustomerServiceReplyViewHolder.class));
        mRecyclerView.setAdapter(customerServiceReplyAdapter);
        List<RenderTypeModel> objects = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            objects.add(renderTypeModel);
        }
        customerServiceReplyAdapter.addData(objects);
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.customer_service_reply);
    }

    @Override
    public void onRefresh() {

    }
}
