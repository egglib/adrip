package com.qmxs.qianmonr.activity.my;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: MyAccountActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/23 3:15 PM
 */
public class MyAccountActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private ImageView mQrCodeImg;
    private TextView mSaveQrCodeBtn;
    private TextView mSignOutBtn;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_my_account;
    }

    @Override
    protected void initView() {
        mQrCodeImg = (ImageView) findViewById(R.id.img_qr_code);
        mSaveQrCodeBtn = (TextView) findViewById(R.id.btn_save_qr_code);
        mSaveQrCodeBtn.setOnClickListener(this);
        mSignOutBtn = (TextView) findViewById(R.id.btn_sign_out);
        mSignOutBtn.setOnClickListener(this);
    }

    @Override
    protected int getLayoutType() {
        return TYPE_LAYOUT_FRAME;
    }

    @Override
    protected int getTitleBackgroundColor() {
        return android.R.color.transparent;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.my_account);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_save_qr_code:
                break;
            case R.id.btn_sign_out:
                break;
            default:
                break;
        }
    }
}
