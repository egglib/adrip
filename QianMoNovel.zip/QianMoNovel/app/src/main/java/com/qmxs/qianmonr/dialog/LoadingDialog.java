package com.qmxs.qianmonr.dialog;


import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.Window;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.widget.NetworkImageView;

public class LoadingDialog extends Dialog {

    private TextView title;
    private Context mContext;

    public LoadingDialog(Context context) {
        this(context, R.style.CustomDialog);
    }

    public LoadingDialog(Context context, int themeResId) {
        super(context, themeResId);
        mContext = context;
        initView();
    }

    private void initView() {
        setContentView(R.layout.layout_loading);
        setCancelable(false);
        setCanceledOnTouchOutside(true);
        Window window = getWindow();
        window.setGravity(Gravity.CENTER);

        title = window.findViewById(R.id.tv_loading_tip);
        NetworkImageView imageView = window.findViewById(R.id.imgView);
        imageView.requestFocus();
        Glide.with(mContext).asGif().load(R.drawable.flip_book).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(imageView);
    }

    public void setCancle(boolean cancle) {
        setCancelable(cancle);
    }

    public void setTipText(String text) {
        String tip = TextUtils.isEmpty(text) ? "数据加载中..." : text;
        title.setText(tip);
    }

}
