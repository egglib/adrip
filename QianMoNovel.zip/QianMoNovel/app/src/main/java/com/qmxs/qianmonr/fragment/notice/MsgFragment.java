package com.qmxs.qianmonr.fragment.notice;

import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.MsgRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.model.NoticeModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.MsgViewHolder;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.BallPulseFooter;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.List;

/*
 * File: MsgFragment.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 8:31 PM
 */
public class MsgFragment extends BaseLazyFragment implements OnLoadMoreListener, OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SmartRefreshLayout mSwipeRefreshLayout;
    private static final int RENDER_TYPE = 1;
    private boolean isLoading = false;
    private int mPageNum = 1;
    private MsgRecyclerViewAdapter msgRecyclerViewAdapter;

    @Override
    protected void onLazyLoad() {

    }

    @Override
    protected int setLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }


    @Override
    protected void initView(View view) {
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = (SmartRefreshLayout) view.findViewById(R.id.swipeRefreshLayout);
        CustomHeaderView header = new CustomHeaderView(getContext());
        mSwipeRefreshLayout.setRefreshHeader(header);

        BallPulseFooter footer = new BallPulseFooter(getContext()).setSpinnerStyle(SpinnerStyle.Scale);
        mSwipeRefreshLayout.setRefreshFooter(footer);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setOnLoadMoreListener(this);

        msgRecyclerViewAdapter = new MsgRecyclerViewAdapter(getContext());

        msgRecyclerViewAdapter.register(RENDER_TYPE, new ItemViewHolderContainer(R.layout.item_notice_msg, MsgViewHolder.class));
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(msgRecyclerViewAdapter);
        mRecyclerView.setHasFixedSize(true);
        setDialogTip("消息数据加载中...");
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        refreshData();
    }

    private void refreshData() {
        if (!isLoading) {
            isLoading = true;
            mPageNum = 1;
            getData();
        }
    }

    private void getData() {
        showDialog();
        ApiManager.getNoticeData(getContext(), mPageNum, 2, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }

                List<NoticeModel> noticeModels = JsonUtil.jsonStrToObjList(response, NoticeModel.class);

                if (noticeModels == null || noticeModels.isEmpty()) {
                    mSwipeRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }

                if (mPageNum == 1) {
                    msgRecyclerViewAdapter.clearData();
                }

                mPageNum++;

                for (NoticeModel noticeModel : noticeModels) {
                    noticeModel.setRenderType(RENDER_TYPE);
                }

                msgRecyclerViewAdapter.addData(noticeModels);
            }

            @Override
            public void onError(Throwable e) {
                isLoading = false;
                dismissDialog();
                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }
            }

            @Override
            public void onComplete() {
                dismissDialog();
                isLoading = false;
            }
        });
    }


    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        getMoreData();
    }

    private void getMoreData() {
        if (!isLoading) {
            isLoading = true;
            getData();
        }
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        refreshData();
    }
}
