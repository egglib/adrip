package com.qmxs.qianmonr.activity;

import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.SearchHistoryAdapter;
import com.qmxs.qianmonr.base.BaseActivity;
import com.qmxs.qianmonr.config.Global;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.SearchHistoryClearViewHolder;
import com.qmxs.qianmonr.viewholder.SearchHistoryViewHolder;
import com.qmxs.qianmonr.widget.flowlayout.FlowLayout;
import com.qmxs.qianmonr.widget.flowlayout.TagAdapter;
import com.qmxs.qianmonr.widget.flowlayout.TagFlowLayout;

import java.util.ArrayList;
import java.util.List;

/*
 * File: SearchActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/21 7:38 PM
 */
public class SearchActivity extends BaseActivity {

    private View mTopView;
    private ImageView mBackImg;
    private EditText mSearchEt;
    private LinearLayout mTitleLayout;
    private RecyclerView mRecyclerView;
    private TagFlowLayout mFlowLayout;


    @Override
    protected int setContentViewId() {
        return R.layout.activity_search;
    }

    @Override
    protected void initView() {
        mTopView = (View) findViewById(R.id.topView);
        mTopView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Global.STUTAS_BAR_HEIGHT));
        mBackImg = (ImageView) findViewById(R.id.img_back);
        mSearchEt = (EditText) findViewById(R.id.et_search);
        mTitleLayout = (LinearLayout) findViewById(R.id.layout_title);
        mBackImg.setOnClickListener(v -> {
            finish();
        });
        mRecyclerView = findViewById(R.id.recyclerView);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);

        SearchHistoryAdapter searchHistoryAdapter = new SearchHistoryAdapter(this);
        searchHistoryAdapter.register(1, new ItemViewHolderContainer(R.layout.item_search_history, SearchHistoryViewHolder.class));
        searchHistoryAdapter.register(2, new ItemViewHolderContainer(R.layout.item_search_history_clear, SearchHistoryClearViewHolder.class));
        mRecyclerView.setAdapter(searchHistoryAdapter);

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            renderTypeModels.add(renderTypeModel);
        }

        RenderTypeModel renderTypeModel = new RenderTypeModel();
        renderTypeModel.setRenderType(2);
        renderTypeModels.add(renderTypeModel);

        searchHistoryAdapter.addData(renderTypeModels);

        mFlowLayout = findViewById(R.id.flowLayout);

        List<String> tags = new ArrayList<>();
        tags.add("斗罗大陆13");
        tags.add("斗罗大陆32312");
        tags.add("斗罗大陆4123");
        tags.add("斗罗大陆4131231");
        tags.add("斗罗");
        tags.add("斗罗大陆");
        tags.add("斗罗");
        tags.add("斗罗大陆");

        mFlowLayout.setAdapter(new TagAdapter<String>(tags) {
            @Override
            public View getView(FlowLayout parent, int position, String s) {
                TextView textView = (TextView) LayoutInflater.from(SearchActivity.this).inflate(R.layout.item_tag, mFlowLayout, false);
                textView.setText(s);
                return textView;
            }
        });

        mFlowLayout.setOnTagClickListener((view, position, parent) -> {
            String text = tags.get(position);
            mSearchEt.setText(text);
            mSearchEt.setSelection(text.length());
            return false;
        });
    }
}
