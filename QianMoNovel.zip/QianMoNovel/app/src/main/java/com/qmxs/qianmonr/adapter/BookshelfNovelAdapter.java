package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: BookshelfNovelAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 6:26 PM
 */
public class BookshelfNovelAdapter extends BaseRecyclerViewAdapter{

    public BookshelfNovelAdapter(Context context) {
        super(context);
    }
}
