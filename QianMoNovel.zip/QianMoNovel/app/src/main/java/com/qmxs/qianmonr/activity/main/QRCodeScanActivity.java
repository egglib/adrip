package com.qmxs.qianmonr.activity.main;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: QRCodeScanActivity.java
 * Description: 二维码扫描界面
 * Author: XiaoTao
 * Create at 2019/2/23 12:30 PM
 */
public class QRCodeScanActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_scan;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.scan);
    }

}
