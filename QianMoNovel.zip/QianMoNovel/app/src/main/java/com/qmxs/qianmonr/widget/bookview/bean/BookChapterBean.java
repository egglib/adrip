package com.qmxs.qianmonr.widget.bookview.bean;

import java.io.Serializable;

/**
 * 书的章节链接(作为下载的进度数据)
 * 同时作为网络章节和本地章节 (没有找到更好分离两者的办法)
 */
public class BookChapterBean implements Serializable {

    /**
     * id : 39259343
     * bookChapterId : 3701813
     * name : 第一章 醉酒的娇妻
     * orderNo : 1
     */

    private int id;

    private int bookChapterId;

    private String name;

    private int orderNo;

    private String bookId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookChapterId() {
        return bookChapterId;
    }

    public void setBookChapterId(int bookChapterId) {
        this.bookChapterId = bookChapterId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }
}