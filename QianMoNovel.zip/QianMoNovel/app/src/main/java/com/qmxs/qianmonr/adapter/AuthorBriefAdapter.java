package com.qmxs.qianmonr.adapter;

import android.content.Context;

/*
 * File: AuthorBriefAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 1:37 PM
 */
public class AuthorBriefAdapter extends BaseRecyclerViewAdapter{

    public AuthorBriefAdapter(Context context) {
        super(context);
    }
}
