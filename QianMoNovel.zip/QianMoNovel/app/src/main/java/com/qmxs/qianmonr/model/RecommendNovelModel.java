package com.qmxs.qianmonr.model;

/*
 * File: RecommendNovelModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/12 3:13 PM
 */
public class RecommendNovelModel extends RenderTypeModel{

    /**
     * id : 57982
     * bookId : 13247
     * title : 从仙侠世界归来
     * cover : /568/38E335C447E284DDE67BCA902BA7537E/38E335C447E284DDE67BCA902BA7537E.jpg
     * author : 发狂的妖魔
     * intro :     五年前，萧凡突然神秘失踪，生不见人，死不见尸，没人知道他其实是去了一个广袤无边，仙神林立，妖魔横行的仙侠世界。
     五年后，萧凡已经在那个仙侠世界度过了漫长的五千年，带着一身神秘莫测，通天动地的能力，他又重新回来了。
     * chapterCnt : 2222
     * loveCnt : 547
     * wordCnt : 6499742
     * score : 0
     * fullFlag : 连载
     * readCnt : 649.97万字
     * downCnt : 89
     * postDate : 0
     * retention : 4706
     * status : 1
     * created_at : 1548417406
     * lastUpdate : 1541462400
     * updated_at : 1551830400
     * deleted : 0
     * list_id : 64862
     * clsId : 5
     * clsName : 都市
     * is_rec : 0
     * cover_id : 0
     * strLastCharpterTime : 3天前更新
     * img : http://book.wankouzi.com/book/568/38E335C447E284DDE67BCA902BA7537E/38E335C447E284DDE67BCA902BA7537E.jpg
     * attach_name : http://book.wankouzi.com/book/568/38E335C447E284DDE67BCA902BA7537E/38E335C447E284DDE67BCA902BA7537E.jpg
     * realChapterNum : 2222
     * tag : 都市 | 发狂的妖魔
     * lastChapter : 第2221章 齐聚天相岛核心之地
     */

    private int id;
    private int bookId;
    private String title;
    private String cover;
    private String author;
    private String intro;
    private int chapterCnt;
    private int loveCnt;
    private int wordCnt;
    private int score;
    private String fullFlag;
    private String readCnt;
    private int downCnt;
    private int postDate;
    private int retention;
    private int status;
    private int created_at;
    private int lastUpdate;
    private int updated_at;
    private int deleted;
    private int list_id;
    private int clsId;
    private String clsName;
    private int is_rec;
    private int cover_id;
    private String strLastCharpterTime;
    private String img;
    private String attach_name;
    private int realChapterNum;
    private String tag;
    private String lastChapter;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public int getChapterCnt() {
        return chapterCnt;
    }

    public void setChapterCnt(int chapterCnt) {
        this.chapterCnt = chapterCnt;
    }

    public int getLoveCnt() {
        return loveCnt;
    }

    public void setLoveCnt(int loveCnt) {
        this.loveCnt = loveCnt;
    }

    public int getWordCnt() {
        return wordCnt;
    }

    public void setWordCnt(int wordCnt) {
        this.wordCnt = wordCnt;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getFullFlag() {
        return fullFlag;
    }

    public void setFullFlag(String fullFlag) {
        this.fullFlag = fullFlag;
    }

    public String getReadCnt() {
        return readCnt;
    }

    public void setReadCnt(String readCnt) {
        this.readCnt = readCnt;
    }

    public int getDownCnt() {
        return downCnt;
    }

    public void setDownCnt(int downCnt) {
        this.downCnt = downCnt;
    }

    public int getPostDate() {
        return postDate;
    }

    public void setPostDate(int postDate) {
        this.postDate = postDate;
    }

    public int getRetention() {
        return retention;
    }

    public void setRetention(int retention) {
        this.retention = retention;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(int lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public int getList_id() {
        return list_id;
    }

    public void setList_id(int list_id) {
        this.list_id = list_id;
    }

    public int getClsId() {
        return clsId;
    }

    public void setClsId(int clsId) {
        this.clsId = clsId;
    }

    public String getClsName() {
        return clsName;
    }

    public void setClsName(String clsName) {
        this.clsName = clsName;
    }

    public int getIs_rec() {
        return is_rec;
    }

    public void setIs_rec(int is_rec) {
        this.is_rec = is_rec;
    }

    public int getCover_id() {
        return cover_id;
    }

    public void setCover_id(int cover_id) {
        this.cover_id = cover_id;
    }

    public String getStrLastCharpterTime() {
        return strLastCharpterTime;
    }

    public void setStrLastCharpterTime(String strLastCharpterTime) {
        this.strLastCharpterTime = strLastCharpterTime;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getAttach_name() {
        return attach_name;
    }

    public void setAttach_name(String attach_name) {
        this.attach_name = attach_name;
    }

    public int getRealChapterNum() {
        return realChapterNum;
    }

    public void setRealChapterNum(int realChapterNum) {
        this.realChapterNum = realChapterNum;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getLastChapter() {
        return lastChapter;
    }

    public void setLastChapter(String lastChapter) {
        this.lastChapter = lastChapter;
    }
}
