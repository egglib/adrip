package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.PopularListRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RankModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: PopularListViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 8:55 PM
 */
public class PopularListViewHolder extends BaseViewHolder {

    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private NetworkImageView mImgMore;
    private static final int RENDER_TYPE = 1;
    private PopularListRecyclerViewAdapter popularListRecyclerViewAdapter;
    private RankModel rankModel;

    public PopularListViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mMoreTitleTv = itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);
        mImgMore = itemView.findViewById(R.id.img_more);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(15), ScreenUtil.dp2px(15), ScreenUtil.dp2px(5), ScreenUtil.dp2px(10)));

        popularListRecyclerViewAdapter = new PopularListRecyclerViewAdapter(mContext);
        popularListRecyclerViewAdapter.register(RENDER_TYPE, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, PopularListInnerViewHolder.class));
        mRecyclerView.setAdapter(popularListRecyclerViewAdapter);


        mMoreLayout.setOnClickListener(v -> {
            JumpUtil.forwordToRankList(mContext, rankModel.getRankName(), rankModel.getRankId());
        });

    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        rankModel = (RankModel) objectList.get(position);
        if (rankModel != null) {
            String title = rankModel.getRankName();
            if (!TextUtils.isEmpty(title)) {
                mMoreTitleTv.setText(title);
            }

            String url = rankModel.getIcon();
            if (!TextUtils.isEmpty(url)) {
                mImgMore.setImgUrl(url);
            }

            List<RankModel.NovelInfo> novelInfos = rankModel.getData();
            for (RankModel.NovelInfo novelInfo : novelInfos) {
                novelInfo.setRenderType(RENDER_TYPE);
            }

            popularListRecyclerViewAdapter.clearData();
            popularListRecyclerViewAdapter.addData(novelInfos);
        }

    }
}
