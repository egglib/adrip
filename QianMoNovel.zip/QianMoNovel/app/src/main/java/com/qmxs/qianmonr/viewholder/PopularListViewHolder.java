package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.MostPopularListActivity;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.PopularListRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;

import java.util.ArrayList;
import java.util.List;

/*
 * File: PopularListViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 8:55 PM
 */
public class PopularListViewHolder extends BaseViewHolder {

    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;

    public PopularListViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = (RecyclerView) itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(15), ScreenUtil.dp2px(15), ScreenUtil.dp2px(0), ScreenUtil.dp2px(10)));

        PopularListRecyclerViewAdapter popularListRecyclerViewAdapter = new PopularListRecyclerViewAdapter(mContext);
        popularListRecyclerViewAdapter.register(1, new ItemViewHolderContainer(R.layout.item_novel_img_tv, FeaturedType41ViewHolder.class));
        mRecyclerView.setAdapter(popularListRecyclerViewAdapter);

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();

        for (int i = 0; i < 20; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            renderTypeModels.add(renderTypeModel);
        }
        popularListRecyclerViewAdapter.addData(renderTypeModels);
        mMoreLayout.setOnClickListener(v -> {
            mContext.startActivity(new Intent(mContext, MostPopularListActivity.class));
        });

    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        int renderType = objectList.get(position).getRenderType();

        if (renderType == 1) {
            mMoreTitleTv.setText("人气榜");

        } else if (renderType == 2) {
            mMoreTitleTv.setText("男榜");
        } else if (renderType == 3) {
            mMoreTitleTv.setText("女榜");
        } else if (renderType == 4) {
            mMoreTitleTv.setText("完结榜");
        } else if (renderType == 5) {
            mMoreTitleTv.setText("收藏榜");
        }
    }
}
