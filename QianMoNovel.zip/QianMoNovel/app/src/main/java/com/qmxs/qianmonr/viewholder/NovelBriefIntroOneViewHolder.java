package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.NovelBreifOneModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: SortBoyViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/22 8:02 PM
 */
public class NovelBriefIntroOneViewHolder extends BaseViewHolder {

    private TextView mNameTv;
    private TextView mIntroTv;
    private TextView mTagTv;
    private TextView mViewsNumberTv;
    private NetworkImageView mCoverImg;

    public NovelBriefIntroOneViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mNameTv = (TextView) itemView.findViewById(R.id.tv_name);
        mIntroTv = (TextView) itemView.findViewById(R.id.tv_intro);
        mTagTv = (TextView) itemView.findViewById(R.id.tv_tag);
        mViewsNumberTv = (TextView) itemView.findViewById(R.id.tv_views_number);
        mCoverImg = (NetworkImageView) itemView.findViewById(R.id.img_cover);
        itemView.setOnClickListener(v -> {
            JumpUtil.forwordToNovelDetail(mContext, ((NovelBreifOneModel) mObjectList.get(mPosition)).getBookId());
        });
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        NovelBreifOneModel novelBreifModel = (NovelBreifOneModel) objectList.get(position);

        if (novelBreifModel != null) {
            String imgUrl = novelBreifModel.getAttach_name();

            if (!TextUtils.isEmpty(imgUrl)) {
                mCoverImg.setImgUrl(imgUrl);
            }

            String title = novelBreifModel.getTitle();
            if (!TextUtils.isEmpty(title)) {
                mNameTv.setText(title);
            }

            String intro = novelBreifModel.getIntro();
            if (!TextUtils.isEmpty(intro)) {
                mIntroTv.setText(intro);
            }

            String tag = novelBreifModel.getTag();
            if (!TextUtils.isEmpty(tag)) {
                mTagTv.setText(tag);
            }

            String readCount = novelBreifModel.getReadCnt();
            if (!TextUtils.isEmpty(readCount)) {
                mViewsNumberTv.setText(readCount);
            }
        }
    }
}
