package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: BookshelfHeaderInfoModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 11:54 AM
 */
public class BookshelfHeaderInfoModel extends RenderTypeModel{

    /**
     * start : 1
     * data : [{"id":269686,"bookId":19095,"title":"牧神记","cover":"","author":"宅猪","intro":"大墟的祖训说，天黑，别出门。大墟残老村的老弱病残们从江边捡到了一个婴儿，取名秦牧，含辛茹苦将他养大。这一天夜幕降临，黑暗笼罩大墟，秦牧走出了家门\u2026\u2026做个春风中荡漾的反派吧！瞎子对他说。秦牧的反派之路，正在崛起！\r\n","chapterCnt":1513,"loveCnt":9381,"wordCnt":4829608,"score":0,"fullFlag":"连载","readCnt":"482.96万字","downCnt":2376,"postDate":0,"retention":6899,"status":1,"created_at":1549360993,"lastUpdate":1541505780,"updated_at":1552348800,"deleted":0,"list_id":276566,"clsId":1,"clsName":"玄幻 - 东方玄幻","is_rec":0,"cover_id":0,"strLastCharpterTime":"3小时前更新","img":"http://book.wankouzi.com/book/83/17f517842b52cbf16c4b0352b98f29eb.jpg","attach_name":"http://book.wankouzi.com/book/83/17f517842b52cbf16c4b0352b98f29eb.jpg","realChapterNum":1510,"tag":"玄幻 - 东方玄幻 | 宅猪","lastChapter":"第一四八五章 太易沦落","topic_intro":"做个春风中荡漾的反派吧"}]
     */

    private String start;
    private List<BookshelfHeaderNovelModel> data;

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public List<BookshelfHeaderNovelModel> getData() {
        return data;
    }

    public void setData(List<BookshelfHeaderNovelModel> data) {
        this.data = data;
    }
}
