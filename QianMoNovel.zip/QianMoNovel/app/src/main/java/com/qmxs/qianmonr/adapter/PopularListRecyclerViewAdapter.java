package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: PopularListRecyclerViewAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 9:01 PM
 */
public class PopularListRecyclerViewAdapter extends BaseRecyclerViewAdapter{

    public PopularListRecyclerViewAdapter(Context context) {
        super(context);
    }
}
