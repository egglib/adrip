package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.BookshelfNovelAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.BookshelfNovelContainer;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;

import java.util.List;

/*
 * File: BookshelfNovelContainerViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 6:21 PM
 */
public class BookshelfNovelContainerViewHolder extends BaseViewHolder {

    private RecyclerView mRecyclerView;
    private BookshelfNovelAdapter bookshelfNovelAdapter;
    public static final int TYPE_BOOKSHELF_NOVEL_INNER = 11;
    public static final int TYPE_BOOKSHELF_NOVEL_INNER_ADD = 12;

    public BookshelfNovelContainerViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);

        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.setFocusable(false);
        mRecyclerView.requestFocus();
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(20), 0));

        bookshelfNovelAdapter = new BookshelfNovelAdapter(mContext);
        bookshelfNovelAdapter.register(TYPE_BOOKSHELF_NOVEL_INNER, new ItemViewHolderContainer(R.layout.item_bookshelf_novel, BookshelfNovelViewHolder.class));
        bookshelfNovelAdapter.register(TYPE_BOOKSHELF_NOVEL_INNER_ADD, new ItemViewHolderContainer(R.layout.item_bookshelf_novel_add, BookshelfNovelAddViewHolder.class));
        mRecyclerView.setAdapter(bookshelfNovelAdapter);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        BookshelfNovelContainer bookshelfNovelContainer = (BookshelfNovelContainer) objectList.get(position);
        if (bookshelfNovelContainer != null && bookshelfNovelContainer.getRenderTypeModels() != null) {
            bookshelfNovelAdapter.clearData();
            bookshelfNovelAdapter.addData(bookshelfNovelContainer.getRenderTypeModels());
        }
    }
}
