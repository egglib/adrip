package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.BookshelfNovelAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;

import java.util.ArrayList;
import java.util.List;

/*
 * File: BookshelfNovelContainerViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 6:21 PM
 */
public class BookshelfNovelContainerViewHolder extends BaseViewHolder {

    private RecyclerView mRecyclerView;

    public BookshelfNovelContainerViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);

        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.requestFocus();
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(20), 0));

        BookshelfNovelAdapter bookshelfNovelAdapter = new BookshelfNovelAdapter(mContext);
        bookshelfNovelAdapter.register(11, new ItemViewHolderContainer(R.layout.item_bookshelf_novel, BookshelfNovelViewHolder.class));
        bookshelfNovelAdapter.register(12, new ItemViewHolderContainer(R.layout.item_bookshelf_novel_add, BookshelfNovelAddViewHolder.class));
        mRecyclerView.setAdapter(bookshelfNovelAdapter);

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();

        for (int i = 0; i < 2; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(11);
            renderTypeModels.add(renderTypeModel);
        }

        RenderTypeModel renderTypeModel1 = new RenderTypeModel();
        renderTypeModel1.setRenderType(12);
        renderTypeModels.add(renderTypeModel1);

        bookshelfNovelAdapter.addData(renderTypeModels);


    }

    private void initView(@NonNull final View itemView) {

    }
}
