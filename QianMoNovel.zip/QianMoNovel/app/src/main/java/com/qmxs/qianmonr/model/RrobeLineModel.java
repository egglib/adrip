package com.qmxs.qianmonr.model;

import java.util.List;

/*
 * File: RrobeLineModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/15 8:50 PM
 */
public class RrobeLineModel {


    /**
     * version : 1.0.0
     * notice :
     * download : {"android":"http://apk.yunyusi.com/qianmo/qianmo-1.0.0.apk"}
     * webSite :
     * updateNotice :
     * must : 0
     * mstatus : 0
     * line : [{"area":"us","url":"x.lanshu.me"},{"area":"us","url":"y.lanshu.me"},{"area":"us","url":"z.lanshu.me"}]
     * ad : {"img_url":"","jump_url":""}
     */

    private String version;
    private String notice;
    private DownloadBean download;
    private String webSite;
    private String updateNotice;
    private int must;
    private int mstatus;
    private AdBean ad;
    private List<LineBean> line;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getNotice() {
        return notice;
    }

    public void setNotice(String notice) {
        this.notice = notice;
    }

    public DownloadBean getDownload() {
        return download;
    }

    public void setDownload(DownloadBean download) {
        this.download = download;
    }

    public String getWebSite() {
        return webSite;
    }

    public void setWebSite(String webSite) {
        this.webSite = webSite;
    }

    public String getUpdateNotice() {
        return updateNotice;
    }

    public void setUpdateNotice(String updateNotice) {
        this.updateNotice = updateNotice;
    }

    public int getMust() {
        return must;
    }

    public void setMust(int must) {
        this.must = must;
    }

    public int getMstatus() {
        return mstatus;
    }

    public void setMstatus(int mstatus) {
        this.mstatus = mstatus;
    }

    public AdBean getAd() {
        return ad;
    }

    public void setAd(AdBean ad) {
        this.ad = ad;
    }

    public List<LineBean> getLine() {
        return line;
    }

    public void setLine(List<LineBean> line) {
        this.line = line;
    }

    public static class DownloadBean {
        /**
         * android : http://apk.yunyusi.com/qianmo/qianmo-1.0.0.apk
         */

        private String android;

        public String getAndroid() {
            return android;
        }

        public void setAndroid(String android) {
            this.android = android;
        }
    }

    public static class AdBean {
        /**
         * img_url :
         * jump_url :
         */

        private String img_url;
        private String jump_url;

        public String getImg_url() {
            return img_url;
        }

        public void setImg_url(String img_url) {
            this.img_url = img_url;
        }

        public String getJump_url() {
            return jump_url;
        }

        public void setJump_url(String jump_url) {
            this.jump_url = jump_url;
        }
    }

    public static class LineBean {
        /**
         * area : us
         * url : x.lanshu.me
         */

        private String area;
        private String url;

        public String getArea() {
            return area;
        }

        public void setArea(String area) {
            this.area = area;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }
}
