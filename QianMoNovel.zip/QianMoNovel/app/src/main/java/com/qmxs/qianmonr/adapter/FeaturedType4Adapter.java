package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: FeaturedType4Adapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 6:25 PM
 */
public class FeaturedType4Adapter extends BaseRecyclerViewAdapter {

    public FeaturedType4Adapter(Context context) {
        super(context);
    }
}
