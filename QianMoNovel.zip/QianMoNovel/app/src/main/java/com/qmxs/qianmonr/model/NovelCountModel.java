package com.qmxs.qianmonr.model;

/*
 * File: NovelCountModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 11:16 AM
 */
public class NovelCountModel extends RenderTypeModel {
    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
