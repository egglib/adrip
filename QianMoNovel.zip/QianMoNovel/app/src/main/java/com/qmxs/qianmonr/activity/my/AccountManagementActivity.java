package com.qmxs.qianmonr.activity.my;

import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.PersonInfoModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.PageJumpUtil;

/*
 * File: AccountManagementActivity.java
 * Description: 账号管理界面
 * Author: XiaoTao
 * Create at 2019/2/23 2:34 PM
 */
public class AccountManagementActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_account_management;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.account_management);
    }

    @Override
    protected void initView() {
        PersonInfoModel personInfoModel = JumpUtil.getPersonInfo(this);
        View view = createActionBarRightIcon(R.mipmap.ic_scan);
        view.setOnClickListener((v) -> PageJumpUtil.forwordToPage(this, CaptureActivity.class));
        int loginStatus = personInfoModel.getIs_login();

        LinearLayout mBindingLoginLayout = findViewById(R.id.layout_binding_login);
        mBindingLoginLayout.setOnClickListener(this);
        LinearLayout mInputInviteCodeLayout = findViewById(R.id.layout_input_invite_code);
        mInputInviteCodeLayout.setOnClickListener(this);
        LinearLayout mMyAccountLayout = (LinearLayout) findViewById(R.id.layout_my_account);
        mMyAccountLayout.setOnClickListener(this);
        LinearLayout mReplaceBindingLayout = (LinearLayout) findViewById(R.id.layout_replace_binding);
        mReplaceBindingLayout.setOnClickListener(this);
        LinearLayout mReplacePasswordLayout = (LinearLayout) findViewById(R.id.layout_replace_password);
        mReplacePasswordLayout.setOnClickListener(this);

        if (loginStatus == 0) {
            mReplacePasswordLayout.setVisibility(View.GONE);
        } else {
            mReplacePasswordLayout.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_binding_login:
//                startActivity(new Intent(this, BindingLoginActivity.class));
                PageJumpUtil.forwordToPage(this,BindingLoginActivity.class);
                break;
            case R.id.layout_input_invite_code:
                startActivity(new Intent(this, InviteCodeActivity.class));
                break;
            case R.id.layout_my_account:
                startActivity(new Intent(this, MyAccountActivity.class));
                break;
            case R.id.layout_replace_binding:
                startActivity(new Intent(this, RepalceBindingActivity.class));
                break;
            case R.id.layout_replace_password:
                startActivity(new Intent(this, RepalcePasswordActivity.class));
                break;
            default:
                break;
        }
    }
}
