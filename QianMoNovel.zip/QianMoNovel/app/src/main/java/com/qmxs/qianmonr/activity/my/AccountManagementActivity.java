package com.qmxs.qianmonr.activity.my;

import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.CaptureActivity;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: AccountManagementActivity.java
 * Description: 账号管理界面
 * Author: XiaoTao
 * Create at 2019/2/23 2:34 PM
 */
public class AccountManagementActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private LinearLayout mBindingLoginLayout;
    private LinearLayout mInputInviteCodeLayout;
    private LinearLayout mMyAccountLayout;
    private LinearLayout mReplaceBindingLayout;
    private LinearLayout mReplacePasswordLayout;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_account_management;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.account_management);
    }

    @Override
    protected void initView() {
        View view = createActionBarRightIcon(R.mipmap.ic_scan);
        view.setOnClickListener((v) -> startActivity(new Intent(this, CaptureActivity.class)));
        mBindingLoginLayout = findViewById(R.id.layout_binding_login);
        mBindingLoginLayout.setOnClickListener(this);
        mInputInviteCodeLayout = findViewById(R.id.layout_input_invite_code);
        mInputInviteCodeLayout.setOnClickListener(this);
        mMyAccountLayout = (LinearLayout) findViewById(R.id.layout_my_account);
        mMyAccountLayout.setOnClickListener(this);
        mReplaceBindingLayout = (LinearLayout) findViewById(R.id.layout_replace_binding);
        mReplaceBindingLayout.setOnClickListener(this);
        mReplacePasswordLayout = (LinearLayout) findViewById(R.id.layout_replace_password);
        mReplacePasswordLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_binding_login:
                startActivity(new Intent(this, BindingLoginActivity.class));
                break;
            case R.id.layout_input_invite_code:
                startActivity(new Intent(this, InviteCodeActivity.class));
                break;
            case R.id.layout_my_account:
                startActivity(new Intent(this, MyAccountActivity.class));
                break;
            case R.id.layout_replace_binding:
                startActivity(new Intent(this, RepalceBindingActivity.class));
                break;
            case R.id.layout_replace_password:
                startActivity(new Intent(this, RepalcePasswordActivity.class));
                break;
            default:
                break;
        }
    }
}
