package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.util.ScreenUtil;


/*
 * File: FeaturedType41ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 6:26 PM
 */
class FeaturedType41ViewHolder extends BaseViewHolder {

    private ImageView mCoverImg;
    private TextView mNovelNameTv;
    private TextView mNovelAuthorTv;
    private LinearLayout mLayoutItem;

    public FeaturedType41ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mCoverImg = (ImageView) itemView.findViewById(R.id.img_cover);
        mNovelNameTv = (TextView) itemView.findViewById(R.id.tv_novel_name);
        mNovelAuthorTv = (TextView) itemView.findViewById(R.id.tv_novel_author);
        mLayoutItem = (LinearLayout) itemView.findViewById(R.id.item_layout);

        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(80)) / 4;
        int height = width * 3 / 2;
        mCoverImg.setLayoutParams(new FrameLayout.LayoutParams(width, height));
    }
}
