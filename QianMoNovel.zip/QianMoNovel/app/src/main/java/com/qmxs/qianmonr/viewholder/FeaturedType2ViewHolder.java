package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.FeaturedType2Adapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.FeaturedNovelModel;
import com.qmxs.qianmonr.model.NovelBreifModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.LogUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/*
 * File: FeaturedType2ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 9:16 PM
 */
public class FeaturedType2ViewHolder extends BaseViewHolder implements View.OnClickListener {

    private ImageView mBgChangeImg;
    private NetworkImageView mTitleImg;
    private TextView mMoreTitleTv;
    private LinearLayout mChangeLayout;
    private RecyclerView mRecyclerView;
    private FeaturedType2Adapter featuredType2Adapter;

    private static final int TYPE_ITEM_FEATURED_21 = 21;

    private int count;

    private int time = 1;


    private List<NovelBreifModel> novelBreifModels = new ArrayList<>();

    private int[] bgImgs = {
            R.mipmap.bg_change_1,
            R.mipmap.bg_change_2,
            R.mipmap.bg_change_3,
            R.mipmap.bg_change_4,
            R.mipmap.bg_change_5,
            R.mipmap.bg_change_6
    };

    public FeaturedType2ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mBgChangeImg = itemView.findViewById(R.id.img_bg_change);
        mTitleImg = itemView.findViewById(R.id.img_title);
        mMoreTitleTv = itemView.findViewById(R.id.tv_title);
        mChangeLayout = itemView.findViewById(R.id.layout_change);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);
        mChangeLayout.setOnClickListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext) {
            @Override
            public boolean canScrollHorizontally() {
                return false;
            }
        };

        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.setFocusable(false);
        mRecyclerView.requestFocus();
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(18), ScreenUtil.dp2px(10)));
        if (mRecyclerView.getAdapter() == null) {
            featuredType2Adapter = new FeaturedType2Adapter(mContext);
        }
        featuredType2Adapter.register(TYPE_ITEM_FEATURED_21, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, FeaturedType21ViewHolder.class));
        mRecyclerView.setAdapter(featuredType2Adapter);

        Random random = new Random();
        int index = random.nextInt(6);
        int bgImgId = bgImgs[index];
        mBgChangeImg.setImageResource(bgImgId);
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        FeaturedNovelModel featruredModel = (FeaturedNovelModel) objectList.get(position);

        if (featruredModel != null) {

            String imgUrl = featruredModel.getIcon();
            if (!TextUtils.isEmpty(imgUrl)) {
                mTitleImg.setImgUrl(imgUrl);
            }

            String title = featruredModel.getTitle();

            if (!TextUtils.isEmpty(title)) {
                mMoreTitleTv.setText(title);
            }

            novelBreifModels = featruredModel.getData();

            int size = novelBreifModels.size();
            count = size / 3;

            for (NovelBreifModel novelBreifModel : novelBreifModels) {
                novelBreifModel.setRenderType(TYPE_ITEM_FEATURED_21);
            }
            changeData();
        }
    }

    private void changeData() {
        if (time <= count) {
            List<NovelBreifModel> novelModelList = new ArrayList<>();

            for (int i = (time - 1) * 3; i < 3 * time; i++) {
                NovelBreifModel novelBreifModel = novelBreifModels.get(i);
                novelModelList.add(novelBreifModel);
            }

            featuredType2Adapter.clearData();
            featuredType2Adapter.addData(novelModelList);
            time++;
        } else {
            time = 1;
            changeData();
        }
    }


    @Override
    public void onClick(View v) {
        LogUtil.e("count===" + count);
        changeData();
    }
}
