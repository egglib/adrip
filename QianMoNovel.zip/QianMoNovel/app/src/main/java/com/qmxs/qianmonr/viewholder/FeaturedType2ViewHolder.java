package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.FeaturedType2Adapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/*
 * File: FeaturedType2ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 9:16 PM
 */
public class FeaturedType2ViewHolder extends BaseViewHolder {

    private ImageView mBgChangeImg;
    private ImageView mMoreImg;
    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private LinearLayout mChangeLayout;
    private RecyclerView mRecyclerView;

    private static final int TYPE_ITEM_FEATURED_21 = 21;

    private int[] bgImgs = {
            R.mipmap.bg_change_1,
            R.mipmap.bg_change_2,
            R.mipmap.bg_change_3,
            R.mipmap.bg_change_4,
            R.mipmap.bg_change_5,
            R.mipmap.bg_change_6
    };

    public FeaturedType2ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mBgChangeImg = (ImageView) itemView.findViewById(R.id.img_bg_change);
        mMoreImg = (ImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mChangeLayout = (LinearLayout) itemView.findViewById(R.id.layout_change);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.requestFocus();
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(18), ScreenUtil.dp2px(15)));

        FeaturedType2Adapter featuredType2Adapter = new FeaturedType2Adapter(mContext);
        featuredType2Adapter.register(TYPE_ITEM_FEATURED_21, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, FeaturedType21ViewHolder.class));
        mRecyclerView.setAdapter(featuredType2Adapter);

        Random random = new Random();
        int index = random.nextInt(6);

        int bgImgId = bgImgs[index];
        mBgChangeImg.setImageResource(bgImgId);

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();
        RenderTypeModel renderTypeModel = new RenderTypeModel();
        renderTypeModel.setRenderType(TYPE_ITEM_FEATURED_21);

        RenderTypeModel renderTypeModel1 = new RenderTypeModel();
        renderTypeModel1.setRenderType(TYPE_ITEM_FEATURED_21);

        RenderTypeModel renderTypeModel2 = new RenderTypeModel();
        renderTypeModel2.setRenderType(TYPE_ITEM_FEATURED_21);

        RenderTypeModel renderTypeModel3 = new RenderTypeModel();
        renderTypeModel3.setRenderType(TYPE_ITEM_FEATURED_21);

        renderTypeModels.add(renderTypeModel);
        renderTypeModels.add(renderTypeModel1);
        renderTypeModels.add(renderTypeModel2);
        renderTypeModels.add(renderTypeModel3);

        featuredType2Adapter.addData(renderTypeModels);
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

    }
}
