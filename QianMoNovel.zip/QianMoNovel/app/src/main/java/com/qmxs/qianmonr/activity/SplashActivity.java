package com.qmxs.qianmonr.activity;

import android.content.Intent;
import android.view.View;
import com.gyf.barlibrary.BarHide;
import com.gyf.barlibrary.ImmersionBar;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.main.MainActivity;
import com.qmxs.qianmonr.activity.my.BindingLoginActivity;
import com.qmxs.qianmonr.base.BaseActivity;

/*
 * File: SplashActivity.java
 * Description: 闪屏界面
 * Author: XiaoTao
 * Create at 2019/2/19 9:53 AM
 */
public class SplashActivity extends BaseActivity {


    @Override
    protected int setContentViewId() {
        return R.layout.activity_splash;
    }


    @Override
    protected void initView() {
        ImmersionBar.with(this).reset().hideBar(BarHide.FLAG_HIDE_BAR).init();
    }

    public void startRead(View view) {
        startActivity(new Intent(this, BindingLoginActivity.class));
        this.finish();
    }

    public void skip(View view) {
        startActivity(new Intent(this, MainActivity.class));
        this.finish();
    }
}
