package com.qmxs.qianmonr.model;

/*
 * File: JumpEvent.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 5:20 PM
 */
public class JumpEvent {
    public int index;
}
