package com.qmxs.qianmonr.net;

/*
 * File: ApiConfig.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/5 12:49 PM
 */
public class ApiConfig {

    public static final String BASE_URL = "http://x.lanshu.me/";
//    public static final String BASE_URL = "http://192.168.10.174:8989/api/";
}
