package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.LinearLayout;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;


/*
 * File: FeaturedGirlSortViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 7:00 PM
 */
public class FeaturedGirlSortViewHolder extends BaseViewHolder implements  View.OnClickListener{

    private LinearLayout mPopularListLayout;
    private LinearLayout mDailyUpdateLayout;
    private LinearLayout mEndLayout;
    private LinearLayout mModernRomanceLayout;
    private LinearLayout mAncientRomanceLayout;

    public FeaturedGirlSortViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mPopularListLayout = (LinearLayout) itemView.findViewById(R.id.layout_popular_list);
        mPopularListLayout.setOnClickListener(this);
        mDailyUpdateLayout = (LinearLayout) itemView.findViewById(R.id.layout_daily_update);
        mDailyUpdateLayout.setOnClickListener(this);
        mEndLayout = (LinearLayout) itemView.findViewById(R.id.layout_end);
        mEndLayout.setOnClickListener(this);
        mModernRomanceLayout = (LinearLayout) itemView.findViewById(R.id.layout_modern_romance);
        mModernRomanceLayout.setOnClickListener(this);
        mAncientRomanceLayout = (LinearLayout) itemView.findViewById(R.id.layout_ancient_romance);
        mAncientRomanceLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_popular_list:
                // TODO 19/03/02
                break;
            case R.id.layout_daily_update:
                // TODO 19/03/02
                break;
            case R.id.layout_end:
                // TODO 19/03/02
                break;
            case R.id.layout_modern_romance:
                // TODO 19/03/02
                break;
            case R.id.layout_ancient_romance:
                // TODO 19/03/02
                break;
            default:
                break;
        }
    }
}
