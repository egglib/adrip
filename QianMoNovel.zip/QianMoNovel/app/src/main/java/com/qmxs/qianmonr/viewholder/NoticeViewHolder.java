package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.NoticeRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.NoticeModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.DateUtil;
import com.qmxs.qianmonr.util.JumpUtil;

import java.util.List;


/*
 * File: NoticeViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 8:42 PM
 */
public class NoticeViewHolder extends BaseViewHolder {

    private ImageView mMarkImg;
    private TextView mTitleTv;
    private TextView mDateTv;
    private TextView mSummaryTv;
    private ImageView mDotImg;
    private NoticeModel noticeModel;
    private NoticeRecyclerViewAdapter noticeRecyclerViewAdapter;

    public NoticeViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mMarkImg = (ImageView) itemView.findViewById(R.id.img_mark);
        mMarkImg.setImageResource(R.mipmap.ic_notice);
        mTitleTv = (TextView) itemView.findViewById(R.id.tv_title);
        mDateTv = (TextView) itemView.findViewById(R.id.tv_date);
        mSummaryTv = (TextView) itemView.findViewById(R.id.tv_summary);
        mDotImg = (ImageView) itemView.findViewById(R.id.img_dot);
        noticeRecyclerViewAdapter = (NoticeRecyclerViewAdapter) adapter;
        itemView.setOnClickListener(v -> {
            setNoticeStatus();
            JumpUtil.forwordToNoticeDetail(mContext, noticeModel);
        });
    }

    private void setNoticeStatus() {
        ApiManager.readNoticeData(mContext, noticeModel.getId(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                noticeModel.setReaded(1);
                noticeRecyclerViewAdapter.notifyItemChanged(mPosition);
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        noticeModel = (NoticeModel) objectList.get(position);
        if (noticeModel != null) {
            String title = noticeModel.getTitle();
            if (!TextUtils.isEmpty(title)) {
                mTitleTv.setText(title);
            }

            String content = noticeModel.getContent();
            if (!TextUtils.isEmpty(content)) {
                mSummaryTv.setText(content);
            }

            int date = noticeModel.getUpdated_at();
            String dateStr = DateUtil.format10ToYMD(date);
            mDateTv.setText(dateStr);

            int readed = noticeModel.getReaded();

            if (readed == 0) {
                mDotImg.setVisibility(View.VISIBLE);
            } else {
                mDotImg.setVisibility(View.GONE);
            }
        }
    }
}
