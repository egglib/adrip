package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.my.CustomerServiceReplyActivity;
import com.qmxs.qianmonr.activity.my.NoticeDetailActivity;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;

import java.util.List;


/*
 * File: NoticeViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 8:42 PM
 */
public class NoticeViewHolder extends BaseViewHolder {

    private ImageView mMarkImg;
    private TextView mTitleTv;
    private TextView mDateTv;
    private TextView mSummaryTv;
    private ImageView mDotImg;

    public NoticeViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mMarkImg = (ImageView) itemView.findViewById(R.id.img_mark);
        mTitleTv = (TextView) itemView.findViewById(R.id.tv_title);
        mDateTv = (TextView) itemView.findViewById(R.id.tv_date);
        mSummaryTv = (TextView) itemView.findViewById(R.id.tv_summary);
        mDotImg = (ImageView) itemView.findViewById(R.id.img_dot);
        mMarkImg.setImageResource(R.mipmap.ic_notice);
        mTitleTv.setText("版本V1.0.1更新公告1更新公告1更新公告1更新公告1更新公告1更新公告1更新公告");
        mSummaryTv.setText("正文内容：版本V1.0.1更新但是放水淀粉1更新但是放水淀粉1更新但是放水淀粉");
        mDateTv.setText("2019-01-11");
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        mItemView.setOnClickListener(v -> {
            if (position % 2 == 0) {
                mContext.startActivity(new Intent(mContext, NoticeDetailActivity.class));
            } else {
                mContext.startActivity(new Intent(mContext, CustomerServiceReplyActivity.class));
            }
        });
    }
}
