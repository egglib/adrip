package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.LinearLayout;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.util.JumpUtil;

/*
 * File: FeaturedBoySortViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 6:52 PM
 */
public class FeaturedBoySortViewHolder extends BaseViewHolder implements View.OnClickListener {

    private LinearLayout mDailyUpdateLayout;
    private LinearLayout mEndLayout;
    private LinearLayout mFantasyLayout;
    private LinearLayout mCityLayout;

    public FeaturedBoySortViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mDailyUpdateLayout = (LinearLayout) itemView.findViewById(R.id.layout_daily_update);
        mEndLayout = (LinearLayout) itemView.findViewById(R.id.layout_end);
        mFantasyLayout = (LinearLayout) itemView.findViewById(R.id.layout_fantasy);
        mCityLayout = (LinearLayout) itemView.findViewById(R.id.layout_city);
        mDailyUpdateLayout.setOnClickListener(this);
        mEndLayout.setOnClickListener(this);
        mFantasyLayout.setOnClickListener(this);
        mCityLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_daily_update:
                JumpUtil.forwordToDailyUpdate(mContext, 1);
                break;
            case R.id.layout_end:
                JumpUtil.forwordToEnd(mContext, 1);
                break;
            case R.id.layout_fantasy:
                JumpUtil.forwordToSortList(mContext, "玄幻", 1);
                break;
            case R.id.layout_city:
                JumpUtil.forwordToSortList(mContext, "都市", 5);
                break;
        }
    }
}
