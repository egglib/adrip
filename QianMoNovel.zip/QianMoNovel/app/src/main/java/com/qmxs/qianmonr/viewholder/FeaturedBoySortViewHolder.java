package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.LinearLayout;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;

/*
 * File: FeaturedBoySortViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 6:52 PM
 */
public class FeaturedBoySortViewHolder extends BaseViewHolder implements View.OnClickListener {

    private LinearLayout mPopularListLayout;
    private LinearLayout mDailyUpdateLayout;
    private LinearLayout mEndLayout;
    private LinearLayout mFantasyLayout;
    private LinearLayout mCityLayout;

    public FeaturedBoySortViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mPopularListLayout = (LinearLayout) itemView.findViewById(R.id.layout_popular_list);
        mDailyUpdateLayout = (LinearLayout) itemView.findViewById(R.id.layout_daily_update);
        mEndLayout = (LinearLayout) itemView.findViewById(R.id.layout_end);
        mFantasyLayout = (LinearLayout) itemView.findViewById(R.id.layout_fantasy);
        mCityLayout = (LinearLayout) itemView.findViewById(R.id.layout_city);
        mPopularListLayout.setOnClickListener(this);
        mDailyUpdateLayout.setOnClickListener(this);
        mEndLayout.setOnClickListener(this);
        mFantasyLayout.setOnClickListener(this);
        mCityLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_popular_list:
                break;
            case R.id.layout_daily_update:
                break;
            case R.id.layout_end:
                break;
            case R.id.layout_fantasy:
                break;
            case R.id.layout_city:
                break;
        }
    }
}
