package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.main.AuthorDetailActivity;
import com.qmxs.qianmonr.adapter.AuthorBriefAdapter;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.AuthorBreifModel;
import com.qmxs.qianmonr.model.FeaturedAuthorModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: AuthorViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 6:36 PM
 */
public class AuthorViewHolder extends BaseViewHolder {

    private NetworkImageView mMoreImg;
    private TextView mMoreTitleTv;
    private RecyclerView mRecyclerView;
    private static final int TYPE_ITEM_FEATURED_01 = 1;
    private AuthorBriefAdapter authorBriefAdapter;

    public AuthorViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mMoreImg = itemView.findViewById(R.id.img_more);
        mMoreTitleTv = itemView.findViewById(R.id.tv_more_title);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.setFocusable(false);
        mRecyclerView.requestFocus();

        if (authorBriefAdapter == null) {
            authorBriefAdapter = new AuthorBriefAdapter(mContext);
        }
        authorBriefAdapter.register(TYPE_ITEM_FEATURED_01, new ItemViewHolderContainer(R.layout.item_novel_author, AuthorBriefViewHolder.class));
        mRecyclerView.setAdapter(authorBriefAdapter);


        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(10), ScreenUtil.dp2px(5), 0, 0));
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        FeaturedAuthorModel featuredAuthorModel = (FeaturedAuthorModel) objectList.get(position);
        String title = featuredAuthorModel.getTitle();

        if (!TextUtils.isEmpty(title)) {
            mMoreTitleTv.setText(title);
        }

        List<AuthorBreifModel> authorBreifModels = featuredAuthorModel.getData();

        for (AuthorBreifModel novelBreifModel : authorBreifModels) {
            novelBreifModel.setRenderType(TYPE_ITEM_FEATURED_01);
        }

        authorBriefAdapter.clearData();
        authorBriefAdapter.addData(authorBreifModels);


    }
}
