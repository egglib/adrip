package com.qmxs.qianmonr.activity.main;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.EndRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.NovelBreifOneModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.viewholder.EndHeaderViewHolder;
import com.qmxs.qianmonr.viewholder.EndTitleViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.NovelBriefIntroOneViewHolder;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.BallPulseFooter;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;

/*
 * File: EndActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 10:49 AM
 */
public class EndActivity extends BaseCommonTitleActivity implements OnLoadMoreListener, OnRefreshListener {

    private EndRecyclerViewAdapter endRecyclerViewAdapter;
    private SmartRefreshLayout mSwipeRefreshLayout;
    private static final int TYPE_BANNER = 1;
    private static final int TYPE_TITLE = 2;
    private static final int TYPE_LIST = 3;

    private int gender;

    private boolean isLoading = false;
    private int mPageNum = 1;

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.str_end);
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview_outside;
    }

    @Override
    protected void initView() {
        View view = createActionBarRightIcon(R.mipmap.ic_search);
        view.setOnClickListener(v -> startActivity(new Intent(EndActivity.this, SearchActivity.class)));

        RecyclerView mRecyclerView = findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        CustomHeaderView header = new CustomHeaderView(this);
        mSwipeRefreshLayout.setRefreshHeader(header);

        BallPulseFooter footer = new BallPulseFooter(this).setSpinnerStyle(SpinnerStyle.Scale);
        mSwipeRefreshLayout.setRefreshFooter(footer);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setOnLoadMoreListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);

        endRecyclerViewAdapter = new EndRecyclerViewAdapter(this);
        mRecyclerView.setAdapter(endRecyclerViewAdapter);

        gender = JumpUtil.getGender(this);

        endRecyclerViewAdapter.register(TYPE_BANNER, new ItemViewHolderContainer(R.layout.item_banner_view, EndHeaderViewHolder.class));
        endRecyclerViewAdapter.register(TYPE_TITLE, new ItemViewHolderContainer(R.layout.item_end_title, EndTitleViewHolder.class));
        endRecyclerViewAdapter.register(TYPE_LIST, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, NovelBriefIntroOneViewHolder.class));

        addExtraTypeData();
        setDialogTip("完结数据加载中...");

    }

    private void addExtraTypeData() {
        List<RenderTypeModel> renderTypeModels = new ArrayList<>();

        RenderTypeModel renderTypeModel = new RenderTypeModel();
        renderTypeModel.setRenderType(TYPE_BANNER);
        renderTypeModels.add(renderTypeModel);

        RenderTypeModel renderTypeModel1 = new RenderTypeModel();
        renderTypeModel1.setRenderType(TYPE_TITLE);
        renderTypeModels.add(renderTypeModel1);

        endRecyclerViewAdapter.addData(renderTypeModels);
    }


    @Override
    protected void pageHandle() {
        super.pageHandle();
        refreshData();
    }

    private void refreshData() {
        if (!isLoading) {
            isLoading = true;
            mPageNum = 1;
            getData();
        }
    }

    private void getMoreData() {
        if (!isLoading) {
            isLoading = true;
            getData();
        }
    }

    private void getData() {
        if (mPageNum == 1) {
            showDialog();
        }
        ApiManager.getEndListData(this, gender, mPageNum, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }

                List<NovelBreifOneModel> novelBreifOneModels = JsonUtil.jsonStrToObjList(response, NovelBreifOneModel.class);

                if (novelBreifOneModels == null && novelBreifOneModels.isEmpty()) {
                    mSwipeRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }

                if (mPageNum == 1) {
                    endRecyclerViewAdapter.clearData();
                    addExtraTypeData();
                }

                mPageNum++;

                for (int i = 0; i < novelBreifOneModels.size(); i++) {
                    NovelBreifOneModel novelBreifOneModel = novelBreifOneModels.get(i);
                    novelBreifOneModel.setRenderType(TYPE_LIST);
                }
                endRecyclerViewAdapter.addData(novelBreifOneModels);
            }

            @Override
            public void onError(Throwable e) {
                isLoading = false;
                dismissDialog();

                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }
            }

            @Override
            public void onComplete() {
                isLoading = false;
                dismissDialog();
            }
        });
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        getMoreData();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        refreshData();
    }
}
