package com.qmxs.qianmonr.adapter;

import android.content.Context;

/*
 * File: RankListAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/13 4:03 PM
 */
public class RankListAdapter extends BaseRecyclerViewAdapter {

    public RankListAdapter(Context context) {
        super(context);
    }
}
