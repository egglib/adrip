package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: FFeaturedRecyclerViewAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 6:10 PM
 */
public class FFeaturedRecyclerViewAdapter extends BaseRecyclerViewAdapter {

    public FFeaturedRecyclerViewAdapter(Context context) {
        super(context);
    }
}
