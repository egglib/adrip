package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.model.SearchHistoryModel;

import java.util.List;

/*
 * File: SearchHistoryViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 9:22 PM
 */
public class SearchHistoryViewHolder extends BaseViewHolder {
    private TextView mKeywordTv;
    private SearchHistoryModel searchHistoryModel;

    public SearchHistoryViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mKeywordTv = (TextView) itemView.findViewById(R.id.tv_keyword);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        searchHistoryModel = (SearchHistoryModel) objectList.get(position);
        if (searchHistoryModel != null) {
            String keyword = searchHistoryModel.getKeywords();
            if (!TextUtils.isEmpty(keyword))
                mKeywordTv.setText(keyword);
        }

    }
}
