package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;

import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;

/*
 * File: SearchHistoryViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 9:22 PM
 */
public class SearchHistoryViewHolder extends BaseViewHolder {

    public SearchHistoryViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
    }
}
