package  com.qmxs.qianmonr.widget.scrollview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ScrollView;

/*
 * File: CommonScrollView.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/23 6:45 PM
 */
public class CommonScrollView extends ScrollView {

    private ScrollListener scrollListener = null;

    public CommonScrollView(Context context) {
        super(context);
    }

    public CommonScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CommonScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setScrollListener(ScrollListener scrollListener) {
        this.scrollListener = scrollListener;
    }

    @Override
    protected void onScrollChanged(int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
        super.onScrollChanged(scrollX, scrollY, oldScrollX, oldScrollY);
        if (scrollListener != null) {
            scrollListener.onScrollChanged(this, scrollX, scrollY, oldScrollX, oldScrollY);
        }
    }
}
