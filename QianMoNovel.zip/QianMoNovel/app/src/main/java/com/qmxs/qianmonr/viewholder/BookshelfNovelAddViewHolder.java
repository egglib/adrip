package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.util.ScreenUtil;


/*
 * File: BookshelfNovelAddViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/1 7:00 PM
 */
class BookshelfNovelAddViewHolder extends BaseViewHolder {

    private CardView mAddCard;

    public BookshelfNovelAddViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mAddCard = itemView.findViewById(R.id.card_add);
        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(80)) / 3;
        int height = width * 3 / 2;
        mAddCard.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        mAddCard.setOnClickListener(v -> Toast.makeText(mContext, "添加书籍", Toast.LENGTH_SHORT).show());
    }
}
