package com.qmxs.qianmonr.fragment;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.MsgRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.MsgViewHolder;

import java.util.ArrayList;
import java.util.List;

/*
 * File: MsgFragment.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/26 8:31 PM
 */
public class MsgFragment extends BaseLazyFragment implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;

    @Override
    protected void onLazyLoad() {

    }

    @Override
    protected int setLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview;
    }


    @Override
    protected void initView(View view) {
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefreshLayout);

        mSwipeRefreshLayout.setColorSchemeColors(getContext().getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);

        MsgRecyclerViewAdapter msgRecyclerViewAdapter = new MsgRecyclerViewAdapter(getContext());

        msgRecyclerViewAdapter.register(1, new ItemViewHolderContainer(R.layout.item_notice_msg, MsgViewHolder.class));

        List<RenderTypeModel> objects = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(1);
            objects.add(renderTypeModel);
        }
        msgRecyclerViewAdapter.addData(objects);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(msgRecyclerViewAdapter);
        mRecyclerView.setHasFixedSize(true);

    }

    @Override
    public void onRefresh() {
        mSwipeRefreshLayout.setRefreshing(false);
    }
}
