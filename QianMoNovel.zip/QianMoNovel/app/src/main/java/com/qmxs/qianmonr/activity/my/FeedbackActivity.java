package com.qmxs.qianmonr.activity.my;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.ToastUtil;

/*
 * File: FeedbackActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/19 9:53 PM
 */
public class FeedbackActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private EditText mContentEt;
    private TextView mSubmitTv;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_feedback;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.feedback);
    }

    @Override
    protected void initView() {
        super.initView();
//        View view = createActionBarRightText(getResources().getString(R.string.feedback_record));
//        view.setOnClickListener(v -> {
//            startActivity(new Intent(this, FeedbackRecordActivity.class));
//        });
        mContentEt = (EditText) findViewById(R.id.et_content);
        mSubmitTv = (TextView) findViewById(R.id.tv_submit);
        mSubmitTv.setOnClickListener(this);
        setDialogTip("反馈提交中...");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_submit:
                submitData();
                break;
            default:
                break;
        }
    }

    private void submitData() {
        String content = mContentEt.getText().toString();
        if (TextUtils.isEmpty(content)) {
            ToastUtil.shortShow(this, "请填写反馈内容");
            return;
        }
        showDialog();
        ApiManager.submitFeedbackData(this, content, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                mContentEt.setText("");

                ToastUtil.shortShow(FeedbackActivity.this, "提交成功");
            }

            @Override
            public void onError(Throwable e) {
                dismissDialog();
                ToastUtil.shortShow(FeedbackActivity.this, "提交失败，请稍后重试~");
            }

            @Override
            public void onComplete() {
                dismissDialog();
            }
        });


    }
}
