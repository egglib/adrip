package com.qmxs.qianmonr.activity.my;

import android.content.Intent;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: FeedbackActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/19 9:53 PM
 */
public class FeedbackActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_feedback;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.feedback);
    }

    @Override
    protected void initView() {
        super.initView();
        View view = createActionBarRightText(getResources().getString(R.string.feedback_record));
        view.setOnClickListener(v -> {
            startActivity(new Intent(this, FeedbackRecordActivity.class));
        });
    }
}
