package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: PopularListAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 8:42 PM
 */
public class PopularListAdapter extends BaseRecyclerViewAdapter{

    public PopularListAdapter(Context context) {
        super(context);
    }
}
