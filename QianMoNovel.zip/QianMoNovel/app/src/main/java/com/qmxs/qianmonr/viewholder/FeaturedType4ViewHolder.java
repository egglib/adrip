package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.FeaturedType4Adapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;

import java.util.ArrayList;
import java.util.List;

/*
 * File: FeaturedType4ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 6:19 PM
 */
public class FeaturedType4ViewHolder extends BaseViewHolder {

    private ImageView mMoreImg;
    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private static final int TYPE_ITEM_FEATURED_41 = 41;

    public FeaturedType4ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mMoreImg = (ImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.requestFocus();
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(18), ScreenUtil.dp2px(10)));

        FeaturedType4Adapter featuredType4Adapter = new FeaturedType4Adapter(mContext);
        featuredType4Adapter.register(TYPE_ITEM_FEATURED_41, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, FeaturedType41ViewHolder.class));
        mRecyclerView.setAdapter(featuredType4Adapter);

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();

        for (int i = 0; i < 20; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(TYPE_ITEM_FEATURED_41);
            renderTypeModels.add(renderTypeModel);
        }

        featuredType4Adapter.addData(renderTypeModels);
    }

}
