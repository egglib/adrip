package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.FeaturedType4Adapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.FeaturedNovelModel;
import com.qmxs.qianmonr.model.NovelBreifModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: FeaturedType4ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/28 6:19 PM
 */
public class FeaturedType4ViewHolder extends BaseViewHolder {

    private NetworkImageView mMoreImg;
    private TextView mMoreTitleTv;
    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private static final int TYPE_ITEM_FEATURED_41 = 41;
    private FeaturedType4Adapter featuredType4Adapter;

    public FeaturedType4ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mMoreImg = (NetworkImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.setFocusable(false);
        mRecyclerView.requestFocus();
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(ScreenUtil.dp2px(18),ScreenUtil.dp2px(18),
                ScreenUtil.dp2px(0),ScreenUtil.dp2px(5)));
        if (mRecyclerView.getAdapter() == null)
            featuredType4Adapter = new FeaturedType4Adapter(mContext);
        featuredType4Adapter.register(TYPE_ITEM_FEATURED_41, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, FeaturedType41ViewHolder.class));
        mRecyclerView.setAdapter(featuredType4Adapter);

    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        FeaturedNovelModel featruredModel = (FeaturedNovelModel) objectList.get(position);

        if (featruredModel != null) {
            String title = featruredModel.getTitle();
            String id = featruredModel.getTopicId();

            mMoreLayout.setOnClickListener(v -> {
                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(id)) {
                    JumpUtil.forwordToRecommendList(mContext, title, id);
                }
            });

            String imgUrl = featruredModel.getIcon();

            if (!TextUtils.isEmpty(imgUrl)) {
                mMoreImg.setImgUrl(imgUrl);
            }

            if (!TextUtils.isEmpty(title)) {
                mMoreTitleTv.setText(title);
            }

            List<NovelBreifModel> novelBreifModels = featruredModel.getData();
            for (NovelBreifModel novelBreifModel : novelBreifModels) {
                novelBreifModel.setRenderType(TYPE_ITEM_FEATURED_41);
            }
            featuredType4Adapter.clearData();
            featuredType4Adapter.addData(novelBreifModels);
        }
    }
}
