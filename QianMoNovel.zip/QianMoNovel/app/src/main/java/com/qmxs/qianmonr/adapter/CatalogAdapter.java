package com.qmxs.qianmonr.adapter;

import com.qmxs.qianmonr.base.BaseListViewAdapter;
import com.qmxs.qianmonr.base.CatalogVHDelgate;
import com.qmxs.qianmonr.base.VHDelegate;

/*
 * File: CatalogAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/17 6:37 PM
 */
public class CatalogAdapter extends BaseListViewAdapter {

    @Override
    protected VHDelegate createVHDelegate(int viewType) {
        return new CatalogVHDelgate();
    }
}
