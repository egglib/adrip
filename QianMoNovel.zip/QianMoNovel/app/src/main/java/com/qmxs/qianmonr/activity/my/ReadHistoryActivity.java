package com.qmxs.qianmonr.activity.my;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;


import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.ReadHistoryAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.ReadHistoryViewHolder;

import java.util.ArrayList;
import java.util.List;

/*
 * File: ReadHistoryActivity.java
 * Description: 阅读历史界面
 * Author: XiaoTao
 * Create at 2019/2/19 8:43 PM
 */
public class ReadHistoryActivity extends BaseCommonTitleActivity implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private static final int TYPE_ITEM_READ_HISTORY = 1;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.read_history);
    }


    @Override
    protected void initView() {
        super.initView();
        View view = createActionBarRightText(getResources().getString(R.string.clear));
        view.setOnClickListener(v -> {

        });
        mRecyclerView = findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

        mSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.color_red_fd5e54));
        mSwipeRefreshLayout.setOnRefreshListener(this);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);

        ReadHistoryAdapter readHistoryAdapter = new ReadHistoryAdapter(this);
        readHistoryAdapter.register(TYPE_ITEM_READ_HISTORY, new ItemViewHolderContainer(R.layout.item_read_history, ReadHistoryViewHolder.class));
        mRecyclerView.setAdapter(readHistoryAdapter);
        readHistoryAdapter.setOnItemClickListener(v -> {
            Toast.makeText(this, "点击阅读历史item", Toast.LENGTH_SHORT).show();
        });

        List<RenderTypeModel> objects = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            RenderTypeModel renderTypeModel = new RenderTypeModel();
            renderTypeModel.setRenderType(TYPE_ITEM_READ_HISTORY);
            objects.add(renderTypeModel);
        }
        readHistoryAdapter.addData(objects);
    }


    @Override
    public void onRefresh() {

    }
}
