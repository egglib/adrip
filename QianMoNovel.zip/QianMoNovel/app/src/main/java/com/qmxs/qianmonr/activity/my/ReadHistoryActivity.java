package com.qmxs.qianmonr.activity.my;

import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.ReadHistoryAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.ReadHistoryModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.ToastUtil;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.ReadHistoryViewHolder;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.BallPulseFooter;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.List;

/*
 * File: ReadHistoryActivity.java
 * Description: 阅读历史界面
 * Author: XiaoTao
 * Create at 2019/2/19 8:43 PM
 */
public class ReadHistoryActivity extends BaseCommonTitleActivity implements OnLoadMoreListener, OnRefreshListener {

    private SmartRefreshLayout mSwipeRefreshLayout;
    private static final int TYPE_ITEM_READ_HISTORY = 1;
    private boolean isLoading = false;
    private int mPageNum = 1;
    private ReadHistoryAdapter readHistoryAdapter;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }

    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.read_history);
    }


    @Override
    protected void initView() {
        super.initView();
        View clearView = createActionBarRightText(getResources().getString(R.string.clear));

        RecyclerView mRecyclerView = findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

        CustomHeaderView header = new CustomHeaderView(this);
        mSwipeRefreshLayout.setRefreshHeader(header);

        BallPulseFooter footer = new BallPulseFooter(this).setSpinnerStyle(SpinnerStyle.Scale);
        mSwipeRefreshLayout.setRefreshFooter(footer);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setOnLoadMoreListener(this);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);

        readHistoryAdapter = new ReadHistoryAdapter(this);
        readHistoryAdapter.register(TYPE_ITEM_READ_HISTORY, new ItemViewHolderContainer(R.layout.item_read_history, ReadHistoryViewHolder.class));
        mRecyclerView.setAdapter(readHistoryAdapter);
        setDialogTip("阅读历史加载中...");

        clearView.setOnClickListener(v -> {

            if (readHistoryAdapter == null || readHistoryAdapter.getDataList() == null || readHistoryAdapter.getDataList().isEmpty()) {
                ToastUtil.shortShow(this, "没有阅读历史啦~");
                return;
            }
            delAllReadHistory();
        });
    }

    private void delAllReadHistory() {
        List<ReadHistoryModel> readHistoryModels = readHistoryAdapter.getDataList();

        StringBuilder stringBuffer = new StringBuilder();
        int size = readHistoryModels.size();
        for (int i = 0; i < size; i++) {
            ReadHistoryModel readHistoryModel = readHistoryModels.get(i);
            int bookId = readHistoryModel.getBookId();
            stringBuffer.append(bookId);
            if (i < size - 1) {
                stringBuffer.append(",");
            }
        }
        String ids = stringBuffer.toString();
        showDialog();
        ApiManager.delReadHistoryData(this, ids, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                readHistoryAdapter.clearData();
                readHistoryAdapter.notifyDataSetChanged();
            }

            @Override
            public void onError(Throwable e) {
                dismissDialog();
            }

            @Override
            public void onComplete() {
                dismissDialog();
            }
        });
    }


    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        getMoreData();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        refreshData();
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        refreshData();
    }

    private void refreshData() {
        if (!isLoading) {
            isLoading = true;
            mPageNum = 1;
            getData();
        }
    }

    private void getMoreData() {
        if (!isLoading) {
            isLoading = true;
            getData();
        }
    }

    private List<ReadHistoryModel> readHistoryModels;

    private void getData() {

        if (mPageNum == 1) {
            showDialog();
        }

        ApiManager.getReadHistoryListData(this, mPageNum, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }

                readHistoryModels = JsonUtil.jsonStrToObjList(response, ReadHistoryModel.class);

                if (readHistoryModels == null || readHistoryModels.isEmpty()) {
                    mSwipeRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }

                if (mPageNum == 1) {
                    readHistoryAdapter.clearData();
                }

                mPageNum++;

                for (ReadHistoryModel readHistoryModel : readHistoryModels) {
                    readHistoryModel.setRenderType(TYPE_ITEM_READ_HISTORY);
                }
                readHistoryAdapter.addData(readHistoryModels);
            }

            @Override
            public void onError(Throwable e) {
                isLoading = false;
                dismissDialog();
                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }
            }

            @Override
            public void onComplete() {
                dismissDialog();
                isLoading = false;
            }
        });
    }

}
