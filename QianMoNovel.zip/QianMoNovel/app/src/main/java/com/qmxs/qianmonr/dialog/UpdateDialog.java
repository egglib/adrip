package com.qmxs.qianmonr.dialog;


import android.app.Dialog;
import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.qmxs.qianmonr.R;


public class UpdateDialog extends Dialog {

    private TextView title;
    private Context mContext;
    private TextView mVersionNameTv;
    private TextView mVersionContentTv;
    private TextView mUpdateBtn;
    private ImageView mCloseImg;

    public UpdateDialog(Context context) {
        this(context, R.style.CustomDialog1);
    }

    public UpdateDialog(Context context, int themeResId) {
        super(context, themeResId);
        mContext = context;
        initView();
    }

    private void initView() {
        setContentView(R.layout.layout_dialog_update);
        setCancelable(false);
        setCanceledOnTouchOutside(true);
        Window window = getWindow();
        window.setGravity(Gravity.CENTER);
        mVersionNameTv = (TextView) window.findViewById(R.id.tv_version_name);
        mVersionContentTv = (TextView) window.findViewById(R.id.tv_version_content);
        mVersionContentTv.setMovementMethod(ScrollingMovementMethod.getInstance());
        mUpdateBtn = (TextView) window.findViewById(R.id.btn_update);
        mCloseImg = (ImageView) window.findViewById(R.id.img_close);
        mCloseImg.setOnClickListener(v -> dismiss());
        mUpdateBtn.setOnClickListener(v -> {

        });
    }

    public void setVersionNameStr(String versionNameStr) {
        mVersionNameTv.setText(versionNameStr);
    }

    public void setVersionContentStr(String contentStr) {
        mVersionContentTv.setText(contentStr);
    }


}
