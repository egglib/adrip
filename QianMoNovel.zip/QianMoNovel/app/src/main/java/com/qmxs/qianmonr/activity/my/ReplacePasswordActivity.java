package com.qmxs.qianmonr.activity.my;


import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: ReplacePasswordActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/19 1:39 PM
 */
public class ReplacePasswordActivity extends BaseCommonTitleActivity {

    @Override
    protected int getLayoutResId() {
        return 0;
    }
}
