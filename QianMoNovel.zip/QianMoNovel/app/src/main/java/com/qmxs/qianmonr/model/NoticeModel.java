package com.qmxs.qianmonr.model;

import android.os.Parcel;
import android.os.Parcelable;

/*
 * File: NoticeModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/14 9:11 PM
 */
public class NoticeModel extends RenderTypeModel implements Parcelable {

    /**
     * id : 2
     * title : 览书上线
     * content : 览书上线
     * type : 0
     * uuid : -1
     * created_at : 1551442828
     * updated_at : 1551442828
     * deleted : 0
     * apptype : qianmo
     * readed : 0
     */

    private int id;
    private String title;
    private String content;
    private int type;
    private String uuid;
    private int created_at;
    private int updated_at;
    private int deleted;
    private String apptype;
    private int readed;

    protected NoticeModel(Parcel in) {
        id = in.readInt();
        title = in.readString();
        content = in.readString();
        type = in.readInt();
        uuid = in.readString();
        created_at = in.readInt();
        updated_at = in.readInt();
        deleted = in.readInt();
        apptype = in.readString();
        readed = in.readInt();
    }

    public static final Creator<NoticeModel> CREATOR = new Creator<NoticeModel>() {
        @Override
        public NoticeModel createFromParcel(Parcel in) {
            return new NoticeModel(in);
        }

        @Override
        public NoticeModel[] newArray(int size) {
            return new NoticeModel[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public String getApptype() {
        return apptype;
    }

    public void setApptype(String apptype) {
        this.apptype = apptype;
    }

    public int getReaded() {
        return readed;
    }

    public void setReaded(int readed) {
        this.readed = readed;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(content);
        dest.writeInt(type);
        dest.writeString(uuid);
        dest.writeInt(created_at);
        dest.writeInt(updated_at);
        dest.writeInt(deleted);
        dest.writeString(apptype);
        dest.writeInt(readed);
    }
}
