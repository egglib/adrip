package  com.qmxs.qianmonr.widget.scrollview;

import android.support.v4.widget.NestedScrollView;

/*
 * File: NestedScrollListener.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/23 7:38 PM
 */
public interface NestedScrollListener {

    void onScrollChanged(NestedScrollView nestedScrollView, int scrollX, int scrollY, int oldScrollX, int oldScrollY);
}
