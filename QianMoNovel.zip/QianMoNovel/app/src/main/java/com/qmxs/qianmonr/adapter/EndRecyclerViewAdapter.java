package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: EndRecyclerViewAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 11:19 AM
 */
public class EndRecyclerViewAdapter extends BaseRecyclerViewAdapter {

    public EndRecyclerViewAdapter(Context context) {
        super(context);
    }
}
