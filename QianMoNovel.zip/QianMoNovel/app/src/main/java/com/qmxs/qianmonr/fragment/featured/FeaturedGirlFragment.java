package com.qmxs.qianmonr.fragment.featured;

import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.FFeaturedRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseLazyFragment;
import com.qmxs.qianmonr.model.AdBannerInfoModel;
import com.qmxs.qianmonr.model.AdBannerModel;
import com.qmxs.qianmonr.model.FSortModel;
import com.qmxs.qianmonr.model.FeaturedNovelModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.viewholder.AuthorViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedBannerViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedGirlSortViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType1ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType2ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType3ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType4ViewHolder;
import com.qmxs.qianmonr.viewholder.FeaturedType6ViewHolder;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.List;

/*
 * File: FeaturedGirlFragment.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/21 4:29 PM
 */
public class FeaturedGirlFragment extends BaseLazyFragment implements OnRefreshListener {

    private FFeaturedRecyclerViewAdapter adapter;

    private static final int TYPE_ITEM_BANNER = -1;
    private static final int TYPE_ITEM_SORT_GIRL = -4;
    private static final int TYPE_ITEM_FEATURED_0 = 0;
    private static final int TYPE_ITEM_FEATURED_1 = 1;
    private static final int TYPE_ITEM_FEATURED_2 = 2;
    private static final int TYPE_ITEM_FEATURED_3 = 3;
    private static final int TYPE_ITEM_FEATURED_4 = 4;
    private static final int TYPE_ITEM_FEATURED_5 = 5;
    private static final int TYPE_ITEM_FEATURED_6 = 6;

    private SmartRefreshLayout mSwipeRefreshLayout;

    @Override
    protected int setLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview_outside;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        RecyclerView mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mSwipeRefreshLayout = (SmartRefreshLayout) view.findViewById(R.id.swipeRefreshLayout);
        CustomHeaderView header = new CustomHeaderView(getContext());
        mSwipeRefreshLayout.setRefreshHeader(header);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);

        adapter = new FFeaturedRecyclerViewAdapter(getContext());
        adapter.register(TYPE_ITEM_BANNER, new ItemViewHolderContainer(R.layout.item_banner_view, FeaturedBannerViewHolder.class));
        adapter.register(TYPE_ITEM_SORT_GIRL, new ItemViewHolderContainer(R.layout.item_featuredgirl_sort, FeaturedGirlSortViewHolder.class));

        adapter.register(TYPE_ITEM_FEATURED_0, new ItemViewHolderContainer(R.layout.item_featured_author, AuthorViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_1, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType1ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_2, new ItemViewHolderContainer(R.layout.item_featured_type_2, FeaturedType2ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_3, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType3ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_4, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType4ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_5, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType6ViewHolder.class));
        adapter.register(TYPE_ITEM_FEATURED_6, new ItemViewHolderContainer(R.layout.item_featured_type_1, FeaturedType6ViewHolder.class));
        mRecyclerView.setAdapter(adapter);
        setDialogTip("精选数据加载中...");

    }

    @Override
    protected void onLazyLoad() {

    }


    @Override
    protected void pageHandle() {
        super.pageHandle();
        getRecommendData();
    }

    private void getRecommendData() {
        adapter.clearData();
        showDialog();
        ApiManager.getAdBannerFeaturedGirlData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                List<AdBannerModel> adBannerModels = JsonUtil.jsonStrToObjList(response, AdBannerModel.class);

                AdBannerInfoModel adBannerInfoModel = new AdBannerInfoModel();
                adBannerInfoModel.setRenderType(TYPE_ITEM_BANNER);
                adBannerInfoModel.setAdBannerModels(adBannerModels);
                adapter.getDataList().add(0, adBannerInfoModel);

                FSortModel fSortModel = new FSortModel();
                fSortModel.setRenderType(TYPE_ITEM_SORT_GIRL);
                adapter.getDataList().add(1, fSortModel);
            }

            @Override
            public void onError(Throwable e) {
                mSwipeRefreshLayout.finishRefresh();
            }

            @Override
            public void onComplete() {
                mSwipeRefreshLayout.finishRefresh();

            }
        });
        ApiManager.getRecommendGirlData(getContext(), new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<FeaturedNovelModel> featruredModels = JsonUtil.jsonStrToObjList(response, FeaturedNovelModel.class);
                for (FeaturedNovelModel featruredModel : featruredModels) {
                    featruredModel.setRenderType(featruredModel.getType());
                }
                adapter.addData(featruredModels);
            }

            @Override
            public void onError(Throwable e) {
                mSwipeRefreshLayout.finishRefresh();
                dismissDialog();
            }

            @Override
            public void onComplete() {
                mSwipeRefreshLayout.finishRefresh();
                dismissDialog();
            }
        });
    }


    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        getRecommendData();
    }
}
