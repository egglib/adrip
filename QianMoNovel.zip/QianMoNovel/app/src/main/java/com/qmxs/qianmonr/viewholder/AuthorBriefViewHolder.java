package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.AuthorBreifModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;
import java.util.Random;

/*
 * File: AuthorBriefViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/2 1:37 PM
 */
class AuthorBriefViewHolder extends BaseViewHolder {

    private ImageView mBgAuhtorImg;
    private NetworkImageView mAuhtorAvatarImg;
    private TextView mAuthorNameTv;
    private TextView mBriefIntroTv;
    private FrameLayout mLayoutItem;
    private LinearLayout mLayoutContent;

    private int[] bgImgs = {
            R.mipmap.bg_img_author_blue,
            R.mipmap.bg_img_author_red,
            R.mipmap.bg_img_author_orange,
            R.mipmap.bg_img_author_purple
    };

    private  AuthorBreifModel authorBreifModel;


    public AuthorBriefViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);

        mBgAuhtorImg = (ImageView) itemView.findViewById(R.id.img_bg_auhtor);
        mLayoutItem = (FrameLayout) itemView.findViewById(R.id.layout_item);
        mAuhtorAvatarImg = itemView.findViewById(R.id.img_auhtor_avatar);
        mAuthorNameTv = (TextView) itemView.findViewById(R.id.tv_author_name);
        mBriefIntroTv = (TextView) itemView.findViewById(R.id.tv_brief_intro);
        mLayoutContent = itemView.findViewById(R.id.layout_content);

        Random random = new Random();
        int index = random.nextInt(4);

        int bgImgId = bgImgs[index];
        mBgAuhtorImg.setImageResource(bgImgId);

        int width = ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(110);
        int height = width * 2 / 3;
        mLayoutItem.setLayoutParams(new FrameLayout.LayoutParams(width, FrameLayout.LayoutParams.WRAP_CONTENT));
        mBgAuhtorImg.setLayoutParams(new FrameLayout.LayoutParams(width, height));

        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) mBgAuhtorImg.getLayoutParams();
        layoutParams.setMargins(0, ScreenUtil.dp2px(15), 0, 0);

        mLayoutContent.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, height + ScreenUtil.dp2px(15)));

        itemView.setOnClickListener(v -> JumpUtil.forwordToAuthorDetail(mContext,authorBreifModel.getId()));
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);

        authorBreifModel  = (AuthorBreifModel) objectList.get(position);

        String url = authorBreifModel.getImg();
        if (!TextUtils.isEmpty(url))
            mAuhtorAvatarImg.setImgUrl(url);

        String name = authorBreifModel.getName();
        if (!TextUtils.isEmpty(name))
            mAuthorNameTv.setText(name);

        String intro = authorBreifModel.getIntroduction();
        if (!TextUtils.isEmpty(intro))
            mBriefIntroTv.setText(intro);
    }
}
