package com.qmxs.qianmonr.adapter;
import android.content.Context;

/*
 * File: SortListPopularAdapter.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/25 5:46 PM
 */
public class SortListPopularAdapter extends BaseRecyclerViewAdapter {

    public SortListPopularAdapter(Context context) {
        super(context);
    }
}
