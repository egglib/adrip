package com.qmxs.qianmonr.model;

/*
 * File: NovelCatalogModel.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/8 3:18 PM
 */
public class NovelCatalogModel extends RenderTypeModel{

    /**
     * id : 1
     * bookChapterId : 2889847
     * name : 第一章 读心术
     * orderNo : 1
     */

    private int id;
    private int bookChapterId;
    private String name;
    private int orderNo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookChapterId() {
        return bookChapterId;
    }

    public void setBookChapterId(int bookChapterId) {
        this.bookChapterId = bookChapterId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }
}
