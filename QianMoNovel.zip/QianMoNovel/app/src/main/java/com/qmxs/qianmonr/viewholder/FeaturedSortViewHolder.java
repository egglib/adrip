package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.LinearLayout;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.main.LiteratureActivity;
import com.qmxs.qianmonr.activity.main.PopularListActivity;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.PageJumpUtil;


/*
 * File: FeaturedSortViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 6:38 PM
 */
public class FeaturedSortViewHolder extends BaseViewHolder {

    private LinearLayout mPopularListLayout;
    private LinearLayout mDailyUpdateLayout;
    private LinearLayout mEndLayout;
    private LinearLayout mLiteratureLayout;

    public FeaturedSortViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mPopularListLayout = (LinearLayout) itemView.findViewById(R.id.layout_popular_list);
        mDailyUpdateLayout = (LinearLayout) itemView.findViewById(R.id.layout_daily_update);
        mEndLayout = (LinearLayout) itemView.findViewById(R.id.layout_end);
        mLiteratureLayout = (LinearLayout) itemView.findViewById(R.id.layout_literature);

        mPopularListLayout.setOnClickListener(v -> {
            mContext.startActivity(new Intent(mContext, PopularListActivity.class));
        });

        mDailyUpdateLayout.setOnClickListener(v -> {
            JumpUtil.forwordToDailyUpdate(mContext, 0);
        });

        mEndLayout.setOnClickListener(v -> {
            JumpUtil.forwordToEnd(mContext, 0);
        });

        mLiteratureLayout.setOnClickListener(v ->
                PageJumpUtil.forwordToPage(mContext, LiteratureActivity.class)
        );
    }
}
