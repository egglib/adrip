package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.LinearLayout;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.activity.AuthorDetailActivity;
import com.qmxs.qianmonr.activity.DailyUpdateListActivity;
import com.qmxs.qianmonr.activity.EndActivity;
import com.qmxs.qianmonr.activity.PopularListActivity;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;


/*
 * File: FeaturedSortViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 6:38 PM
 */
public class FeaturedSortViewHolder extends BaseViewHolder {

    private LinearLayout mPopularListLayout;
    private LinearLayout mDailyUpdateLayout;
    private LinearLayout mEndLayout;
    private LinearLayout mLiteratureLayout;

    public FeaturedSortViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mPopularListLayout = (LinearLayout) itemView.findViewById(R.id.layout_popular_list);
        mDailyUpdateLayout = (LinearLayout) itemView.findViewById(R.id.layout_daily_update);
        mEndLayout = (LinearLayout) itemView.findViewById(R.id.layout_end);
        mLiteratureLayout = (LinearLayout) itemView.findViewById(R.id.layout_literature);

        mPopularListLayout.setOnClickListener(v -> {
            mContext.startActivity(new Intent(mContext, PopularListActivity.class));
        });

        mDailyUpdateLayout.setOnClickListener(v -> {
            mContext.startActivity(new Intent(mContext, DailyUpdateListActivity.class));
        });

        mEndLayout.setOnClickListener(v -> {
            mContext.startActivity(new Intent(mContext, EndActivity.class));
        });

        mLiteratureLayout.setOnClickListener(v ->
                mContext.startActivity(new Intent(mContext, AuthorDetailActivity.class))
        );
    }
}
