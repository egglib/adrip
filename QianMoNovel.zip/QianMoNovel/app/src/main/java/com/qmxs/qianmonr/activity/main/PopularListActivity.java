package com.qmxs.qianmonr.activity.main;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.PopularListAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RankFirstInfoModel;
import com.qmxs.qianmonr.model.RankFirstModel;
import com.qmxs.qianmonr.model.RankModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.PopularListHeaderViewHolder;
import com.qmxs.qianmonr.viewholder.PopularListViewHolder;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.List;

/*
 * File: PopularListActivity.java
 * Description:榜单界面
 * Author: XiaoTao
 * Create at 2019/2/26 10:06 PM
 */
public class PopularListActivity extends BaseCommonTitleActivity implements OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SmartRefreshLayout mSwipeRefreshLayout;
    private static final int TYPE_ITEM_HEADER = -1;
    private static final int TYPE_ITEM_POPULAR_1 = 1;
    private static final int TYPE_ITEM_POPULAR_2 = 2;
    private static final int TYPE_ITEM_POPULAR_3 = 3;
    private static final int TYPE_ITEM_POPULAR_4 = 4;
    private static final int TYPE_ITEM_POPULAR_5 = 5;
    private static final int TYPE_ITEM_POPULAR_6 = 6;

    private PopularListAdapter popularListAdapter;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_smartrefreshlayout_recyclerview;
    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.popular_list);
    }

    @Override
    protected void initView() {
        View view = createActionBarRightIcon(R.mipmap.ic_search);
        view.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        mRecyclerView = findViewById(R.id.recyclerView);

        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        CustomHeaderView header = new CustomHeaderView(this);
        mSwipeRefreshLayout.setRefreshHeader(header);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setNestedScrollingEnabled(false);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        popularListAdapter = new PopularListAdapter(this);

        popularListAdapter.register(TYPE_ITEM_HEADER, new ItemViewHolderContainer(R.layout.item_popular_list_header, PopularListHeaderViewHolder.class));
        popularListAdapter.register(TYPE_ITEM_POPULAR_1, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        popularListAdapter.register(TYPE_ITEM_POPULAR_2, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        popularListAdapter.register(TYPE_ITEM_POPULAR_3, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        popularListAdapter.register(TYPE_ITEM_POPULAR_4, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        popularListAdapter.register(TYPE_ITEM_POPULAR_5, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));
        popularListAdapter.register(TYPE_ITEM_POPULAR_6, new ItemViewHolderContainer(R.layout.item_popular_list, PopularListViewHolder.class));

        mRecyclerView.setAdapter(popularListAdapter);

        setDialogTip("榜单数据加载中...");
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        getData();
    }

    private void getData() {
        showDialog();
        ApiManager.getRankFirst(this, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<RankFirstModel> rankFirstModels = JsonUtil.jsonStrToObjList(response, RankFirstModel.class);
                RankFirstInfoModel rankFirstInfoModel = new RankFirstInfoModel();
                rankFirstInfoModel.setRenderType(TYPE_ITEM_HEADER);
                rankFirstInfoModel.setRankFirstModels(rankFirstModels);
                popularListAdapter.getDataList().add(0, rankFirstInfoModel);
                mSwipeRefreshLayout.finishRefresh();
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
        ApiManager.getRankData(this, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {
                List<RankModel> rankModels = JsonUtil.jsonStrToObjList(response, RankModel.class);
                for (RankModel rankModel : rankModels) {
                    rankModel.setRenderType(rankModel.getRankId());
                }
                popularListAdapter.addData(rankModels);
                mSwipeRefreshLayout.finishRefresh();
            }

            @Override
            public void onError(Throwable e) {
                dismissDialog();
            }

            @Override
            public void onComplete() {
                dismissDialog();
            }
        });
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        popularListAdapter.clearData();
        getData();
    }
}
