package com.qmxs.qianmonr.widget;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.qmxs.qianmonr.pagetransformer.AlphaPageTransformer;


/*
 * File: CustomViewPager.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/25 12:54 PM
 */
public class CustomViewPager extends ViewPager {

    /**
     * 默认可以滚动
     */
    private boolean isCanScroll = true;

    public CustomViewPager(@NonNull Context context) {
        super(context, null);
    }

    public CustomViewPager(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    /**
     * 设置其是否能滑动换页
     *
     * @param isCanScroll false 不能换页， true 可以滑动换页
     */
    public void setCanScroll(boolean isCanScroll) {
        this.isCanScroll = isCanScroll;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        return isCanScroll && super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        return isCanScroll && super.onTouchEvent(ev);
    }

    private void init() {
        this.setPageTransformer(true, new AlphaPageTransformer());
    }

}
