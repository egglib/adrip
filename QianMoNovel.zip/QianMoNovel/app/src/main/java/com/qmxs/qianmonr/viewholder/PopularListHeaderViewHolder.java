package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RankFirstInfoModel;
import com.qmxs.qianmonr.model.RankFirstModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: PopularListHeaderViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/12 8:23 PM
 */
public class PopularListHeaderViewHolder extends BaseViewHolder {

    private NetworkImageView mCover3Img;
    private TextView mNovelName3Tv;
    private TextView mNovelAuthor3Tv;
    private NetworkImageView mCover1Img;
    private TextView mNovelName1Tv;
    private TextView mNovelAuthor1Tv;
    private NetworkImageView mCover2Img;
    private TextView mNovelName2Tv;
    private TextView mNovelAuthor2Tv;
    private LinearLayout mLayout1;
    private LinearLayout mLayout2;
    private LinearLayout mLayout3;


    public PopularListHeaderViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mCover3Img = (NetworkImageView) itemView.findViewById(R.id.img_cover_3);
        mNovelName3Tv = (TextView) itemView.findViewById(R.id.tv_novel_name_3);
        mNovelAuthor3Tv = (TextView) itemView.findViewById(R.id.tv_novel_author_3);
        mCover1Img = (NetworkImageView) itemView.findViewById(R.id.img_cover_1);
        mNovelName1Tv = (TextView) itemView.findViewById(R.id.tv_novel_name_1);
        mNovelAuthor1Tv = (TextView) itemView.findViewById(R.id.tv_novel_author_1);
        mCover2Img = (NetworkImageView) itemView.findViewById(R.id.img_cover_2);
        mNovelName2Tv = (TextView) itemView.findViewById(R.id.tv_novel_name_2);
        mNovelAuthor2Tv = (TextView) itemView.findViewById(R.id.tv_novel_author_2);

        mLayout1 = (LinearLayout) itemView.findViewById(R.id.layout1);
        mLayout2 = (LinearLayout) itemView.findViewById(R.id.layout2);
        mLayout3 = (LinearLayout) itemView.findViewById(R.id.layout3);

        int width = (ScreenUtil.getScreenWidth() - ScreenUtil.dp2px(60)) / 3;
        int height = width * 3 / 2;
        int height1 = width * 3 / 2 - ScreenUtil.dp2px(20);

        mCover1Img.setLayoutParams(new FrameLayout.LayoutParams(width, height));
        mCover2Img.setLayoutParams(new FrameLayout.LayoutParams(width, height1));
        mCover3Img.setLayoutParams(new FrameLayout.LayoutParams(width, height1));

        LinearLayout.LayoutParams params1 = (LinearLayout.LayoutParams) mLayout1.getLayoutParams();
        params1.setMargins(ScreenUtil.dp2px(15), 0, ScreenUtil.dp2px(15), 0);

        LinearLayout.LayoutParams params3 = (LinearLayout.LayoutParams) mLayout3.getLayoutParams();
        params3.setMargins(ScreenUtil.dp2px(15), 0, 0, 0);

        LinearLayout.LayoutParams params2 = (LinearLayout.LayoutParams) mLayout2.getLayoutParams();
        params2.setMargins(0, 0, ScreenUtil.dp2px(15), 0);
    }

    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        RankFirstInfoModel rankFirstInfoModel = (RankFirstInfoModel) objectList.get(position);
        if (rankFirstInfoModel != null) {
            List<RankFirstModel> rankFirstModels = rankFirstInfoModel.getRankFirstModels();
            RankFirstModel rankFirstModel = rankFirstModels.get(0);
            mCover3Img.setImgUrl(rankFirstModel.getImg());
            mNovelName3Tv.setText(rankFirstModel.getTitle());
            mNovelAuthor3Tv.setText(rankFirstModel.getAuthor());

            mLayout3.setOnClickListener(v -> JumpUtil.forwordToNovelDetail(mContext, rankFirstModel.getBookId()));

            RankFirstModel rankFirstModel1 = rankFirstModels.get(1);
            mCover1Img.setImgUrl(rankFirstModel1.getImg());
            mNovelName1Tv.setText(rankFirstModel1.getTitle());
            mNovelAuthor1Tv.setText(rankFirstModel1.getAuthor());
            mLayout1.setOnClickListener(v -> JumpUtil.forwordToNovelDetail(mContext, rankFirstModel1.getBookId()));

            RankFirstModel rankFirstModel2 = rankFirstModels.get(2);
            mCover2Img.setImgUrl(rankFirstModel2.getImg());
            mNovelName2Tv.setText(rankFirstModel2.getTitle());
            mNovelAuthor2Tv.setText(rankFirstModel2.getAuthor());
            mLayout2.setOnClickListener(v -> JumpUtil.forwordToNovelDetail(mContext, rankFirstModel2.getBookId()));

        }
    }
}
