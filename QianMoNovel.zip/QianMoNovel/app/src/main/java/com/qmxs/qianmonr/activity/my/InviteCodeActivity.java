package com.qmxs.qianmonr.activity.my;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: InviteCodeActivity.java
 * Description: 邀请码界面
 * Author: XiaoTao
 * Create at 2019/2/20 10:01 AM
 */
public class InviteCodeActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private TextView mConfirmBtn;
    private EditText mInviteCodeEt;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_invite_code;
    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.invite_code);
    }


    @Override
    protected void initView() {
        mConfirmBtn = (TextView) findViewById(R.id.btn_confirm);
        mConfirmBtn.setOnClickListener(this);
        mInviteCodeEt = (EditText) findViewById(R.id.et_invite_code);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_confirm:
                confirmSubmit();
                break;
            default:
                break;
        }
    }

    private void confirmSubmit() {

    }
}
