package com.qmxs.qianmonr.activity.my;

import android.view.View;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;

/*
 * File: InviteCodeActivity.java
 * Description: 邀请码界面
 * Author: XiaoTao
 * Create at 2019/2/20 10:01 AM
 */
public class InviteCodeActivity extends BaseCommonTitleActivity implements View.OnClickListener {

    private TextView mConfirmBtn;

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_invite_code;
    }


    @Override
    protected String getTitleText() {
        return getResources().getString(R.string.invite_code);
    }


    @Override
    protected void initView() {
        mConfirmBtn = (TextView) findViewById(R.id.btn_confirm);
        mConfirmBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_confirm:
                break;
            default:
                break;
        }
    }
}
