package com.qmxs.qianmonr.base;

import android.app.Application;
import android.support.annotation.Nullable;

import com.crashlytics.android.Crashlytics;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;
import com.qmxs.qianmonr.BuildConfig;
import com.qmxs.qianmonr.config.Global;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.squareup.leakcanary.LeakCanary;

import io.fabric.sdk.android.Fabric;


public class BaseApplication extends Application {

    private static BaseApplication mInstance;

    public static BaseApplication getInstance() {
        return mInstance;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        if (mInstance == null) {
            mInstance = this;
        }
        ScreenUtil.initScreenInfo(this);
//        initLeakCanary();
        Fabric.with(this, new Crashlytics());
        initLog();
        getStatusHeight();
    }

    private void getStatusHeight() {
        int height = 0;
        int resourceId = this.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            height = this.getResources().getDimensionPixelSize(resourceId);
        }
        Global.STUTAS_BAR_HEIGHT = height;
    }

    private void initLog() {
        Logger.addLogAdapter(new AndroidLogAdapter() {
            @Override
            public boolean isLoggable(int priority, @Nullable String tag) {
                return BuildConfig.DEBUG;
            }
        });
    }

    private void initLeakCanary() {
        if (LeakCanary.isInAnalyzerProcess(this)) {
            return;
        }
        LeakCanary.install(this);
    }
}
