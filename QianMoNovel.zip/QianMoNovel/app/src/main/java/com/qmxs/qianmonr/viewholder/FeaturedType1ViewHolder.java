package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.Featured1RecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.GridSpacingItemDecoration;
import com.qmxs.qianmonr.util.ScreenUtil;

import java.util.ArrayList;
import java.util.List;

/*
 * File: FeaturedType1ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 8:19 PM
 */
public class FeaturedType1ViewHolder extends BaseViewHolder {

    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private ImageView mMoreImg;
    private TextView mMoreTitleTv;
    private Featured1RecyclerViewAdapter featured1RecyclerViewAdapter;

    public FeaturedType1ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);
        mMoreImg = (ImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3);
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.requestFocus();
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        featured1RecyclerViewAdapter = new Featured1RecyclerViewAdapter(mContext);
        featured1RecyclerViewAdapter.register(11, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, FeaturedType11ViewHolder.class));
        featured1RecyclerViewAdapter.register(12, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, FeaturedType12ViewHolder.class));
        mRecyclerView.setAdapter(featured1RecyclerViewAdapter);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (position == 0) {
                    return 3;
                } else {
                    return 1;
                }
            }
        });
        mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(1, 3, ScreenUtil.dp2px(18),
                true, false, true));

        List<RenderTypeModel> renderTypeModels = new ArrayList<>();
        RenderTypeModel renderTypeModel = new RenderTypeModel();
        renderTypeModel.setRenderType(11);

        RenderTypeModel renderTypeModel1 = new RenderTypeModel();
        renderTypeModel1.setRenderType(12);

        RenderTypeModel renderTypeModel2 = new RenderTypeModel();
        renderTypeModel2.setRenderType(12);

        RenderTypeModel renderTypeModel3 = new RenderTypeModel();
        renderTypeModel3.setRenderType(12);

        renderTypeModels.add(renderTypeModel);
        renderTypeModels.add(renderTypeModel1);
        renderTypeModels.add(renderTypeModel2);
        renderTypeModels.add(renderTypeModel3);

        featured1RecyclerViewAdapter.addData(renderTypeModels);
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);


    }
}
