package com.qmxs.qianmonr.viewholder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.BaseRecyclerViewAdapter;
import com.qmxs.qianmonr.adapter.Featured1RecyclerViewAdapter;
import com.qmxs.qianmonr.base.BaseViewHolder;
import com.qmxs.qianmonr.model.FeaturedNovelModel;
import com.qmxs.qianmonr.model.NovelBreifModel;
import com.qmxs.qianmonr.model.RenderTypeModel;
import com.qmxs.qianmonr.util.GridSpacingItemDecoration;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.widget.NetworkImageView;

import java.util.List;

/*
 * File: FeaturedType1ViewHolder.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/2/27 8:19 PM
 */
public class FeaturedType1ViewHolder extends BaseViewHolder {

    private LinearLayout mMoreLayout;
    private RecyclerView mRecyclerView;
    private NetworkImageView mMoreImg;
    private TextView mMoreTitleTv;
    private Featured1RecyclerViewAdapter featured1RecyclerViewAdapter;
    private TextView mNameTv;
    private TextView mIntroTv;
    private TextView mTagTv;
    private TextView mViewsNumberTv;
    private NetworkImageView mCoverImg;

    public FeaturedType1ViewHolder(Context context, BaseRecyclerViewAdapter adapter, @NonNull View itemView) {
        super(context, adapter, itemView);
        mMoreLayout = (LinearLayout) itemView.findViewById(R.id.layout_more);
        mRecyclerView = itemView.findViewById(R.id.recyclerView);
        mMoreImg = (NetworkImageView) itemView.findViewById(R.id.img_more);
        mMoreTitleTv = (TextView) itemView.findViewById(R.id.tv_more_title);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        mRecyclerView.setFocusableInTouchMode(false);
        mRecyclerView.setFocusable(false);
        mRecyclerView.requestFocus();
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setNestedScrollingEnabled(false);
        if (mRecyclerView.getAdapter() == null)
            featured1RecyclerViewAdapter = new Featured1RecyclerViewAdapter(mContext);
        featured1RecyclerViewAdapter.register(11, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, NovelBriefIntroViewHolder.class));
        featured1RecyclerViewAdapter.register(12, new ItemViewHolderContainer(R.layout.item_novel_img_tv_tv, FeaturedType12ViewHolder.class));
        mRecyclerView.setAdapter(featured1RecyclerViewAdapter);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (position == 0) {
                    return 3;
                } else {
                    return 1;
                }
            }
        });
        mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(1, 3, ScreenUtil.dp2px(18),
                true, false, true));
    }


    @Override
    public void renderView(List<? extends RenderTypeModel> objectList, int position) {
        super.renderView(objectList, position);
        FeaturedNovelModel featruredModel = (FeaturedNovelModel) objectList.get(position);

        if (featruredModel != null) {

            String title = featruredModel.getTitle();
            String id = featruredModel.getTopicId();

            mMoreLayout.setOnClickListener(v -> {
                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(id)) {
                    JumpUtil.forwordToRecommendList(mContext, title, id);
                }
            });

            String imgUrl = featruredModel.getIcon();
            if (!TextUtils.isEmpty(imgUrl)) {
                mMoreImg.setImgUrl(imgUrl);
            }

            if (!TextUtils.isEmpty(title)) {
                mMoreTitleTv.setText(title);
            }

            List<NovelBreifModel> novelBreifModels = featruredModel.getData();
            for (int i = 0; i < novelBreifModels.size(); i++) {
                NovelBreifModel novelBreifModel = novelBreifModels.get(i);
                if (i == 0) {
                    novelBreifModel.setRenderType(11);
                } else {
                    novelBreifModel.setRenderType(12);
                }
            }
            featured1RecyclerViewAdapter.clearData();
            featured1RecyclerViewAdapter.addData(novelBreifModels);
        }

    }
}
