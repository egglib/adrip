package com.qmxs.qianmonr.activity.main;

import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.qmxs.qianmonr.R;
import com.qmxs.qianmonr.adapter.RecommendListAdapter;
import com.qmxs.qianmonr.base.BaseCommonTitleActivity;
import com.qmxs.qianmonr.model.RecommendNovelInfoModel;
import com.qmxs.qianmonr.model.RecommendNovelModel;
import com.qmxs.qianmonr.net.ApiManager;
import com.qmxs.qianmonr.net.RetrofitCallback;
import com.qmxs.qianmonr.util.JsonUtil;
import com.qmxs.qianmonr.util.JumpUtil;
import com.qmxs.qianmonr.util.ScreenUtil;
import com.qmxs.qianmonr.util.SpacesItemDecoration;
import com.qmxs.qianmonr.viewholder.ItemViewHolderContainer;
import com.qmxs.qianmonr.viewholder.RecommendListViewHolder;
import com.qmxs.qianmonr.widget.CustomHeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.BallPulseFooter;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.List;

/*
 * File: RecommendListActivity.java
 * Description:
 * Author: XiaoTao
 * Create at 2019/3/12 12:20 PM
 */
public class RecommendListActivity extends BaseCommonTitleActivity implements OnLoadMoreListener, OnRefreshListener {

    private RecyclerView mRecyclerView;
    private SmartRefreshLayout mSwipeRefreshLayout;
    private String channelId;
    private RecommendListAdapter recommendListAdapter;
    private static final int RENDER_TYPE = 1;
    private boolean isLoading = false;
    private int mPageNum = 1;

    @Override
    protected int getLayoutResId() {
        return R.layout.layout_swiperefreshlayout_recyclerview_outside;
    }

    @Override
    protected void initView() {
        super.initView();
        mSwipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        mRecyclerView = findViewById(R.id.recyclerView);
        CustomHeaderView header = new CustomHeaderView(this);
        mSwipeRefreshLayout.setRefreshHeader(header);

        BallPulseFooter footer = new BallPulseFooter(this).setSpinnerStyle(SpinnerStyle.Scale);
        mSwipeRefreshLayout.setRefreshFooter(footer);

        String title = JumpUtil.getTitleStr(this);
        setTitleStr(title);
        channelId = JumpUtil.getChannelIdStr(this);

        recommendListAdapter = new RecommendListAdapter(this);
        recommendListAdapter.register(RENDER_TYPE, new ItemViewHolderContainer(R.layout.item_novel_brief_intro_style, RecommendListViewHolder.class));

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(recommendListAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(0, 0, ScreenUtil.dp2px(15), 0));

        mSwipeRefreshLayout.setOnLoadMoreListener(this);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        setDialogTip("推荐数据加载中...");
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        getMoreData();
    }

    private void getMoreData() {
        if (!isLoading) {
            isLoading = true;
            getData();
        }
    }

    @Override
    protected void pageHandle() {
        super.pageHandle();
        refreshData();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        refreshData();
    }

    private void refreshData() {
        if (!isLoading) {
            isLoading = true;
            mPageNum = 1;
            getData();
        }
    }


    private void getData() {

        if (mPageNum == 1) {
            showDialog();
        }

        ApiManager.getRecommendListData(this, channelId, mPageNum, new RetrofitCallback() {
            @Override
            public void onSuccess(String response) {

                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }

                RecommendNovelInfoModel recommendNovelInfo = JsonUtil.jsonStrToObj(response, RecommendNovelInfoModel.class);

                if (recommendNovelInfo == null) {
                    mSwipeRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }

                List<RecommendNovelModel> novelModelList = recommendNovelInfo.getData();

                if (novelModelList == null || novelModelList.isEmpty()) {
                    mSwipeRefreshLayout.finishLoadMoreWithNoMoreData();
                    return;
                }

                if (mPageNum == 1) {
                    recommendListAdapter.clearData();
                }
                mPageNum++;

                for (RecommendNovelModel recommendNovelModel : novelModelList) {
                    recommendNovelModel.setRenderType(RENDER_TYPE);
                }
                recommendListAdapter.addData(novelModelList);

            }

            @Override
            public void onError(Throwable e) {
                isLoading = false;
                if (mPageNum == 1) {
                    mSwipeRefreshLayout.finishRefresh();
                } else if (mPageNum > 1) {
                    mSwipeRefreshLayout.finishLoadMore();
                }
                dismissDialog();
            }

            @Override
            public void onComplete() {
                isLoading = false;
                dismissDialog();
            }
        });
    }


}
