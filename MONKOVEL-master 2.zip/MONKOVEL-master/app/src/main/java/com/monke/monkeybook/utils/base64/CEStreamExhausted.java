package com.monke.monkeybook.utils.base64;

import java.io.IOException;

public class CEStreamExhausted extends IOException {
    static final long serialVersionUID = -5889118049525891904L;

    public CEStreamExhausted() {
    }
}
