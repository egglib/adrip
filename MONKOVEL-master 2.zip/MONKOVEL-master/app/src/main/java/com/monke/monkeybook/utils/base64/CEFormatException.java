package com.monke.monkeybook.utils.base64;

import java.io.IOException;

public class CEFormatException extends IOException {
    static final long serialVersionUID = -7139121221067081482L;

    public CEFormatException(String var1) {
        super(var1);
    }
}