package com.monke.monkeybook.widget.refreshview;

public interface OnRefreshWithProgressListener extends BaseRefreshListener{

    public int getMaxProgress();
}
