package com.monke.basemvplib;

import android.app.Application;

public class BaseApplication extends Application{
    @Override
    public void onCreate() {
        super.onCreate();
    }
}