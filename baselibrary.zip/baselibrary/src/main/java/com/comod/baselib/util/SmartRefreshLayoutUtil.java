package com.comod.baselib.util;

import android.content.Context;

import com.comod.baselib.R;
import com.scwang.smart.refresh.footer.BallPulseFooter;
import com.scwang.smart.refresh.header.ClassicsHeader;
import com.scwang.smart.refresh.layout.constant.SpinnerStyle;

public class SmartRefreshLayoutUtil {

    /**
     * 自定义头部视图
     *
     * @param context
     * @return
     */
    public static ClassicsHeader getCustomHeader(Context context) {
        return getCustomHeader(context, R.mipmap.icon_down_arrow, R.color.color_b4, R.color.transparent);
    }


    public static ClassicsHeader getCustomHeader(Context context, int color) {
        return getCustomHeader(context, R.mipmap.icon_down_arrow, R.color.color_b4, color);
    }

    public static ClassicsHeader getWhiteHeader(Context context) {
        return getCustomHeader(context, R.mipmap.icon_down_arrow_white, R.color.white, R.color.transparent);
    }

    public static ClassicsHeader getCustomHeader(Context context, int res, int textColor, int bgColor) {
        ClassicsHeader classicsHeader = new ClassicsHeader(context);
        classicsHeader.setArrowResource(res);
        classicsHeader.setAccentColor(context.getResources().getColor(textColor));
        classicsHeader.setBackgroundColor(context.getResources().getColor(bgColor));
        classicsHeader.setEnableLastTime(true);
        classicsHeader.setTextSizeTitle(12);
        classicsHeader.setTextSizeTime(11);
        classicsHeader.setDrawableArrowSize(15);
        classicsHeader.setDrawableProgressSize(15);
        return classicsHeader;
    }


    /**
     * 自定义底部视图
     *
     * @param context
     * @return
     */
    public static BallPulseFooter getCustomFooter(Context context) {
        BallPulseFooter footer = new BallPulseFooter(context).setSpinnerStyle(SpinnerStyle.Scale);
        footer.setAnimatingColor(context.getResources().getColor(R.color.color_primary));
        return footer;
    }

    /**
     * @param context
     * @param color
     * @return
     */
    public static BallPulseFooter getCustomFooter(Context context, int color) {
        BallPulseFooter footer = new BallPulseFooter(context).setSpinnerStyle(SpinnerStyle.Scale);
        footer.setAnimatingColor(context.getResources().getColor(color));
        return footer;
    }

}
