package com.comod.baselib.listener;

public abstract class CommonCallback<T> {
    public abstract void callback(T bean);
}
