package com.comod.baselib.list;

import android.view.View;
import android.view.ViewGroup;

public interface VHDelegate<T extends BaseListViewAdapter.ViewRenderType> {

    View createItemView(ViewGroup parent, BaseListViewAdapter<T> adapter);

    void initView(View itemView);

    void onBindVH(T item, int position);
}
