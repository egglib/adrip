package com.comod.baselib.util;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.comod.baselib.R;

public class DialogUtil {

    public static final int INPUT_TYPE_TEXT = 0;
    public static final int INPUT_TYPE_NUMBER = 1;
    public static final int INPUT_TYPE_NUMBER_PASSWORD = 2;
    public static final int INPUT_TYPE_TEXT_PASSWORD = 3;

    public static Dialog loadingDialog(Context context) {
        return loadingDialog(context, "");
    }

    public static Dialog loadingDialog(Context context, String text) {
        Dialog dialog = new Dialog(context, R.style.dialog_style);
        dialog.setContentView(R.layout.dialog_loading);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (!TextUtils.isEmpty(text)) {
            TextView titleView = dialog.findViewById(R.id.text);
            if (titleView != null) {
                titleView.setText(text);
            }
        }
        return dialog;
    }


    public static void showDialog(Context context, Dialog dialog) {
        if (dialog != null && !dialog.isShowing() && !((Activity) context).isFinishing()) {
            dialog.show();
        }
    }

    public static void dismissDialog(Dialog dialog) {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    public static void showSimpleTipDialog(Context context, String content) {
        showSimpleTipDialog(context, null, content);
    }

    public static void showSimpleTipDialog(Context context, String title, String content) {
        try {
            Dialog dialog = new Dialog(context, R.style.dialog);
            dialog.setContentView(R.layout.dialog_simple_tip);
            dialog.setCancelable(true);
            dialog.setCanceledOnTouchOutside(true);
            if (!TextUtils.isEmpty(title)) {
                TextView titleView = (TextView) dialog.findViewById(R.id.title);
                titleView.setText(title);
            }
            if (!TextUtils.isEmpty(content)) {
                TextView contentTextView = (TextView) dialog.findViewById(R.id.content);
                contentTextView.setText(content);
            }
            dialog.findViewById(R.id.btn_confirm).setOnClickListener(v -> dialog.dismiss());
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface SimpleCallback {
        void onConfirmClick(Dialog dialog, String content);
    }

    public interface SimpleCallback2 extends SimpleCallback {
        void onCancelClick();
    }

    public interface SimpleCallback3 extends SimpleCallback2 {
        void onCloseClick();
    }

    public static void showSimpleDialog(Context context, String content, SimpleCallback callback) {
        showSimpleDialog(context, content, true, callback);
    }

    public static void showSimpleDialog(Context context, String content, boolean cancelable, SimpleCallback callback) {
        showSimpleDialog(context, null, content, cancelable, callback);
    }


    public static void showSimpleDialog(Context context, String content, String cancelString, String confirmString, SimpleCallback callback) {
        showSimpleDialog(context, content, cancelString, confirmString, false, false, callback);
    }

    public static void showSimpleDialog(Context context, String content, String cancelString, String confirmString, boolean isHide, boolean cancelable, SimpleCallback callback) {
        showSimpleDialog(context, "", content, cancelString, confirmString, isHide, cancelable, callback);
    }

    public static void showSimpleDialog(Context context, String title, String content, boolean cancelable, SimpleCallback callback) {
        try {
            new Builder(context)
                    .setTitle(title)
                    .setContent(content)
                    .setCancelable(cancelable)
                    .setClickCallback(callback)
                    .setBackgroundDimEnabled(true)
                    .build()
                    .show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void showSimpleDialog(Context context, String title, String content, String cancelString, String confirmString, boolean isHide, boolean cancelable, SimpleCallback callback) {
        try {
            new Builder(context)
                    .setTitle(title)
                    .setContent(content)
                    .setCancelString(cancelString)
                    .setConfirmString(confirmString)
                    .setCloseHide(isHide)
                    .setCancelable(cancelable)
                    .setClickCallback(callback)
                    .setBackgroundDimEnabled(true)
                    .build()
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static class Builder {

        private final Context mContext;
        private String mTitle;
        private String mContent;
        private String mConfirmString;
        private String mCancelString;
        private boolean mCancelable;
        private boolean mBackgroundDimEnabled;//显示区域以外是否使用黑色半透明背景
        private boolean mInput;//是否是输入框的
        private String mHint;
        private int mInputType;
        private int mLength;
        private boolean mIsHide = true;
        private SimpleCallback mClickCallback;

        public Builder(Context context) {
            mContext = context;
        }

        public Builder setTitle(String title) {
            mTitle = title;
            return this;
        }

        public Builder setContent(String content) {
            mContent = content;
            return this;
        }

        public Builder setConfirmString(String confirmString) {
            mConfirmString = confirmString;
            return this;
        }

        public Builder setCancelString(String cancelString) {
            mCancelString = cancelString;
            return this;
        }

        public Builder setCancelable(boolean cancelable) {
            mCancelable = cancelable;
            return this;
        }

        public Builder setBackgroundDimEnabled(boolean backgroundDimEnabled) {
            mBackgroundDimEnabled = backgroundDimEnabled;
            return this;
        }

        public Builder setInput(boolean input) {
            mInput = input;
            return this;
        }

        public Builder setHint(String hint) {
            mHint = hint;
            return this;
        }

        public Builder setInputType(int inputType) {
            mInputType = inputType;
            return this;
        }

        public Builder setLength(int length) {
            mLength = length;
            return this;
        }

        public Builder setCloseHide(boolean isHide) {
            mIsHide = isHide;
            return this;
        }

        public Builder setClickCallback(SimpleCallback clickCallback) {
            mClickCallback = clickCallback;
            return this;
        }

        public Dialog build() {
            try {
                Dialog dialog = new Dialog(mContext, mBackgroundDimEnabled ? R.style.dialog : R.style.dialog2);
                dialog.setContentView(mInput ? R.layout.dialog_input : R.layout.dialog_simple);
                dialog.setCancelable(mCancelable);
                dialog.setCanceledOnTouchOutside(mCancelable);
                TextView titleView = (TextView) dialog.findViewById(R.id.title);
                if (!TextUtils.isEmpty(mTitle)) {
                    titleView.setText(mTitle);
                }

                EditText content = (EditText) dialog.findViewById(R.id.content);
                if (!TextUtils.isEmpty(mHint)) {
                    content.setHint(mHint);
                }
                if (!TextUtils.isEmpty(mContent)) {
                    content.setText(mContent);
                }
                if (mInputType == INPUT_TYPE_NUMBER) {
                    content.setInputType(InputType.TYPE_CLASS_NUMBER);
                } else if (mInputType == INPUT_TYPE_NUMBER_PASSWORD) {
                    content.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
                } else if (mInputType == INPUT_TYPE_TEXT_PASSWORD) {
                    content.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }
                if (mLength > 0) {
                    content.setFilters(new InputFilter[]{new InputFilter.LengthFilter(mLength)});
                }
                TextView btnConfirm = (TextView) dialog.findViewById(R.id.btn_confirm);
                if (!TextUtils.isEmpty(mConfirmString)) {
                    btnConfirm.setText(mConfirmString);
                }

                TextView btnCancel = (TextView) dialog.findViewById(R.id.btn_cancel);
                if (!TextUtils.isEmpty(mCancelString)) {
                    btnCancel.setText(mCancelString);
                }

                ImageView imgClose = (ImageView) dialog.findViewById(R.id.img_close);

                if (mIsHide) {
                    imgClose.setVisibility(View.INVISIBLE);
                } else {
                    imgClose.setVisibility(View.VISIBLE);
                }

                View.OnClickListener listener = v -> {
                    if (v.getId() == R.id.btn_confirm) {
                        if (mClickCallback != null) {
                            if (mInput) {
                                mClickCallback.onConfirmClick(dialog, content.getText().toString());
                            } else {
                                dialog.dismiss();
                                mClickCallback.onConfirmClick(dialog, "");
                            }
                        } else {
                            dialog.dismiss();
                        }
                    } else if (v.getId() == R.id.btn_cancel) {
                        dialog.dismiss();
                        if (mClickCallback instanceof SimpleCallback2) {
                            ((SimpleCallback2) mClickCallback).onCancelClick();
                        }
                    } else if (v.getId() == R.id.img_close) {
                        dialog.dismiss();
                        if (mClickCallback instanceof SimpleCallback3) {
                            ((SimpleCallback3) mClickCallback).onCloseClick();
                        }
                    }
                };
                btnConfirm.setOnClickListener(listener);
                btnCancel.setOnClickListener(listener);
                imgClose.setOnClickListener(listener);
                return dialog;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

    }

}
