package com.comod.baselib.util;

import android.content.Context;
import android.graphics.Typeface;

import androidx.viewpager.widget.ViewPager;

import com.comod.baselib.view.magicindicator.buildins.commonnavigator.indicators.DotPagerIndicator;
import com.comod.baselib.view.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class MagicIndicatorUtil {

    @NotNull
    public static SimplePagerTitleView getSimplePagerTitleView(Context context, int index,
                                                               List<String> tabTitles,
                                                               ViewPager viewPager,
                                                               int textSize, int normalColor, int selectedColor) {
        SimplePagerTitleView simplePagerTitleView = new SimplePagerTitleView(context){
            @Override
            public void onSelected(int index, int totalCount) {
                super.onSelected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT_BOLD);
            }

            @Override
            public void onDeselected(int index, int totalCount) {
                super.onDeselected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT);
            }
        };
        simplePagerTitleView.setText(tabTitles.get(index));
        simplePagerTitleView.setTextSize(textSize);
        simplePagerTitleView.setNormalColor(normalColor);
        simplePagerTitleView.setSelectedColor(selectedColor);

        simplePagerTitleView.setOnClickListener(v -> viewPager.setCurrentItem(index));
        return simplePagerTitleView;
    }


    @NotNull
    public static DotPagerIndicator getDotPagerIndicator(Context context, int color) {
        DotPagerIndicator roundPagerIndicator = new DotPagerIndicator(context);
        roundPagerIndicator.setColor(color);
        roundPagerIndicator.setXOffset(5);
        roundPagerIndicator.setYOffset(15);
        return roundPagerIndicator;
    }

}
