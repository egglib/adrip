package com.comod.baselib.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.TextUtils;

import java.util.List;

public class VersionUtil {

    private static String mVersionStr;

    /**
     * 是否是最新版本
     */
    public static boolean isLatest(Context context, String version) {
        if (TextUtils.isEmpty(version)) {
            return true;
        }
        String curVersion = getVersion(context);
        if (TextUtils.isEmpty(curVersion)) {
            return true;
        }
        return curVersion.equals(version);
    }

    /**
     * 获取版本号
     */
    public static String getVersion(Context context) {
        if (TextUtils.isEmpty(mVersionStr)) {
            try {
                PackageManager manager = context.getPackageManager();
                PackageInfo info = manager.getPackageInfo(context.getPackageName(), 0);
                mVersionStr = info.versionName;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mVersionStr;
    }


    public static void delOldApk(Context context, String packageName)  {
        if (isExistPackage(context, packageName)) {
            Intent uninstallIntent = new Intent();
            uninstallIntent.setAction(Intent.ACTION_DELETE);
            uninstallIntent.setData(Uri.parse("package:" + packageName));
            context.startActivity(uninstallIntent);
        }
    }

    private static boolean isExistPackage(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        List<PackageInfo> packages = pm.getInstalledPackages(0);
        for (int i = 0; i < packages.size(); i++) {
            if (packages.get(i).packageName.equalsIgnoreCase(packageName)) {
                return true;
            }
        }
        return false;
    }

}
