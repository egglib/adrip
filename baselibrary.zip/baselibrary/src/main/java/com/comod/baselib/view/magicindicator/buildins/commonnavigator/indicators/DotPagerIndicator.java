package com.comod.baselib.view.magicindicator.buildins.commonnavigator.indicators;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;

import com.comod.baselib.view.magicindicator.FragmentContainerHelper;
import com.comod.baselib.view.magicindicator.buildins.UIUtil;
import com.comod.baselib.view.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import com.comod.baselib.view.magicindicator.buildins.commonnavigator.model.PositionData;

import java.util.List;


public class DotPagerIndicator extends View implements IPagerIndicator {

    private List<PositionData> mPositionDataList;

    private float mLeftCircleRadius;
    private float mLeftCircleX;
    private float mRightCircleRadius;
    private float mRightCircleX;

    private float mLeftCircleY;
    private float mRightCircleY;

    private float mYOffset;
    private float mXOffset;
    /**
     * 半径
     */
    private float mMaxCircleRadius;
    private float mMinCircleRadius;

    private Paint mPaint;

    private Interpolator mStartInterpolator = new AccelerateInterpolator();
    private Interpolator mEndInterpolator = new DecelerateInterpolator();

    private boolean maxTextHeight;

    private int mColor;

    public DotPagerIndicator(Context context) {
        super(context);
        init(context);
    }

    public int getColor() {
        return mColor;
    }

    public void setColor(int color) {
        mColor = color;
    }

    private void init(Context context) {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.FILL);
        mMaxCircleRadius = UIUtil.dip2px(context, 6);
        mMinCircleRadius = UIUtil.dip2px(context, 3);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        mPaint.setColor(mColor);
        canvas.drawCircle(mLeftCircleX - mXOffset, mLeftCircleY + mYOffset, mLeftCircleRadius, mPaint);
        canvas.drawCircle(mRightCircleX - mXOffset, mRightCircleY + mYOffset, mRightCircleRadius, mPaint);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        if (mPositionDataList == null || mPositionDataList.isEmpty()) {
            return;
        }

        // 计算锚点位置
        PositionData current = FragmentContainerHelper.getImitativePositionData(mPositionDataList, position);
        PositionData next = FragmentContainerHelper.getImitativePositionData(mPositionDataList, position + 1);

        float leftX = current.mContentRight;
        float rightX = next.mContentRight;

        mLeftCircleX = leftX + (rightX - leftX) * mStartInterpolator.getInterpolation(positionOffset);
        mRightCircleX = leftX + (rightX - leftX) * mEndInterpolator.getInterpolation(positionOffset);

        if (!maxTextHeight) {
            maxTextHeight = true;
            mLeftCircleY = current.mContentTop;
            mRightCircleY = current.mContentTop;
        }

        mLeftCircleRadius = mMaxCircleRadius + (mMinCircleRadius - mMaxCircleRadius) * mEndInterpolator.getInterpolation(positionOffset);
        mRightCircleRadius = mMinCircleRadius + (mMaxCircleRadius - mMinCircleRadius) * mStartInterpolator.getInterpolation(positionOffset);

        invalidate();
    }

    @Override
    public void onPageSelected(int position) {
    }

    @Override
    public void onPageScrollStateChanged(int state) {
    }

    @Override
    public void onPositionDataProvide(List<PositionData> dataList) {
        mPositionDataList = dataList;
    }

    public float getMaxCircleRadius() {
        return mMaxCircleRadius;
    }

    public void setMaxCircleRadius(float maxCircleRadius) {
        mMaxCircleRadius = maxCircleRadius;
    }

    public float getMinCircleRadius() {
        return mMinCircleRadius;
    }

    public void setMinCircleRadius(float minCircleRadius) {
        mMinCircleRadius = minCircleRadius;
    }

    public float getYOffset() {
        return mYOffset;
    }

    public void setYOffset(float yOffset) {
        mYOffset = yOffset;
    }

    public float getXOffset() {
        return mXOffset;
    }

    public void setXOffset(float yOffset) {
        mXOffset = yOffset;
    }

    public void setStartInterpolator(Interpolator startInterpolator) {
        mStartInterpolator = startInterpolator;
        if (mStartInterpolator == null) {
            mStartInterpolator = new AccelerateInterpolator();
        }
    }

    public void setEndInterpolator(Interpolator endInterpolator) {
        mEndInterpolator = endInterpolator;
        if (mEndInterpolator == null) {
            mEndInterpolator = new DecelerateInterpolator();
        }
    }
}
