package com.comod.baselib.adapter;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class CommonPagerAdapter extends FragmentPagerAdapter {

    private List<Fragment> mFragmentList;

    public CommonPagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
        mFragmentList = new ArrayList<>();
    }

    public CommonPagerAdapter(FragmentManager fragmentManager, List<Fragment> fragments) {
        super(fragmentManager);
        mFragmentList = fragments;
    }

    public void refreshFragmentList(List<Fragment> fragments) {
        if (!mFragmentList.isEmpty()) {
            mFragmentList.clear();
        }
        mFragmentList.addAll(fragments);
        notifyDataSetChanged();
    }


    @Override
    public Fragment getItem(int position) {
        Fragment fragment;
        if (position < mFragmentList.size()) {
            fragment = mFragmentList.get(position);
        } else {
            fragment = mFragmentList.get(0);
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return mFragmentList != null && !mFragmentList.isEmpty() ? mFragmentList.size() : 0;
    }


    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        //注释这行，不管怎么切换，page都不会被销毁
        //super.destroyItem(container, position, object);
    }

}
