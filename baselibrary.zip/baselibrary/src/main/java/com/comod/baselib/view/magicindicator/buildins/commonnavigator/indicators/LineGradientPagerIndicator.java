package com.comod.baselib.view.magicindicator.buildins.commonnavigator.indicators;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Shader;

public class LineGradientPagerIndicator extends LinePagerIndicator {

    private int[] mColorList;
    private float[] mPositionList;

    public LineGradientPagerIndicator(Context context) {
        super(context);
    }

    public void setGradientColorList(int[] colorList) {
        mColorList = colorList;
    }

    public void setGradientPositionList(float[] positionList) {
        mPositionList = positionList;
    }

    @SuppressLint("DrawAllocation")
    @Override
    protected void onDraw(Canvas canvas) {
        if (mColorList != null && mPositionList != null) {
            LinearGradient gradient = new LinearGradient(mLineRect.left, mLineRect.top, mLineRect.right, mLineRect.bottom, mColorList, mPositionList, Shader.TileMode.MIRROR);
            mPaint.setShader(gradient);
        }
        super.onDraw(canvas);
    }
}
