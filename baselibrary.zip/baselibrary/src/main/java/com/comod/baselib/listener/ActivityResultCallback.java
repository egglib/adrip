package com.comod.baselib.listener;

import android.content.Intent;

public abstract class ActivityResultCallback {
    public abstract void onSuccess(Intent intent);
    public void onFailure() {

    }
}
