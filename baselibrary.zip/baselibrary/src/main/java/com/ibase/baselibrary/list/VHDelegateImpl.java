package com.ibase.baselibrary.list;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class VHDelegateImpl<T extends BaseListViewAdapter.ViewRenderType> implements VHDelegate<T> {

    protected abstract int getItemLayoutId();

    private Context context;

    private View view;

    private T mItem;

    private int mPosition;

    private BaseListViewAdapter<T> mAdapter;

    @Override
    public View createItemView(ViewGroup parent, BaseListViewAdapter<T> adapter) {
        try {
            context = parent.getContext();
            mAdapter = adapter;
            view = LayoutInflater.from(context).inflate(getItemLayoutId(), parent, false);
            return view;
        } catch (Exception e) {
            return null;
        }
    }

    public T getCurItemBean() {
        return mItem;
    }

    public int getCurPosition() {
        return mPosition;
    }

    public BaseListViewAdapter<T> getAdapter() {
        return mAdapter;
    }

    @Override
    public void onBindVH(T item, int position) {
        mItem = item;
        mPosition = position;
    }

    public void onItemClick(View view, T item, int position) {
    }

    public boolean onItemLongClick(View view, T item, int position) {
        return false;
    }


    protected Context getContext() {
        return context;
    }

    protected View getItemView() {
        return view;
    }

}
