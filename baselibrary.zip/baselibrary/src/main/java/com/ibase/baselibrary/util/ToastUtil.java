package com.ibase.baselibrary.util;

import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

import com.ibase.baselibrary.view.CustomToast;

/**
 *
 */
public class ToastUtil {

    public static void show(Context context, int res) {
        show(context, context.getResources().getString(res));
    }


    public static void show(Context context, CharSequence msg) {
        if (!TextUtils.isEmpty(msg)) {
            shortShow(context, msg);
        }
    }


    /**
     * show long time
     *
     * @param msg
     */
    public static void longShow(Context context, CharSequence msg) {
        CustomToast.makeText(context, msg == null ? "" : msg, Toast.LENGTH_LONG).show();
    }


    /**
     * show short time
     *
     * @param msg
     */
    public static void shortShow(Context context, CharSequence msg) {
        CustomToast.makeText(context, msg == null ? "" : msg, Toast.LENGTH_SHORT).show();
    }

    public static void shortCenterShow(Context context, CharSequence msg) {
        CustomToast.makeCenterText(context, msg == null ? "" : msg, Toast.LENGTH_SHORT).show();
    }
}
