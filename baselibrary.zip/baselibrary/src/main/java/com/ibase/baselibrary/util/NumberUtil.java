package com.ibase.baselibrary.util;


public class NumberUtil {

    public static final int TYPE_CN_UNIT = 1;
    public static final int TYPE_LETTER_UNIT = 2;

    /**
     * @param num
     * @return
     */
    public static String formatNum(String num) {
        String format;
        double newNum = Double.valueOf(num);
        if (newNum >= 10000000) {
            newNum = newNum / 100000000;
            format = String.format("%.2f", newNum) + "億";
        } else if (newNum >= 10000) {
            newNum = newNum / 10000;
            format = String.format("%.2f", newNum) + "萬";
        } else if (newNum >= 1000) {
            newNum = newNum / 1000;
            format = String.format("%.2f", newNum) + "千";
        } else {
            format = (int) newNum + "";
        }
        return format;
    }

    public static String formatOrderNum(int num) {
        if (num >= 0 && num < 10) {
            return "0" + num;
        }
        return String.valueOf(num);
    }

    public static String formatNewNum(double num, int type) {
        return formatNewNum(String.valueOf(num >= 0 ? num : 0), type);
    }

    public static String formatNewNum(long num, int type) {
        return formatNewNum(String.valueOf(num >= 0 ? num : 0), type);
    }

    public static String formatNewNum(int num, int type) {
        return formatNewNum(String.valueOf(Math.max(num, 0)), type);
    }

    public static String formatNewNum(String num, int type) {
        String format;
        double newNum = Double.valueOf(num);

        if (newNum >= 100000000) {
            newNum = newNum / 100000000;
            if (type == TYPE_CN_UNIT) {
                format = String.format("%.2f", newNum) + "亿";
            } else {
                format = String.format("%.2f", newNum) + "y";
            }
        } else if (newNum >= 10000) {
            newNum = newNum / 10000;
            if (type == TYPE_CN_UNIT) {
                format = String.format("%.2f", newNum) + "万";
            } else {
                format = String.format("%.2f", newNum) + "w";
            }
        } else if (newNum >= 1000) {
            newNum = newNum / 1000;
            if (type == TYPE_CN_UNIT) {
                format = String.format("%.2f", newNum) + "千";
            } else {
                format = String.format("%.2f", newNum) + "k";
            }
        } else {
            format = (int) newNum + "";
        }
        return format;
    }

}
