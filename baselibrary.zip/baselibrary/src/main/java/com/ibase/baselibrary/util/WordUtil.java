package com.ibase.baselibrary.util;

import android.text.TextUtils;

import com.ibase.baselibrary.BaseAppContext;

public class WordUtil {


    public static String getString(int res) {
        return BaseAppContext.getInstance().getString(res);
    }

    public static String getSignStr(String sign,String defaultStr) {
        return !TextUtils.isEmpty(sign) ? sign : defaultStr;
    }

    public static String getFormatStr(String str) {
        return !TextUtils.isEmpty(str) ? str : "";
    }

}
