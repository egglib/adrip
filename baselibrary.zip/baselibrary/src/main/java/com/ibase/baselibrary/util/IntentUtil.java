package com.ibase.baselibrary.util;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;


public class IntentUtil {

    public static void forward(Context context, Class<?> cls) {
        forward(context, cls, null);
    }

    public static void forward(Context context, Class<?> cls, Bundle bundle) {
        Intent intent = new Intent(context, cls);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        context.startActivity(intent);
    }
}
