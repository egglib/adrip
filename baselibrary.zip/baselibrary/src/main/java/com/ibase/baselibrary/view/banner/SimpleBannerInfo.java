package com.ibase.baselibrary.view.banner;

public abstract class SimpleBannerInfo implements BaseBannerInfo {
    @Override
    public String getXBannerTitle() {
        return null;
    }
}
