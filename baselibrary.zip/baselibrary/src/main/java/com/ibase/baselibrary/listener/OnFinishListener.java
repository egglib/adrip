package com.ibase.baselibrary.listener;

/**
 * 进度完成监听接口
 */

public interface OnFinishListener {

    /**
     * 结束时回调
     */
    void onFinish();
}
