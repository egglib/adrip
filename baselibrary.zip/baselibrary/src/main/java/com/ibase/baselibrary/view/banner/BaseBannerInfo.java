package com.ibase.baselibrary.view.banner;

/**
 * author: xiaohaibin.
 * time: 2018/12/3
 * mail:xhb_199409@163.com
 * github:https://github.com/xiaohaibin
 * describe: BaseBannerInfo
 */
public interface BaseBannerInfo {
    Object getXBannerUrl();

    String getXBannerTitle();
}
