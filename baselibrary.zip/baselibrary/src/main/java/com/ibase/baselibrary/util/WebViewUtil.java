package com.ibase.baselibrary.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class WebViewUtil {


    /**
     * 打开自带的浏览器
     *
     * @param context
     * @param url
     */
    public static void jumpToSelfBrowser(Context context, String url) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        context.startActivity(intent);
    }

}
