package com.ibase.baselibrary.util;

import android.util.Log;

import com.ibase.baselibrary.BuildConfig;

public class L {

    private final static String TAG = "log--->";

    public static void e(String s) {
        e(TAG, s);
    }

    public static void e(String tag, String s) {
        if (BuildConfig.DEBUG) {
            Log.e(tag, s);
        }
    }

    public static void i(String tag, String s) {
        if (BuildConfig.DEBUG) {
            Log.i(tag, s);
        }
    }
}
