package com.ibase.baselibrary.bean;

import com.ibase.baselibrary.list.BaseListViewAdapter;

import java.io.Serializable;


public class VideoEditInfo extends BaseListViewAdapter.ViewRenderType implements Serializable {
    public String path; //图片的sd卡路径
    public long time;//图片所在视频的时间  毫秒

    public VideoEditInfo() {
    }
}
