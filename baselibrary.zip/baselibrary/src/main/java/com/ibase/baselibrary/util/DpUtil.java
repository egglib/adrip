package com.ibase.baselibrary.util;

import android.content.Context;

/**
 * dp转px工具类
 */

public class DpUtil {

    public static int dp2px(Context context, int dpVal) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (scale * dpVal + 0.5f);
    }

    public static int dp2px(Context context, float dpVal) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (scale * dpVal + 0.5f);
    }


    public static int sp2px(Context context, float spValue) {
        final float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (spValue * fontScale + 0.5f);
    }
}
