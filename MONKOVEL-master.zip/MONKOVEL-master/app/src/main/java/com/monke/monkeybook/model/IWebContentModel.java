//Copyright (c) 2017. 章钦豪. All rights reserved.
package com.monke.monkeybook.model;

public interface IWebContentModel {

    String analyBookcontent(String s,String realUrl) throws Exception;
}