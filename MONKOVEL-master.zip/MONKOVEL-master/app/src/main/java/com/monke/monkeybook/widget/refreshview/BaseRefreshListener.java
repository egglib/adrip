package com.monke.monkeybook.widget.refreshview;

public interface BaseRefreshListener {

    public void startRefresh();
}
