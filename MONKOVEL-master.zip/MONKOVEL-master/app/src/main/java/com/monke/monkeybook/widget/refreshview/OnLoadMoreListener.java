package com.monke.monkeybook.widget.refreshview;

public interface OnLoadMoreListener {

    public void startLoadmore();

    public void loadMoreErrorTryAgain();
}
