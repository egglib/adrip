# MONKOVEL
一款可以优雅的阅读本地小说以及大量网络小说的APP
# APP预览以及体验
http://blog.csdn.net/github_38075367/article/details/76255230
# 项目基本介绍
http://blog.csdn.net/github_38075367/article/details/77075477
#
你要商业？不建议，盗版小说请勿传播，仅供学习使用。<br/>
你要修改？请修改我的Logo/应用名，移除预留QQ，修改包名，谢谢
