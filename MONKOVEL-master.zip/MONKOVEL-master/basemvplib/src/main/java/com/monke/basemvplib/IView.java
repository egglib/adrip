package com.monke.basemvplib;

import android.content.Context;

public interface IView {
    public Context getContext();
}
