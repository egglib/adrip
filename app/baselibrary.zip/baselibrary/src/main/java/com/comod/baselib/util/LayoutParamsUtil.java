package com.comod.baselib.util;

import android.view.View;
import android.view.ViewGroup;

public class LayoutParamsUtil {

    public static void initLayoutParams(View view, int width, int ratioWidth, int ratioHeight) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.width = width;
        layoutParams.height = width * ratioHeight / ratioWidth;
    }
}
