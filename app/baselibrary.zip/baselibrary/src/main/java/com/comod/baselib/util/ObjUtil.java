package com.comod.baselib.util;

public class ObjUtil {
    public static boolean isNotNull(Object obj) {
        return obj != null;
    }
}
