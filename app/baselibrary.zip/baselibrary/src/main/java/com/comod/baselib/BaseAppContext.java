package com.comod.baselib;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;

import java.util.Stack;

public class BaseAppContext extends Application {

    public static BaseAppContext mInstance;

    public static BaseAppContext getInstance() {
        return mInstance;
    }

    private static Stack<Activity> activityStack = new Stack<>();

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
    }

    public void addActivity(Activity activity) {
        try {
            if (activityStack == null) {
                activityStack = new Stack<>();
            }
            activityStack.add(activity);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }


    public void finishActivity(Activity activity) {
        try {
            if (activity != null) {
                if (activityStack != null) {
                    activityStack.remove(activity);
                }
                if (!activity.isFinishing()) {
                    activity.finish();
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }


    public void finishAllActivity() {
        if (activityStack != null && !activityStack.isEmpty()) {
            for (int i = 0, size = activityStack.size(); i < size; i++) {
                if (null != activityStack.get(i)) {
                    try {
                        Activity activity = activityStack.get(i);
                        if (!activity.isFinishing()) {
                            activity.finish();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            activityStack.clear();
        }
    }

    @Override
    protected void attachBaseContext(Context base) {
        MultiDex.install(this);
        super.attachBaseContext(base);
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
    }


    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }


    public String getBaseUrl() {
        return "";
    }
}
