package com.comod.baselib.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class AdBannerBean implements Parcelable {

    private int id;
    private String title;
    private String img_url;
    private String url;
    private int type;
    private String value;

    protected AdBannerBean() {
    }

    protected AdBannerBean(Parcel in) {
        id = in.readInt();
        title = in.readString();
        img_url = in.readString();
        url = in.readString();
        type = in.readInt();
        value = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(img_url);
        dest.writeString(url);
        dest.writeInt(type);
        dest.writeString(value);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<AdBannerBean> CREATOR = new Creator<AdBannerBean>() {
        @Override
        public AdBannerBean createFromParcel(Parcel in) {
            return new AdBannerBean(in);
        }

        @Override
        public AdBannerBean[] newArray(int size) {
            return new AdBannerBean[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImgUrl() {
        return img_url;
    }

    public void setImgUrl(String img_url) {
        this.img_url = img_url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }


    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
