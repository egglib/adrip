package com.comod.baselib.util;

import android.content.Context;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.regex.Pattern;

public class StringUtil {


    public String getString(Context context, int string) {
        return context.getResources().getString(string);
    }


    /**
     * Returns true if the string is null or 0-length.
     *
     * @param str the string to be examined
     * @return true if str is null or zero length
     */
    public static boolean isEmpty(CharSequence str) {
        return str == null || str.length() == 0;
    }

    /**
     * {@hide}
     */
    public static String nullIfEmpty(String str) {
        return isEmpty(str) ? null : str;
    }

    /**
     * {@hide}
     */
    public static String emptyIfNull(String str) {
        return str == null ? "" : str;
    }

    private static DecimalFormat sDecimalFormat;
    private static DecimalFormat sDecimalFormat2;
    // private static Pattern sPattern;
    private static Pattern sIntPattern;


    static {
        sDecimalFormat = new DecimalFormat("#.#");
        sDecimalFormat.setRoundingMode(RoundingMode.HALF_UP);
        sDecimalFormat2 = new DecimalFormat("#.##");
        sDecimalFormat2.setRoundingMode(RoundingMode.DOWN);
        //sPattern = Pattern.compile("[\u4e00-\u9fa5]");
        sIntPattern = Pattern.compile("^[-\\+]?[\\d]*$");
    }

    public static String format(double value) {
        return sDecimalFormat.format(value);
    }

    /**
     * 把数字转化成多少万
     */
    public static String toWan(long num) {
        if (num < 10000) {
            return String.valueOf(num);
        }
        return sDecimalFormat.format(num / 10000d) + "w";
    }


    /**
     * 把数字转化成多少万
     */
    public static String toWan2(long num) {
        if (num < 10000) {
            return String.valueOf(num);
        }
        return sDecimalFormat.format(num / 10000d);
    }

    /**
     * 把数字转化成多少万
     */
    public static String toWan3(long num) {
        if (num < 10000) {
            return String.valueOf(num);
        }
        return sDecimalFormat2.format(num / 10000d) + "w";
    }

//    /**
//     * 判断字符串中是否包含中文
//     */
//    public static boolean isContainChinese(String str) {
//        Matcher m = sPattern.matcher(str);
//        if (m.find()) {
//            return true;
//        }
//        return false;
//    }

    /**
     * 判断一个字符串是否是数字
     */
    public static boolean isInt(String str) {
        return sIntPattern.matcher(str).matches();
    }


    /**
     * 把一个long类型的总毫秒数转成时长
     */
    public static String getDurationText(long mms) {
        int hours = (int) (mms / (1000 * 60 * 60));
        int minutes = (int) ((mms % (1000 * 60 * 60)) / (1000 * 60));
        int seconds = (int) ((mms % (1000 * 60)) / 1000);
        String s = "";
        if (hours > 0) {
            if (hours < 10) {
                s += "0" + hours + ":";
            } else {
                s += hours + ":";
            }
        }
        if (minutes > 0) {
            if (minutes < 10) {
                s += "0" + minutes + ":";
            } else {
                s += minutes + ":";
            }
        } else {
            s += "00" + ":";
        }
        if (seconds > 0) {
            if (seconds < 10) {
                s += "0" + seconds;
            } else {
                s += seconds;
            }
        } else {
            s += "00";
        }
        return s;
    }


    public static String discountAmount(String amount, String off) {

        try {
            //计算可提現的百分比
            BigDecimal a1 = new BigDecimal(amount);
            BigDecimal b1 = new BigDecimal(1);
            BigDecimal off1 = new BigDecimal(off);

            BigDecimal multiplyOff = (off1.divide(b1, 2, BigDecimal.ROUND_HALF_EVEN));
            BigDecimal bigDecimal = a1.multiply(multiplyOff);

            return bigDecimal.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }

    public static String mulAmount(String amount, String rate) {
        try {
            BigDecimal a1 = new BigDecimal(amount);
            BigDecimal b1 = new BigDecimal(rate);
            BigDecimal bigDecimal = a1.multiply(b1);

            return bigDecimal.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }


    public static String subAmount(String amount, String rate) {
        try {
            BigDecimal a1 = new BigDecimal(amount);
            BigDecimal b1 = new BigDecimal(rate);
            BigDecimal rateFee = a1.multiply(b1);
            BigDecimal bigDecimal = a1.subtract(rateFee);
            return bigDecimal.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

}
