package com.comod.baselib.util;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.LinearLayout;

import com.comod.baselib.R;
import com.comod.baselib.adapter.CommonPagerAdapter;
import com.comod.view.magicindicator.MagicIndicator;
import com.comod.view.magicindicator.ViewPagerHelper;
import com.comod.view.magicindicator.buildins.commonnavigator.CommonNavigator;
import com.comod.view.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import com.comod.view.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import com.comod.view.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;

import java.util.ArrayList;
import java.util.List;

public abstract class ComViewPagerHelper {

    private ViewPager mViewpager;
    private MagicIndicator mIndicator;

    public ComViewPagerHelper(Context context,
                              Activity activity,
                              List<String> tabTitleList,
                              List<Fragment> fragmentList,
                              List<Integer> selectorImgList,
                              FragmentManager fragmentManager) {
        try {
            mViewpager = activity.findViewById(R.id.viewPager);
            mIndicator = activity.findViewById(R.id.indicator);
            initHandle(context, tabTitleList, fragmentList, selectorImgList, fragmentManager);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public ComViewPagerHelper(Context context,
                              View view,
                              List<String> tabTitleList,
                              List<Fragment> fragmentList,
                              List<Integer> selectorImgList,
                              FragmentManager fragmentManager) {
        try {
            mViewpager = view.findViewById(R.id.viewPager);
            mIndicator = view.findViewById(R.id.indicator);
            initHandle(context, tabTitleList, fragmentList, selectorImgList, fragmentManager);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void initHandle(Context context, List<String> tabTitleList, List<Fragment> fragmentList, List<Integer> selectorImgList, FragmentManager fragmentManager) {

        if (tabTitleList != null && fragmentList != null && !tabTitleList.isEmpty() && !fragmentList.isEmpty()) {

            CommonPagerAdapter pagerAdapter = new CommonPagerAdapter(fragmentManager, fragmentList);
            mViewpager.setOffscreenPageLimit(getOffscreenPageLimit());
            mViewpager.setAdapter(pagerAdapter);
            mViewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                    onViewPageScrolled(position, positionOffset, positionOffsetPixels);
                }

                @Override
                public void onPageSelected(int position) {
                    onViewPageSelected(position);
                }

                @Override
                public void onPageScrollStateChanged(int state) {
                    onViewPageScrollStateChanged(state);
                }
            });

            List<Integer> mSelectorImgList = new ArrayList<>();
            if (selectorImgList != null && !selectorImgList.isEmpty()) {
                mSelectorImgList.addAll(selectorImgList);
            }

            initMagicIndicator(context, tabTitleList, mSelectorImgList);
        }
    }


    private void initMagicIndicator(Context context, List<String> tabTitleList, List<Integer> selectorImgList) {
        try {
            CommonNavigator commonNavigator = new CommonNavigator(context);
            commonNavigator.setAdjustMode(getAdjustMode());
            commonNavigator.setAdapter(new CommonNavigatorAdapter() {
                @Override
                public int getCount() {
                    return tabTitleList == null ? 0 : tabTitleList.size();
                }

                @Override
                public IPagerTitleView getTitleView(Context context, int index) {
                    return getIPagerTitleView(context, index, mViewpager, tabTitleList, selectorImgList);
                }

                @Override
                public IPagerIndicator getIndicator(Context context) {
                    return getIPagerIndicator(context);
                }
            });

            mIndicator.setNavigator(commonNavigator);

            LinearLayout titleContainer = commonNavigator.getTitleContainer();

            if (isShowMiddleDivider()) {
                titleContainer.setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
                titleContainer.setDividerPadding(getDividerPadding(context));
                titleContainer.setDividerDrawable(getDividerDrawable(context));
            }

            ViewPagerHelper.bind(mIndicator, mViewpager);

            mViewpager.setCurrentItem(getCurrentItem());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Drawable getDividerDrawable(Context context) {
        return context.getResources().getDrawable(R.drawable.vertical_line_color_ccc);
    }

    protected int getDividerPadding(Context context) {
        return DpUtil.dp2px(context, 15);
    }

    protected boolean isShowMiddleDivider() {
        return false;
    }

    public int getCurrentItem() {
        return 0;
    }

    public int getItemCount() {
        return mViewpager != null ? mViewpager.getChildCount() : 0;
    }

    public void setViewPagerCurItem(int index) {
        if (mViewpager != null) {
            mViewpager.setCurrentItem(index);
        }
    }

    protected int getOffscreenPageLimit() {
        return 2;
    }

    public boolean getAdjustMode() {
        return false;
    }

    public abstract IPagerTitleView getIPagerTitleView(Context context, int index, ViewPager viewPager, List<String> tabTitleList, List<Integer> selectorImgList);

    public IPagerIndicator getIPagerIndicator(Context context) {
        return null;
    }


    protected void onViewPageScrollStateChanged(int state) {
    }

    public void onViewPageSelected(int position) {
    }

    protected void onViewPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }
}
