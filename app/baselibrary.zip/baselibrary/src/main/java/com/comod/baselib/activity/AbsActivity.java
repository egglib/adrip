package com.comod.baselib.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import android.support.annotation.Nullable;

import com.comod.baselib.BaseAppContext;
import com.comod.baselib.R;
import com.gyf.immersionbar.ImmersionBar;


public abstract class AbsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setStatusBar();
            BaseAppContext.getInstance().addActivity(this);
            setContentView(getLayoutResId());
            init(savedInstanceState);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected abstract int getLayoutResId();

    protected abstract void init(Bundle savedInstanceState);

    protected void setStatusBar() {
        ImmersionBar.with(this).reset()
                .fitsSystemWindows(true, R.color.white)
                .statusBarDarkFont(true)
                .navigationBarColor(R.color.white)
                .init();
    }

    protected void setBackImgRes(int resId) {
        try {
            ImageView backImg = findViewById(R.id.img_back);
            if (backImg != null) {
                backImg.setImageResource(resId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void setTitleFitsSystemWindows(boolean fitSystemWindows) {
        try {
            LinearLayout layoutTitle = findViewById(R.id.layout_title);
            if (layoutTitle != null) {
                layoutTitle.setFitsSystemWindows(fitSystemWindows);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void setTitleBackTransparent() {
        try {
            LinearLayout layoutTitle = findViewById(R.id.layout_title);
            if (layoutTitle != null) {
                layoutTitle.setBackgroundColor(getResources().getColor(R.color.transparent));
                layoutTitle.setFitsSystemWindows(true);
                View line = findViewById(R.id.line);
                if (line != null) {
                    line.setVisibility(View.GONE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void setTitleBackColor(int colorId, boolean fitsSystemWindows, boolean isShowLine) {
        try {
            LinearLayout layoutTitle = findViewById(R.id.layout_title);
            if (layoutTitle != null) {
                layoutTitle.setBackgroundColor(getResources().getColor(colorId));
                layoutTitle.setFitsSystemWindows(fitsSystemWindows);
                View line = findViewById(R.id.line);
                if (line != null) {
                    if (isShowLine) {
                        line.setVisibility(View.VISIBLE);
                    } else {
                        line.setVisibility(View.GONE);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void setTitleStr(String titleStr) {
        try {
            TextView titleView = findViewById(R.id.tv_title);
            if (titleView != null) {
                titleView.setText(titleStr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void setTitleTextColor(int colorId) {
        try {
            TextView titleView = findViewById(R.id.tv_title);
            if (titleView != null) {
                titleView.setTextColor(getResources().getColor(colorId));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    protected void setSubTitleTextColor(int colorId) {
        try {
            TextView subTitleView = findViewById(R.id.tv_sub_title);
            if (subTitleView != null) {
                subTitleView.setTextColor(getResources().getColor(colorId));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void setSubTitleStr(String subTitleStr) {
        try {
            TextView subTitleView = findViewById(R.id.tv_sub_title);
            if (subTitleView != null) {
                if (!TextUtils.isEmpty(subTitleStr)) {
                    subTitleView.setVisibility(View.VISIBLE);
                    subTitleView.setText(subTitleStr);
                } else {
                    subTitleView.setVisibility(View.GONE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void backClick(View view) {
        try {
            if (view.getId() == R.id.img_back) {
                onBackPressed();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void subTitleClick(View view) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            BaseAppContext.getInstance().finishActivity(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
