package com.comod.baselib.util;

import android.content.Context;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class RecyclerViewUtil {


    public static void initRecyclerView(RecyclerView recyclerview, RecyclerView.LayoutManager layoutManager, RecyclerView.ItemDecoration itemDecoration, RecyclerView.Adapter adapter) {
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.addItemDecoration(itemDecoration);
        recyclerview.setAdapter(adapter);
    }

    public static LinearLayoutManager getVerticalLinearLayoutManager(Context context) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        return linearLayoutManager;
    }


    public static LinearLayoutManager getHorizontalLinearLayoutManager(Context context) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        return linearLayoutManager;
    }


    public static GridLayoutManager getGridLayoutManager(Context context,int spanCount) {
        return new GridLayoutManager(context,spanCount);
    }

}
