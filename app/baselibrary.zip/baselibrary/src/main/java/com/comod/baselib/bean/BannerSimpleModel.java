package com.comod.baselib.bean;


import com.comod.baselib.view.banner.SimpleBannerInfo;

public class BannerSimpleModel extends SimpleBannerInfo {

    @Override
    public Object getXBannerUrl() {
        return null;
    }
}
