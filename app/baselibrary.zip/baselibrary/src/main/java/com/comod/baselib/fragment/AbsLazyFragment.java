package com.comod.baselib.fragment;

import android.view.View;

public abstract class AbsLazyFragment extends AbsFragment {

    protected boolean isLazyLoaded = false;

    protected boolean isInited = false;

    protected boolean isVisible = false;


    @Override
    protected void createView(View view) {
        isInited = true;
        initView(view);
        tryLoad();
    }

    protected abstract void initView(View view);

    private void tryLoad() {
        if (isInited && isVisible && !isLazyLoaded) {
            onLazyLoad();
            isLazyLoaded = true;
        }
    }


    //当前Fragment可见时，setUserVisibleHint()回调，其中isVisibleToUser=true；
    // 当前Fragment由可见到不可见或实例化时，setUserVisibleHint()回调，其中isVisibleToUser=false
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        isVisible = isVisibleToUser;
        tryLoad();
    }

    /**
     * 当视图初始化并且对可见时加载数据
     */
    protected abstract void onLazyLoad();

    /**
     * 视图销毁时将Fragment是否初始化的状态变为false
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }


}
