package com.comod.baselib.util;

import android.text.TextUtils;

import com.comod.baselib.BaseAppContext;


public class WordUtil {

    public static String getString(int res) {
        return BaseAppContext.getInstance().getString(res);
    }

    public static String getFormatStr(String str) {
        return getFormatStr(str,"");
    }

    public static String getFormatStr(String str,String defaultStr) {
        return !TextUtils.isEmpty(str) ? str: defaultStr;
    }

}
