package com.comod.baselib.util;

import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;

import com.comod.baselib.bean.SpecialTxtIndexBean;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SpecialTxtColorUtil {

    public static SpannableStringBuilder findSearchKeyWord(int color, String text, String keyword) {
        SpannableStringBuilder spannableString = new SpannableStringBuilder(text);
        try {
            keyword = "(?i)" + keyword;//忽略大小写
            Pattern p = Pattern.compile(keyword);
            Matcher m = p.matcher(spannableString);
            while (m.find()) {
                int start = m.start();
                int end = m.end();
                spannableString.setSpan(new ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                StyleSpan styleSpan = new StyleSpan(Typeface.BOLD);//粗体
                spannableString.setSpan(styleSpan, start, end, Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return spannableString;
    }


    public static SpannableStringBuilder setSpecialTxtColor(String text, int color) {

        SpannableStringBuilder builder = new SpannableStringBuilder(text);

        try {
            //  记录关键字的次数 与他在整个字符中所占的索引位置
            ArrayList<Integer> indexList = new ArrayList<>();

            for (int i = 0; i < text.length(); i++) {
                if (String.valueOf(text.charAt(i)).equals("【") || String.valueOf(text.charAt(i)).equals("】")) {
                    indexList.add(i);
                }
            }

            ArrayList<SpecialTxtIndexBean> txtIndexList = new ArrayList<>();

            if (!indexList.isEmpty() && indexList.size() % 2 == 0) {
                for (int i = 0; i < indexList.size(); i = i + 2) {
                    SpecialTxtIndexBean bean = new SpecialTxtIndexBean();
                    bean.setStart(indexList.get(i));
                    bean.setEnd(indexList.get(i + 1));
                    txtIndexList.add(bean);
                }
            }

            if (!txtIndexList.isEmpty()) {
                for (int i = 0; i < txtIndexList.size(); i++) {
                    ForegroundColorSpan redSpan = new ForegroundColorSpan(color);
                    builder.setSpan(redSpan, txtIndexList.get(i).getStart(), txtIndexList.get(i).getEnd() + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    StyleSpan styleSpan = new StyleSpan(Typeface.BOLD);//粗体
                    builder.setSpan(styleSpan, txtIndexList.get(i).getStart(), txtIndexList.get(i).getEnd() + 1, Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return builder;
    }
}
