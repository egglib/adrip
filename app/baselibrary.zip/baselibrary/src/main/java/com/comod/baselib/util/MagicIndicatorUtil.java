package com.comod.baselib.util;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v4.view.ViewPager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

import com.comod.view.magicindicator.buildins.commonnavigator.indicators.DotPagerIndicator;
import com.comod.view.magicindicator.buildins.commonnavigator.indicators.LineGradientPagerIndicator;
import com.comod.view.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import com.comod.view.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;
import com.comod.view.magicindicator.ext.titles.ScaleTransitionPagerTitleView;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class MagicIndicatorUtil {

    public static ScaleTransitionPagerTitleView getScaleTransitionPagerTitleView(Context context,
                                                                                 int index, List<String> tabTitles, ViewPager viewPager,
                                                                                 int textSize, int normalColor, int selectedColor) {

        ScaleTransitionPagerTitleView scaleTransitionPagerTitleView = new ScaleTransitionPagerTitleView(context) {
            @Override
            public void onSelected(int index, int totalCount) {
                super.onSelected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT_BOLD);
            }

            @Override
            public void onDeselected(int index, int totalCount) {
                super.onDeselected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT);
            }
        };
        scaleTransitionPagerTitleView.setText(tabTitles.get(index));
        scaleTransitionPagerTitleView.setTextSize(textSize);
        scaleTransitionPagerTitleView.setNormalColor(normalColor);
        scaleTransitionPagerTitleView.setSelectedColor(selectedColor);
        scaleTransitionPagerTitleView.setOnClickListener(v -> viewPager.setCurrentItem(index));
        return scaleTransitionPagerTitleView;
    }

    public static ScaleTransitionPagerTitleView getScaleTransitionPagerTitleView(Context context,
                                                                                 int index, List<String> tabTitles, ViewPager viewPager,
                                                                                 int textSize, int normalColor, int selectedColor, int childPadding) {

        ScaleTransitionPagerTitleView scaleTransitionPagerTitleView = new ScaleTransitionPagerTitleView(context) {
            @Override
            public void onSelected(int index, int totalCount) {
                super.onSelected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT_BOLD);
            }

            @Override
            public void onDeselected(int index, int totalCount) {
                super.onDeselected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT);
            }
        };
        scaleTransitionPagerTitleView.setText(tabTitles.get(index));
        scaleTransitionPagerTitleView.setTextSize(textSize);
        scaleTransitionPagerTitleView.setNormalColor(normalColor);
        scaleTransitionPagerTitleView.setSelectedColor(selectedColor);
        scaleTransitionPagerTitleView.setOnClickListener(v -> viewPager.setCurrentItem(index));
        scaleTransitionPagerTitleView.setPadding(childPadding, 0, childPadding, 0);
        return scaleTransitionPagerTitleView;
    }


    @NotNull
    public static SimplePagerTitleView getSimplePagerTitleView(Context context,
                                                               int index, List<String> tabTitles, ViewPager viewPager,
                                                               int textSize, int normalColor, int selectedColor) {
        SimplePagerTitleView simplePagerTitleView = new SimplePagerTitleView(context) {
            @Override
            public void onSelected(int index, int totalCount) {
                super.onSelected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT_BOLD);
            }

            @Override
            public void onDeselected(int index, int totalCount) {
                super.onDeselected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT);
            }
        };
        simplePagerTitleView.setText(tabTitles.get(index));
        simplePagerTitleView.setTextSize(textSize);
        simplePagerTitleView.setNormalColor(normalColor);
        simplePagerTitleView.setSelectedColor(selectedColor);
        simplePagerTitleView.setOnClickListener(v -> viewPager.setCurrentItem(index));
        return simplePagerTitleView;
    }

    @NotNull
    public static SimplePagerTitleView getSimplePagerTitleView(Context context,
                                                               int index, List<String> tabTitles, ViewPager viewPager,
                                                               int textSize, int normalColor, int selectedColor, int childPadding) {
        SimplePagerTitleView simplePagerTitleView = new SimplePagerTitleView(context) {
            @Override
            public void onSelected(int index, int totalCount) {
                super.onSelected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT_BOLD);
            }

            @Override
            public void onDeselected(int index, int totalCount) {
                super.onDeselected(index, totalCount);
                this.setTypeface(Typeface.DEFAULT);
            }
        };
        simplePagerTitleView.setText(tabTitles.get(index));
        simplePagerTitleView.setTextSize(textSize);
        simplePagerTitleView.setNormalColor(normalColor);
        simplePagerTitleView.setSelectedColor(selectedColor);
        simplePagerTitleView.setOnClickListener(v -> viewPager.setCurrentItem(index));
        simplePagerTitleView.setPadding(childPadding, 0, childPadding, 0);
        return simplePagerTitleView;
    }


    public static LineGradientPagerIndicator getLineGradientPagerIndicator(Context context,
                                                                           int lineHeight, int lineWidth, int radius,
                                                                           int[] colorList, float[] positionList) {
        LineGradientPagerIndicator indicator = new LineGradientPagerIndicator(context);
        indicator.setMode(LinePagerIndicator.MODE_EXACTLY);
        indicator.setLineHeight(lineHeight);
        indicator.setLineWidth(lineWidth);
        indicator.setRoundRadius(radius);
        indicator.setStartInterpolator(new AccelerateInterpolator());
        indicator.setEndInterpolator(new DecelerateInterpolator(1.5f));
        indicator.setGradientColorList(colorList);
        indicator.setGradientPositionList(positionList);
        return indicator;
    }

    public static LineGradientPagerIndicator getLineGradientWrapContentPagerIndicator(Context context,
                                                                                      int lineHeight, int radius,
                                                                                      int[] colorList, float[] positionList) {
        LineGradientPagerIndicator indicator = new LineGradientPagerIndicator(context);
        indicator.setMode(LinePagerIndicator.MODE_WRAP_CONTENT);
        indicator.setLineHeight(lineHeight);
        indicator.setRoundRadius(radius);
        indicator.setStartInterpolator(new AccelerateInterpolator());
        indicator.setEndInterpolator(new DecelerateInterpolator(1.5f));
        indicator.setGradientColorList(colorList);
        indicator.setGradientPositionList(positionList);
        return indicator;
    }


    @NotNull
    public static DotPagerIndicator getDotPagerIndicator(Context context, int color) {
        DotPagerIndicator roundPagerIndicator = new DotPagerIndicator(context);
        roundPagerIndicator.setColor(color);
        roundPagerIndicator.setXOffset(5);
        roundPagerIndicator.setYOffset(15);
        return roundPagerIndicator;
    }


}
