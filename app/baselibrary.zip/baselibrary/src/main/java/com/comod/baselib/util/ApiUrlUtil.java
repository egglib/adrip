package com.comod.baselib.util;

public class ApiUrlUtil {

    public static String getFormatUrl(String apiStr){
        if (apiStr.startsWith("/")) {
            return apiStr;
        } else {
            return "/" + apiStr;
        }
    }
}
