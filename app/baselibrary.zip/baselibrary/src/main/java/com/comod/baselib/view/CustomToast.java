package com.comod.baselib.view;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.comod.baselib.R;
import com.comod.baselib.util.DpUtil;


public class CustomToast extends Toast {


    /**
     * 构造方法
     *
     * @param context
     */
    private CustomToast(Context context, CharSequence text, int duration, int gravity, int x, int y) {
        super(context);
        initView(context, text, duration, gravity,x,y);
    }


    /**
     * 初始化布局
     *
     * @param context
     * @param text
     * @param duration
     */
    private void initView(Context context, CharSequence text, int duration, int gravity, int x, int y) {
        View view = LayoutInflater.from(context).inflate(R.layout.custom_toast, null);
        TextView content = view.findViewById(R.id.tv_content);
        content.setText(text);
        setDuration(duration);
        setGravity(gravity, x, y);
        setView(view);

    }


    /**
     *
     * @param context
     * @param text
     * @param duration
     * @return
     */
    public static Toast makeText(Context context, CharSequence text, int duration) {
        return new CustomToast(context, text, duration, Gravity.BOTTOM,0, DpUtil.dp2px(context,50));
    }

    public static Toast makeCenterText(Context context, CharSequence text, int duration) {
        return new CustomToast(context, text, duration, Gravity.CENTER,0,0);
    }
}
