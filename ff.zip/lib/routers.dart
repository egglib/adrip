import 'package:go_router/go_router.dart';
import 'package:gtea/navigator/tab_navigator.dart';
import 'package:gtea/pages/activity_page.dart';
import 'package:gtea/pages/app_center.dart';
import 'package:gtea/pages/attention_collect/attention_collect.dart';
import 'package:gtea/pages/contact_official.dart';
import 'package:gtea/pages/dynamic_page.dart';
import 'package:gtea/pages/home_page.dart';
import 'package:gtea/pages/login_page.dart';
import 'package:gtea/pages/my_bought.dart';
import 'package:gtea/pages/my_coupon.dart';
import 'package:gtea/pages/my_invite.dart';
import 'package:gtea/pages/my_page.dart';
import 'package:gtea/pages/my_reserve.dart';
import 'package:gtea/pages/online_service.dart';
import 'package:gtea/pages/quick_hidden.dart';
import 'package:gtea/pages/home_search_page.dart';
import 'package:gtea/pages/search_page.dart';
import 'package:gtea/pages/settled_page.dart';
import 'package:gtea/pages/sliver_coin_mall.dart';
import 'package:gtea/pages/splash_page.dart';
import 'package:gtea/pages/webview_page.dart';

class Routers {
  static String home = '/home';
  static String homeSearch = '/homeSearch';
  static String search = '/search';
  static String dynamicPage = '/dynamicPage';
  static String mine = '/mine';
  static String login = '/login';
  static String webview = '/webviewPage';
  static String settled = '/settled';
  static String activity = '/activity';

  static String attentionCollect = '/attentionCollect';
  static String myBought = '/myBought';
  static String myReserve = '/myReserve';
  static String myCoupon = '/myCoupon';
  static String sliverCoinMall = '/sliverCoinMall';
  static String onlineService = '/onlineService';
  static String myInvite = '/myInvite';
  static String quickHidden = '/quickHidden';
  static String contactOfficial = '/contactOfficial';
  static String appCenter = '/appCenter';

  static GoRouter init() {
    return GoRouter(routes: [
      GoRoute(path: '/', builder: (context, state) => const SplashPage()),
      GoRoute(path: home, builder: (context, state) => const HomePage()),
      GoRoute(
          path: homeSearch,
          builder: (context, state) => const HomeSearchPage()),
      GoRoute(path: search, builder: (context, state) => const SearchPage()),
      GoRoute(
          path: dynamicPage, builder: (context, state) => const DynamicPage()),
      GoRoute(path: mine, builder: (context, state) => const MyPage()),
      GoRoute(path: login, builder: (context, state) => const LoginPage()),
      GoRoute(
          path: attentionCollect,
          builder: (context, state) => const AttentionCollect()),
      GoRoute(path: myBought, builder: (context, state) => const MyBought()),
      GoRoute(path: myReserve, builder: (context, state) => const MyReserve()),
      GoRoute(path: myCoupon, builder: (context, state) => const MyCoupon()),
      GoRoute(
          path: sliverCoinMall,
          builder: (context, state) => const SliverCoinMall()),
      GoRoute(
          path: onlineService,
          builder: (context, state) => const OnlineService()),
      GoRoute(path: myInvite, builder: (context, state) => const MyInvite()),
      GoRoute(
          path: quickHidden, builder: (context, state) => const QuickHidden()),
      GoRoute(
          path: contactOfficial,
          builder: (context, state) => const ContactOfficial()),
      GoRoute(path: appCenter, builder: (context, state) => const AppCenter()),
      GoRoute(
          path: webview,
          builder: (context, state) {
            final args = state.extra as Map<String, dynamic>;
            return WebViewPage(
              args: args,
            );
          }),
      GoRoute(
          path: settled,
          builder: (context, state) {
            return SettledPage();
          }),
      GoRoute(
          path: activity,
          builder: (context, state) {
            return ActivityPage();
          }),
    ]);
  }
}
