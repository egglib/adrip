import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:gtea/net/api_util.dart';
import 'package:hive/hive.dart';

import 'net/http_request.dart';

class AppGlobal {
  static List<String> apiLines = [
    "https://squid.yesebo.net/api.php",
    "https://squid.yesebo.net/api.php",
    "https://squid.yesebo.net/api.php"
  ];

  static String apiBaseURL = "https://tongx.yesebo.net";
  static String apiToken = "";
  static Map appInfo;

  static BuildContext appContext;
  static bool appInit = false;
  static Box appBox;
  static bool routerReplace = false;

  //依赖注入，全局单例
  static GetIt getIt = GetIt.instance;

  /// 依赖注入，全局单例对象
  static setup() {
    getIt.registerSingleton(HttpRequest());
    getIt.registerSingleton(ApiUtil());
  }
}
