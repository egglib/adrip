import 'package:gtea/base/base_presenter.dart';
import 'package:gtea/view/abs_home_page_view.dart';

class HomePagePresenter extends BasePresenter<AbsHomePageView>{

}