// ignore_for_file: non_constant_identifier_names

class ImgRes {
  static String IMAGE_PATH = 'assets/images/';
  static String LOTTIE_PATH = 'assets/lottie/';
  static String IC_NAV_DOT = '${IMAGE_PATH}ic_nav_dot.png';
  static String IC_SEARCH = '${IMAGE_PATH}ic_search.png';
  static String IC_SEARCH_GRAY = '${IMAGE_PATH}ic_search_gray.png';
  static String BANNER_TEST = '${IMAGE_PATH}banner_test.png';
  static String BANNER_TEST_1 = '${IMAGE_PATH}banner_test_1.png';
  static String IC_ENTRY_1 = '${IMAGE_PATH}ic_entry_1.png';
  static String IC_ENTRY_2 = '${IMAGE_PATH}ic_entry_2.png';
  static String IC_ARROW_RIGHT_GRAY = '${IMAGE_PATH}ic_arrow_right_gray.png';
  static String IMG_BACK_TEST = '${IMAGE_PATH}img_back_test.png';
  static String IC_LOCATION = '${IMAGE_PATH}ic_location.png';
  static String IC_FILTER = '${IMAGE_PATH}ic_filter.png';
  static String BG_HOT_TOPIC = '${IMAGE_PATH}bg_hot_topic.png';
  static String IC_SHARE = '${IMAGE_PATH}ic_share.png';
  static String IC_LIKE = '${IMAGE_PATH}ic_like.png';
  static String DOWN_REFRESH_GIF = '${IMAGE_PATH}down_refresh.gif';
  static String DOWN_REFRESH_PNG = '${IMAGE_PATH}down_refresh.png';
  static String IC_BACK_BLACK = '${IMAGE_PATH}ic_back_black.png';
  static String IC_BACK_WHITE = '${IMAGE_PATH}ic_back_white.png';
  static String IC_STAR_SELECTED = '${IMAGE_PATH}ic_star_selected.png';
  static String IC_STAR_NORMAL = '${IMAGE_PATH}ic_star_normal.png';
  static String IC_STAR_HALF = '${IMAGE_PATH}ic_star_half.png';
  static String IC_LOGO = '${IMAGE_PATH}logo.png';
  static String IC_HOME_NORMAL = '${IMAGE_PATH}ic_home_normal.png';
  static String IC_HOME_ACTIVE = '${IMAGE_PATH}ic_home_active.png';
  static String IC_DYNAMIC_NORMAL = '${IMAGE_PATH}ic_dynamic_normal.png';
  static String IC_DYNAMIC_ACTIVE = '${IMAGE_PATH}ic_dynamic_active.png';
  static String IC_MINE_NORMAL = '${IMAGE_PATH}ic_mine_normal.png';
  static String IC_MINE_ACTIVE = '${IMAGE_PATH}ic_mine_active.png';
  static String IC_SEARCH_NORMAL = '${IMAGE_PATH}ic_search_normal.png';
  static String IC_SEARCH_ACTIVE = '${IMAGE_PATH}ic_search_active.png';
  static String IC_CLEAR_GRAY = '${IMAGE_PATH}ic_clear_gray.png';
  static String IC_NO_DATA = '${IMAGE_PATH}ic_no_data.png';
  static String IC_NO_NETWORK = '${IMAGE_PATH}ic_no_network.png';

  /// my page
  static String MY_FUNC_00 = '${IMAGE_PATH}my_func_00.png';
  static String MY_FUNC_01 = '${IMAGE_PATH}my_func_01.png';
  static String MY_FUNC_02 = '${IMAGE_PATH}my_func_02.png';
  static String MY_FUNC_03 = '${IMAGE_PATH}my_func_03.png';
  static String MY_FUNC_04 = '${IMAGE_PATH}my_func_04.png';
  static String MY_FUNC_05 = '${IMAGE_PATH}my_func_05.png';
  static String MY_FUNC_06 = '${IMAGE_PATH}my_func_06.png';
  static String MY_FUNC_07 = '${IMAGE_PATH}my_func_07.png';
  static String MY_FUNC_08 = '${IMAGE_PATH}my_func_08.png';
  static String MY_FUNC_09 = '${IMAGE_PATH}my_func_09.png';

  static String MY_TOP_BACK = '${IMAGE_PATH}my_top_back.png';
  static String MY_MSG_ICON = '${IMAGE_PATH}my_msg_icon.png';
  static String MY_SET_ICON = '${IMAGE_PATH}my_set_icon.png';
  static String MY_MBR_TYPE = '${IMAGE_PATH}my_mbr_type.png';
  static String MY_MBR_BACK = '${IMAGE_PATH}my_mbr_back.png';
  static String MY_MBR_ICON = '${IMAGE_PATH}my_mbr_icon.png';

  static String MY_OVER_BACK = '${IMAGE_PATH}my_over_back.png';
  static String MY_FREE_BACK = '${IMAGE_PATH}my_free_back.png';
  static String MY_WORK_BACK = '${IMAGE_PATH}my_work_back.png';
  static String MY_WORK_ICON = '${IMAGE_PATH}my_work_icon.png';

  static String APP_CENTER_ICON = '${IMAGE_PATH}app_center_icon.png';

  static String ATT_SGMT_INDICATOR = '${IMAGE_PATH}att_sgmt_indicator.png';
}
