class AppConst {
  static const String KEY_TOKEN = "gtea_token";
  static const String OAUTH_TYPE = "pwa";
  static const String PREFIX_LOG = "gtea===";
  static bool isDebug = true;
}
