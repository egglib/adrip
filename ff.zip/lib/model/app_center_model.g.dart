// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_center_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AppItemModel _$AppItemModelFromJson(Map<String, dynamic> json) {
  return AppItemModel()
    ..title = json['title'] as String
    ..description = json['description'] as String
    ..linkUrl = json['link_url'] as String
    ..clicked = json['clicked'] as int
    ..imgUrlFull = json['img_url_full'] as String
    ..id = json['id'] as int
    ..imgUrl = json['img_url'] as String
    ..status = json['status'] as int
    ..statusStr = json['status_str'] as String
    ..sort = json['sort'] as int
    ..platform = json['platform'] as int
    ..createdAt = json['created_at'] as String
    ..createdStr = json['created_str'] as String;
}

Map<String, dynamic> _$AppItemModelToJson(AppItemModel instance) =>
    <String, dynamic>{
      'title': instance.title,
      'description': instance.description,
      'link_url': instance.linkUrl,
      'clicked': instance.clicked,
      'img_url_full': instance.imgUrlFull,
      'id': instance.id,
      'img_url': instance.imgUrl,
      'status': instance.status,
      'status_str': instance.statusStr,
      'sort': instance.sort,
      'platform': instance.platform,
      'created_at': instance.createdAt,
      'created_str': instance.createdStr,
    };
