class ConfigModel {
    List<AdsPop> ads_pop;
    List<AdsScreen> ads_screen;
    PlayerCfg player_cfg;
    String system_group;
    String system_notice;
    Upload upload;
    Version version;

    ConfigModel({this.ads_pop, this.ads_screen, this.player_cfg, this.system_group, this.system_notice, this.upload, this.version});

    factory ConfigModel.fromJson(Map<String, dynamic> json) {
        return ConfigModel(
            ads_pop: json['ads_pop'] != null ? (json['ads_pop'] as List).map((i) => AdsPop.fromJson(i)).toList() : null,
            ads_screen: json['ads_screen'] != null ? (json['ads_screen'] as List).map((i) => AdsScreen.fromJson(i)).toList() : null,
            player_cfg: json['player_cfg'] != null ? PlayerCfg.fromJson(json['player_cfg']) : null,
            system_group: json['system_group'],
            system_notice: json['system_notice'],
            upload: json['upload'] != null ? Upload.fromJson(json['upload']) : null,
            version: json['version'] != null ? Version.fromJson(json['version']) : null,
        );
    }

    Map<String, dynamic> toJson() {
        final Map<String, dynamic> data = new Map<String, dynamic>();
        data['system_group'] = this.system_group;
        data['system_notice'] = this.system_notice;
        if (this.ads_pop != null) {
            data['ads_pop'] = this.ads_pop.map((v) => v.toJson()).toList();
        }
        if (this.ads_screen != null) {
            data['ads_screen'] = this.ads_screen.map((v) => v.toJson()).toList();
        }
        if (this.player_cfg != null) {
            data['player_cfg'] = this.player_cfg.toJson();
        }
        if (this.upload != null) {
            data['upload'] = this.upload.toJson();
        }
        if (this.version != null) {
            data['version'] = this.version.toJson();
        }
        return data;
    }
}

class Version {
    String apk;
    int id;
    int must;
    String tips;
    String type;
    String version;
    String via;

    Version({this.apk, this.id, this.must, this.tips, this.type, this.version, this.via});

    factory Version.fromJson(Map<String, dynamic> json) {
        return Version(
            apk: json['apk'],
            id: json['id'],
            must: json['must'],
            tips: json['tips'],
            type: json['type'],
            version: json['version'],
            via: json['via'],
        );
    }

    Map<String, dynamic> toJson() {
        final Map<String, dynamic> data = new Map<String, dynamic>();
        data['apk'] = this.apk;
        data['id'] = this.id;
        data['must'] = this.must;
        data['tips'] = this.tips;
        data['type'] = this.type;
        data['version'] = this.version;
        data['via'] = this.via;
        return data;
    }
}

class AdsScreen {
    String app_via;
    String channel;
    String description;
    int id;
    int img_type;
    String img_url;
    String img_url_full;
    String pos_flag;
    int status;
    String status_str;
    String title;
    int type;
    String url;

    AdsScreen({this.app_via, this.channel, this.description, this.id, this.img_type, this.img_url, this.img_url_full, this.pos_flag, this.status, this.status_str, this.title, this.type, this.url});

    factory AdsScreen.fromJson(Map<String, dynamic> json) {
        return AdsScreen(
            app_via: json['app_via'],
            channel: json['channel'],
            description: json['description'],
            id: json['id'],
            img_type: json['img_type'],
            img_url: json['img_url'],
            img_url_full: json['img_url_full'],
            pos_flag: json['pos_flag'],
            status: json['status'],
            status_str: json['status_str'],
            title: json['title'],
            type: json['type'],
            url: json['url'],
        );
    }

    Map<String, dynamic> toJson() {
        final Map<String, dynamic> data = new Map<String, dynamic>();
        data['app_via'] = this.app_via;
        data['channel'] = this.channel;
        data['description'] = this.description;
        data['id'] = this.id;
        data['img_type'] = this.img_type;
        data['img_url'] = this.img_url;
        data['img_url_full'] = this.img_url_full;
        data['pos_flag'] = this.pos_flag;
        data['status'] = this.status;
        data['status_str'] = this.status_str;
        data['title'] = this.title;
        data['type'] = this.type;
        data['url'] = this.url;
        return data;
    }
}

class AdsPop {
    String app_via;
    String channel;
    String description;
    int id;
    int img_type;
    String img_url;
    String img_url_full;
    String pos_flag;
    int status;
    String status_str;
    String title;
    int type;
    String url;

    AdsPop({this.app_via, this.channel, this.description, this.id, this.img_type, this.img_url, this.img_url_full, this.pos_flag, this.status, this.status_str, this.title, this.type, this.url});

    factory AdsPop.fromJson(Map<String, dynamic> json) {
        return AdsPop(
            app_via: json['app_via'],
            channel: json['channel'],
            description: json['description'],
            id: json['id'],
            img_type: json['img_type'],
            img_url: json['img_url'],
            img_url_full: json['img_url_full'],
            pos_flag: json['pos_flag'],
            status: json['status'],
            status_str: json['status_str'],
            title: json['title'],
            type: json['type'],
            url: json['url'],
        );
    }

    Map<String, dynamic> toJson() {
        final Map<String, dynamic> data = new Map<String, dynamic>();
        data['app_via'] = this.app_via;
        data['channel'] = this.channel;
        data['description'] = this.description;
        data['id'] = this.id;
        data['img_type'] = this.img_type;
        data['img_url'] = this.img_url;
        data['img_url_full'] = this.img_url_full;
        data['pos_flag'] = this.pos_flag;
        data['status'] = this.status;
        data['status_str'] = this.status_str;
        data['title'] = this.title;
        data['type'] = this.type;
        data['url'] = this.url;
        return data;
    }
}

class Upload {
    String img_key;
    String img_url;
    String mp4_key;
    String mp4_url;

    Upload({this.img_key, this.img_url, this.mp4_key, this.mp4_url});

    factory Upload.fromJson(Map<String, dynamic> json) {
        return Upload(
            img_key: json['img_key'],
            img_url: json['img_url'],
            mp4_key: json['mp4_key'],
            mp4_url: json['mp4_url'],
        );
    }

    Map<String, dynamic> toJson() {
        final Map<String, dynamic> data = new Map<String, dynamic>();
        data['img_key'] = this.img_key;
        data['img_url'] = this.img_url;
        data['mp4_key'] = this.mp4_key;
        data['mp4_url'] = this.mp4_url;
        return data;
    }
}

class PlayerCfg {
    String dekey;
    String refer;
    bool use_new;
    String x_auth;

    PlayerCfg({this.dekey, this.refer, this.use_new, this.x_auth});

    factory PlayerCfg.fromJson(Map<String, dynamic> json) {
        return PlayerCfg(
            dekey: json['dekey'],
            refer: json['refer'],
            use_new: json['use_new'],
            x_auth: json['x_auth'],
        );
    }

    Map<String, dynamic> toJson() {
        final Map<String, dynamic> data = new Map<String, dynamic>();
        data['dekey'] = this.dekey;
        data['refer'] = this.refer;
        data['use_new'] = this.use_new;
        data['x_auth'] = this.x_auth;
        return data;
    }
}