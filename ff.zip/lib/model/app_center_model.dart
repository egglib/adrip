
import 'package:json_annotation/json_annotation.dart';

part 'app_center_model.g.dart';

@JsonSerializable()
class AppItemModel {

  String title;
  String description;
  @JsonKey(name: 'link_url')
  String linkUrl;
  int clicked;
  @JsonKey(name: 'img_url_full')
  String imgUrlFull;

  int id;
  @JsonKey(name: 'img_url')
  String imgUrl;
  int status;
  @JsonKey(name: 'status_str')
  String statusStr; 
  int sort;
  int platform;
  @JsonKey(name: 'created_at')
  String createdAt;
  @JsonKey(name: 'created_str')
  String createdStr;

  AppItemModel();

  factory AppItemModel.fromJson(Map<String, dynamic> json) => _$AppItemModelFromJson(json);

  Map<String, dynamic> toJson() => _$AppItemModelToJson(this);

  AppItemModel innerTest() {
    title = "坦桑尼亚";
    description = "爱和纯 男士平衡舒缓套装 爱和纯 男士平衡舒缓套装 爱和纯 男士平衡舒缓套装";
    linkUrl = "https://www.baidu.com/";
    clicked = 1234567;
    imgUrlFull = "";
    return this;
  }
}