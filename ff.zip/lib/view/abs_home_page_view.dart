import 'package:gtea/base/base_view.dart';

abstract class AbsHomePageView extends BaseView{

}