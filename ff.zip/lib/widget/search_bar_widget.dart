import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/img_widget.dart';

class SearchBarWidget extends StatefulWidget {
  final bool hideBack;
  final String hint;
  final ValueChanged<String> onChanged;
  final ValueChanged<String> onSubmit;

  const SearchBarWidget(
      {Key key,
      this.hideBack = false,
      this.hint,
      this.onChanged,
      this.onSubmit})
      : super(key: key);

  @override
  _SearchBarWidgetState createState() => _SearchBarWidgetState();
}

class _SearchBarWidgetState extends State<SearchBarWidget> {
  bool showClear = false;
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: ScreenUtil().setWidth(35),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          widget?.hideBack ? const SizedBox() : _buildBackImg(context),
          Expanded(
            child: Container(
              margin: widget?.hideBack
                  ? EdgeInsets.only(left: 0)
                  : EdgeInsets.only(left: 10),
              height: ScreenUtil().setWidth(35),
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
              decoration: BoxDecoration(
                  color: ColorRes.color_f1f1f1,
                  borderRadius: BorderRadius.circular(20)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ImgWidget.buildSimpleLocalImage(ImgRes.IC_SEARCH_GRAY,
                      width: 15, height: 15),
                  Expanded(child: _buildSearchTextField()),
                  showClear ? _buildClearImg() : const SizedBox(),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildClearImg() {
    return ImgWidget.buildLocalImg(ImgRes.IC_CLEAR_GRAY, width: 16, height: 16,
        callback: () {
      setState(() {
        _controller.clear();
        _onChanged('');
      });
    });
  }

  TextField _buildSearchTextField() {
    return TextField(
        autofocus: false,
        controller: _controller,
        onChanged: _onChanged,
        textInputAction: TextInputAction.search,
        keyboardType: TextInputType.text,
        style: AppTextStyle.c30313f_s15,
        onSubmitted: widget?.onSubmit,
        decoration: InputDecoration(
            isCollapsed: true,
            contentPadding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
            border: InputBorder.none,
            hintText: widget.hint ?? '',
            hintStyle: AppTextStyle.c999999_s15));
  }

  Widget _buildBackImg(BuildContext context) {
    return ImgWidget.buildLocalImg(ImgRes.IC_BACK_BLACK, width: 20, height: 20,
        callback: () {
      context.pop();
    });
  }

  _onChanged(String text) {
    if (text.isNotEmpty) {
      setState(() {
        showClear = true;
      });
    } else {
      setState(() {
        showClear = false;
      });
    }
    if (widget.onChanged != null) {
      widget.onChanged(text);
    }
  }
}
