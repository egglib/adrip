import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:gtea/res/img_res.dart';

class RatingBarWidget {
  static buildHorizontalRatingBar(
      {double initRating = 1,
      double itemPadding = 5,
      double itemSize = 20,
      Function onUpdate}) {
    return RatingBar(
      initialRating: initRating,
      minRating: 1,
      direction: Axis.horizontal,
      allowHalfRating: true,
      itemCount: 5,
      itemSize: itemSize,
      itemPadding: EdgeInsets.symmetric(horizontal: itemPadding),
      ratingWidget: RatingWidget(
        full: Image.asset(ImgRes.IC_STAR_SELECTED),
        half: Image.asset(ImgRes.IC_STAR_HALF),
        empty: Image.asset(ImgRes.IC_STAR_NORMAL),
      ),
      onRatingUpdate: (rating) {
        onUpdate(rating);
      },
    );
  }
}
