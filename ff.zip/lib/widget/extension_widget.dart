import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:gtea/utils/edcrypt.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';
import 'package:flutter_page_indicator/flutter_page_indicator.dart';
import 'package:transformer_page_view/transformer_page_view.dart';

extension ColorExt on Color {
  List<Color> add(Color color) {
    return <Color>[this, color];
  }
}

extension TripartiteLibraryWidgetExt on Widget {
  RefreshLoadListWidget intoRefreshWidget(
      {Key key, Function onRefresh, Function onLoading}) {
    return RefreshLoadListWidget(
      key: key,

      child: (data){
        return this;
      },
    );
  }

  Swiper intoSwiper({
    Widget Function(BuildContext, int) itemBuilder,
    PageIndicatorLayout indicatorLayout = PageIndicatorLayout.NONE,
    PageTransformer transformer,
    int itemCount,
    bool autoplay = false,
    SwiperLayout layout = SwiperLayout.DEFAULT,
    int autoplayDelay = kDefaultAutoplayDelayMs,
    bool autoplayDisableOnInteraction = true,
    int duration = kDefaultAutoplayTransactionDuration,
    void Function(int) onIndexChanged,
    int index,
    void Function(int) onTap,
    SwiperPlugin control,
    bool loop = true,
    Curve curve = Curves.ease,
    Axis scrollDirection = Axis.horizontal,
    SwiperPlugin pagination,
    List<SwiperPlugin> plugins,
    ScrollPhysics physics,
    Key key,
    SwiperController controller,
    CustomLayoutOption customLayoutOption,
    double containerHeight,
    double containerWidth,
    double viewportFraction = 1.0,
    double itemHeight,
    double itemWidth,
    bool outer = false,
    double scale,
    double fade,
  }) {
    return Swiper(
        itemBuilder: itemBuilder,
        indicatorLayout: indicatorLayout,
        transformer: transformer,
        itemCount: itemCount,
        autoplay: autoplay,
        layout: layout,
        autoplayDelay: autoplayDelay,
        autoplayDisableOnInteraction: autoplayDisableOnInteraction,
        duration: duration,
        onIndexChanged: onIndexChanged,
        index: index,
        onTap: onTap,
        control: control,
        loop: loop,
        curve: curve,
        scrollDirection: scrollDirection,
        pagination: pagination,
        plugins: plugins,
        physics: physics,
        key: key,
        controller: controller,
        customLayoutOption: customLayoutOption,
        containerHeight: containerHeight,
        containerWidth: containerWidth,
        viewportFraction: viewportFraction,
        itemHeight: itemHeight,
        itemWidth: itemWidth,
        outer: outer,
        scale: scale,
        fade: fade);
  }
}

/// single-child Widget type extension
///
extension WidgetExt on Widget {
  List<Widget> addWidget(Widget widget) {
    return <Widget>[this, widget];
  }

  ClipRRect intoClipRRect({
    Key key,
    BorderRadius borderRadius = BorderRadius.zero,
    CustomClipper<RRect> clipper,
    Clip clipBehavior = Clip.antiAlias,
  }) {
    return ClipRRect(
      key: key,
      borderRadius: borderRadius,
      clipper: clipper,
      clipBehavior: clipBehavior,
      child: this,
    );
  }

  Widget intoExpanded({Key key, int flex = 1}) {
    return Expanded(key: key, flex: flex, child: this);
  }

  Widget intoAlign({
    Key key,
    AlignmentGeometry alignment = Alignment.center,
    double widthFactor,
    double heightFactor,
  }) {
    return Align(
      key: key,
      alignment: alignment,
      widthFactor: widthFactor,
      heightFactor: heightFactor,
    );
  }

  Widget intoCenter({Key key, double widthFactor, double heightFactor}) {
    return Center(
      key: key,
      widthFactor: widthFactor,
      heightFactor: heightFactor,
      child: this,
    );
  }

  Widget intoPadding({Key key, EdgeInsetsGeometry padding}) {
    return Padding(key: key, padding: padding, child: this);
  }

  Widget intoPositioned(
      {Key key,
      double left,
      double top,
      double right,
      double bottom,
      double width,
      double height}) {
    return Positioned(
        left: left,
        top: top,
        right: right,
        bottom: bottom,
        width: width,
        height: height,
        child: this);
  }

  Widget intoSizedBox({
    Key key,
    double width,
    double height,
  }) {
    return SizedBox(
      key: key,
      width: width,
      height: height,
      child: this,
    );
  }

  Widget intoContainer({
    Key key,
    AlignmentGeometry alignment,
    EdgeInsetsGeometry padding,
    Color color,
    Decoration decoration,
    Decoration foregroundDecoration,
    double width,
    double height,
    BoxConstraints constraints,
    EdgeInsetsGeometry margin,
    Matrix4 transform,
    AlignmentGeometry transformAlignment,
    Clip clipBehavior = Clip.none,
  }) {
    return Container(
      key: key,
      alignment: alignment,
      padding: padding,
      color: color,
      decoration: decoration,
      foregroundDecoration: foregroundDecoration,
      width: width,
      height: height,
      constraints: constraints,
      margin: margin,
      transform: transform,
      clipBehavior: clipBehavior,
      child: this,
    );
  }

  Widget intoSafeArea({
    Key key,
    bool left = true,
    bool top = true,
    bool right = true,
    bool bottom = true,
    EdgeInsets minimum = EdgeInsets.zero,
    bool maintainBottomViewPadding = false,
  }) {
    return SafeArea(
        key: key,
        left: left,
        top: top,
        right: right,
        bottom: bottom,
        minimum: minimum,
        child: this);
  }

  Widget intoSingleChildScrollView(
      {Key key,
      Axis scrollDirection = Axis.vertical,
      bool reverse = false,
      EdgeInsetsGeometry padding,
      bool primary,
      ScrollPhysics physics,
      ScrollController controller,
      DragStartBehavior dragStartBehavior = DragStartBehavior.start,
      Clip clipBehavior = Clip.hardEdge,
      String restorationId,
      ScrollViewKeyboardDismissBehavior keyboardDismissBehavior =
          ScrollViewKeyboardDismissBehavior.manual}) {
    return SingleChildScrollView(
      key: key,
      scrollDirection: scrollDirection,
      reverse: reverse,
      padding: padding,
      primary: primary,
      physics: physics,
      controller: controller,
      dragStartBehavior: dragStartBehavior,
      clipBehavior: clipBehavior,
      restorationId: restorationId,
      keyboardDismissBehavior: keyboardDismissBehavior,
      child: this,
    );
  }

  Widget intoGestureDetector(
      {Key key,
      void Function(TapDownDetails) onTapDown,
      void Function(TapUpDetails) onTapUp,
      void Function() onTap,
      void Function() onTapCancel,
      void Function() onSecondaryTap,
      void Function(TapDownDetails) onSecondaryTapDown,
      void Function(TapUpDetails) onSecondaryTapUp,
      void Function() onSecondaryTapCancel,
      void Function(TapDownDetails) onTertiaryTapDown,
      void Function(TapUpDetails) onTertiaryTapUp,
      void Function() onTertiaryTapCancel,
      void Function(TapDownDetails) onDoubleTapDown,
      void Function() onDoubleTap,
      void Function() onDoubleTapCancel,
      void Function(LongPressDownDetails) onLongPressDown,
      void Function() onLongPressCancel,
      void Function() onLongPress,
      void Function(LongPressStartDetails) onLongPressStart,
      void Function(LongPressMoveUpdateDetails) onLongPressMoveUpdate,
      void Function() onLongPressUp,
      void Function(LongPressEndDetails) onLongPressEnd,
      void Function(LongPressDownDetails) onSecondaryLongPressDown,
      void Function() onSecondaryLongPressCancel,
      void Function() onSecondaryLongPress,
      void Function(LongPressStartDetails) onSecondaryLongPressStart,
      void Function(LongPressMoveUpdateDetails) onSecondaryLongPressMoveUpdate,
      void Function() onSecondaryLongPressUp,
      void Function(LongPressEndDetails) onSecondaryLongPressEnd,
      void Function(LongPressDownDetails) onTertiaryLongPressDown,
      void Function() onTertiaryLongPressCancel,
      void Function() onTertiaryLongPress,
      void Function(LongPressStartDetails) onTertiaryLongPressStart,
      void Function(LongPressMoveUpdateDetails) onTertiaryLongPressMoveUpdate,
      void Function() onTertiaryLongPressUp,
      void Function(LongPressEndDetails) onTertiaryLongPressEnd,
      void Function(DragDownDetails) onVerticalDragDown,
      void Function(DragStartDetails) onVerticalDragStart,
      void Function(DragUpdateDetails) onVerticalDragUpdate,
      void Function(DragEndDetails) onVerticalDragEnd,
      void Function() onVerticalDragCancel,
      void Function(DragDownDetails) onHorizontalDragDown,
      void Function(DragStartDetails) onHorizontalDragStart,
      void Function(DragUpdateDetails) onHorizontalDragUpdate,
      void Function(DragEndDetails) onHorizontalDragEnd,
      void Function() onHorizontalDragCancel,
      void Function(ForcePressDetails) onForcePressStart,
      void Function(ForcePressDetails) onForcePressPeak,
      void Function(ForcePressDetails) onForcePressUpdate,
      void Function(ForcePressDetails) onForcePressEnd,
      void Function(DragDownDetails) onPanDown,
      void Function(DragStartDetails) onPanStart,
      void Function(DragUpdateDetails) onPanUpdate,
      void Function(DragEndDetails) onPanEnd,
      void Function() onPanCancel,
      void Function(ScaleStartDetails) onScaleStart,
      void Function(ScaleUpdateDetails) onScaleUpdate,
      void Function(ScaleEndDetails) onScaleEnd,
      HitTestBehavior behavior,
      bool excludeFromSemantics = false,
      DragStartBehavior dragStartBehavior = DragStartBehavior.start}) {
    return GestureDetector(
      key: key,
      child: this,
      onTapDown: onTapDown,
      onTapUp: onTapUp,
      onTap: onTap,
      onTapCancel: onTapCancel,
      onSecondaryTap: onSecondaryTap,
      onSecondaryTapDown: onSecondaryTapDown,
      onSecondaryTapUp: onSecondaryTapUp,
      onSecondaryTapCancel: onSecondaryTapCancel,
      onTertiaryTapDown: onTertiaryTapDown,
      onTertiaryTapUp: onTertiaryTapUp,
      onTertiaryTapCancel: onTertiaryTapCancel,
      onDoubleTapDown: onDoubleTapDown,
      onDoubleTap: onDoubleTap,
      onDoubleTapCancel: onDoubleTapCancel,
      onLongPressDown: onLongPressDown,
      onLongPressCancel: onLongPressCancel,
      onLongPress: onLongPress,
      onLongPressStart: onLongPressStart,
      onLongPressMoveUpdate: onLongPressMoveUpdate,
      onLongPressUp: onLongPressUp,
      onLongPressEnd: onLongPressEnd,
      onSecondaryLongPressDown: onSecondaryLongPressDown,
      onSecondaryLongPressCancel: onSecondaryLongPressCancel,
      onSecondaryLongPress: onSecondaryLongPress,
      onSecondaryLongPressStart: onSecondaryLongPressStart,
      onSecondaryLongPressMoveUpdate: onSecondaryLongPressMoveUpdate,
      onSecondaryLongPressUp: onSecondaryLongPressUp,
      onSecondaryLongPressEnd: onSecondaryLongPressEnd,
      onTertiaryLongPressDown: onTertiaryLongPressDown,
      onTertiaryLongPressCancel: onTertiaryLongPressCancel,
      onTertiaryLongPress: onTertiaryLongPress,
      onTertiaryLongPressStart: onTertiaryLongPressStart,
      onTertiaryLongPressMoveUpdate: onTertiaryLongPressMoveUpdate,
      onTertiaryLongPressUp: onTertiaryLongPressUp,
      onTertiaryLongPressEnd: onTertiaryLongPressEnd,
      onVerticalDragDown: onVerticalDragDown,
      onVerticalDragStart: onVerticalDragStart,
      onVerticalDragUpdate: onVerticalDragUpdate,
      onVerticalDragEnd: onVerticalDragEnd,
      onVerticalDragCancel: onVerticalDragCancel,
      onHorizontalDragDown: onHorizontalDragDown,
      onHorizontalDragStart: onHorizontalDragStart,
      onHorizontalDragUpdate: onHorizontalDragUpdate,
      onHorizontalDragEnd: onHorizontalDragEnd,
      onHorizontalDragCancel: onHorizontalDragCancel,
      onForcePressStart: onForcePressStart,
      onForcePressPeak: onForcePressPeak,
      onForcePressUpdate: onForcePressUpdate,
      onForcePressEnd: onForcePressEnd,
      onPanDown: onPanDown,
      onPanStart: onPanStart,
      onPanUpdate: onPanUpdate,
      onPanEnd: onPanEnd,
      onPanCancel: onPanCancel,
      onScaleStart: onScaleStart,
      onScaleUpdate: onScaleUpdate,
      onScaleEnd: onScaleEnd,
      behavior: behavior,
      excludeFromSemantics: excludeFromSemantics,
      dragStartBehavior: dragStartBehavior,
    );
  }

  Scaffold intoScaffold({
    Key key,
    PreferredSizeWidget appBar,
    Widget floatingActionButton,
    FloatingActionButtonLocation floatingActionButtonLocation,
    FloatingActionButtonAnimator floatingActionButtonAnimator,
    List<Widget> persistentFooterButtons,
    Widget drawer,
    void Function(bool) onDrawerChanged,
    Widget endDrawer,
    void Function(bool) onEndDrawerChanged,
    Widget bottomNavigationBar,
    Widget bottomSheet,
    Color backgroundColor,
    bool resizeToAvoidBottomInset,
    bool primary = true,
    DragStartBehavior drawerDragStartBehavior = DragStartBehavior.start,
    bool extendBody = false,
    bool extendBodyBehindAppBar = false,
    Color drawerScrimColor,
    double drawerEdgeDragWidth,
    bool drawerEnableOpenDragGesture = true,
    bool endDrawerEnableOpenDragGesture = true,
    String restorationId,
  }) {
    return Scaffold(
      key: key,
      appBar: appBar,
      floatingActionButton: floatingActionButton,
      floatingActionButtonLocation: floatingActionButtonLocation,
      floatingActionButtonAnimator: floatingActionButtonAnimator,
      persistentFooterButtons: persistentFooterButtons,
      drawer: drawer,
      onDrawerChanged: onDrawerChanged,
      endDrawer: endDrawer,
      onEndDrawerChanged: onEndDrawerChanged,
      bottomNavigationBar: bottomNavigationBar,
      bottomSheet: bottomSheet,
      backgroundColor: backgroundColor,
      resizeToAvoidBottomInset: resizeToAvoidBottomInset,
      primary: primary,
      drawerDragStartBehavior: drawerDragStartBehavior,
      extendBody: extendBody,
      extendBodyBehindAppBar: extendBodyBehindAppBar,
      drawerScrimColor: drawerScrimColor,
      drawerEdgeDragWidth: drawerEdgeDragWidth,
      drawerEnableOpenDragGesture: drawerEnableOpenDragGesture,
      endDrawerEnableOpenDragGesture: endDrawerEnableOpenDragGesture,
      restorationId: restorationId,
      body: this,
    );
  }
}

/// multi-child Widget type extension
///
extension WidgetListExt<T extends Widget> on List<T> {
  List<Widget> addWidget(Widget widget) {
    return this..add(widget);
  }

  Widget intoRow({
    Key key,
    MainAxisAlignment mainAxisAlignment = MainAxisAlignment.start,
    MainAxisSize mainAxisSize = MainAxisSize.max,
    CrossAxisAlignment crossAxisAlignment = CrossAxisAlignment.center,
    TextDirection textDirection,
    VerticalDirection verticalDirection = VerticalDirection.down,
    TextBaseline textBaseline,
  }) {
    return Row(
      key: key,
      mainAxisAlignment: mainAxisAlignment,
      mainAxisSize: mainAxisSize,
      crossAxisAlignment: crossAxisAlignment,
      textDirection: textDirection,
      verticalDirection: verticalDirection,
      textBaseline: textBaseline,
      children: this,
    );
  }

  Widget intoColumn({
    Key key,
    MainAxisAlignment mainAxisAlignment = MainAxisAlignment.start,
    MainAxisSize mainAxisSize = MainAxisSize.max,
    CrossAxisAlignment crossAxisAlignment = CrossAxisAlignment.center,
    TextDirection textDirection,
    VerticalDirection verticalDirection = VerticalDirection.down,
    TextBaseline textBaseline,
  }) {
    return Column(
      key: key,
      mainAxisAlignment: mainAxisAlignment,
      mainAxisSize: mainAxisSize,
      crossAxisAlignment: crossAxisAlignment,
      textDirection: textDirection,
      verticalDirection: verticalDirection,
      textBaseline: textBaseline,
      children: this,
    );
  }

  Widget intoStack({
    Key key,
    AlignmentGeometry alignment = AlignmentDirectional.topStart,
    TextDirection textDirection,
    StackFit fit = StackFit.loose,
    // ignore: deprecated_member_use
    Overflow overflow = Overflow.clip,
    Clip clipBehavior = Clip.hardEdge,
  }) {
    return Stack(
      key: key,
      alignment: alignment,
      fit: fit,
      // ignore: deprecated_member_use
      overflow: overflow,
      clipBehavior: clipBehavior,
      children: this,
    );
  }

  Widget intoWrap({
    Key key,
    Axis direction = Axis.horizontal,
    WrapAlignment alignment = WrapAlignment.start,
    double spacing = 0.0,
    WrapAlignment runAlignment = WrapAlignment.start,
    double runSpacing = 0.0,
    WrapCrossAlignment crossAxisAlignment = WrapCrossAlignment.start,
    TextDirection textDirection,
    VerticalDirection verticalDirection = VerticalDirection.down,
    Clip clipBehavior = Clip.none,
  }) {
    return Wrap(
      key: key,
      direction: direction,
      alignment: alignment,
      spacing: spacing,
      runAlignment: runAlignment,
      runSpacing: runSpacing,
      crossAxisAlignment: crossAxisAlignment,
      textDirection: textDirection,
      verticalDirection: verticalDirection,
      clipBehavior: clipBehavior,
      children: this,
    );
  }

  Widget intoFlow({
    Key key,
    FlowDelegate delegate,
    Clip clipBehavior = Clip.hardEdge,
  }) {
    return Flow(
        key: key,
        delegate: delegate,
        clipBehavior: clipBehavior,
        children: this);
  }

  Widget intoListView(
      {Key key,
      Axis scrollDirection = Axis.vertical,
      bool reverse = false,
      ScrollController controller,
      bool primary,
      ScrollPhysics physics,
      bool shrinkWrap = false,
      EdgeInsetsGeometry padding,
      double itemExtent,
      Widget prototypeItem,
      bool addAutomaticKeepAlives = true,
      bool addRepaintBoundaries = true,
      bool addSemanticIndexes = true,
      double cacheExtent,
      int semanticChildCount,
      DragStartBehavior dragStartBehavior = DragStartBehavior.start,
      ScrollViewKeyboardDismissBehavior keyboardDismissBehavior =
          ScrollViewKeyboardDismissBehavior.manual,
      String restorationId,
      Clip clipBehavior = Clip.hardEdge}) {
    return ListView(
      key: key,
      scrollDirection: scrollDirection,
      reverse: reverse,
      controller: controller,
      primary: primary,
      physics: physics,
      shrinkWrap: shrinkWrap,
      padding: padding,
      itemExtent: itemExtent,
      prototypeItem: prototypeItem,
      addAutomaticKeepAlives: addAutomaticKeepAlives,
      addRepaintBoundaries: addRepaintBoundaries,
      addSemanticIndexes: addSemanticIndexes,
      cacheExtent: cacheExtent,
      semanticChildCount: semanticChildCount,
      dragStartBehavior: dragStartBehavior,
      keyboardDismissBehavior: keyboardDismissBehavior,
      restorationId: restorationId,
      clipBehavior: clipBehavior,
      children: this,
    );
  }
}

///
///
extension BoxDecorationExt on BoxDecoration {
  static BoxDecoration image(String assetPath,
      {AlignmentGeometry alignment = Alignment.center}) {
    return BoxDecoration(
        image: DecorationImage(
            image: AssetImage(assetPath), alignment: alignment));
  }
}

/// Widget Convenient
/// Create Objects Quickly
///
extension WidgetConvenient on Widget {
  Widget onPackageContainer({
    double radius = 0,
    EdgeInsets margin,
    EdgeInsets padding,
    double width,
    double height,
    AlignmentGeometry alignment,
    List<Color> colors,
    AlignmentGeometry begin = Alignment.centerLeft,
    AlignmentGeometry end = Alignment.centerRight,
    String assetPath,
    AlignmentGeometry imageAlignment = Alignment.center,
    Color boxBgColor,
    Color shadowColor,
    double shadowRadius,
    Offset shadowOffset = Offset.zero,
  }) {
    /// print('$radius -- $assetPath --- $colors ---- $shadowColor');
    return Container(
      margin: margin,
      padding: padding,
      width: width,
      height: height,
      alignment: alignment,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          image: null == assetPath
              ? null
              : DecorationImage(
                  image: AssetImage(assetPath), alignment: imageAlignment),
          color: boxBgColor,
          gradient: null == colors
              ? null
              : LinearGradient(begin: begin, end: end, colors: colors),
          boxShadow: null == shadowColor
              ? null
              : [
                  BoxShadow(
                      blurRadius: shadowRadius,
                      color: shadowColor,
                      offset: shadowOffset)
                ]),
      child: this,
    );
  }
}
