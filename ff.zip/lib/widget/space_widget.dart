import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SpaceWidget {

  static Widget h_space_3 = getSpace(hSpace: 3);

  static Widget h_space_5 = getSpace(hSpace: 5);

  static Widget h_space_6 = getSpace(hSpace: 6);

  static Widget h_space_10 = getSpace(hSpace: 10);

  static Widget h_space_12 = getSpace(hSpace: 12);

  static Widget h_space_15 = getSpace(hSpace: 15);

  static Widget h_space_20 = getSpace(hSpace: 20);

  static Widget v_space_10 = getSpace(vSpace: 10);

  static Widget v_space_15 = getSpace(vSpace: 15);

  static Widget v_space_20 = getSpace(vSpace: 20);

  static Widget v_space_30 = getSpace(vSpace: 30);

  static SizedBox getSpace({int hSpace = 0, int vSpace = 0}) {
    return SizedBox(
      width: ScreenUtil().setWidth(hSpace),
      height: ScreenUtil().setWidth(vSpace),
    );
  }
}
