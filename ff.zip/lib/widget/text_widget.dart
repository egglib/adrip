import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TextWidget {
  static buildText(String text, TextStyle style,
      {double leftPadding = 0,
      double topPadding = 0,
      double rightPadding = 0,
      double bottomPadding = 0,
      double leftMargin = 0,
      double topMargin = 0,
      double rightMargin = 0,
      double bottomMargin = 0,
      int maxLines = 1,
      TextOverflow overflow = TextOverflow.ellipsis,
      VoidCallback callback}) {
    return GestureDetector(
      onTap: () {
        callback?.call();
      },
      child: Container(
        padding: EdgeInsets.fromLTRB(
            leftPadding, topPadding, rightPadding, bottomPadding),
        margin: EdgeInsets.fromLTRB(
            leftMargin, topMargin, rightMargin, bottomMargin),
        child: Text(
          text,
          maxLines: maxLines,
          overflow: overflow,
          style: style,
        ),
      ),
    );
  }

  static buildSimpleText(String text, TextStyle style,
      {double leftPadding = 0,
      double topPadding = 0,
      double rightPadding = 0,
      double bottomPadding = 0,
      double leftMargin = 0,
      double topMargin = 0,
      double rightMargin = 0,
      double bottomMargin = 0,
      int maxLines = 1,
      TextOverflow overflow = TextOverflow.ellipsis}) {
    return Container(
      padding: EdgeInsets.fromLTRB(
          leftPadding, topPadding, rightPadding, bottomPadding),
      margin:
          EdgeInsets.fromLTRB(leftMargin, topMargin, rightMargin, bottomMargin),
      child: Text(
        text,
        maxLines: maxLines,
        overflow: overflow,
        style: style,
      ),
    );
  }
}
