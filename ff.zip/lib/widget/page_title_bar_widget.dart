import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/img_widget.dart';

// ignore: must_be_immutable
class PageTitleBarWidget extends StatefulWidget {
  String title;
  String backIcon;
  Widget rightWidget;
  double height;
  Color bgColor;
  TextStyle textStyle;
  bool isShowLine;

  PageTitleBarWidget(
      {Key key,
      this.title,
      this.backIcon,
      this.textStyle,
      this.bgColor = Colors.transparent,
      this.height = 0.0,
      this.isShowLine = true,
      this.rightWidget})
      : super(key: key);

  @override
  _PageTitleBarWidgetState createState() => _PageTitleBarWidgetState();
}

class _PageTitleBarWidgetState extends State<PageTitleBarWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          color: widget.bgColor,
          alignment: Alignment.center,
          width: ScreenUtil().screenWidth,
          height: widget.height > 0.0 ? widget.height : AppStyle.titleBarHeight,
          child: Text(
            widget.title ?? '页面',
            style: widget.textStyle ?? AppTextStyle.c333333_s18,
          ),
        ),
        Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            top: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: ScreenUtil().setWidth(10),
                      vertical: ScreenUtil().setWidth(5)),
                  child: ImgWidget.buildLocalImg(
                      widget.backIcon ?? ImgRes.IC_BACK_BLACK,
                      width: 20,
                      height: 20, callback: () {
                    context.pop();
                  }),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: ScreenUtil().setWidth(10)),
                  child: widget.rightWidget ?? Container(),
                )
              ],
            )),
        widget.isShowLine
            ? Positioned(
                child: Container(
                  width: ScreenUtil().screenWidth,
                  height: 0.3,
                  color: ColorRes.color_ebebeb,
                ),
                bottom: 0,
              )
            : const SizedBox(
                width: 0,
                height: 0,
              )
      ],
    );
  }
}
