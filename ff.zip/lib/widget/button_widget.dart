import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/style/base_text_style.dart';
import 'package:gtea/widget/text_widget.dart';

class ButtonWidget {
  static buildButton(
      String text,
      Color textColor,
      double fontSize,
      double btnWidth,
      double btnHeight,
      double radius,
      AlignmentGeometry begin,
      AlignmentGeometry end,
      List<Color> colors,
      VoidCallback callback) {
    return GestureDetector(
      onTap: () {
        if(callback!=null) {
          callback?.call();
        }
      },
      child: Container(
        width: ScreenUtil().setWidth(btnWidth),
        height: ScreenUtil().setWidth(btnHeight),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(radius)),
          gradient: LinearGradient(begin: begin, end: end, colors: colors),
        ),
        child: Center(
          child: TextWidget.buildText(
              text, BaseTextStyle.buildTextStyle(textColor, fontSize)),
        ),
      ),
    );
  }
}
