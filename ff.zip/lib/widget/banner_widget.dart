import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/widget/img_widget.dart';

class BannerWidget {
  static SizedBox buildBigBanner(BuildContext context, int count,
      {double boxWidth = 0,
      double boxHeight = 150,
      int radius = 5,
      Axis scrollDirection = Axis.horizontal,
      VoidCallback callback}) {
    return SizedBox(
      height: ScreenUtil().setWidth(boxHeight),
      width: ScreenUtil().setWidth(boxWidth),
      child: ClipRRect(
          borderRadius:
              BorderRadius.all(Radius.circular(ScreenUtil().setWidth(radius))),
          child: Swiper(
            itemCount: count,
            autoplay: true,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  if (callback != null) {
                    callback?.call();
                  }
                },
                // child: Image.asset(ImgRes.BANNER_TEST, fit: BoxFit.cover),
                child: ImgWidget.buildImg(ImgRes.BANNER_TEST,
                    fit: BoxFit.cover, isNet: false),
              );
            },
            controller: SwiperController(),
            scrollDirection: scrollDirection,
            pagination: SwiperPagination(),
          )),
    );
  }
}
