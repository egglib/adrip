import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ListWidget {
  static buildVerticalListView(int itemCount, IndexedWidgetBuilder itemBuilder,
      {EdgeInsets pagePadding,
      bool shrinkWrap = true,
      ScrollPhysics physics = const BouncingScrollPhysics()}) {
    return ListView.builder(
      padding: pagePadding,
      itemCount: itemCount,
      shrinkWrap: shrinkWrap,
      scrollDirection: Axis.vertical,
      physics: physics,
      itemBuilder: itemBuilder,
    );
  }

  static buildHorizontalListView(
      int itemCount, IndexedWidgetBuilder itemBuilder,
      {EdgeInsets pagePadding,
      bool shrinkWrap = true,
      ScrollPhysics physics = const BouncingScrollPhysics()}) {
    return ListView.builder(
      padding: pagePadding,
      itemCount: itemCount,
      shrinkWrap: shrinkWrap,
      scrollDirection: Axis.horizontal,
      physics: physics,
      itemBuilder: itemBuilder,
    );
  }

  static buildGridView(int itemCount, IndexedWidgetBuilder itemBuilder,
      {double childRatio = 1,
      int crossCount = 2,
      double mainSpace = 0,
      double crossSpace = 0,
      EdgeInsets pagePadding,
      ScrollController controller,
      bool shrinkWrap = true,
      ScrollPhysics physics = const BouncingScrollPhysics()}) {
    return GridView.builder(
        padding: pagePadding,
        itemCount: itemCount,
        shrinkWrap: shrinkWrap,
        physics: physics,
        controller: controller,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisSpacing: ScreenUtil().setWidth(mainSpace),
            crossAxisSpacing: ScreenUtil().setWidth(crossSpace),
            childAspectRatio: childRatio,
            crossAxisCount: crossCount),
        itemBuilder: itemBuilder);
  }
}
