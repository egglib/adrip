import 'package:flutter/material.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/widget/img_widget.dart';

class AppWidget {

  static Widget blueVerticalLine = Container(
    width: 5,
    height: 20,
    alignment: Alignment.center,
    decoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(3)),
        gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [ColorRes.color_7f85f4, ColorRes.color_6c5aef])),
  );

  static Widget grayArrowRight = ImgWidget.buildImg(ImgRes.IC_ARROW_RIGHT_GRAY,
      width: 4, height: 8, isNet: false);

  static Widget iconLocation = ImgWidget.buildImg(ImgRes.IC_LOCATION,
      width: 13, height: 13, fit: BoxFit.contain, isNet: false);

  static Widget iconFilter = ImgWidget.buildImg(ImgRes.IC_FILTER,
      width: 13, height: 13, fit: BoxFit.contain, isNet: false);
}
