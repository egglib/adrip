import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/dimen_res.dart';

class HintWidget {

  static CancelFunc showToast(String content,
      {double radius = 20,
      Color contentColor = ColorRes.color_6c5aef,
      double fontSize = 15,
      Color textColor = Colors.white,
      int seconds = 3}) {
    return BotToast.showText(
        text: content,
        borderRadius: BorderRadius.all(Radius.circular(radius)),
        contentColor: contentColor,
        textStyle: TextStyle(
            overflow: TextOverflow.ellipsis,
            fontSize: ScreenUtil().setWidth(fontSize),
            color: textColor),
        duration: Duration(seconds: seconds));
  }

  static void showSimpleDialog(
      {String content,
      String cancelStr = '',
      String confirmStr = '',
      VoidCallback cancel,
      VoidCallback confirm}) {
    var contentSplit = content.split('#');

    contentWidget(String value) {
      return Text(
        value,
        style: TextStyle(
          color: ColorRes.color_333333,
          fontSize: ScreenUtil().setSp(DimenRes.dimen_16),
          decoration: TextDecoration.none,
          fontWeight: FontWeight.normal,
        ),
      );
    }

    tipsWidget() {
      return contentSplit.map((value) {
        Widget widget = contentWidget(value);
        return widget;
      }).toList();
    }

    List<Widget> newTipsWidget = tipsWidget();
    newTipsWidget.add(Container(width: double.infinity));

    BotToast.showWidget(
        toastBuilder: (cancelFunc) => Container(
                child: Stack(children: [
              _dialogBackSection(cancelFunc, cancel),
              _dialogContentSection(newTipsWidget, cancelStr, confirmStr,
                  cancelFunc, cancel, confirm)
            ])));
  }

  static Positioned _dialogContentSection(
      List<Widget> newTipsWidget,
      String cancelStr,
      String confirmStr,
      CancelFunc cancelFunc,
      VoidCallback cancel,
      VoidCallback confirm) {
    return Positioned(
      child: Center(
          child: SizedBox(
              width: ScreenUtil().setWidth(300),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: double.infinity,
                    decoration: _contentBoxDecoration(),
                    child: Column(
                      children: [
                        _contentTextSection(
                            newTipsWidget, cancelStr, confirmStr),
                        _bottomButtonSection(
                            cancelStr, confirmStr, cancelFunc, cancel, confirm),
                      ],
                    ),
                  )
                ],
              ))),
    );
  }

  static BoxDecoration _contentBoxDecoration() {
    return const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(10)));
  }

  static Container _bottomButtonSection(String cancelStr, String confirmStr,
      CancelFunc cancelFunc, VoidCallback cancel, VoidCallback confirm) {
    return Container(
      margin: cancelStr.isEmpty && confirmStr.isEmpty
          ? const EdgeInsets.all(0)
          : const EdgeInsets.fromLTRB(15, 10, 15, 30),
      child: Wrap(
        alignment: WrapAlignment.center,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          _bottomCancelButtonSection(cancelStr, cancelFunc, cancel),
          _bottomButtonGapSection(cancelStr, confirmStr),
          _bottomConfirmButtonSection(confirmStr, cancelFunc, confirm),
        ],
      ),
    );
  }

  static SizedBox _bottomButtonGapSection(String cancelStr, String confirmStr) {
    return cancelStr.isEmpty || confirmStr.isEmpty
        ? const SizedBox()
        : const SizedBox(width: 20);
  }

  static Widget _bottomConfirmButtonSection(
      String confirmStr, CancelFunc cancelFunc, VoidCallback confirm) {
    return confirmStr.isEmpty
        ? SizedBox()
        : GestureDetector(
            onTap: () {
              cancelFunc();
              confirm?.call();
            },
            child: _buildBottomButton(confirmStr, Colors.white,
                ColorRes.color_7f85f4, ColorRes.color_6c5aef));
  }

  static Widget _bottomCancelButtonSection(
      String cancelStr, CancelFunc cancelFunc, VoidCallback cancel) {
    return cancelStr.isEmpty
        ? SizedBox()
        : GestureDetector(
            onTap: () {
              cancelFunc();
              cancel?.call();
            },
            child: _buildBottomButton(cancelStr, ColorRes.color_666666,
                ColorRes.color_f2f2f2, ColorRes.color_f2f2f2));
  }

  static Container _contentTextSection(
      List<Widget> newTipsWidget, String cancelStr, String confirmStr) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: ScreenUtil().setWidth(300),
      ),
      child: _buildContentText(newTipsWidget),
      margin: cancelStr.isEmpty && confirmStr.isEmpty
          ? const EdgeInsets.fromLTRB(20, 30, 20, 30)
          : const EdgeInsets.fromLTRB(20, 30, 20, 20),
    );
  }

  static Widget _buildContentText(List<Widget> newTipsWidget) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: newTipsWidget,
      ),
    );
  }

  static Container _buildBottomButton(
      String textStr, Color textColor, Color startColor, Color endColor) {
    return Container(
      height: ScreenUtil().setWidth(40),
      width: ScreenUtil().setWidth(120),
      padding: const EdgeInsets.fromLTRB(12, 5, 12, 5),
      decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(20)),
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [startColor, endColor])),
      child: _buildButtonText(textColor, textStr),
    );
  }

  static Center _buildButtonText(Color textColor, String textStr) {
    return Center(
      widthFactor: 1,
      child: Text(
        textStr,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: textColor,
          fontSize: ScreenUtil().setSp(DimenRes.dimen_15),
          decoration: TextDecoration.none,
          fontWeight: FontWeight.normal,
        ),
      ),
    );
  }

  static GestureDetector _dialogBackSection(
      CancelFunc cancelFunc, VoidCallback cancel) {
    return GestureDetector(
      onTap: () {
        cancelFunc();
        // cancel.call();
      },
      child: Container(
        decoration: const BoxDecoration(color: Colors.black38),
      ),
    );
  }
}
