import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart'
    hide RefreshIndicator, RefreshIndicatorState;
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/hint_widget.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class GifHeader extends RefreshIndicator {
  GifHeader({Key key})
      : super(
            key: key,
            height: ScreenUtil().setWidth(80),
            refreshStyle: RefreshStyle.Follow);

  @override
  State<StatefulWidget> createState() {
    return GifHeaderState();
  }
}

class GifHeaderState extends RefreshIndicatorState<GifHeader> {
  @override
  void onModeChange(RefreshStatus mode) {
    if (mode == RefreshStatus.refreshing) {}
    super.onModeChange(mode);
  }

  @override
  Future<void> endRefresh() {
    return Future.delayed(Duration(microseconds: 500), () {});
  }

  @override
  Widget buildContent(BuildContext context, RefreshStatus mode) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: ScreenUtil().setWidth(15)),
      child: Image.asset(
        mode == RefreshStatus.refreshing
            ? ImgRes.DOWN_REFRESH_GIF
            : ImgRes.DOWN_REFRESH_GIF,
        height: ScreenUtil().setWidth(50),
        fit: BoxFit.fitHeight,
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}

typedef GetRespData = Future<dynamic> Function(int index);
typedef ParseList = List Function(dynamic result);
typedef ListItem = Widget Function(List dataList);

class RefreshLoadListWidget extends StatefulWidget {
  RefreshLoadListWidget(
      {Key key,
      this.getData,
      this.parseList,
      this.child,
      this.enableRefresh = true,
      this.enableLoad = true})
      : super(key: key);

  ListItem child;
  bool enableRefresh;
  bool enableLoad;
  GetRespData getData;
  ParseList parseList;

  @override
  _RefreshLoadListWidgetState createState() => _RefreshLoadListWidgetState();
}

class _RefreshLoadListWidgetState extends State<RefreshLoadListWidget> {
  RefreshController _refreshController;
  Timer _timerOut;
  Timer _timer;
  bool startRefresh = false;
  bool startLoad = false;

  List dataList = [];
  int pageIndex = 1;

  @override
  void initState() {
    super.initState();
    _refreshController = RefreshController(initialRefresh: false);
  }

  @override
  void dispose() {
    super.dispose();
    _refreshController.dispose();
    if (_timer != null) {
      _timer.cancel();
    }
    if (_timerOut != null) {
      _timerOut.cancel();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: SmartRefresher(
        enablePullDown: widget?.enableRefresh,
        enablePullUp: widget?.enableLoad,
        header: GifHeader(),
        footer: CustomFooter(
          builder: (BuildContext context, LoadStatus mode) {
            Widget body;
            if (mode == LoadStatus.idle) {
              body = Text(StringRes.str_pull_up_load,
                  style: AppTextStyle.c999999_s12);
            } else if (mode == LoadStatus.loading) {
              body = const CupertinoActivityIndicator(
                radius: 8,
              );
            } else if (mode == LoadStatus.failed) {
              body = Text(StringRes.str_load_failed_retry,
                  style: AppTextStyle.c999999_s12);
            } else if (mode == LoadStatus.canLoading) {
              body = Text(StringRes.str_release_load_more,
                  style: AppTextStyle.c999999_s12);
            } else {
              body = Text(StringRes.str_no_more_data,
                  style: AppTextStyle.c999999_s12);
            }
            return SizedBox(
              height: 55.0,
              child: Center(child: body),
            );
          },
        ),
        controller: _refreshController,
        onRefresh: _onRefresh,
        onLoading: _onLoading,
        child: widget.child(dataList),
      ),
    );
  }

  void _onRefresh() async {
    if (widget.enableRefresh && !startRefresh) {
      startRefresh = true;
      _timerOut = Timer.periodic(const Duration(seconds: 10), (timer) {
        timer.cancel();
        if (_timer != null && _timer.isActive) {
          _timer.cancel();
        }
        HintWidget.showToast(StringRes.str_request_time_out);
        _refreshController.refreshCompleted();
      });
      _timer = Timer.periodic(const Duration(milliseconds: 1500), (timer) {
        if (!startRefresh) {
          if (_timerOut != null && _timerOut.isActive) {
            _timerOut.cancel();
          }
          timer.cancel();
          _refreshController.refreshCompleted();
        }
      });
      await loadData(loadMore: false);
      startRefresh = false;
    }
  }

  void _onLoading() async {
    if (widget.enableLoad && !startLoad) {
      startLoad = true;
      await loadData(loadMore: true);
      _refreshController.loadComplete();
      startLoad = false;
    }
  }

  loadData({bool loadMore}) async {
    if (!loadMore) {
      pageIndex = 1;
    }

    try {
      var result = await widget?.getData(pageIndex);
      if (mounted) {
        setState(() {
          List objList = widget?.parseList(result);
          if (loadMore) {
            if (objList.isEmpty) {
              _refreshController.loadNoData();
            } else {
              _refreshController.loadComplete();
            }
            //合成新数组
            dataList = [...dataList, ...objList];
          } else {
            dataList = objList;
            _refreshController.refreshCompleted(resetFooterState: true);
          }
          if (objList.isNotEmpty) {
            pageIndex++;
          }
        });
      }
    } catch (e) {
      setState(() {
        Future.delayed(Duration(seconds: 1), () {
          if (loadMore) {
            _refreshController.loadFailed();
          } else {
            _refreshController.refreshFailed();
          }
        });
      });
    }
  }
}
