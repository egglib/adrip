import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:lottie/lottie.dart';

class StatusWidget {

  static Widget loading({String tips = ''}) {
    return Container(
      alignment: Alignment.center,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _loadAnimSection(),
          _loadHintSection(tips, AppTextStyle.c999999_s12,
              defaultStr: StringRes.str_loading_hint)
        ],
      ),
    );
  }

  static Function showLoadingDialog({String tips = ''}) {
    return BotToast.showLoading(
        backgroundColor: Colors.black45,
        wrapToastAnimation: (AnimationController animation, fc, Widget child) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _loadAnimSection(),
              _loadHintSection(tips, AppTextStyle.white_s12)
            ],
          );
        });
  }

  static Text _loadHintSection(String tips, TextStyle textStyle,
      {String defaultStr = ''}) {
    return Text(
      tips.isNotEmpty ? tips : defaultStr,
      style: textStyle,
    );
  }

  static Container _loadAnimSection() {
    return Container(
      child: Lottie.asset('${ImgRes.LOTTIE_PATH}loading.json',
          height: ScreenUtil().setWidth(60), fit: BoxFit.fitWidth),
    );
  }

  static void closeLoading() {
    return BotToast.closeAllLoading();
  }
}
