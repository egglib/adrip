import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ImgWidget {

  static Widget buildLocalImg(String path,
      {double width = 1,
        double height = 1,
        double radius = 0,
        BoxFit fit = BoxFit.contain,
        bool isNet = false,
        VoidCallback callback}) {
    return buildImg(path, width: width,
        height: height,
        radius: radius,
        fit: fit,
        isNet: isNet,
        callback: callback);
  }

  static Widget buildImg(String path,
      {double width = 1,
        double height = 1,
        double radius = 0,
        BoxFit fit = BoxFit.contain,
        bool isNet = true,
        VoidCallback callback}) {
    return GestureDetector(
      onTap: () {
        callback?.call();
      },
      child: isNet
          ? buildSimpleNetImage(path,
          width: width, height: height, radius: radius, fit: fit)
          : buildSimpleLocalImage(path,
          width: width, height: height, radius: radius, fit: fit),
    );
  }

  static buildSimpleNetImage(String path,
      {double width,
        double height,
        double radius = 0,
        BoxFit fit = BoxFit.contain}) {
    return ClipRRect(
        borderRadius: BorderRadius.all(Radius.circular(radius)),
        child: Image.network(
          path,
          width: ScreenUtil().setWidth(width),
          height: ScreenUtil().setWidth(height),
          fit: fit,
        ));
  }

  static buildSimpleLocalImage(String path,
      {double width,
        double height,
        double radius = 0,
        BoxFit fit = BoxFit.contain}) {
    return ClipRRect(
        borderRadius: BorderRadius.all(Radius.circular(radius)),
        child: Image.asset(
          path,
          width: ScreenUtil().setWidth(width),
          height: ScreenUtil().setWidth(height),
          fit: fit,
        ));
  }

  static Widget buildCircleAvatar(String path,
      {double width = 30,
        double height = 30,
        BoxFit fit = BoxFit.cover,
        bool isNet = false,
        VoidCallback callback}) {
    return GestureDetector(
        onTap: () {
          callback?.call();
        },
        child: isNet
            ? ClipOval(
            child: buildSimpleNetImage(path,
                width: width, height: height, fit: fit))
            : ClipOval(
            child: buildSimpleLocalImage(path,
                width: width, height: height, fit: fit)));
  }
}
