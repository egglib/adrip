class SwitchWidget {
}