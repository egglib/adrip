import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/text_widget.dart';

enum LoadState {
  STATE_SUCCESS,
  STATE_ERROR,
  STATE_NO_NETWORK,
  STATE_LOADING,
  STATE_EMPTY
}

class LoadSateWidget extends StatefulWidget {
  final LoadState state;
  final Widget successWidget;
  final VoidCallback errorRetry;
  final VoidCallback emptyRetry;
  final VoidCallback noNetWorkRetry;

  const LoadSateWidget(
      {Key key,
      this.state,
      this.successWidget,
      this.errorRetry,
      this.emptyRetry,
      this.noNetWorkRetry})
      : super(key: key);

  @override
  _LoadSateWidgetState createState() => _LoadSateWidgetState();
}

class _LoadSateWidgetState extends State<LoadSateWidget> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: double.infinity,
      child: _buildWidget(),
    );
  }

  Widget _buildWidget() {
    switch (widget.state) {
      case LoadState.STATE_SUCCESS:
        widget.successWidget;
        break;
      case LoadState.STATE_ERROR:
        return _errorView();
        break;

      case LoadState.STATE_LOADING:
        return _loadingView();
        break;

      case LoadState.STATE_EMPTY:
        return _noDataView();
        break;

      case LoadState.STATE_NO_NETWORK:
        return _noNetWorkView();
        break;

      default:
        return null;
    }
  }

  Widget _errorView() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Colors.white,
      child: InkWell(
        onTap: widget.errorRetry,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(15),
              child: Image.asset(ImgRes.IC_NO_NETWORK),
            ),
            TextWidget.buildSimpleText('加载失败，请轻触重试', AppTextStyle.c999999_s14)
          ],
        ),
      ),
    );
  }

  Widget _loadingView() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Colors.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Padding(
            padding: EdgeInsets.all(15),
            child: CupertinoActivityIndicator(radius: 12),
          ),
          TextWidget.buildSimpleText('加载中...', AppTextStyle.c999999_s14)
        ],
      ),
    );
  }

  Widget _noDataView() {
    return Container(
      color: Colors.white,
      width: double.infinity,
      height: double.infinity,
      child: InkWell(
        onTap: widget.emptyRetry,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(15),
              child: Image.asset(ImgRes.IC_NO_DATA),
            ),
            TextWidget.buildSimpleText('暂无数据，点击重试', AppTextStyle.c999999_s14)
          ],
        ),
      ),
    );
  }

  Widget _noNetWorkView() {
    return Container(
      color: Colors.white,
      width: double.infinity,
      height: double.infinity,
      child: InkWell(
        onTap: widget.noNetWorkRetry,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(15),
              child: Image.asset(ImgRes.IC_NO_NETWORK),
            ),
            TextWidget.buildSimpleText('网络异常，请稍后点击重试', AppTextStyle.c999999_s14)
          ],
        ),
      ),
    );
  }
}
