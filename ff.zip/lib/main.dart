import 'dart:io';

import 'package:bot_toast/bot_toast.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/routers.dart';
import 'package:gtea/utils/bar_util.dart';
import 'package:gtea/utils/common_util.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:package_info_plus/package_info_plus.dart';

import 'global.dart';

void main() async {
  await Hive.initFlutter();
  AppGlobal.appBox = await Hive.openBox('HiveBox');
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  // 初始化APP基础信息
  AppGlobal.appInfo = {
    "oauth_id": AppGlobal.appBox.get('oauth_id') ??
        '${CommonUtil.randomId(16)}_${DateTime.now().millisecondsSinceEpoch.toString()}',
    "bundle_id": "com.pwa.gtea",
    "version": "1.0.0",
    "oauth_type": "web",
  };
  if (!kIsWeb) {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      AppGlobal.appInfo = {
        "oauth_id": androidInfo.androidId,
        "bundle_id": packageInfo.packageName,
        "version": packageInfo.version,
        "oauth_type": "android",
      };
    } else {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      AppGlobal.appInfo = {
        "oauth_id": iosInfo.identifierForVendor,
        "bundle_id": packageInfo.packageName,
        "version": "1.0.0",
        "oauth_type": "ios",
      };
    }
  }
  AppGlobal.setup();
  BarUtil.setBarUi(color: Colors.transparent);
  runApp(const MyApp());

}

final _router = Routers.init();

class MyApp extends StatelessWidget {
  const MyApp({Key key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    final botToastBuilder = BotToastInit();
    return ScreenUtilInit(
      designSize: const Size(375, 667),
      builder: () => MaterialApp.router(
        debugShowCheckedModeBanner: false,
        routeInformationParser: _router.routeInformationParser,
        routerDelegate: _router.routerDelegate,
        title: StringRes.str_app_name,
        theme: ThemeData(
            primarySwatch: Colors.blue,
            backgroundColor: Colors.white,
            scaffoldBackgroundColor: Colors.white),
        builder: (context, widget) {
          widget = botToastBuilder(context, widget);
          widget = MediaQuery(
            //设置文字大小不随系统设置改变
            data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
            child: widget,
          );
          return widget;
        },
      ),
    );
  }
}
