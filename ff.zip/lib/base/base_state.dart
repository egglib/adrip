import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gtea/base/base_presenter.dart';
import 'package:gtea/base/base_view.dart';
import 'package:gtea/utils/bar_util.dart';
import 'package:gtea/widget/hint_widget.dart';
import 'package:gtea/widget/status_widget.dart';

abstract class BaseState<P extends BasePresenter, W extends StatefulWidget>
    extends State<W> with AutomaticKeepAliveClientMixin implements BaseView {
  P mPresenter;

  //是否初始化
  bool _isPrepared = false;

  //请求dialog
  Function dialog;

  @override
  void initState() {
    mPresenter = createPresenter();
    _attachView();
    super.initState();
  }

  P createPresenter();

  void _attachView() {
    if (mPresenter != null) {
      mPresenter.attachView(this);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (!_isPrepared) {
      Timer.run(() => preparePage());
      _isPrepared = true;
    }
    // setBarUi();
    return AnnotatedRegion(
        child: Scaffold(
          body: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [buildAppBar(), buildPageLayout()],
            ),
          ),
        ),
        value: SystemUiOverlayStyle.dark);
  }

  /// 初始化一次 用于 presenter 请求网络数据后调用 showDialog 拿不到合适的 context 报错
  void preparePage() {}

  void setBarUi() {
    BarUtil.setBarUi();
  }

  Widget buildAppBar();

  Widget buildPageLayout();

  @mustCallSuper
  @override
  void dispose() {
    super.dispose();
    _detachView();
  }

  @override
  void closeLoading() {
    /// 必须和 showLoading 方法配对使用 ，避免 pop 当前页面
    if (dialog != null) {
      Navigator.pop(context);
      StatusWidget.closeLoading();
      dialog = null;
    }
  }

  @override
  void reload() {}

  @override
  void showError({String errorMsg}) {
    if (errorMsg != null) {
      HintWidget.showToast(errorMsg);
    }
  }

  @override
  void showLoading({String msg}) {
    dialog = StatusWidget.showLoadingDialog(tips: msg ?? '加载中');
  }

  @override
  void tokenError() {}

  //不会被销毁,占内存中
  @override
  bool get wantKeepAlive => true;

  void _detachView() {
    if (null != mPresenter) {
      mPresenter.detachView();
    }
  }
}
