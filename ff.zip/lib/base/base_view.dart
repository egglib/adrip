abstract class BaseView {

  bool isShowTitle() ;

  void showLoading({String msg});

  void closeLoading();

  void reload();

  void showError({String errorMsg});

  //token失效，去登录页面
  void tokenError();
}
