import 'package:dio/dio.dart';
import 'package:gtea/net/http_exception.dart';
import 'package:gtea/net/result_code.dart';
import 'package:gtea/utils/log_util.dart';

import 'dio_factory.dart';

class HttpRequest {
  static const String GET = 'GET';
  static const String POST = 'POST';
  static const String PUT = 'PUT';
  static const String PATCH = 'PATCH';
  static const String DELETE = 'DELETE';

  Future request(String action, String url,
      {Map<String, dynamic> params, bool isJson}) async {
    var formData;
    if (!isJson) {
      formData = params != null ? FormData.fromMap(params) : null;
    } else {
      formData = params;
    }
    Response response;
    try {
      switch (action) {
        case GET:
          response =
              await DioFactory.instance.dio.get(url, queryParameters: params);
          break;
        case POST:
          response = await DioFactory.instance.dio.post(url, data: formData);
          break;
      }
    } on DioError catch (error) {
      LogUtil.i('请求出错--->' + error.toString());

      Response errorResponse;
      if (error.response != null) {
        errorResponse = error.response;
      } else {
        errorResponse = Response(statusCode: ResultCode.NO_NETWORK);
      }

      // 请求超时
      if (error.type == DioErrorType.connectTimeout) {
        errorResponse.statusCode = ResultCode.CONNECT_TIMEOUT;
      } else if (error.type == DioErrorType.receiveTimeout) {
        errorResponse.statusCode = ResultCode.RECEIVE_TIMEOUT;
      }
      throw CommonException(errorMsg: "网络异常");
    }
    return response.data;
  }

  Stream postRequest(String url, {Map<String, dynamic> params}) {
    return Stream.fromFuture(request(POST, url, params: params, isJson: true));
  }

  Stream getRequest(String url, {Map<String, dynamic> params}) {
    return Stream.fromFuture(request(GET, url, params: params, isJson: true));
  }
}
