import 'dart:convert';
import 'dart:ffi';

import 'package:dio/dio.dart';
import 'package:gtea/net/base_response.dart';
import 'package:gtea/utils/log_util.dart';

import '../base/base_view.dart';
import 'package:rxdart/rxdart.dart';

void OnSuccess(dynamic data) {}

void OnFailure(String error) {}

class RxObserver {
  //页面引用对象（显示进度框、提示语）
  BaseView view;

  //提示语
  String msg;

  //是否显示进度框
  bool isShowDialog;

  //成功回调
  Function onSuccess;

  //失败回调
  Function onFailure;

  RxObserver(
      {this.view, this.msg, this.isShowDialog, this.onSuccess, this.onFailure});

  ///http网络请求 [request] 接收 Stream 类型
  void requestObserver(Stream request) {
    request.doOnListen(() {
      //开始网络请求，根据提示语显示弹框
      if (view != null && isShowDialog) {
        view.showLoading(msg: msg);
      }
    }).listen((data) {
      //请求成功，返回结果，关闭弹框
      if (view != null && isShowDialog) {
        view.closeLoading();
      }
      //请求成功 获取数据data， data是返回结果json
      BaseResponse response = BaseResponse.fromJson(data);

      String enDataJson = jsonEncode(response.data);
      LogUtil.i("[ response status ] = [ ${response.status} ]");
      LogUtil.i("[ response msg ] = [ ${response.msg} ]");
      LogUtil.i("[ response data ] = [ ${enDataJson} ]");
      LogUtil.i("[ response isVip ] = [ ${response.isVip} ]");
      LogUtil.i("[ response daily_view ] = [ ${response.daily_view} ]");

      if (response.status == 200) {
        if (response.data != null) {
          onSuccess(response.data);
        } else {
          onSuccess(response.msg);
        }
      } else {
        handlerError(response.msg);
      }
    }, onError: (error) {
      if (view != null && isShowDialog) {
        view.closeLoading();
      }

      //请求失败
      DioError e = error;
      handlerError(e.message);
    }, onDone: () {});
  }

  void handlerError(String error) {
    if (view != null && isShowDialog) {
      view.showError(errorMsg: error);
    }
    //请求失败
    onFailure(error);
  }
}
