class BaseResponse {
  dynamic data;
  int status;
  String msg;
  int isVip;
  int daily_view;

  BaseResponse({this.data, this.status, this.msg, this.isVip, this.daily_view});

  BaseResponse.fromJson(Map<String, dynamic> json) {
    data = json['data'];
    status = json['status'];
    msg = json['msg'];
    isVip = json['isVip'];
    daily_view = json['daily_view'];
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> data = new Map<String, dynamic>();
    data['data'] = this.data;
    data['status'] = this.status;
    data['msg'] = this.msg;
    data['isVip'] = this.isVip;
    data['daily_view'] = this.daily_view;
    return data;
  }
}
