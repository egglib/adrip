import 'dart:io';

import 'package:dio/adapter.dart';
import 'package:dio/dio.dart';
import 'package:gtea/global.dart';
import 'package:gtea/net/http_log_interceptor.dart';

class DioFactory {

  /// global dio object
  Dio dio;

  /// default options
  static const int CONNECT_TIMEOUT = 15 * 1000;
  static const int RECEIVE_TIMEOUT = 15 * 1000;

  factory DioFactory() => _getInstance();

  static DioFactory get instance => _getInstance();

  static DioFactory _instance;

  BaseOptions options;

  ///是否开启代理
  bool isProxy = false;

  static DioFactory _getInstance() {
    _instance ??= DioFactory._internal();
    return _instance;
  }

  DioFactory._internal() {
    dio = Dio()
      ..options = BaseOptions(
          baseUrl: AppGlobal.apiBaseURL,
          connectTimeout: CONNECT_TIMEOUT,
          receiveTimeout: RECEIVE_TIMEOUT,
          contentType: Headers.formUrlEncodedContentType)
      ..interceptors.add(HttpLogInterceptor());
    if (isProxy) {
      (dio.httpClientAdapter as DefaultHttpClientAdapter).onHttpClientCreate =
          (client) {
        client.findProxy = (url) {
          return "PROXY 192.168.0.122:8888";
        };
        client.badCertificateCallback =
            (X509Certificate cert, String host, int port) => true;
      };
    }
  }
}
