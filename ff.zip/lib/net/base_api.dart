import 'package:get_it/get_it.dart';
import 'package:gtea/net/http_request.dart';
import 'package:gtea/net/rx_observer.dart';

class BaseApi {

  //接口请求操作类-全局单例
  HttpRequest dioRequest = GetIt.instance<HttpRequest>();

  //请求列表接口，每页数量
  int pageCount = 10;

  Map<String, dynamic> params = Map();

  void sendRequest(Stream stream, RxObserver observer) {
    observer.requestObserver(stream);
  }
}
