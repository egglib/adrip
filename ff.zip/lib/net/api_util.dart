import 'package:gtea/net/base_api.dart';
import 'package:gtea/net/rx_observer.dart';

class ApiUtil extends BaseApi {

   void getConfig(RxObserver observer) {
    params.clear();
    Stream stream = dioRequest.postRequest('/api/home/conf');
    sendRequest(stream, observer);
  }


}
