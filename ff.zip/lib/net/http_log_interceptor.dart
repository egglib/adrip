import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:go_router/go_router.dart';
import 'package:gtea/app_const.dart';
import 'package:gtea/global.dart';
import 'package:gtea/routers.dart';
import 'package:gtea/utils/edcrypt.dart';
import 'package:gtea/utils/log_util.dart';
import 'package:hive/hive.dart';

class HttpLogInterceptor extends Interceptor {
  bool isJump = false;

  getToken() {
    Box box = AppGlobal.appBox;
    return box.get(AppConst.KEY_TOKEN);
  }

  @override
  void onRequest(
      RequestOptions options, RequestInterceptorHandler handler) async {
    LogUtil.i(
        "------------------------------- 请求数据 start -------------------------------");
    LogUtil.i("[ url ] = [ ${options.uri.toString()} ]");
    LogUtil.i("[ headers ] = [ ${options.headers} ]");

    Map _data = {};
    String token = getToken();
    if (token != null && token != '') {
      AppGlobal.apiToken = token;
    }
    _data.addAll({'token': AppGlobal.apiToken});
    _data.addAll(AppGlobal.appInfo);
    if (options.data != null) {
      _data.addAll(options.data);
    }
    LogUtil.i("[ 加密前 data ] = [ ${_data.toString()} ]");
    options.data = await AppEDCrypt.encryptReqParams(jsonEncode(_data));
    LogUtil.i("[ 加密后 data ] = [ ${options.data} ]");
    LogUtil.i(
        "------------------------------- 请求数据 end -------------------------------");
    super.onRequest(options, handler);
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) async {
    LogUtil.i(
        "------------------------------- 响应数据 start -------------------------------");
    LogUtil.i("[ statusCode ] = [ ${response.statusCode} ]");
    LogUtil.i("[ statusMessage ] = [ ${response.statusMessage} ]");
    if (response != null && response.data != null) {
      LogUtil.i("[ 解密前 data ] = [ ${response.data} ]");
      response.data = jsonDecode(response.data);
      String deData = await AppEDCrypt.decryptResData(response.data['data']);
      response.data = jsonDecode(deData);
    }
    LogUtil.i("[ 解密后 data ] = [ ${response.data} ]");
    LogUtil.i("[ 解密后 内部 data ] = [ ${response.data['data']} ]");
    LogUtil.i(
        "------------------------------- 响应数据 end -------------------------------");
    if (response.data["msg"] == "token无效" &&
        !isJump &&
        AppGlobal.appContext != null &&
        AppGlobal.appInit) {
      // CommonUtils.showText("token失效,请重新登录");
      isJump = true;
      AppGlobal.apiToken = '';
      Box box = AppGlobal.appBox;
      box.delete(AppConst.KEY_TOKEN);
      if (AppGlobal.routerReplace) {
        AppGlobal.appContext.pop();
      }
      AppGlobal.appContext.push(Routers.login, extra: {'is_expired': true});
      Future.delayed(Duration(seconds: 3), () {
        isJump = false;
      });
    }
    super.onResponse(response, handler);
  }

  @override
  void onError(DioError err, ErrorInterceptorHandler handler) {
    LogUtil.i(
        "------------------------------- 错误响应数据 start -------------------------------");
    LogUtil.i("[ error type ] = [ ${err.type} ]");
    LogUtil.i("[ error statusCode ] = [ ${err.response.statusCode} ]");
    LogUtil.i("[ error message ] = [ ${err.message} ]");

    String errorMsg;
    switch (err.type) {
      case DioErrorType.sendTimeout:
        errorMsg = '请求超时';
        break;
      case DioErrorType.receiveTimeout:
        errorMsg = '接收超时';
        break;
      case DioErrorType.connectTimeout:
        errorMsg = '连接超时';
        break;
      case DioErrorType.response:
        errorMsg = '响应错误';
        break;
      case DioErrorType.cancel:
        errorMsg = '取消请求';
        break;
      case DioErrorType.other:
        errorMsg = '网络错误';
        break;
    }
    LogUtil.i("[ errorMsg ] = [ $errorMsg ]");
    LogUtil.i(
        "------------------------------- 错误响应数据 end -------------------------------");
    super.onError(err, handler);
  }
}
