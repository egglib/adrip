import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/pages/home_page.dart';
import 'package:gtea/pages/my_page.dart';
import 'package:gtea/pages/dynamic_page.dart';
import 'package:gtea/pages/home_search_page.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';

class TabNavigator extends StatefulWidget {
  const TabNavigator({Key key}) : super(key: key);

  @override
  _TabNavigatorState createState() => _TabNavigatorState();
}

class _TabNavigatorState extends State<TabNavigator> {
  List navBarItem = [
    {
      "title": StringRes.str_home,
      "icon": ImgRes.IC_HOME_NORMAL,
      "activeIcon": ImgRes.IC_HOME_ACTIVE,
    },
    {
      "title": StringRes.str_dynamic,
      "icon": ImgRes.IC_DYNAMIC_NORMAL,
      "activeIcon": ImgRes.IC_DYNAMIC_ACTIVE,
    },
    {
      "title": StringRes.str_search,
      "icon": ImgRes.IC_SEARCH_NORMAL,
      "activeIcon": ImgRes.IC_SEARCH_ACTIVE,
    },
    {
      "title": StringRes.str_mine,
      "icon": ImgRes.IC_MINE_NORMAL,
      "activeIcon": ImgRes.IC_MINE_ACTIVE,
    }
  ];
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Column(
        children: [_pageViewSection(), _bottomTabNavSection()],
      ),
      // )
    );
  }

  Expanded _pageViewSection() {
    return Expanded(
        child: Stack(children: [
      _buildPagViewPositioned(
          -_currentIndex * ScreenUtil().screenWidth, const HomePage()),
      _buildPagViewPositioned(
          (-_currentIndex + 1) * ScreenUtil().screenWidth, const DynamicPage()),
      _buildPagViewPositioned(
          (-_currentIndex + 2) * ScreenUtil().screenWidth, const HomeSearchPage()),
      _buildPagViewPositioned(
          (-_currentIndex + 3) * ScreenUtil().screenWidth, const MyPage()),
    ]));
  }

  Positioned _buildPagViewPositioned(double left, Widget page) {
    return Positioned(
      left: left,
      top: 0,
      bottom: 0,
      child: SizedBox(
          width: ScreenUtil().screenWidth,
          height: double.infinity,
          child: page),
    );
  }

  Container _bottomTabNavSection() {
    return Container(
      width: double.infinity,
      height: AppStyle.bottomNavBarHeight,
      decoration: _boxShadowSection(),
      child: _bottomNavBarSection(),
    );
  }

  BoxDecoration _boxShadowSection() {
    return BoxDecoration(
        color: Colors.white,
        boxShadow: [
          _buildBoxShadow(),
        ],
        borderRadius: BorderRadius.vertical(
            top: Radius.circular(ScreenUtil().setWidth(15))));
  }

  Row _bottomNavBarSection() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: navBarItem
          .asMap()
          .keys
          .map((key) => buildBottomNavBarItem(key))
          .toList(),
    );
  }

  BoxShadow _buildBoxShadow() {
    return const BoxShadow(
        color: Color.fromRGBO(0, 0, 0, 0.08),
        spreadRadius: 1.0,
        offset: Offset(0.0, -5.0),
        blurRadius: 5.0);
  }

  GestureDetector buildBottomNavBarItem(int key) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _currentIndex = key;
        });
      },
      child: Column(
        children: [
          Image.asset(
              _currentIndex == key
                  ? navBarItem[key]['activeIcon']
                  : navBarItem[key]['icon'],
              width: ScreenUtil().setWidth(29),
              height: ScreenUtil().setWidth(21),
              fit: BoxFit.fitWidth),
          const SizedBox(height: 1),
          Text(
            navBarItem[key]['title'],
            style: _currentIndex == key
                ? AppTextStyle.bottomNavBarTextStyleActive
                : AppTextStyle.bottomNavBarTextStyleNormal,
          )
        ],
        mainAxisAlignment: MainAxisAlignment.center,
      ),
    );
  }
}
