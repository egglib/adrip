import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:gtea/model/nav_item.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';

import '../routers.dart';

class ScrollTabNavigator extends StatefulWidget {
  final List<NavItem> navItems;
  final List pages;
  final Function onNavIndexChanged;

  ScrollTabNavigator(
      {Key key, this.navItems, this.pages, this.onNavIndexChanged})
      : super(key: key);

  @override
  _ScrollTabNavigatorState createState() => _ScrollTabNavigatorState();
}

class _ScrollTabNavigatorState extends State<ScrollTabNavigator> {
  List<GlobalKey> keys = <GlobalKey>[];
  ScrollController _controller;
  PageController _pageController;
  int selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _controller = ScrollController();
    _pageController = PageController();
    _pageController.addListener(() {
      Timer(Duration(milliseconds: 200), () {
        int index = _pageController.page.toInt();
        if (selectedIndex != index) {
          selectedIndex = index;
          setState(() {});
          scrollItemToCenter(index);
          if (widget.onNavIndexChanged != null) {
            widget.onNavIndexChanged(index);
          }
        }
      });
    });
    for (int i = 0; i < widget.navItems.length; i++) {
      keys.add(GlobalKey(debugLabel: 'navitems-${i.toString()}'));
    }
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
    _pageController.dispose();
  }

  void scrollItemToCenter(int pos) {
    RenderBox box = keys[pos].currentContext.findRenderObject();
    Offset os = box.localToGlobal(Offset.zero);
    double w = box.size.width;
    double x = os.dx;
    double windowW = ScreenUtil().screenWidth;
    double rlOffset = windowW / 2 - (x + w / 2);
    double offset = _controller.offset - rlOffset;
    _controller.animateTo(offset,
        duration: Duration(milliseconds: 200), curve: Curves.easeInOut);
  }

  @override
  Widget build(BuildContext context) {
    return (widget.navItems != null && widget.pages != null)
        ? Column(
            children: [
              Container(
                alignment: AlignmentDirectional.center,
                color: Colors.white,
                width: ScreenUtil().screenWidth,
                height: AppStyle.topNavBarHeight,
                padding: EdgeInsets.symmetric(horizontal: AppStyle.pagePadding),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [_scrollTabSection(), _buildSearchBtn(context)],
                ),
              ),
              _buildPageContainer()
            ],
          )
        : Container();
  }

  Expanded _scrollTabSection() {
    return Expanded(
        child: ListView(
      physics: ClampingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      controller: _controller,
      children: _buildNavItems(),
    ));
  }

  List<GestureDetector> _buildNavItems() {
    return widget.navItems
        .asMap()
        .keys
        .map((index) => GestureDetector(
              onTap: () {
                _pageController.animateToPage(index,
                    duration: Duration(milliseconds: 200),
                    curve: Curves.easeInOut);
              },
              child: Container(
                key: keys[index],
                padding: EdgeInsets.only(right: ScreenUtil().setWidth(20)),
                child: _buildTabNavItem(index),
              ),
            ))
        .toList();
  }

  Stack _buildTabNavItem(int index) {
    return Stack(
      alignment: Alignment.center,
      children: [
        selectedIndex == index
            ? Positioned(
                top: 10,
                right: 0,
                child: Image.asset(ImgRes.IC_NAV_DOT,
                    width: ScreenUtil().setWidth(15),
                    height: ScreenUtil().setWidth(15)),
              )
            : Container(),
        Container(
          // margin: selectedIndex == index
          //     ? EdgeInsets.only(
          //         top: ScreenUtil().setWidth(4))
          //     : EdgeInsets.only(
          //         top: ScreenUtil().setWidth(1)),
          child: Padding(
            padding: EdgeInsets.only(right: 5),
            child: Text(
              widget.navItems[index].name,
              style: selectedIndex == index
                  ? AppTextStyle.c30313f_s20_bold
                  : AppTextStyle.c30313f_s15,
            ),
          ),
        )
      ],
    );
  }

  Container _buildPageContainer() {
    return Container(
      width: ScreenUtil().screenWidth,
      height: ScreenUtil().screenHeight -
          AppStyle.topNavBarHeight -
          AppStyle.bottomNavBarHeight -
          ScreenUtil().bottomBarHeight -
          ScreenUtil().statusBarHeight -
          ScreenUtil().setWidth(38),
      padding: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
      child: PageView(
        controller: _pageController,
        children: widget.pages,
      ),
    );
  }

  GestureDetector _buildSearchBtn(BuildContext context) {
    return GestureDetector(
        onTap: () {
          // 打开搜索
          context.push(Routers.search);
        },
        child: Container(
          padding: EdgeInsets.only(left: ScreenUtil().setWidth(6)),
          child: Image.asset(
            ImgRes.IC_SEARCH,
            width: ScreenUtil().setWidth(27),
            height: ScreenUtil().setWidth(21),
          ),
        ));
  }
}
