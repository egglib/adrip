import 'dart:async';

import 'package:flutter/material.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';

class SegmentConfig {
  SegmentConfig({
    this.margin = 15,
    this.lMargin = 15,
    this.rMargin = 15,
    this.space = 10,
    this.lSpace = 0,
    this.rSpace = 0,
    this.textStyle,
    this.selectedTextStyle,
    this.indicator,
    this.offset = 0,
    this.alignment = Alignment.bottomCenter,
  });

  //
  final double offset;

  // container
  final double margin;
  final double lMargin;
  final double rMargin;
  // text left space
  final double space;
  final double lSpace;
  final double rSpace;

  final TextStyle textStyle;
  final TextStyle selectedTextStyle;

  final Widget indicator;
  final Alignment alignment;

  // final double navHeight;
  // final double pageHeight;
}

class ScrollSegment extends StatefulWidget {
  const ScrollSegment(
      {Key key,
      this.navItems,
      this.navHeight,
      this.pages,
      this.pageHeight,
      this.onNavIndexChanged,
      this.config,
      this.moreWidget})
      : super(key: key);

  final Function onNavIndexChanged;
  final List navItems;
  final List<Widget> pages;
  final double navHeight;
  final double pageHeight;

  final Widget moreWidget;

  final SegmentConfig config;

  @override
  _ScrollSegmentState createState() => _ScrollSegmentState();
}

class _ScrollSegmentState extends State<ScrollSegment> {
  List<GlobalKey> keys = <GlobalKey>[];
  int selectedIndex = 0;
  PageController _pageController;
  ScrollController _scrollController;

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    _pageController.dispose();
  }

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _scrollController = ScrollController();

    _pageController.addListener(() {
      Timer(const Duration(milliseconds: 200), () {
        int index = _pageController.page.toInt();
        if (selectedIndex != index) {
          selectedIndex = index;
          setState(() {});
          itemScrollToCenter(index);
          if (widget.onNavIndexChanged != null) {
            widget.onNavIndexChanged(index);
          }
        }
      });
    });

    for (int i = 0; i < widget.navItems.length; i++) {
      keys.add(GlobalKey(debugLabel: 'navitems-${i.toString()}'));
    }
  }

  ///
  ///
  void itemScrollToCenter(int index) {
    RenderBox box = keys[index].currentContext.findRenderObject();
    Offset offset = box.localToGlobal(Offset.zero);
    var x = offset.dx;
    var w = box.size.width;
    var rlOffset = (AppStyle.screenWidth / 2) - (x + w / 2);

    /// need offset x
    var offsetX = _scrollController.offset - rlOffset;
    _scrollController.animateTo(offsetX,
        duration: const Duration(milliseconds: 200), curve: Curves.easeInOut);
  }

  @override
  Widget build(BuildContext context) {
    return (widget.navItems != null && widget.pages != null)
        ? Column(
            children: [
              /// 导航区域
              Container(
                alignment: AlignmentDirectional.center,
                color: Colors.transparent,
                width: AppStyle.screenWidth,
                height: widget.navHeight,
                child: Row(
                  children: [
                    _buildScrollNavTitle(),
                  ],
                ),
              ),

              /// 内容区域
              _buildPageContainer(context),
            ],
          )
        : Container();
  }

  /// 导航滚动区域
  Widget _buildScrollNavTitle() {
    return Expanded(
      child: ListView(
        physics: ClampingScrollPhysics(),
        scrollDirection: Axis.horizontal,
        controller: _scrollController,
        // reverse: true,
        shrinkWrap: true,
        padding: EdgeInsets.only(
            left: widget.config.lMargin, right: widget.config.rMargin),
        children: widget.navItems
            .asMap()
            .keys
            .map((index) => GestureDetector(
                  onTap: () {
                    _pageController.animateToPage(index,
                        duration: Duration(milliseconds: 200),
                        curve: Curves.linearToEaseOut);
                  },
                  child: Container(
                    key: keys[index],
                    padding: EdgeInsets.only(right: 0),
                    child: _buildNavItem(index),
                  ),
                ))
            .toList(),
      ),
    );
  }

  Widget _buildNavItem(int index) {
    return Stack(
      alignment: Alignment.center,
      children: [
        selectedIndex == index
            ? Positioned(
                right: -3,
                bottom: 5,
                child: Image.asset(ImgRes.ATT_SGMT_INDICATOR,
                    width: AppStyle.adapter(24.5), height: AppStyle.adapter(21)),
              )
            : Container(),
        Container(
          child: Padding(
            padding: EdgeInsets.only(left: widget.config.lSpace, right: widget.config.rSpace),
            child: Text(widget.navItems[index]['name'],
                style: selectedIndex == index
                    ? widget.config.selectedTextStyle
                    : widget.config.textStyle),
          ),
        )
      ],
    );
  }

  /// 内容显示区域
  Widget _buildPageContainer(BuildContext context) {
    var media = MediaQuery.of(context);
    var bottom = MediaQuery.of(context).padding.bottom;
    return Container(
        // width: media.size.width,
        height: widget.pageHeight,
        // padding: EdgeInsets.only(top: AppStyle.adapter(6)),
        child: PageView(
          controller: _pageController,
          children: widget.pages,
        ));
  }
}
