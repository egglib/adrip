import 'package:flutter/material.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';

class AttTrader extends StatefulWidget {
  const AttTrader({Key key}) : super(key: key);

  @override
  _AttTraderState createState() => _AttTraderState();
}

class _AttTraderState extends State<AttTrader> {
  List dataList = [];

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
    dataList = [1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7];

    if (mounted) setState(() {});
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));

    dataList.add(8);
    dataList.add(9);
    dataList.add(8);
    dataList.add(9);

    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _onRefresh();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15.w),
      child: RefreshLoadListWidget(
        // onLoading: _onLoading,
        // onRefresh: _onRefresh,
        child: (dataList) {
          return ListView.builder(
            padding: EdgeInsets.only(bottom: 20.w),
            itemCount: dataList.length,
            itemBuilder: (context, index) {
              return _buildItem()
                  .intoPadding(padding: EdgeInsets.only(bottom: 27.5.w));
            },
          );
        },
      ),
    );
  }

  Widget _buildItem() {
    return Row(
      children: [
        Image.asset(
          ImgRes.IMG_BACK_TEST,
          width: 49.w,
          height: 49.w,
          fit: BoxFit.cover,
        ).intoClipRRect(borderRadius: BorderRadius.circular(24.5.w)),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('峡谷霸主',
                style: AppTextStyle.buildB(ColorRes.color_1a1a1a, 15.sp)),
            SizedBox(height: 3.w),
            [
              Text('成交12单',
                  style: AppTextStyle.build(ColorRes.color_b3b3b3, 12.sp)),
              SizedBox(width: 10.w),
              Text('仔仔12人',
                  style: AppTextStyle.build(ColorRes.color_b3b3b3, 12.sp)),
              SizedBox(width: 10.w),
              Text('动态12条',
                  style: AppTextStyle.build(ColorRes.color_b3b3b3, 12.sp)),
            ].intoRow()
          ],
        )
            .intoPadding(padding: EdgeInsets.fromLTRB(10.w, 0, 10.w, 0))
            .intoExpanded(),
        Text('已收藏', style: AppTextStyle.build(ColorRes.color_999999, 13.sp))
            .intoCenter()
            .onPackageContainer(
              width: 64.w,
              height: 28.w,
              radius: 3.w,
              boxBgColor: ColorRes.color_f5f5f5,
            )
      ],
    );
  }
}
