import 'package:flutter/material.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';

class AttDynamic extends StatefulWidget {
  const AttDynamic({Key key}) : super(key: key);

  @override
  _AttDynamicState createState() => _AttDynamicState();
}

class _AttDynamicState extends State<AttDynamic> {
  List dataList = [];

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
    dataList = [1, 2, 3, 4, 5, 6, 7];

    if (mounted) setState(() {});
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));

    dataList.add(8);
    dataList.add(9);
    dataList.add(8);
    dataList.add(9);

    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _onRefresh();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15.w),
      child: RefreshLoadListWidget(
          // onLoading: _onLoading,
          // onRefresh: _onRefresh,
          child: (dataList) {
            return ListView.builder(
                itemCount: dataList.length,
                itemBuilder: (context, index) {
                  return _buildItem(index);
                });
          }),
    );
  }

  Widget _buildItem(int index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Image.asset(
              ImgRes.IMG_BACK_TEST,
              width: 50.w,
              height: 50.w,
              fit: BoxFit.cover,
            ).intoClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(25.w)),
            ),
            Text(
              '男神汇官方',
              style: AppTextStyle.buildB(const Color(0xff3f4050), 15.sp),
            ).intoPadding(padding: EdgeInsets.symmetric(horizontal: 8.w)),
          ],
        ),
        Text(
          '安德森啊活动卡',
          style: AppTextStyle.buildB(ColorRes.color_1b1b2e, 15),
        ).intoPadding(padding: EdgeInsets.symmetric(vertical: 8.w)),
        Text(
          '视觉中国是全球性优质正版图片、视频等视觉内容平台型互联网上市公司...',
          maxLines: 2,
          style: AppTextStyle.build(const Color(0xff4f5063), 15),
        ),
        Container(
          height: 112.w,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                RichText(
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  text: TextSpan(
                    text: '#',
                    style: AppTextStyle.c3f3f3f_s11,
                    children: [
                      TextSpan(text: '携程', style: AppTextStyle.c3f3f3f_s11)
                    ],
                  ),
                ).onPackageContainer(
                  height: 17.w,
                  radius: 8.5.w,
                  boxBgColor: ColorRes.color_f6f9f9,
                  padding: EdgeInsets.fromLTRB(8.5.w, 0, 8.5, 0),
                )
              ],
            ),
            Row(
              children: [
                Text(
                  '358',
                  style: AppTextStyle.build(const Color(0xffc6c7db), 12.sp),
                ),
                Text(
                  '358',
                  style: AppTextStyle.build(const Color(0xffc6c7db), 12.sp),
                ),
              ],
            )
          ],
        ),
        Container(
            height: 3,
            margin: EdgeInsets.fromLTRB(0, 11.w, 0, 12.5.w),
            color: index == dataList.length - 1
                ? Colors.transparent
                : const Color(0xfff2f1f4))
      ],
    );
  }

  Widget share(String icon, String text) {
    return Container(
        margin: EdgeInsets.only(left: AppStyle.adapter(10)),
        padding: EdgeInsets.only(left: AppStyle.adapter(25.5)),
        alignment: Alignment.centerLeft,
        decoration: BoxDecorationExt.image(ImgRes.MY_MBR_TYPE),
        child: Text(text,
            style: AppTextStyle.build(const Color(0xffc6c7db), 12.sp)));
  }
}
