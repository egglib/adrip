import 'package:flutter/material.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';

class AttResource extends StatefulWidget {
  const AttResource({Key key}) : super(key: key);

  @override
  _AttResourceState createState() => _AttResourceState();
}

class _AttResourceState extends State<AttResource> {
  List dataList = [];

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
    dataList = [1, 2, 3, 4, 5, 6, 7];

    if (mounted) setState(() {});
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));

    dataList.add(8);
    dataList.add(9);
    dataList.add(8);
    dataList.add(9);

    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _onRefresh();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15.w),
      child: RefreshLoadListWidget(
        // onLoading: _onLoading,
        // onRefresh: _onRefresh,
        child: (dataList){
          return ListView(
            padding: EdgeInsets.only(),
            children: _buildItems(),
          );
        },
      ),
    );
  }

  List<Widget> _buildItems() {
    return dataList
        .asMap()
        .keys
        .map((index) => Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [_buildLeftItem(), _buildRightItem()],
                ),
                Container(
                  width: 171.w,
                  height: 0.5.w,
                  color: index == dataList.length - 1
                      ? Colors.transparent
                      : ColorRes.color_e8e8e8,
                  margin: EdgeInsets.fromLTRB(0, 10.w, 0, 8.w),
                ),
              ],
            ))
        .toList();
  }

  Widget _buildLeftItem() {
    return Stack(
      children: [
        Image.asset(
          ImgRes.IMG_BACK_TEST,
          width: 157.5.w,
          height: 103.w,
          fit: BoxFit.cover,
        ).intoClipRRect(borderRadius: BorderRadius.all(Radius.circular(6.5.w))),
        Text('213人解锁', style: AppTextStyle.white_s11).onPackageContainer(
          radius: 3.w,
          padding: EdgeInsets.fromLTRB(5.w, 1.w, 5.w, 1.w),
          margin: EdgeInsets.only(left: 5.w, top: 5.w),
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            ColorRes.color_89ebff,
            ColorRes.color_f4aef4,
            ColorRes.color_facf60
          ],
        )
      ],
    );
  }

  Widget _buildRightItem() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '铁板胸肌训练营',
          style: AppTextStyle.buildB(ColorRes.color_1b1b2e, 15.sp),
        ),
        SizedBox(height: 9.w),
        Text('北京市', style: AppTextStyle.build(ColorRes.color_9d9d9d, 13.sp)),
        SizedBox(height: 9.w),
        Text('20岁|175cm|可1可0',
            style: AppTextStyle.build(ColorRes.color_9d9d9d, 13.sp)),
        SizedBox(height: 9.w),
        Text('¥:200元', style: AppTextStyle.build(ColorRes.color_f15d58, 13.sp)),
        // SizedBox(height: 10.w),
        // Container(width: 171.w, height: 0.5.w, color: ColorRes.color_e8e8e8),
        // SizedBox(height: 8.w),
      ],
    ).intoPadding(padding: EdgeInsets.only(left: 15.w));
  }
}
