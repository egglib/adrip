import 'package:flutter/material.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';

class AttMerchant extends StatefulWidget {
  const AttMerchant({Key key}) : super(key: key);

  @override
  _AttMerchantState createState() => _AttMerchantState();
}

class _AttMerchantState extends State<AttMerchant> {
  List dataList = [];

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
    dataList = [1, 2, 3, 4, 5, 6, 7];

    if (mounted) setState(() {});
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));

    dataList.add(8);
    dataList.add(9);
    dataList.add(8);
    dataList.add(9);

    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _onRefresh();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshLoadListWidget(
      // onLoading: _onLoading,
      // onRefresh: _onRefresh,
      child: (dataList) {
        return GridView.builder(
          itemCount: dataList.length,
          padding: EdgeInsets.symmetric(horizontal: 15.w),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 163.5 / 210,
            crossAxisSpacing: 18.w,
            mainAxisSpacing: 15.w,
          ),
          itemBuilder: (context, index) => Container(
            clipBehavior: Clip.hardEdge,
            decoration:
                BoxDecoration(borderRadius: BorderRadius.circular(6.5.w)),
            child: _buildUpperWidget(),
          ),
        );
      },
    );
  }

  Widget _buildUpperWidget() {
    return Stack(
      children: [
        Image.asset(
          ImgRes.IMG_BACK_TEST,
          width: 163.5.w,
          height: 210.w,
          fit: BoxFit.cover,
        )
        // .intoClipRRect(
        //   borderRadius: BorderRadius.all(Radius.circular(6.5.w)),
        // )
        ,
        Text('213人已约', style: AppTextStyle.white_s11).onPackageContainer(
          radius: 3.w,
          padding: EdgeInsets.fromLTRB(5.w, 1.w, 5.w, 1.w),
          margin: EdgeInsets.only(left: 5.w, top: 5.w),
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            ColorRes.color_89ebff,
            ColorRes.color_f4aef4,
            ColorRes.color_facf60
          ],
        ),
        Positioned(left: 0, bottom: 0, child: _bulidLowerWidget())
      ],
    );
  }

  Widget _bulidLowerWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("健身教练", style: AppTextStyle.buildB(Colors.white, 12.sp)),
        SizedBox(height: 3.w),
        Text(
          "20岁 178CM 可1可0 一次200 ",
          style: AppTextStyle.build(Colors.white, 11.sp),
        ),
      ],
    ).intoContainer(
      padding: EdgeInsets.fromLTRB(6.w, 5.w, 6.w, 5.w),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        // borderRadius: BorderRadius.vertical(bottom: Radius.circular(5.w)),
      ),
    );
  }
}
