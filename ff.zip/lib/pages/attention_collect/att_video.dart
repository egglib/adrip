import 'package:flutter/material.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';

class AttVideo extends StatefulWidget {
  const AttVideo({Key key}) : super(key: key);

  @override
  _AttVideoState createState() => _AttVideoState();
}

class _AttVideoState extends State<AttVideo> {
  List dataList = [];

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
    dataList = [1, 2, 3, 4, 5, 6, 7];

    if (mounted) setState(() {});
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));

    dataList.add(8);
    dataList.add(9);
    dataList.add(8);
    dataList.add(9);

    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _onRefresh();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshLoadListWidget(
      // onLoading: _onLoading,
      // onRefresh: _onRefresh,
      child: (dataList) {
        return GridView.builder(
          itemCount: dataList.length,
          padding: EdgeInsets.symmetric(horizontal: 15.w),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 165 / 144,
            crossAxisSpacing: 15.w,
            mainAxisSpacing: 15.w,
          ),
          itemBuilder: (context, index) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [_buildUpperWidget()],
          ),
        );
      },
    );
  }

  Widget _buildUpperWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        [
          Image.asset(
            ImgRes.IMG_BACK_TEST,
            width: 1635.w,
            height: 94.w,
            fit: BoxFit.cover,
          ).intoClipRRect(
            clipBehavior: Clip.hardEdge,
            borderRadius: BorderRadius.circular(6.w),
          ),
          _bulidLowerWidget().intoPositioned(left: 0, right: 0, bottom: 0)
        ].intoStack(),
        Text(
          '王者荣耀搞笑视频《嘴强青铜》猴子',
          maxLines: 2,
          style: AppTextStyle.build(ColorRes.color_1a1a1a, 13),
        ).intoPadding(padding: EdgeInsets.fromLTRB(0, 6.5.w, 0, 6.5.w)),
      ],
    );
  }

  Widget _bulidLowerWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text("1234", style: AppTextStyle.build(Colors.white, 12.sp)),
        //.intoContainer(decoration: BoxDecoration(image: DecorationImage(image: AssetImage('')))),
        SizedBox(height: 3.w),
        Text("05:00", style: AppTextStyle.build(Colors.white, 12.sp)),
      ],
    ).intoContainer(
      padding: EdgeInsets.fromLTRB(6.w, 5.w, 6.w, 5.w),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(6.w)),
      ),
    );
  }
}
