import 'package:flutter/material.dart';
import 'package:gtea/navigator/scroll_segment.dart';
import 'package:gtea/pages/attention_collect/att_certified.dart';
import 'package:gtea/pages/attention_collect/att_dynamic.dart';
import 'package:gtea/pages/attention_collect/att_merchant.dart';
import 'package:gtea/pages/attention_collect/att_resource.dart';
import 'package:gtea/pages/attention_collect/att_trader.dart';
import 'package:gtea/pages/attention_collect/att_video.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/page_title_bar_widget.dart';

class AttentionCollect extends StatefulWidget {
  const AttentionCollect({Key key}) : super(key: key);

  @override
  _AttentionCollectState createState() => _AttentionCollectState();
}

class _AttentionCollectState extends State<AttentionCollect> {
  List navItems = [];
  List<Widget> pages = <Widget>[];

  @override
  void initState() {
    super.initState();

    navItems.add({'name': '资源信息'});
    navItems.add({'name': '认证仔仔'});
    navItems.add({'name': '商家仔仔'});
    navItems.add({'name': '商家'});
    navItems.add({'name': '视频'});
    navItems.add({'name': '动态'});

    pages.add(const AttResource());
    pages.add(const AttCertified());
    pages.add(const AttMerchant());
    pages.add(const AttTrader());
    pages.add(const AttVideo());
    pages.add(const AttDynamic());
  }

  final sgmtconfig = SegmentConfig(
    // margin: 7.w,
    // space: 8.w,
    lMargin: 7.w,
    rMargin: 7.w,
    lSpace: 7.w,
    rSpace: 7.w,
    textStyle: TextStyle(color: ColorRes.color_30313f, fontSize: 14.sp),
    selectedTextStyle: TextStyle(
      color: ColorRes.color_30313f,
      fontSize: 15.sp,
      fontWeight: FontWeight.w500,
    ),
    // indicator: 
  );

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context);

    return Scaffold(
        body: Column(
      children: [
        SizedBox(width: AppStyle.screenWidth, height: media.padding.top),
        PageTitleBarWidget(title: StringRes.str_att_collect, height: 44.w),
        ScrollSegment(
          navItems: navItems,
          navHeight: 44.w,
          pages: pages,
          pageHeight: media.size.height - media.padding.top - 44.w - 44.w,
          config: sgmtconfig,
        ),
      ],
    ));
  }
}
