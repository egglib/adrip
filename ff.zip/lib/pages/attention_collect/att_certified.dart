import 'package:flutter/material.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';

class AttCertified extends StatefulWidget {
  const AttCertified({Key key}) : super(key: key);

  @override
  _AttCertifiedState createState() => _AttCertifiedState();
}

class _AttCertifiedState extends State<AttCertified> {
  List dataList = [];

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
    dataList = [1, 2, 3, 4, 5, 6, 7];

    if (mounted) setState(() {});
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));

    dataList.add(8);
    dataList.add(9);
    dataList.add(8);
    dataList.add(9);

    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _onRefresh();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshLoadListWidget(
      // onLoading: _onLoading,
      // onRefresh: _onRefresh,
      child: (dataList) {
        return GridView.builder(
          itemCount: dataList.length,
          padding: EdgeInsets.symmetric(horizontal: 15.w),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 163.5 / 225,
            crossAxisSpacing: 18.w,
            mainAxisSpacing: 15.w,
          ),
          itemBuilder: (context, index) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildUpperWidget(),
              _bulidLowerWidget(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildUpperWidget() {
    return Stack(
      children: [
        Image.asset(
          ImgRes.IMG_BACK_TEST,
          width: 163.5.w,
          height: 165.w,
          fit: BoxFit.cover,
        ).intoClipRRect(
          borderRadius: BorderRadius.vertical(top: Radius.circular(6.5.w)),
        ),
        RichText(
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          text: TextSpan(text: '颜值', style: AppTextStyle.white_s12, children: [
            TextSpan(text: '90', style: AppTextStyle.cfef693_s12)
          ]),
        ).intoContainer(
          padding: EdgeInsets.fromLTRB(7.5.w, 2.w, 7.5.w, 2.w),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(6.5.w),
                bottomRight: Radius.circular(6.5.w)),
            gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [ColorRes.color_7f85f4, ColorRes.color_6c5aef]),
          ),
        ),
        Text('213人解锁', style: AppTextStyle.white_s11).onPackageContainer(
          radius: 3.w,
          padding: EdgeInsets.fromLTRB(5.w, 1.w, 5.w, 1.w),
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            ColorRes.color_89ebff,
            ColorRes.color_f4aef4,
            ColorRes.color_facf60
          ],
        ).intoPositioned(right: 7.w, bottom: 5.5.w)
      ],
    );
  }

  Widget _bulidLowerWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("健身教练", style: AppTextStyle.c30313f_s15),
        SizedBox(height: 3.w),
        Text("20岁 178CM 可1可0 一次200 ", style: AppTextStyle.c646464_s11),
      ],
    ).intoContainer(
      padding: EdgeInsets.fromLTRB(8.w, 11.w, 8.w, 9.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(5.w)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 7.5,
            spreadRadius: 1,
            offset: const Offset(0.0, 0.0),
          )
        ],
      ),
    );
  }
}
