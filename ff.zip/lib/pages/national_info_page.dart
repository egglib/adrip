import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:gtea/model/nav_item.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/routers.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/app_widget.dart';
import 'package:gtea/widget/banner_widget.dart';
import 'package:gtea/widget/hint_widget.dart';
import 'package:gtea/widget/img_widget.dart';
import 'package:gtea/widget/list_widget.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';
import 'package:gtea/widget/space_widget.dart';
import 'package:gtea/widget/text_widget.dart';

class NationalInfoPage extends StatefulWidget {
  const NationalInfoPage({Key key}) : super(key: key);

  @override
  _NationalInfoPageState createState() => _NationalInfoPageState();
}

class _NationalInfoPageState extends State<NationalInfoPage> {
  List<String> imageList = [];
  List<String> infoList = [
    'a',
    'b',
    'c',
    'aa',
    'bb',
    'cc',
    'aaa',
    'bbb',
    'ccc'
  ];

  @override
  void initState() {
    super.initState();
    imageList
      ..add(ImgRes.BANNER_TEST)
      ..add(ImgRes.BANNER_TEST)
      ..add(ImgRes.BANNER_TEST);
  }

  @override
  void dispose() {
    super.dispose();
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use loadFailed(),if no data return,use LoadNodata()
    infoList.add((infoList.length + 1).toString());
    infoList.add((infoList.length + 1).toString());
    infoList.add((infoList.length + 1).toString());
    infoList.add((infoList.length + 1).toString());
    if (mounted) setState(() {});
  }

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: AppStyle.pagePadding),
      child: RefreshLoadListWidget(
        getData: (pageIndex) {
          return null;
        },
        // parseList: ,
        child: (List dataList) {
          return ListView(
            children: [
              BannerWidget.buildBigBanner(context, 3, callback: () {}),
              SpaceWidget.v_space_20,
              _fastEntrySection(),
              SpaceWidget.v_space_20,
              _recommendTitleSection(),
              SpaceWidget.v_space_15,
              _recommendListSection(),
              SpaceWidget.v_space_30,
              _infoTitleSection(),
              SpaceWidget.v_space_30,
              _infoListSection()
            ],
          );
        },
      ),
    );
  }

  ListView _infoListSection() {
    return ListWidget.buildVerticalListView(infoList.length, (context, index) {
      return Column(
        children: index == 3
            ? [
                ImgWidget.buildImg(ImgRes.BANNER_TEST_1,
                    width: MediaQuery.of(context).size.width,
                    height: ScreenUtil().setWidth(70),
                    fit: BoxFit.fill,
                    isNet: false),
                SpaceWidget.v_space_15,
              ]
            : [
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.all(
                          Radius.circular(ScreenUtil().setWidth(8))),
                      child: Image.asset(
                        ImgRes.IMG_BACK_TEST,
                        width: MediaQuery.of(context).size.width,
                        height: ScreenUtil().setWidth(179),
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.fromLTRB(5, 1, 5, 1),
                      margin: const EdgeInsets.only(left: 5, top: 5),
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(3)),
                          gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                ColorRes.color_89ebff,
                                ColorRes.color_f4aef4,
                                ColorRes.color_facf60,
                              ])),
                      child: Text(
                        '1000元',
                        style: AppTextStyle.white_s11,
                      ),
                    ),
                  ],
                ),
                SpaceWidget.v_space_15,
              ],
      );
    });
  }

  Row _infoTitleSection() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        AppWidget.blueVerticalLine,
        SpaceWidget.h_space_6,
        Expanded(
            child: TextWidget.buildText('全国性息', AppTextStyle.c30313f_s18_bold)),
        SpaceWidget.h_space_6,
        TextWidget.buildText(StringRes.str_beijing, AppTextStyle.c30313f_s14),
        SpaceWidget.h_space_3,
        AppWidget.iconLocation,
        SpaceWidget.h_space_15,
        TextWidget.buildText(StringRes.str_filter, AppTextStyle.c30313f_s14),
        SpaceWidget.h_space_3,
        AppWidget.iconFilter,
      ],
    );
  }

  SizedBox _recommendListSection() {
    return SizedBox(
      height: ScreenUtil().setWidth(179),
      child: ListWidget.buildHorizontalListView(
          10,
          (context, index) => Row(
                children: [
                  Stack(
                    children: [
                      ImgWidget.buildLocalImg(ImgRes.IMG_BACK_TEST,
                          width: 138, height: 179),
                      Container(
                          padding: const EdgeInsets.fromLTRB(5, 1, 5, 1),
                          margin: const EdgeInsets.only(left: 5, top: 5),
                          decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(3)),
                              gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    ColorRes.color_89ebff,
                                    ColorRes.color_f4aef4,
                                    ColorRes.color_facf60,
                                  ])),
                          child: TextWidget.buildText(
                              '1000元', AppTextStyle.white_s11)),
                      Positioned(
                          left: 8,
                          right: 8,
                          bottom: 8,
                          child: TextWidget.buildText(
                              '平台入驻入驻平台入入平台入驻入驻平台入入', AppTextStyle.white_s12))
                    ],
                  ),
                  SpaceWidget.h_space_15
                ],
              )),
    );
  }

  Row _recommendTitleSection() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        AppWidget.blueVerticalLine,
        SpaceWidget.h_space_6,
        Expanded(
            child: Text(
          '官方仔仔推荐',
          style: AppTextStyle.c30313f_s20_bold,
        )),
        SpaceWidget.h_space_6,
        Text(StringRes.str_more, style: AppTextStyle.c999999_s12),
        SpaceWidget.h_space_3,
        AppWidget.grayArrowRight,
      ],
    );
  }

  Row _fastEntrySection() {
    return Row(
      children: [
        Expanded(
          child: ImgWidget.buildImg(ImgRes.IC_ENTRY_1, height: 80, isNet: false,
              callback: () {
            context.push(Routers.activity);
          }),
        ),
        SpaceWidget.h_space_20,
        Expanded(
          child: ImgWidget.buildImg(ImgRes.IC_ENTRY_2, height: 80, isNet: false,
              callback: () {
            context.push(Routers.settled);
          }),
        )
      ],
    );
  }
}
