import 'dart:io';

import 'package:flutter/material.dart';
import 'package:gtea/widget/page_title_bar_widget.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebViewPage extends StatefulWidget {
  final Map args;

  const WebViewPage({
    this.args,
    Key key,
  }) : super(key: key);

  @override
  _WebViewPageState createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  bool isLoaded = false;
  double progressValue = 0.0;

  @override
  void initState() {
    super.initState();
    if (Platform.isAndroid) WebView.platform = AndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: Column(
        children: [
          PageTitleBarWidget(title: widget?.args['title']),
          !isLoaded
              ? LinearProgressIndicator(
                  minHeight: 3,
                  value: progressValue,
                )
              : const SizedBox(
                  width: 0,
                  height: 0,
                ),
          Expanded(
              child: WebView(
            initialUrl: widget?.args['url'],
            javascriptMode: JavascriptMode.unrestricted,
            backgroundColor: Colors.white,
            onProgress: (progress) {
              setState(() {
                progressValue = progress / 100;
              });
            },
            onPageFinished: (url) {
              setState(() {
                isLoaded = true;
              });
            },
          ))
        ],
      ),
    ));
  }
}
