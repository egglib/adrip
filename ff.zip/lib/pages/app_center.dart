import 'package:flutter/material.dart';
import 'package:gtea/model/app_center_model.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/page_title_bar_widget.dart';

class AppCenter extends StatefulWidget {
  const AppCenter({Key key}) : super(key: key);

  @override
  _AppCenterState createState() => _AppCenterState();
}

class _AppCenterState extends State<AppCenter> {
  List<AppItemModel> itemsModel = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() async {
    await Future.delayed(const Duration(milliseconds: 2000));
    setState(() {
      itemsModel = [
        AppItemModel().innerTest(),
        AppItemModel().innerTest(),
        AppItemModel().innerTest(),
        AppItemModel().innerTest(),
        AppItemModel().innerTest(),
        AppItemModel().innerTest(),
        AppItemModel().innerTest(),
        AppItemModel().innerTest(),
        AppItemModel().innerTest(),
      ];
    });
  }

  Widget applicationColumn() {
    List<Widget> list = itemsModel
        .map((item) => AppItemWidget(
              icon: item.imgUrlFull,
              text: item.title,
              clicked: item.clicked,
              desc: item.description,
              link: item.linkUrl,
            ))
        .toList();
    return list.isEmpty ? Container() : list.intoColumn();
  }

  Widget applicationTitle() {
    var titleWidget = [
      Image.asset(ImgRes.APP_CENTER_ICON,
          width: AppStyle.adapter(20), height: AppStyle.adapter(20)),
      SizedBox(width: AppStyle.adapter(8)),
      Text(StringRes.str_app_center_text,
          style: AppTextStyle.build(ColorRes.color_333333, 20))
    ].intoRow().intoPadding(
        padding: EdgeInsets.only(
            top: AppStyle.adapter(44), bottom: AppStyle.adapter(10.5)));
    return itemsModel.isEmpty ? Container() : titleWidget;
  }

  @override
  Widget build(BuildContext context) {
    return [
      PageTitleBarWidget(title: StringRes.str_app_center),
      [
        Container(height: AppStyle.adapter(160)),
        applicationTitle(),
        applicationColumn(),
      ]
          .intoColumn(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
          )
          .intoPadding(
            padding: EdgeInsets.only(
              left: AppStyle.adapter(16),
              right: AppStyle.adapter(16),
            ),
          )
          .intoRefreshWidget(onRefresh: _loadData)
          .intoExpanded()
    ].intoColumn().intoSafeArea().intoScaffold();
  }
}

///
///
///
class AppItemWidget extends StatefulWidget {
  const AppItemWidget(
      {Key key, this.icon, this.text, this.clicked, this.desc, this.link})
      : super(key: key);

  final String text;
  final String desc;
  final String icon;
  final String link;
  final int clicked;

  @override
  _AppItemWidgetState createState() => _AppItemWidgetState();
}

class _AppItemWidgetState extends State<AppItemWidget> {
  _onTapClick() {}

  String get clickCount {
    return formatNumber(widget.clicked.toDouble(), 2) +
        StringRes.str_download_num;
  }

  formatNumber(double number, int positon) {
    var result = number.toString();
    if (number >= 10000) {
      result = formatDecimal(number / 10000, positon) + '万';
    }
    return result;
  }

  formatDecimal(double number, int positon) {
    var temp = number.toString();
    if ((temp.length - temp.lastIndexOf('.') - 1) <= positon) {
      return number.toStringAsFixed(positon);
    } else {
      return temp.substring(0, temp.lastIndexOf('.') + positon + 1);
    }
  }

  @override
  Widget build(BuildContext context) {
    return [
      Image(
        image: AssetImage(ImgRes.IMG_BACK_TEST),
        fit: BoxFit.cover,
        width: AppStyle.adapter(64),
        height: AppStyle.adapter(64),
      ).intoClipRRect(borderRadius: BorderRadius.circular(AppStyle.adapter(5))),
      [
        Text(widget.text,
            style: AppTextStyle.buildB(ColorRes.color_333333, 15)),
        SizedBox(height: AppStyle.adapter(5)),
        Text(clickCount, style: AppTextStyle.build(ColorRes.color_999999, 10)),
        SizedBox(height: AppStyle.adapter(5)),
        Text(widget.desc, style: AppTextStyle.build(ColorRes.color_999999, 11))
      ]
          .intoColumn(crossAxisAlignment: CrossAxisAlignment.start)
          .intoContainer(
              padding: EdgeInsets.symmetric(horizontal: AppStyle.adapter(10)))
          .intoExpanded(),
      Text(StringRes.str_download, style: AppTextStyle.build(Colors.white, 14))
          .intoCenter()
          .onPackageContainer(
            radius: AppStyle.adapter(12.5),
            width: AppStyle.adapter(60),
            height: AppStyle.adapter(25),
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: const Color(0xffff694b).add(const Color(0xffff247d)),
          )
          .intoGestureDetector(onTap: _onTapClick),
    ]
        .intoRow()
        .intoPadding(padding: EdgeInsets.only(bottom: AppStyle.adapter(20.5)));
  }
}
