import 'package:flutter/material.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/widget/page_title_bar_widget.dart';

class SettledPage extends StatefulWidget {
  const SettledPage({Key key}) : super(key: key);

  @override
  _SettledPageState createState() => _SettledPageState();
}

class _SettledPageState extends State<SettledPage>
    with SingleTickerProviderStateMixin {
  TabController _tabController;
  List tabs = ["认证仔仔", "认证商家"];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: tabs.length, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            PageTitleBarWidget(
              title: '平台入驻',
            ),
            Container(
              width: 200,
              height: 30,
              margin: EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                    width: 1,
                    color: ColorRes.color_6c5aef,
                    style: BorderStyle.solid),
                borderRadius: BorderRadius.circular(20),
              ),
              child: TabBar(
                labelColor: Colors.white,
                unselectedLabelColor: ColorRes.color_6c5aef,
                indicatorSize: TabBarIndicatorSize.tab,
                controller: _tabController,
                indicator: BoxDecoration(
                    color: ColorRes.color_6c5aef,
                    borderRadius: BorderRadius.circular(20)),
                tabs: tabs.map((e) => Tab(text: e)).toList(),
              ),
            ),
            Expanded(
                child: TabBarView(
              //构建
              controller: _tabController,
              children: tabs.map((e) {
                return Container(
                  alignment: Alignment.center,
                  child: Text(e, textScaleFactor: 1),
                );
              }).toList(),
            ))
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    // 释放资源
    _tabController.dispose();
    super.dispose();
  }
}
