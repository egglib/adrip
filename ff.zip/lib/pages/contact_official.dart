import 'package:flutter/material.dart';

class ContactOfficial extends StatefulWidget {
  const ContactOfficial({ Key key }) : super(key: key);

  @override
  _ContactOfficialState createState() => _ContactOfficialState();
}

class _ContactOfficialState extends State<ContactOfficial> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}