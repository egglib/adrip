import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:gtea/routers.dart';
import 'package:flutter/widgets.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/extension_widget.dart';
import 'package:gtea/widget/img_widget.dart';
import 'package:gtea/res/img_res.dart';

class MyPage extends StatefulWidget {
  const MyPage({Key key}) : super(key: key);

  @override
  _MyPageState createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  var dataLoading = true;
  var networkError = false;

  final _margin = EdgeInsets.symmetric(horizontal: AppStyle.adapter(15));

  @override
  void initState() {
    super.initState();
  }

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
  }

  /// system message & setting
  ///
  Widget messageWithSettingWidget() {
    return ImgWidget.buildLocalImg(ImgRes.MY_MSG_ICON,
            width: 21, height: 19, callback: () {})
        .intoPadding(
            padding: EdgeInsets.symmetric(horizontal: AppStyle.adapter(7)))
        .addWidget(ImgWidget.buildLocalImg(ImgRes.MY_SET_ICON,
                width: 21, height: 19, callback: () {})
            .intoPadding(
                padding: EdgeInsets.only(
                    left: AppStyle.adapter(7), right: AppStyle.pagePadding)))
        .intoRow(mainAxisAlignment: MainAxisAlignment.end);
  }

  Widget userInfoWidget() {
    var mbrType = Text('VIP永久', style: AppTextStyle.white_s12).intoContainer(
        margin: EdgeInsets.only(left: AppStyle.adapter(10)),
        padding: EdgeInsets.only(left: AppStyle.adapter(25.5)),
        alignment: Alignment.centerLeft,
        width: AppStyle.adapter(76),
        height: AppStyle.adapter(22),
        decoration: BoxDecorationExt.image(ImgRes.MY_MBR_TYPE));

    return ImgWidget.buildCircleAvatar(ImgRes.IMG_BACK_TEST,
            width: AppStyle.adapter(57), height: AppStyle.adapter(57))
        .addWidget(Text('xxxxxxxx', style: AppTextStyle.c1b1b2e_s20)
            .addWidget(SizedBox(height: AppStyle.adapter(5.5)))
            .addWidget([Text('121', style: AppTextStyle.c909090_s14), mbrType]
                .intoRow())
            .intoColumn(crossAxisAlignment: CrossAxisAlignment.start)
            .intoContainer(
                padding: EdgeInsets.only(left: AppStyle.adapter(12))))
        .intoRow()
        .intoContainer(height: AppStyle.adapter(57), margin: _margin);
  }

  /// mbr date
  ///
  Widget mbrStatusWidget() {
    return [
      Image.asset(ImgRes.MY_MBR_ICON,
          width: AppStyle.adapter(25.5), height: AppStyle.adapter(20)),
      Text('别币会员 2020-12-02到期',
              style: AppTextStyle.build(const Color(0xfff9e2be), 14))
          .intoPadding(padding: EdgeInsets.only(left: AppStyle.adapter(9.5)))
          .intoExpanded(),
      GestureDetector(
          onTap: _openMbrAction,
          child: Text('立即续费', style: AppTextStyle.c333333_s12)
              .intoCenter()
              .onPackageContainer(
                  radius: AppStyle.adapter(12.5),
                  width: AppStyle.adapter(70.5),
                  height: AppStyle.adapter(22.5),
                  colors: const Color(0xfffaeed5).add(const Color(0xffdbaa8b))))
    ].intoRow().intoContainer(
        margin: _margin,
        padding: EdgeInsets.only(
            left: AppStyle.adapter(13), right: AppStyle.adapter(15)),
        height: AppStyle.adapter(48),
        decoration: BoxDecorationExt.image(ImgRes.MY_MBR_BACK));
  }

  /// open member
  _openMbrAction() {
    context.push(Routers.login);
  }

  ///
  ///
  Widget itemActionWidget(String title, String actionTxt, String assetPath,
      List<Color> colors, Color shadowColor,
      {VoidCallback callback}) {
    return Text(title, style: AppTextStyle.white_s14_bold)
        .addWidget(Text(actionTxt, style: AppTextStyle.white_s12)
            .intoCenter()
            .onPackageContainer(
                radius: AppStyle.adapter(10.5),
                margin: EdgeInsets.only(top: AppStyle.adapter(6)),
                width: AppStyle.adapter(69.5),
                height: AppStyle.adapter(21.5),
                boxBgColor: Colors.white,
                colors: colors,
                shadowRadius: AppStyle.adapter(4.5),
                shadowColor: shadowColor,
                shadowOffset:
                    Offset(AppStyle.adapter(1.7), AppStyle.adapter(1.9)))
            .intoGestureDetector(onTap: callback))
        .intoColumn(crossAxisAlignment: CrossAxisAlignment.start)
        .intoContainer(
            width: AppStyle.adapter(167.5),
            padding: EdgeInsets.only(
                top: AppStyle.adapter(10), left: AppStyle.adapter(12.5)),
            decoration: BoxDecorationExt.image(assetPath));
  }

  Widget atOnceRowWidget() {
    return itemActionWidget(
            '金币余额:300',
            '立即充值',
            ImgRes.MY_OVER_BACK,
            const Color(0x59ffd1aa).add(const Color(0x59ffc892)),
            const Color(0x51f4ae66),
            callback: () {})
        .addWidget(itemActionWidget(
            '领取免费会员',
            '立即领取',
            ImgRes.MY_FREE_BACK,
            const Color(0x59ffbdba).add(const Color(0x59ffaca7)),
            const Color(0x51eb3b30),
            callback: () {}))
        .intoRow(mainAxisAlignment: MainAxisAlignment.spaceBetween)
        .intoContainer(height: AppStyle.adapter(62.5), margin: _margin);
  }

  ///
  ///
  Widget workspaceWidget() {
    return Text('工作空间', style: AppTextStyle.white_s15_bold)
        .intoPadding(padding: EdgeInsets.only(left: AppStyle.adapter(28)))
        .addWidget(Text('进入', style: AppTextStyle.white_s15_bold)
            .addWidget(Image(
              image: AssetImage(ImgRes.MY_WORK_ICON),
              width: AppStyle.adapter(24.5),
              height: AppStyle.adapter(25),
            ).intoPadding(
                padding: EdgeInsets.only(
                    left: AppStyle.adapter(8),
                    top: AppStyle.adapter(3),
                    right: AppStyle.adapter(15))))
            .intoRow()
            .intoGestureDetector(onTap: () {
          context.push(Routers.settled);
        }))
        .intoRow(mainAxisAlignment: MainAxisAlignment.spaceBetween)
        .intoContainer(
            margin: _margin,
            height: AppStyle.adapter(42.5),
            decoration: BoxDecorationExt.image(ImgRes.MY_WORK_BACK));
  }

  /// common functions
  ///
  var operList = [
    {
      'name': '关注收藏',
      'icon': ImgRes.MY_FUNC_00,
      'router': Routers.attentionCollect
    },
    {'name': '我的购买', 'icon': ImgRes.MY_FUNC_01, 'router': Routers.myBought},
    {'name': '我的预约', 'icon': ImgRes.MY_FUNC_02, 'router': Routers.myReserve},
    {'name': '我的卡券', 'icon': ImgRes.MY_FUNC_03, 'router': Routers.myCoupon},
    {
      'name': '银币商场',
      'icon': ImgRes.MY_FUNC_04,
      'router': Routers.sliverCoinMall
    },
    {
      'name': '在线客服',
      'icon': ImgRes.MY_FUNC_05,
      'router': Routers.onlineService
    },
    {'name': '邀请赚钱', 'icon': ImgRes.MY_FUNC_06, 'router': Routers.myInvite},
    {'name': '快速隐身', 'icon': ImgRes.MY_FUNC_07, 'router': Routers.quickHidden},
    {
      'name': '联系官方',
      'icon': ImgRes.MY_FUNC_08,
      'router': Routers.contactOfficial
    },
    {'name': '应用推荐', 'icon': ImgRes.MY_FUNC_09, 'router': Routers.appCenter},
  ];

  Widget operateListWidget() {
    var width = AppStyle.screenWidth * 0.25 -
        0.5 * (AppStyle.pagePadding + AppStyle.adapter(7));
    List<Widget> tempList = [];
    for (var value in operList) {
      tempList.add(GestureDetector(
          onTap: () {
            context.push(value['router']);
          },
          child: [
            Image.asset(
              value['icon'],
              width: AppStyle.adapter(45),
              height: AppStyle.adapter(45),
            ),
            SizedBox(height: AppStyle.adapter(6)),
            Text(
              value['name'],
              overflow: TextOverflow.ellipsis,
              style: AppTextStyle.c3e4559_s13,
            ),
          ].intoColumn().intoSizedBox(width: width)));
    }
    return Wrap(
      runSpacing: AppStyle.adapter(28),
      children: tempList,
    ).intoPadding(
      padding: EdgeInsets.symmetric(
        vertical: AppStyle.adapter(24.5),
        horizontal: AppStyle.adapter(3.5),
      ),
    );
  }

  // Widget

  @override
  Widget build(BuildContext context) {
    //var isLogin = (['', null, false].contains(Global.apiToken)) ? false : true;
    return Scaffold(
      body: messageWithSettingWidget()
          .addWidget(SizedBox(height: AppStyle.adapter(13.5)))
          .addWidget(userInfoWidget())
          .addWidget(SizedBox(height: AppStyle.adapter(22.5)))
          .addWidget(mbrStatusWidget())
          .addWidget(SizedBox(height: AppStyle.adapter(13.5)))
          .addWidget(atOnceRowWidget())
          .addWidget(SizedBox(height: AppStyle.adapter(13.5)))
          .addWidget(workspaceWidget())
          .addWidget(SizedBox(height: AppStyle.adapter(29.5)))
          .addWidget([
            Text('常用功能', style: AppTextStyle.c1b1b2e_s15).intoPadding(
                padding: EdgeInsets.only(left: AppStyle.adapter(24)))
          ].intoRow())
          .addWidget(SizedBox(height: AppStyle.adapter(13.5)))
          .addWidget(operateListWidget().onPackageContainer(
              radius: AppStyle.adapter(10),
              boxBgColor: Colors.white,
              shadowRadius: AppStyle.adapter(5),
              shadowColor: Colors.black12))
          .addWidget(SizedBox(height: AppStyle.adapter(13.5)))
          .intoColumn()
          .intoSingleChildScrollView()
          .intoRefreshWidget(onRefresh: _onRefresh)
          .intoSafeArea()
          .onPackageContainer(
              assetPath: ImgRes.MY_TOP_BACK,
              imageAlignment: Alignment.topCenter),
    );
  }
}
