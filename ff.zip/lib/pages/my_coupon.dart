import 'package:flutter/material.dart';

class MyCoupon extends StatefulWidget {
  const MyCoupon({ Key key }) : super(key: key);

  @override
  _MyCouponState createState() => _MyCouponState();
}

class _MyCouponState extends State<MyCoupon> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}