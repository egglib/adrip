import 'package:flutter/material.dart';
import 'package:gtea/widget/load_state_widget.dart';

class ActivityPage extends StatefulWidget {
  const ActivityPage({Key key}) : super(key: key);

  @override
  _ActivityPageState createState() => _ActivityPageState();
}

class _ActivityPageState extends State<ActivityPage> {

  LoadState state = LoadState.STATE_NO_NETWORK;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: LoadSateWidget(
          state: state,
          emptyRetry: () {
            setState(() {
              state = LoadState.STATE_LOADING;
            });
          },
          errorRetry: () {
            setState(() {
              state = LoadState.STATE_LOADING;
            });
          },
          noNetWorkRetry: () {
            setState(() {
              state = LoadState.STATE_LOADING;
            });
          },
        ),
      ),
    );
  }
}
