import 'dart:async';

import 'package:flutter/material.dart';
import 'package:gtea/navigator/tab_navigator.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({Key key}) : super(key: key);

  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  int curIndex = 0;

  toHome() {
    curIndex = 1;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    Timer.periodic(Duration(microseconds: 500), (timer) {
      toHome();
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        child: Scaffold(
          body: GestureDetector(
            onTap: () {
              FocusScopeNode currentFocus = FocusScope.of(context);
              if (!currentFocus.hasPrimaryFocus &&
                  currentFocus.focusedChild != null) {
                FocusManager.instance.primaryFocus.unfocus();
              }
            },
            behavior: HitTestBehavior.translucent,
            child: IndexedStack(
              index: curIndex,
              children: [
                Container(
                  color: Colors.transparent,
                  child: null,
                ),
                curIndex != 1 ? Container() : TabNavigator()
              ],
            ),
          ),
        ),
        onWillPop: () {});
  }
}
