import 'package:flutter/material.dart';

class MyReserve extends StatefulWidget {
  const MyReserve({ Key key }) : super(key: key);

  @override
  _MyReserveState createState() => _MyReserveState();
}

class _MyReserveState extends State<MyReserve> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}