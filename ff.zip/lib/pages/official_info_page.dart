import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/app_widget.dart';
import 'package:gtea/widget/banner_widget.dart';
import 'package:gtea/widget/img_widget.dart';
import 'package:gtea/widget/list_widget.dart';
import 'package:gtea/widget/space_widget.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class OfficialInfoPage extends StatefulWidget {
  const OfficialInfoPage({Key key}) : super(key: key);

  @override
  _OfficialInfoPageState createState() => _OfficialInfoPageState();
}

class _OfficialInfoPageState extends State<OfficialInfoPage> {
  double gridItemWidth;
  double gridItemHeight;

  @override
  void initState() {
    super.initState();
    gridItemWidth = (ScreenUtil().screenWidth - ScreenUtil().setWidth(45)) / 2;
    gridItemHeight = gridItemWidth * 4 / 3;
  }

  @override
  Widget build(BuildContext context) {
    return SmartRefresher(
        controller: RefreshController(),
        header: WaterDropHeader(),
        child: ListView(
          padding: EdgeInsets.only(
              left: AppStyle.pagePadding, right: AppStyle.pagePadding),
          children: [
            BannerWidget.buildBigBanner(context, 3, callback: () {}),
            SpaceWidget.v_space_20,
            _recommendAvatarListSection(),
            SpaceWidget.v_space_10,
            _infoTitleSection(),
            SpaceWidget.v_space_20,
            ListWidget.buildGridView(
                10,
                (context, index) => Container(
                      width: gridItemWidth,
                      height: gridItemHeight,
                      child: Center(
                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(5),
                                  topRight: Radius.circular(5)),
                              child: Stack(
                                children: [
                                  Image.asset(
                                    ImgRes.IMG_BACK_TEST,
                                    fit: BoxFit.cover,
                                    width: gridItemWidth - 4,
                                    height: gridItemHeight -
                                        ScreenUtil().setWidth(60),
                                  ),
                                  Container(
                                    constraints: BoxConstraints(
                                      maxWidth: gridItemWidth - 10,
                                    ),
                                    padding: const EdgeInsets.only(
                                        left: 6, top: 2, right: 6, bottom: 2),
                                    decoration: const BoxDecoration(
                                        gradient: LinearGradient(
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                            colors: [
                                              ColorRes.color_7f85f4,
                                              ColorRes.color_6c5aef
                                            ]),
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(5),
                                            topRight: Radius.circular(3),
                                            bottomRight: Radius.circular(3))),
                                    child: RichText(
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      text: TextSpan(
                                          text: '魅力值',
                                          style: AppTextStyle.white_s12,
                                          children: [
                                            TextSpan(
                                                text: '90',
                                                style: AppTextStyle.cfef693_s12)
                                          ]),
                                    ),
                                  ),
                                  Positioned(
                                      bottom: 5,
                                      right: 5,
                                      child: Container(
                                        constraints: BoxConstraints(
                                          maxWidth: gridItemWidth - 15,
                                        ),
                                        padding: const EdgeInsets.fromLTRB(
                                            5, 1, 5, 1),
                                        margin: const EdgeInsets.only(
                                            left: 5, top: 5),
                                        decoration: const BoxDecoration(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(3)),
                                            gradient: LinearGradient(
                                                begin: Alignment.topLeft,
                                                end: Alignment.bottomRight,
                                                colors: [
                                                  ColorRes.color_89ebff,
                                                  ColorRes.color_f4aef4,
                                                  ColorRes.color_facf60,
                                                ])),
                                        child: Text(
                                          '213人约过',
                                          style: AppTextStyle.white_s11,
                                        ),
                                      ))
                                ],
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.only(right: 2),
                              width: gridItemWidth - 4,
                              height: ScreenUtil().setWidth(60),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.black.withOpacity(0.05),
                                        spreadRadius: 1.0,
                                        offset: Offset(0.0, 1.0),
                                        blurRadius: 1.0),
                                  ],
                                  borderRadius: BorderRadius.vertical(
                                      bottom: Radius.circular(
                                          ScreenUtil().setWidth(5)))),
                              child: Container(
                                  padding: EdgeInsets.only(
                                      left: 10, top: 10, right: 10),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "健身教练",
                                        style: AppTextStyle.c30313f_s15,
                                      ),
                                      Container(
                                        child: Text(
                                          "20岁 178CM 可1可0 一次200 ",
                                          style: AppTextStyle.c646464_s11,
                                        ),
                                        padding: EdgeInsets.only(top: 3),
                                      )
                                    ],
                                  )),
                            )
                          ],
                        ),
                      ),
                    ),
                childRatio: 0.75,
                crossCount: 2),
          ],
        ));
  }

  Row _infoTitleSection() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        AppWidget.blueVerticalLine,
        SpaceWidget.h_space_6,
        Expanded(
            child: Text(
          '全国性息',
          style: AppTextStyle.c30313f_s18_bold,
        )),
        SpaceWidget.h_space_6,
        Text(StringRes.str_beijing, style: AppTextStyle.c30313f_s14),
        SpaceWidget.h_space_3,
        AppWidget.iconLocation,
        SpaceWidget.h_space_15,
        Text(StringRes.str_filter, style: AppTextStyle.c30313f_s14),
        SpaceWidget.h_space_3,
        AppWidget.iconFilter,
      ],
    );
  }

  SizedBox _recommendAvatarListSection() {
    return SizedBox(
      height: ScreenUtil().setWidth(80),
      child: ListView.builder(
        itemCount: 10,
        scrollDirection: Axis.horizontal,
        physics: BouncingScrollPhysics(),
        itemBuilder: (BuildContext context, int index) {
          return Row(
            children: [
              SizedBox(
                width: ScreenUtil().setWidth(56),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildAvatarItem(),
                    SpaceWidget.h_space_6,
                    Text("巨屌", style: AppTextStyle.c999999_s12),
                  ],
                ),
              ),
              SpaceWidget.h_space_12
            ],
          );
        },
      ),
    );
  }

  GestureDetector _buildAvatarItem() {
    return GestureDetector(
      child: Stack(
        alignment: Alignment.center,
        children: [
          ClipOval(
              child: Container(
            width: ScreenUtil().setWidth(56),
            height: ScreenUtil().setWidth(56),
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                  ColorRes.color_89ebff,
                  ColorRes.color_f4aef4,
                  ColorRes.color_facf60
                ])),
          )),
          ClipOval(
              child: Container(
            width: ScreenUtil().setWidth(53),
            height: ScreenUtil().setWidth(53),
            color: Colors.white,
          )),
          ImgWidget.buildCircleAvatar(ImgRes.IMG_BACK_TEST,
              width: 49, height: 49)
        ],
      ),
      onTap: () {},
    );
  }
}
