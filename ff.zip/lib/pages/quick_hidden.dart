import 'package:flutter/material.dart';

class QuickHidden extends StatefulWidget {
  const QuickHidden({ Key key }) : super(key: key);

  @override
  _QuickHiddenState createState() => _QuickHiddenState();
}

class _QuickHiddenState extends State<QuickHidden> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}