import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/style/app_style.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/widget/banner_widget.dart';
import 'package:gtea/widget/hint_widget.dart';
import 'package:gtea/widget/img_widget.dart';
import 'package:gtea/widget/refresh_load_list_widget.dart';
import 'package:gtea/widget/space_widget.dart';
import 'package:gtea/widget/text_widget.dart';

class DynamicPage extends StatefulWidget {
  const DynamicPage({Key key}) : super(key: key);

  @override
  _DynamicPageState createState() => _DynamicPageState();
}

class _DynamicPageState extends State<DynamicPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: RefreshLoadListWidget(
          child: (dataList) {
            return ListView(
              // padding: EdgeInsets.only(
              //     left: AppStyle.pagePadding,
              //     right: AppStyle.pagePadding,
              //     top: AppStyle.pagePadding),
              children: [
                Padding(
                  padding: EdgeInsets.only(
                      left: AppStyle.pagePadding,
                      right: AppStyle.pagePadding,
                      top: AppStyle.pagePadding),
                  child:
                      BannerWidget.buildBigBanner(context, 3, callback: () {}),
                ),
                SpaceWidget.v_space_20,
                TextWidget.buildText('热门主题', AppTextStyle.c30313f_s18_bold,
                    leftPadding: AppStyle.pagePadding,
                    rightPadding: AppStyle.pagePadding),
                SpaceWidget.v_space_15,
                Padding(
                  padding: EdgeInsets.only(left: AppStyle.pagePadding),
                  child: _hotTopicListSection(),
                ),
                SpaceWidget.v_space_20,
                _buildListSection()
              ],
            );
          },
        ),
      ),
    );
  }

  ListView _buildListSection() {
    return ListView.builder(
        itemCount: 10,
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          return Column(
            children: [
              Padding(
                  padding: EdgeInsets.only(
                      left: AppStyle.pagePadding,
                      right: AppStyle.pagePadding,
                      top: AppStyle.pagePadding),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _userInfoSection(),
                      SpaceWidget.v_space_10,
                      Row(
                        children: [
                          Text(
                            "男神汇官方",
                            style: AppTextStyle.c30313f_s15,
                          ),
                        ],
                      ),
                      SpaceWidget.v_space_15,
                      Text(
                        "男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方男神汇官方",
                        style: AppTextStyle.c30313f_s15,
                        maxLines: 3,
                      ),
                      SpaceWidget.v_space_15,
                      _imgGridViewSection(),
                      SpaceWidget.v_space_10,
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.only(
                                left: 8, top: 3, right: 8, bottom: 3),
                            decoration: BoxDecoration(
                                color: ColorRes.color_f6f9f9,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            child: Text(
                              "#携程",
                              style: AppTextStyle.c3f3f3f_s11,
                            ),
                          ),
                          SpaceWidget.h_space_6,
                          Container(
                            padding: const EdgeInsets.only(
                                left: 8, top: 3, right: 8, bottom: 3),
                            decoration: BoxDecoration(
                                color: ColorRes.color_f6f9f9,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            child: Text(
                              "#携程是发",
                              style: AppTextStyle.c3f3f3f_s11,
                            ),
                          ),
                          Expanded(child: SizedBox()),
                          ImgWidget.buildImg(ImgRes.IC_SHARE,
                              width: 12, height: 12, isNet: false),
                          SpaceWidget.h_space_3,
                          Text(
                            "358",
                            style: AppTextStyle.c3f3f3f_s11,
                          ),
                          SpaceWidget.h_space_15,
                          ImgWidget.buildImg(ImgRes.IC_LIKE,
                              width: 12, height: 12, isNet: false),
                          SpaceWidget.h_space_3,
                          TextWidget.buildText("358", AppTextStyle.c3f3f3f_s11)
                        ],
                      )
                    ],
                  )),
              SpaceWidget.v_space_10,
              Container(
                color: ColorRes.color_f2f2f2,
                width: ScreenUtil().screenWidth,
                height: 3,
              )
            ],
          );
        });
  }

  GridView _imgGridViewSection() {
    return GridView.builder(
        itemCount: 9,
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisSpacing: ScreenUtil().setWidth(5),
            crossAxisSpacing: ScreenUtil().setWidth(5),
            childAspectRatio: 1,
            crossAxisCount: 3),
        itemBuilder: (context, index) {
          return ClipRRect(
            borderRadius: BorderRadius.all(Radius.circular(5)),
            child: Image.asset(
              ImgRes.IMG_BACK_TEST,
              fit: BoxFit.cover,
              width: ScreenUtil().setWidth(112),
              height: ScreenUtil().setWidth(112),
            ),
          );
        });
  }

  Row _userInfoSection() {
    return Row(
      children: [
        ImgWidget.buildCircleAvatar(ImgRes.BG_HOT_TOPIC, isNet: false,
            callback: () {
          HintWidget.showToast("头像被点击");
        }),
        SpaceWidget.h_space_10,
        TextWidget.buildText("男神汇官方", AppTextStyle.c30313f_s15)
      ],
    );
  }

  SizedBox _hotTopicListSection() {
    return SizedBox(
      height: ScreenUtil().setWidth(110),
      child: ListView.builder(
        itemCount: 10,
        physics: BouncingScrollPhysics(),
        scrollDirection: Axis.horizontal,
        itemBuilder: (BuildContext context, int index) {
          return Row(
            children: [
              Image.asset(
                ImgRes.BG_HOT_TOPIC,
                width: ScreenUtil().setWidth(240),
                height: ScreenUtil().setWidth(110),
              ),
              SpaceWidget.h_space_15
            ],
          );
        },
      ),
    );
  }

  _onRefresh() {}

  _onLoading() {}
}
