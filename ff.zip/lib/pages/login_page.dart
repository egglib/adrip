import 'dart:io';
import 'dart:typed_data';

import 'package:android_intent/android_intent.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:gtea/global.dart';
import 'package:gtea/model/config_model.dart';
import 'package:gtea/net/api_util.dart';
import 'package:gtea/net/rx_observer.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/img_res.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/routers.dart';
import 'package:gtea/style/app_text_style.dart';
import 'package:gtea/utils/img_util.dart';
import 'package:gtea/utils/log_util.dart';
import 'package:gtea/utils/permission_util.dart';
import 'package:gtea/utils/web_util.dart';
import 'package:gtea/widget/hint_widget.dart';
import 'package:gtea/widget/img_widget.dart';
import 'package:gtea/widget/page_title_bar_widget.dart';
import 'package:gtea/widget/rating_bar_widget.dart';
import 'package:gtea/widget/text_widget.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:qr_flutter/qr_flutter.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final String _url = 'https://flutter.dev';
  bool _isCheck;
  bool _isBoxCheck = false;
  GlobalKey certificateWidgetKey = GlobalKey();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _isCheck = false;
    _isBoxCheck = true;
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
        key: certificateWidgetKey,
        child: Scaffold(
            key: _scaffoldKey,
            endDrawer: Container(
              width: ScreenUtil().screenWidth * 4 / 5,
              color: Colors.white,
              child: ListView(
                // Important: Remove any padding from the ListView.
                padding: EdgeInsets.zero,
                children: [
                  ListTile(
                    title: const Text('Item 1'),
                    onTap: () {
                      print('-----Item----1-----');
                    },
                  ),
                  ListTile(
                    title: const Text('Item 2'),
                    onTap: () {
                      print('-----Item----2-----');
                    },
                  ),
                ],
              ),
            ),
            body: SafeArea(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PageTitleBarWidget(title: '详情页面'),
                    ElevatedButton(
                      onPressed: () {
                        AppGlobal.getIt<ApiUtil>().getConfig(RxObserver(
                            onSuccess: (data) {
                              ConfigModel config = ConfigModel.fromJson(data);
                              String notice = config.system_notice;
                              String system_group = config.version.tips;
                              LogUtil.i(notice);
                              LogUtil.i(system_group);
                            },
                            onFailure: () {}));
                      },
                      child: TextWidget.buildSimpleText(
                          '点击测试', AppTextStyle.white_s11),
                    ),
                    RatingBarWidget.buildHorizontalRatingBar(
                        initRating: 1,
                        onUpdate: (rating) {
                          print("rate----->" + rating.toString());
                        }),
                    ElevatedButton(
                        onPressed: () {
                          WebUtil.browserLaunchURL(_url);
                        },
                        child: TextWidget.buildSimpleText(
                            '跳转到浏览器', AppTextStyle.white_s11)),
                    Switch(
                        value: _isCheck,
                        activeColor: Colors.green,
                        inactiveTrackColor: ColorRes.color_999999,
                        onChanged: (isCheck) {
                          setState(() {
                            _isCheck = isCheck;
                          });
                        }),
                    QrImage(
                        data: "1234567890",
                        version: QrVersions.auto,
                        size: 150,
                        embeddedImage: AssetImage(ImgRes.IC_LOGO),
                        embeddedImageStyle: QrEmbeddedImageStyle(
                          size: Size(30, 30),
                        )),
                    ElevatedButton(
                        onPressed: () {
                          List<Permission> permissionList = [
                            Permission.storage,
                            Permission.camera
                          ];
                          PermissionUtil.check(permissionList,
                              onSuccess: () async {
                            ImgUtil.saveViewToImg(certificateWidgetKey);
                          }, onFail: () {
                            HintWidget.showToast(
                                StringRes.str_denied_permission_hint);
                          });
                        },
                        child: TextWidget.buildSimpleText(
                            '保存图片', AppTextStyle.white_s11)),
                    ElevatedButton(
                        onPressed: () async {
                          PermissionStatus storageStatus =
                              await Permission.camera.status;
                          if (storageStatus == PermissionStatus.denied) {
                            storageStatus = await Permission.camera.request();
                            if (storageStatus == PermissionStatus.denied ||
                                storageStatus ==
                                    PermissionStatus.permanentlyDenied) {
                              HintWidget.showToast(
                                  StringRes.str_denied_permission_hint);
                              return;
                            }
                          } else if (storageStatus ==
                              PermissionStatus.permanentlyDenied) {
                            HintWidget.showToast(
                                "无法保存到相册中，你关闭了存储权限，请前往设置中打开权限");
                            return;
                          }

                          XFile photos = await ImagePicker()
                              .pickImage(source: ImageSource.gallery);
                          LogUtil.i(photos.toString());
                        },
                        child: TextWidget.buildSimpleText(
                            '选择图片', AppTextStyle.white_s11)),
                    ElevatedButton(
                        onPressed: () async {
                          PermissionStatus storageStatus =
                              await Permission.camera.status;
                          if (storageStatus == PermissionStatus.denied) {
                            storageStatus = await Permission.camera.request();
                            if (storageStatus == PermissionStatus.denied ||
                                storageStatus ==
                                    PermissionStatus.permanentlyDenied) {
                              HintWidget.showToast(
                                  StringRes.str_denied_permission_hint);
                              return;
                            }
                          } else if (storageStatus ==
                              PermissionStatus.permanentlyDenied) {
                            HintWidget.showToast(
                                "无法保存到相册中，你关闭了存储权限，请前往设置中打开权限");
                            return;
                          }

                          XFile photos = await ImagePicker()
                              .pickImage(source: ImageSource.camera);
                          LogUtil.i(photos.path.toString());
                        },
                        child: TextWidget.buildSimpleText(
                            '拍照', AppTextStyle.white_s11)),
                    Checkbox(
                        shape: CircleBorder(),
                        activeColor: ColorRes.color_ff334b,
                        side:
                            BorderSide(color: ColorRes.color_9ea1ad, width: 1),
                        value: _isBoxCheck,
                        onChanged: (value) {
                          setState(() {
                            _isBoxCheck = value;
                          });
                        }),
                    ElevatedButton(
                        onPressed: () {
                          context.push(Routers.webview, extra: {
                            'title': 'flutter官网',
                            'url': 'https://flutter.dev'
                          });
                        },
                        child: TextWidget.buildSimpleText(
                            '跳转到webview', AppTextStyle.white_s11)),
                    ElevatedButton(
                        onPressed: () {
                          _scaffoldKey.currentState.openEndDrawer();
                          // Scaffold.of(context).openDrawer();
                        },
                        child: TextWidget.buildSimpleText(
                            '打开抽屉', AppTextStyle.white_s11)),
                  ],
                ),
              ),
            )));
  }
}
