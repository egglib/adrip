import 'package:flutter/material.dart';

class OnlineService extends StatefulWidget {
  const OnlineService({ Key key }) : super(key: key);

  @override
  _OnlineServiceState createState() => _OnlineServiceState();
}

class _OnlineServiceState extends State<OnlineService> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}