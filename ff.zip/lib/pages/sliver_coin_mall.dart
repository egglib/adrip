import 'package:flutter/material.dart';

class SliverCoinMall extends StatefulWidget {
  const SliverCoinMall({ Key key }) : super(key: key);

  @override
  _SliverCoinMallState createState() => _SliverCoinMallState();
}

class _SliverCoinMallState extends State<SliverCoinMall> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}