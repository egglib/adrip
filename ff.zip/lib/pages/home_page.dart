import 'package:flutter/material.dart';
import 'package:gtea/base/base_state.dart';
import 'package:gtea/model/nav_item.dart';
import 'package:gtea/navigator/scroll_tab_navigator.dart';
import 'package:gtea/presenter/home_page_presenter.dart';
import 'package:gtea/view/abs_home_page_view.dart';

import 'national_info_page.dart';
import 'official_info_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends BaseState<HomePagePresenter, HomePage>
    implements AbsHomePageView {
  List<NavItem> navItems = <NavItem>[];
  List<Widget> pages = <Widget>[];

  @override
  void initState() {
    super.initState();
    NavItem item = NavItem(id: 12, name: "全国性息");
    navItems.add(item);

    NavItem item1 = NavItem(id: 13, name: "官方仔仔");
    navItems.add(item1);

    pages.add(const NationalInfoPage());
    pages.add(const OfficialInfoPage());
  }

  @override
  Widget buildAppBar() {
    return Container();
  }

  @override
  Widget buildPageLayout() {
    return ScrollTabNavigator(
        navItems: navItems, pages: pages, onNavIndexChanged: (index) {});
  }

  @override
  HomePagePresenter createPresenter() {
    return HomePagePresenter();
  }

  @override
  bool isShowTitle() {
    // TODO: implement isShowTitle
    throw UnimplementedError();
  }

}
