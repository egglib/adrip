import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/utils/log_util.dart';
import 'package:gtea/widget/search_bar_widget.dart';

class HomeSearchPage extends StatefulWidget {
  const HomeSearchPage({Key key}) : super(key: key);

  @override
  _HomeSearchPageState createState() => _HomeSearchPageState();
}

class _HomeSearchPageState extends State<HomeSearchPage> {
  TextInputType boardType = TextInputType.text;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          child: SearchBarWidget(
            hint: StringRes.str_search_hint,
            hideBack: true,
            onChanged: _onChanged,
            onSubmit: _onSubmit,
          ),
        ),
      ),
    );
  }

  void _onSubmit(String value) {
    LogUtil.i("_onSubmit-------${value}");
  }

  void _onChanged(String value) {
    LogUtil.i("_onChanged-------${value}");
  }
}
