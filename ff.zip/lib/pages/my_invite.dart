import 'package:flutter/material.dart';

class MyInvite extends StatefulWidget {
  const MyInvite({ Key key }) : super(key: key);

  @override
  _MyInviteState createState() => _MyInviteState();
}

class _MyInviteState extends State<MyInvite> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}