import 'package:flutter/material.dart';

class MyBought extends StatefulWidget {
  const MyBought({ Key key }) : super(key: key);

  @override
  _MyBoughtState createState() => _MyBoughtState();
}

class _MyBoughtState extends State<MyBought> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}