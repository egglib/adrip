import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BarUtil {

  static void setBarUi(
      {Color color = Colors.transparent, Brightness status = Brightness.dark}) {
    if (Platform.isAndroid) {
      SystemUiOverlayStyle systemUiOverlayStyle = SystemUiOverlayStyle(
          systemNavigationBarColor: Colors.white,
          statusBarColor: color,
          statusBarIconBrightness: status);
      SystemChrome.setSystemUIOverlayStyle(systemUiOverlayStyle);
    }
  }
}
