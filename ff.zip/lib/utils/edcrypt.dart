import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:encrypt/encrypt.dart';
import 'package:hex/hex.dart';

final key = Key.fromUtf8("7156aeedfa08a0fb");
final iv = IV.fromUtf8("c7d70229ccbfe36d");
const appkey = "8409fe8162017d4c91a6eb8657382a17";

final mediaKey = Key.fromUtf8("f5d965df75336270");
final mediaIv = IV.fromUtf8("97b60394abc2fbe1");

String getSign(Map obj) {
  String md5Text;
  List keyValues = [];
  keyValues.add("data=${obj['data']}");
  keyValues.add("timestamp=${obj['timestamp']}");
  String text = '${keyValues.join('&')}$appkey';
  Digest _digest = sha256.convert(utf8.encode(text));
  md5Text = md5.convert(utf8.encode(_digest.toString())).toString();
  return md5Text;
}

class AppEDCrypt {
  static Future<dynamic> encryptReqParams(String params) async {
    Encrypter encryptor = Encrypter(AES(key, mode: AESMode.cbc));
    Encrypted encrypted = encryptor.encryptBytes(utf8.encode(params), iv: iv);
    String data = utf8.decode(encrypted.base64.codeUnits);
    int timestamp = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    String sign = getSign({"data": data, "timestamp": timestamp});
    return "timestamp=$timestamp&data=$data&sign=$sign";
  }

  static Future<String> decryptResData(dynamic data) async {
    Encrypter encryptor = Encrypter(AES(key, mode: AESMode.cbc));
    Encrypted encrypted = Encrypted.fromBase64(data);
    String decrypted = encryptor.decrypt(encrypted, iv: iv);
    return decrypted;
  }

  static dynamic decryptImage(data) {
    try {
      Encrypter encryptor = Encrypter(AES(mediaKey, mode: AESMode.cbc));
      String encoded = base64.encode(HEX.decode(data));
      Encrypted encrypted = Encrypted.fromBase64(encoded);
      final stopwatch = Stopwatch()..start();
      String decrypted = encryptor.decrypt(encrypted, iv: mediaIv);
      var a = base64.decode(decrypted);
      return a;
    } catch (err) {
      return null;
    }
  }

  static dynamic decryptM3U8(data) {
    try {
      Encrypter encryptor = Encrypter(AES(mediaKey, mode: AESMode.cbc));
      Encrypted encrypted = Encrypted.fromBase64(data);
      final stopwatch = Stopwatch()..start();
      String decrypted = encryptor.decrypt(encrypted, iv: mediaIv);
      return decrypted;
    } catch (err) {
      return null;
    }
  }
}
