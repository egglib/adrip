import 'dart:io';

import 'package:android_intent/android_intent.dart';
import 'package:flutter/cupertino.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/widget/hint_widget.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionUtil {
  static VoidCallback defaultCall = () {};

  static void check(List<Permission> permissionList,
      {String errMsg,
      VoidCallback onSuccess,
      VoidCallback onFail,
      VoidCallback onOpenSetting = _openSetting}) async {
    bool isAllGranted = true;

    for (var permission in permissionList) {
      var status = await permission.status;
      if (!status.isGranted) {
        isAllGranted = false;
        break;
      }
    }

    if (!isAllGranted) {
      PermissionStatus permissionStatus =
          await requestPermission(permissionList);
      if (permissionStatus.isGranted) {
        onSuccess != null ? onSuccess() : defaultCall();
      } else if (permissionStatus.isDenied) {
        onFail != null ? onFail() : defaultCall();
      } else if (permissionStatus.isPermanentlyDenied) {
        onOpenSetting != null ? onOpenSetting() : defaultCall();
      } else if (permissionStatus.isRestricted) {
        //iOS单独处理
        onOpenSetting != null ? onOpenSetting() : defaultCall();
      } else if (permissionStatus.isLimited) {
        //iOS单独处理
        onOpenSetting != null ? onOpenSetting() : defaultCall();
      }
    } else {
      onSuccess != null ? onSuccess() : defaultCall();
    }
  }

  static _openSetting() async {
    if (Platform.isAndroid) {
      AndroidIntent intent = const AndroidIntent(
        action: 'android.settings.SETTINGS',
      );
      await intent.launch();
    } else {
      HintWidget.showToast(StringRes.str_denied_permission_hint);
    }
  }

  static Future<PermissionStatus> requestPermission(
      List<Permission> permissionList) async {
    Map<Permission, PermissionStatus> statuses = await permissionList.request();
    PermissionStatus curPermissionStatus = PermissionStatus.granted;
    statuses.forEach((key, value) {
      if (!value.isGranted) {
        curPermissionStatus = value;
        return;
      }
    });
    return curPermissionStatus;
  }
}
