import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:gtea/res/string_res.dart';
import 'package:gtea/widget/hint_widget.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'dart:ui' as ui;

class ImgUtil {

  static Future<void> saveViewToImg(GlobalKey globalKey) async {
    RenderRepaintBoundary boundary =
        globalKey.currentContext.findRenderObject();
    ui.Image image = await boundary.toImage(pixelRatio: 3.0);
    ByteData byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    Uint8List pngBytes = byteData.buffer.asUint8List();
    final result = await ImageGallerySaver.saveImage(pngBytes);
    if (result['isSuccess']) {
      HintWidget.showToast(StringRes.str_save_success);
    } else {
      HintWidget.showToast(StringRes.str_save_fail);
    }
  }
}
