import 'dart:developer';

import 'package:gtea/app_const.dart';

class LogUtil {
  static void i(dynamic obj) {
    if (AppConst.isDebug) {
      log(obj.toString());
    }
  }
}
