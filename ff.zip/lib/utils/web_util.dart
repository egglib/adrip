import 'package:gtea/widget/hint_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class WebUtil {
  static void browserLaunchURL(String url) async {
    try {
      await launch(url, forceSafariVC: false);
    } catch (e) {
      HintWidget.showToast("加载失败，请检查网址后重试");
    }
  }
}
