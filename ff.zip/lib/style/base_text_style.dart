import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BaseTextStyle {
  static TextStyle buildTextStyle(Color color, double fontSize,
      {TextOverflow overflow = TextOverflow.ellipsis,
      FontWeight fontWeight = FontWeight.normal,
      TextDecoration decoration = TextDecoration.none}) {
    return TextStyle(
        color: color,
        fontSize: ScreenUtil().setSp(fontSize),
        overflow: overflow,
        fontWeight: fontWeight,
        decoration: decoration);
  }
}
