// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gtea/res/color_res.dart';
import 'package:gtea/res/dimen_res.dart';

import 'base_text_style.dart';

class AppTextStyle {
  static TextStyle bottomNavBarTextStyleNormal =
      BaseTextStyle.buildTextStyle(ColorRes.color_b2b8c6, DimenRes.dimen_11);

  static TextStyle bottomNavBarTextStyleActive =
      BaseTextStyle.buildTextStyle(ColorRes.color_374358, DimenRes.dimen_11);

  static TextStyle c999999_s12 =
      BaseTextStyle.buildTextStyle(ColorRes.color_999999, DimenRes.dimen_12);

  static TextStyle c999999_s14 =
      BaseTextStyle.buildTextStyle(ColorRes.color_999999, DimenRes.dimen_14);

  static TextStyle c999999_s15 =
  BaseTextStyle.buildTextStyle(ColorRes.color_999999, DimenRes.dimen_15);

  static TextStyle cfef693_s12 =
      BaseTextStyle.buildTextStyle(ColorRes.color_fef693, DimenRes.dimen_12);

  static TextStyle c30313f_s18_bold = BaseTextStyle.buildTextStyle(
      ColorRes.color_30313f, DimenRes.dimen_18,
      fontWeight: FontWeight.bold);

  static TextStyle c333333_s18_bold = BaseTextStyle.buildTextStyle(
      ColorRes.color_333333, DimenRes.dimen_18,
      fontWeight: FontWeight.bold);

  static TextStyle c333333_s18 =
      BaseTextStyle.buildTextStyle(ColorRes.color_333333, DimenRes.dimen_18);

  static TextStyle white_s10 =
      BaseTextStyle.buildTextStyle(Colors.white, DimenRes.dimen_10);

  static TextStyle white_s11 =
      BaseTextStyle.buildTextStyle(Colors.white, DimenRes.dimen_11);

  static TextStyle white_s12 =
      BaseTextStyle.buildTextStyle(Colors.white, DimenRes.dimen_12);

  static TextStyle white_s14_bold = BaseTextStyle.buildTextStyle(
      Colors.white, DimenRes.dimen_14,
      fontWeight: FontWeight.w500);

  static TextStyle white_s15 =
      BaseTextStyle.buildTextStyle(Colors.white, DimenRes.dimen_15);

  static TextStyle white_s15_bold = BaseTextStyle.buildTextStyle(
      Colors.white, DimenRes.dimen_15,
      fontWeight: FontWeight.w500);

  static TextStyle c333333_s12 =
      BaseTextStyle.buildTextStyle(ColorRes.color_333333, DimenRes.dimen_12);

  static TextStyle c3e4559_s13 =
      BaseTextStyle.buildTextStyle(ColorRes.color_3e4559, DimenRes.dimen_12);

  static TextStyle c646464_s11 =
      BaseTextStyle.buildTextStyle(ColorRes.color_646464, DimenRes.dimen_11);

  static TextStyle c909090_s14 =
      BaseTextStyle.buildTextStyle(ColorRes.color_909090, DimenRes.dimen_15);

  static TextStyle c1b1b2e_s15 = BaseTextStyle.buildTextStyle(
      ColorRes.color_1b1b2e, DimenRes.dimen_15,
      fontWeight: FontWeight.w500);

  static TextStyle c1b1b2e_s20 = BaseTextStyle.buildTextStyle(
      ColorRes.color_1b1b2e, DimenRes.dimen_20,
      fontWeight: FontWeight.w500);

  static TextStyle c30313f_s20_bold = BaseTextStyle.buildTextStyle(
      ColorRes.color_30313f, DimenRes.dimen_20,
      fontWeight: FontWeight.bold);

  static TextStyle c30313f_s11 =
      BaseTextStyle.buildTextStyle(ColorRes.color_30313f, DimenRes.dimen_11);

  static TextStyle c30313f_s14 =
      BaseTextStyle.buildTextStyle(ColorRes.color_30313f, DimenRes.dimen_14);

  static TextStyle c30313f_s15 =
      BaseTextStyle.buildTextStyle(ColorRes.color_30313f, DimenRes.dimen_15);

  static TextStyle c30313f_s16 =
      BaseTextStyle.buildTextStyle(ColorRes.color_30313f, DimenRes.dimen_16);

  static TextStyle c3f3f3f_s11 =
      BaseTextStyle.buildTextStyle(ColorRes.color_3f3f3f, DimenRes.dimen_11);

  //
  static TextStyle build(Color color, double fontSize,
      {TextOverflow overflow = TextOverflow.ellipsis,
      FontWeight fontWeight = FontWeight.normal,
      TextDecoration decoration = TextDecoration.none}) {
    return TextStyle(
        color: color,
        fontSize: ScreenUtil().setSp(fontSize),
        overflow: overflow,
        fontWeight: fontWeight,
        decoration: decoration);
  }

  static TextStyle buildB(Color color, double fontSize) {
    return AppTextStyle.build(color, fontSize, fontWeight: FontWeight.w500);
  }
}
