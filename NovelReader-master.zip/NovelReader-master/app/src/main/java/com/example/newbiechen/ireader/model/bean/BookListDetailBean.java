package com.example.newbiechen.ireader.model.bean;

import java.util.List;

/**
 * Created by newbiechen on 17-5-2.
 */

public class BookListDetailBean {
    /**
     * _id : 57c3ffcabbba8a463aab9959
     * updated : 2016-08-29T09:49:09.726Z
     * title : 找到一批经典免费书，好赞啊！
     * author : {"_id":"576680476fc4bac56b03e67c","avatar":"/avatar/5a/70/5a7099dd2222576dce92ca2a03800f26","nickname":"路人甲","type":"normal","lv":8}
     * desc : 统统都是大神的书，不好看你抽我，看书还愁没钱么！
     * gender : female
     * created : 2016-08-29T09:26:34.832Z
     * tags : ["宠文","总裁","古代言情"]
     * stickStopTime : null
     * isDraft : false
     * isDistillate : null
     * collectorCount : 12164
     * books : [{"book":{"cat":"都市生活","_id":"58c1fd50bb87bc7024088fbc","title":"翻窗作案：老婆，你被潜了","author":"千羽兮","longIntro":"某日记者采访：\u201c厉总，请问你平时都喜欢玩些什么？\u201d　　 厉大总裁高深莫测了一会儿，紧接着甩出惊天话语，\u201c玩老婆\u2026\u2026\u201d　　 当晚，某女一身劲装，挥着小皮鞭出现在某男跟前，\u201c听说，你平时喜欢玩老婆？\u201d　　\u201c老婆，你听我解释\u2026\u2026\u201d　　\u201c想怎么玩？站着？坐着？躺着？还是\u2026\u2026\u201d　　\u201c老婆你来真的？\u201d　　\u201c你说呢？\u201d　 　后来，记者再问：\u201c厉总，你平常都喜欢玩些什么？\u201d　　 厉大总裁搂着怀里笑得灿烂动人的娇妻，\u201c老婆玩什么，我就玩什么。\u201d","majorCate":"都市","minorCate":"都市生活","cover":"/cover/14891086681579","site":"zhuishuvip","banned":0,"latelyFollower":3509,"wordCount":251043,"retentionRatio":28.97},"comment":""},{"book":{"cat":"豪门总裁","_id":"57e3a13bbec14e2878ca85c2","title":"强婚夺爱：腹黑老公，狠狠爱","author":"安不离","longIntro":"\u201c滚开！\u201d黑暗中，男人的声音冷冽残酷。\u201c我好热，对不起！\u201d话落，还未发育完全地身体再一次靠过去。\u201c再说一遍，给我滚开！\u201d男人再一次怒吼。\u201c对不起，我真的好热，你身上很凉快！\u201d她再一次像无尾熊一样贴了过去！\u201c你会后悔的，该死\u2026\u2026\u201d说完，体内的欲望再也不能靠意志压制，薄唇狠狠地压上她柔软丰润的嘴唇\u2026\u2026十六岁，为帮妈妈筹集手术费，尤樱把自己卖给了神秘人。原以为只是普通的肉体交易，却不想事后肚子里多了一个球。五岁入军营，十八岁成为帝国赫赫有名的将军，拥有无上功勋的太子殿下，从没想到，人生第一次失败就如此惨重。黑暗中一场蚀骨欢爱大戏，让他被敌人抓到把柄，被迫推迟登基大典，被迫远赴他乡。他发誓，要把所有耻辱加倍地报复回去\u2026\u2026六年后，一场酒醉，一夜情缘，他和她再次被命运安排在了一张床上。可是不久之后，他发现新来公司的女清洁工不光跟他一夜情，还有一个很像他自己的小弟弟\u2026\u2026","majorCate":"现代言情","minorCate":"豪门总裁","cover":"/agent/http://rm2.kingreader.com/book/1186903%2Fm%2F%5B640%5D_%E5%BC%BA%E5%A9%9A%E5%A4%BA%E7%88%B1%EF%BC%9A%E8%85%B9%E9%BB%91%E8%80%81%E5%85%AC%EF%BC%8C%E7%8B%A0%E7%8B%A0%E7%88%B1.jpg","site":"zhuishuvip","banned":0,"latelyFollower":1336,"wordCount":1069151,"retentionRatio":27.46},"comment":""},{"book":{"cat":"都市生活","_id":"58ac1549d14ef9be0c84b254","title":"甜妻来袭：饿狼老公，求放过","author":"安不离","longIntro":"富可敌国、霸道狂妄、杀伐决断的他，唯独心里只存了一个她。\u201c老公，我爱你！\u201d\u201c我也爱\u2026\u2026上你！\u201d\u201c老公，我想去潜水！\u201d\u201c水里更润滑。\u201d \u201c混蛋！我要跟你离婚！\u201d\u201c嗯？\u201d\u201c离婚！！！\u201d结果某男怒了，一吻封口，将她压在身下，攻占城池，单刀直入，一飞冲天\u2026\u2026某女人气得抓狂，听说只有累坏的牛，没有耕坏的田，于是她反将他压在身下，看看谁拼得过谁！","majorCate":"都市","minorCate":"都市生活","cover":"/cover/148781695980546","site":"zhuishuvip","banned":0,"latelyFollower":675,"wordCount":361543,"retentionRatio":12.81},"comment":""},{"book":{"cat":"豪门总裁","_id":"587efec12991180937366680","title":"误入豪门：弃妇大翻身","author":"晓风残月","longIntro":"一纸婚约，荣家三少荣瑾瑜娶了沐家空有名头的沐大小姐沐凉笙。洞房花烛夜，荣家三少留宿夜店，新婚第一天，沐家大小姐独自面对媒体追问。荣瑾瑜恶狠狠的问沐凉笙：\u201c那一定点的沐氏股份难道比你幸福生活更重要？\u201d沐凉笙回答：\u201c是！\u201d荣瑾瑜冷笑：\u201c沐凉笙，你让我觉得恶心！\u201d沐凉笙无所谓。三年之后，沐凉笙将已经签好名的离婚协议放在荣瑾瑜面前，她给他要的自由，沐家的股份，荣家的财富，她全都可以舍弃。而荣瑾瑜咬牙切齿：\u201c沐凉笙，这婚不是你想离，想离就能离的！\u201d","majorCate":"现代言情","minorCate":"豪门总裁","cover":"/agent/http://rm2.kingreader.com/book/1417376%2Fm%2F%5B640%5D_5MQ4_1395.jpg","site":"zhuishuvip","banned":0,"latelyFollower":605,"wordCount":231633,"retentionRatio":49.21},"comment":""},{"book":{"cat":"都市生活","_id":"589ab29d00c37d923b8eedde","title":"婚不可测：前夫来势汹汹","author":"花花桃子","longIntro":"她成了心上人的妻子，本以为可以终于真心相伴，最后却得知这只是他报复的开始。只是，这报复，怎么抱到床上了！！他振振有词，\u201c取悦我，也是你偿还的方式之一。\u201d她奋起反抗，得到的，则是被更加彻底的吃干抹净他笑得像是狐狸，\u201c老婆，没想到，你这么热情\u2026\u2026\u201d","majorCate":"现代言情","minorCate":"都市生活","cover":"/agent/http://rm2.kingreader.com/book/1422880%2Fm%2F%5B640%5D_AB8P_1493.jpg","site":"zhuishuvip","banned":0,"latelyFollower":294,"wordCount":368461,"retentionRatio":30.05},"comment":""},{"book":{"cat":"仙侠","_id":"5881b6fd8b53b19159ffb90a","title":"养猫成妻：夫君，哪里逃","author":"安柒月","longIntro":"素和大将军家的千金大小姐有个不为人知的秘密，她的命其实是一只黑猫续下去的！原以为一切都天衣无缝，谁知会遇上即墨家族唯一的儿子\u2014\u2014即墨越！魂穿而来的即墨越误以为她也是个现代人，本着同是天涯沦落人的心境，传闻是断袖的他娶了大家公认的男人婆！谁知道有一天晚上，他看到了一只小黑猫走出了他夫人的身体！\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014每晚十点后更新，不见不散哦！收藏过10就加更，有人催更也加更！总之，你们的支持，就是我写下去的动力！","majorCate":"武侠仙侠","minorCate":"仙侠","cover":"/agent/http://rm2.kingreader.com/book/1418227%2Fm%2F%5B640%5D_E7VI_1387.jpg","site":"zhuishuvip","banned":0,"latelyFollower":87,"wordCount":317462,"retentionRatio":0},"comment":""},{"book":{"_id":"566c31b3bc3816fb3d9548e0","title":"倾世暖婚：首席亿万追妻","author":"玲珑如玉","longIntro":"一场由亲人精心策划的阴谋，让她阴错阳差\b怀了商界顶尖人物的孩子。\r\n他不问她的身世地位，不查她的祖宗八代。\r\n他说，\u201c留下孩子，我娶你！\u201d\r\n她说，\u201c对不起，我不嫁豪门！\u201d\r\n霸道如他，却对她体贴入微，温柔眷顾。宠她，\r\n宠到天边。\r\n大婚那天，他却笑的冰冷，\u201c原来，因为他回来了，你才肯跟我结婚？\u201d\r\n她\b反唇相讥，\u201c若不是为了集团主席的位置，你会娶我?\u201d\r\n一年后，他递上离婚协议书。\r\n离婚后，他却满世界疯狂的找她！（宠文，男女主身心干净）","cover":"/agent/http://img1.chuangshi.qq.com/upload/cover/20150930/cb_560b479882244.jpg","cat":"都市言情","site":"zhuishuvip","majorCate":"现代言情","minorCate":"豪门总裁","banned":0,"latelyFollower":1187,"wordCount":3750231,"retentionRatio":48.97},"comment":""},{"book":{"cat":"豪门总裁","_id":"589ab29e64780f6d34b58333","title":"倾世暖婚：二嫁亿万首席","author":"猫不守色","longIntro":"她看着视频里交叠的身体，熟悉而陌生的男人，宋南音彻底怒了。连夜赶到宾馆捉奸，反而被陌生男子吃干了摸净了。夜半，自己的老公拖着疲软的身体归来，她看着他，心中再无波澜，\u201c天天回家喊累，原来是早就把公粮上交给别的野女人了\u201d他佯装淡定，\u201c老婆，你又多想\u201d宋南音嘴角再无暖色，她怎么也想不到，曾经视为天的男人竟事小人，当撕破脸的那一刻，夺家产，捍主权，她视男人为砒霜。可她万万没想到，一个如神祗一般的男人再一次把她全入怀中，\u201c宋南音，你身上的伤是怎么回事？\u201d","majorCate":"现代言情","minorCate":"豪门总裁","cover":"/agent/http://rm2.kingreader.com/book/1422879%2Fm%2F%5B640%5D_EJY1_1376.jpg","site":"zhuishuvip","banned":0,"latelyFollower":74,"wordCount":313696,"retentionRatio":0},"comment":""},{"book":{"cat":"豪门总裁","_id":"58635ec6add03a64574ce1c6","title":"天价弃妇：邪少太强势","author":"豆蔻","longIntro":"\u201c我要睡你！\u201d一场算计，让她睡了鼎鼎有名的穆天泽，从此过上了没日没夜没羞没臊的日子。穆天泽本领强大上天入地，偏偏就是和许欢颜过不去。许欢颜咬牙切齿：\u201c我的事情，你不要插手！\u201d穆天泽眉眼一笑，轻轻揽她入怀，指尖挑开她的樱唇：\u201c好，我不插手\u2026\u2026我插别的\u2026\u2026\u201d\r\n","majorCate":"现代言情","minorCate":"豪门总裁","cover":"/cover/14850752592271","site":"zhuishuvip","banned":0,"latelyFollower":437,"wordCount":482006,"retentionRatio":19.92},"comment":""},{"book":{"cat":"豪门总裁","_id":"580833f4d7fc259735792a5c","title":"撩妻36计：总裁，深深爱","author":"喵喵鱼尾","longIntro":"尚阳城，人人皆知九门之首的厉少冷漠决绝。　　可是私底下，他却是鬼迷心窍的\u2018宠爱\u2019着前妻。　　比如某天，乔笙从调香室出来，抱怨，\u201c里面好热啊！\u201d　　厉锦墨挑了挑眉，\u201c湿了吗？\u201d　　又如某天，乔笙翻着日历，提醒，\u201c过两天就是七夕了，这次你必须浪漫一点。\u201d　　厉锦墨薄唇撩起，\u201c嗯，睡觉的时候，你浪一点，我慢一点\u2026\u2026\u201d　　***　　乔笙走过的最深最长的路，就是厉锦墨的套路。　　四年前是，四年后，依旧逃不开。　　　因为有的人，一眼钻心，就再也不舍得出来\u2026\u2026　　\u2014\u2014如果早知会深爱，我一定先穿越人海去套路你。（乔笙）　　\u2014\u2014于我这里，有什么大过天，却没什么能大过你。（厉锦墨）","majorCate":"现代言情","minorCate":"豪门总裁","cover":"/cover/147728894951284","site":"zhuishuvip","banned":0,"latelyFollower":8940,"wordCount":866193,"retentionRatio":31.67},"comment":""},{"book":{"cat":"穿越时空","_id":"583d5199e53fe982669dfaf5","title":"宠无下限：朕的无良医后","author":"俗女","longIntro":"她是21世纪重口味女法医，平素不爱活人，爱死人。一场意外，她穿越回到古代成为失宠待嫁公主，初遇冷暴皇帝，差点命丧香艳浴池。幸得聪明机智，她后来在古代混得风生水起，闲来无事斗斗奸妃，查案尸检包她身上，太医院教学亮瞎他人狗眼 。　　\u201c脱！迅速的！\u201d　　\u201c皇后娘娘，臣不能脱\u2026\u2026\u201d　　某女伸出小手拉扯某大臣衣服，\u201c算了，我帮你脱！\u201d　　啪声响起，某皇帝气势逼人的拽住了某女，\u201c你居然敢脱其他男人的衣服？！\u201d　　\u201c废话，不脱怎么教解剖？\u201d　　某女被某皇帝扛起，\u201c回去，朕给你脱！\u201d","majorCate":"古代言情","minorCate":"穿越时空","cover":"/cover/148047048194451","site":"zhuishuvip","banned":0,"latelyFollower":3456,"wordCount":606659,"retentionRatio":32.54},"comment":""},{"book":{"_id":"573deffe59cf8c3c52590d7b","title":"宠妃当道：皇上，快躺好！","author":"颜若倾城","longIntro":"\u201c皇上相公，我\u2026\u2026\u201d\r\n\u201c又想要了？\u201d话音刚落，原本低头批奏章的男人一下将她压在龙案之侧，欺身而上。\r\n\u201c你混蛋！\u201d\r\n\u2014\u2014太后赐婚，那个未来夫君，可不就是她随手抓来的便宜相公？！从那以后，夏情欢就跟螃蟹似的，喜欢横着走\u2014\u2014不管是他当皇子的时候，还是当皇帝以后！可她实在是想不通，为什么在这个男人面前，她就只能乖乖当只小绵羊？某天，夏情欢扶着酸痛的腰大声抱怨：\u201c狗皇帝，你不是说这辈子都会疼我宠我？为什么我只感觉到了你的欺压！\u201d帝王沙哑的嗓音缓缓响起，\u201c乖女孩，不欺不压怎么疼你宠你？\u201d\r\n御书房里的温度节节攀升，门外侍卫面红耳赤。\r\n\u2014\u2014这辈子，你是我斩不断的相思。","cover":"/agent/http://img1.write.qq.com/upload/cover/2016-05-09/cb_573054c5d9c75.jpg","cat":"穿越","site":"zhuishuvip","majorCate":"古代言情","minorCate":"穿越时空","banned":0,"latelyFollower":14905,"wordCount":2118049,"retentionRatio":55.77},"comment":""},{"book":{"cat":"都市生活","_id":"57a7ec3c8083239c141b5207","title":"强势夺爱：顾先生请自重","author":"金佑木木","longIntro":"\"秦阮阮\u201c分手大师\u201d的名号打得响，却一脚踩在了\u201c天王老子\u201d顾临泫的脚上。\r\n\r\n一毛钱没赚到不说，还被逼倒欠三百万！\r\n\r\n没办法，为了还债，她不得不以身犯险，这险套路太深，她防不胜防。\r\n\r\n最后逼得日日夜夜被压着\u201c还债\u201d，赔了夫人又折兵。\r\n\r\n顾临泫最擅长的事就是翻手为云覆手为雨，以前是用在商场上，后来是用在秦阮阮身上，秦阮阮是他的云，是他的雨，把她扔床上翻来覆去，不知疲惫\u2026\u2026\"\r\n","majorCate":"现代言情","minorCate":"都市生活","cover":"/cover/147132509933927","site":"zhuishuvip","banned":0,"latelyFollower":650,"wordCount":772595,"retentionRatio":46.58},"comment":""},{"book":{"_id":"57bacb81356c991c727bcaac","title":"惹火小辣妻：老公，用力点","author":"万里里","longIntro":"\u201c嗯\u2026\u2026老公，热！\u201d\r\n\u201c热还穿这么多，乖，我帮你脱了。\u201d\r\n婚后五年形同陌路，一夜倾覆，她成了他的禁脔，从此夜夜难休\u2026\u2026\r\n\u201c厉司承，合约里说好的不能碰我的！\u201d\r\n他将她扑倒淡定回答：\u201c昨天晚上你碰我的时候，可不是这么说的。\u201d\r\n【重生+宠文+爽文】","cover":"/agent/http://img1.write.qq.com/upload/cover/2016-08-05/cb_57a4039d2cf32.jpg","cat":"总裁","site":"zhuishuvip","majorCate":"现代言情","minorCate":"豪门总裁","banned":0,"latelyFollower":34479,"wordCount":1554566,"retentionRatio":61.85},"comment":""},{"book":{"cat":"豪门总裁","_id":"5821936e84a13ba970e2a6df","title":"军婚撩人：首席大人太腹黑","author":"鱼尾袅袅","longIntro":"幽暗的房间里，昏黄的灯光下，男人勾唇，邪魅一笑：\u201c我是你的第几个男人？\u201d女子气的咬牙切齿，却还是软绵绵的应道：\u201c太多了，人家怎么记得清？\u201d男子若有所思的再次出声：\u201c嗯，多我一个，也不算什么！\u201d\u201c虾米？你不是有洁癖？\u201d男子讪笑：\u201c这个嘛，看情况！大爷我还是分得清，什么时候该讲究，什么时候该将就的。\u201d叶清子皱眉，她这算不算是撂了虎须，还挖好坑自己跳下去等着老虎发威？","majorCate":"现代言情","minorCate":"豪门总裁","cover":"/agent/http://rm2.kingreader.com/book/1229216%2Fm%2F%5B640%5D_%E5%86%9B%E5%A9%9A%E6%92%A9%E4%BA%BA%EF%BC%9A%E9%A6%96%E5%B8%AD%E5%A4%A7%E4%BA%BA%E5%A4%AA%E8%85%B9%E9%BB%91.jpg","site":"zhuishuvip","banned":0,"latelyFollower":340,"wordCount":419951,"retentionRatio":0},"comment":""}]
     * shareLink : http://share.zhuishushenqi.com/booklist/57c3ffcabbba8a463aab9959
     * id : 57c3ffcabbba8a463aab9959
     * total : 15
     */

    private String _id;
    private String updated;
    private String title;
    private AuthorBean author;
    private String desc;
    private String gender;
    private String created;
    private Object stickStopTime;
    private boolean isDraft;
    private Object isDistillate;
    private int collectorCount;
    private String shareLink;
    private String id;
    private int total;
    private List<String> tags;
    private List<BooksBean> books;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public AuthorBean getAuthor() {
        return author;
    }

    public void setAuthor(AuthorBean author) {
        this.author = author;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public Object getStickStopTime() {
        return stickStopTime;
    }

    public void setStickStopTime(Object stickStopTime) {
        this.stickStopTime = stickStopTime;
    }

    public boolean isIsDraft() {
        return isDraft;
    }

    public void setIsDraft(boolean isDraft) {
        this.isDraft = isDraft;
    }

    public Object getIsDistillate() {
        return isDistillate;
    }

    public void setIsDistillate(Object isDistillate) {
        this.isDistillate = isDistillate;
    }

    public int getCollectorCount() {
        return collectorCount;
    }

    public void setCollectorCount(int collectorCount) {
        this.collectorCount = collectorCount;
    }

    public String getShareLink() {
        return shareLink;
    }

    public void setShareLink(String shareLink) {
        this.shareLink = shareLink;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public List<BooksBean> getBooks() {
        return books;
    }

    public void setBooks(List<BooksBean> books) {
        this.books = books;
    }


    public static class BooksBean {
        /**
         * book : {"cat":"都市生活","_id":"58c1fd50bb87bc7024088fbc","title":"翻窗作案：老婆，你被潜了","author":"千羽兮","longIntro":"某日记者采访：\u201c厉总，请问你平时都喜欢玩些什么？\u201d　　 厉大总裁高深莫测了一会儿，紧接着甩出惊天话语，\u201c玩老婆\u2026\u2026\u201d　　 当晚，某女一身劲装，挥着小皮鞭出现在某男跟前，\u201c听说，你平时喜欢玩老婆？\u201d　　\u201c老婆，你听我解释\u2026\u2026\u201d　　\u201c想怎么玩？站着？坐着？躺着？还是\u2026\u2026\u201d　　\u201c老婆你来真的？\u201d　　\u201c你说呢？\u201d　 　后来，记者再问：\u201c厉总，你平常都喜欢玩些什么？\u201d　　 厉大总裁搂着怀里笑得灿烂动人的娇妻，\u201c老婆玩什么，我就玩什么。\u201d","majorCate":"都市","minorCate":"都市生活","cover":"/cover/14891086681579","site":"zhuishuvip","banned":0,"latelyFollower":3509,"wordCount":251043,"retentionRatio":28.97}
         * comment :
         */

        private BookBean book;
        private String comment;

        public BookBean getBook() {
            return book;
        }

        public void setBook(BookBean book) {
            this.book = book;
        }

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }

        public static class BookBean {
            /**
             * cat : 都市生活
             * _id : 58c1fd50bb87bc7024088fbc
             * title : 翻窗作案：老婆，你被潜了
             * author : 千羽兮
             * longIntro : 某日记者采访：“厉总，请问你平时都喜欢玩些什么？”　　 厉大总裁高深莫测了一会儿，紧接着甩出惊天话语，“玩老婆……”　　 当晚，某女一身劲装，挥着小皮鞭出现在某男跟前，“听说，你平时喜欢玩老婆？”　　“老婆，你听我解释……”　　“想怎么玩？站着？坐着？躺着？还是……”　　“老婆你来真的？”　　“你说呢？”　 　后来，记者再问：“厉总，你平常都喜欢玩些什么？”　　 厉大总裁搂着怀里笑得灿烂动人的娇妻，“老婆玩什么，我就玩什么。”
             * majorCate : 都市
             * minorCate : 都市生活
             * cover : /cover/14891086681579
             * site : zhuishuvip
             * banned : 0
             * latelyFollower : 3509
             * wordCount : 251043
             * retentionRatio : 28.97
             */

            private String cat;
            private String _id;
            private String title;
            private String author;
            private String longIntro;
            private String majorCate;
            private String minorCate;
            private String cover;
            private String site;
            private int banned;
            private int latelyFollower;
            private int wordCount;
            private double retentionRatio;

            public String getCat() {
                return cat;
            }

            public void setCat(String cat) {
                this.cat = cat;
            }

            public String get_id() {
                return _id;
            }

            public void set_id(String _id) {
                this._id = _id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getAuthor() {
                return author;
            }

            public void setAuthor(String author) {
                this.author = author;
            }

            public String getLongIntro() {
                return longIntro;
            }

            public void setLongIntro(String longIntro) {
                this.longIntro = longIntro;
            }

            public String getMajorCate() {
                return majorCate;
            }

            public void setMajorCate(String majorCate) {
                this.majorCate = majorCate;
            }

            public String getMinorCate() {
                return minorCate;
            }

            public void setMinorCate(String minorCate) {
                this.minorCate = minorCate;
            }

            public String getCover() {
                return cover;
            }

            public void setCover(String cover) {
                this.cover = cover;
            }

            public String getSite() {
                return site;
            }

            public void setSite(String site) {
                this.site = site;
            }

            public int getBanned() {
                return banned;
            }

            public void setBanned(int banned) {
                this.banned = banned;
            }

            public int getLatelyFollower() {
                return latelyFollower;
            }

            public void setLatelyFollower(int latelyFollower) {
                this.latelyFollower = latelyFollower;
            }

            public int getWordCount() {
                return wordCount;
            }

            public void setWordCount(int wordCount) {
                this.wordCount = wordCount;
            }

            public double getRetentionRatio() {
                return retentionRatio;
            }

            public void setRetentionRatio(double retentionRatio) {
                this.retentionRatio = retentionRatio;
            }
        }
    }
}
