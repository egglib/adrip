package com.example.newbiechen.ireader.event;

/**
 * Created by newbiechen on 17-5-5.
 */

public class BookSubSortEvent {
    public String bookSubSort;

    public BookSubSortEvent(String bookSubSort){
        this.bookSubSort = bookSubSort;
    }
}
