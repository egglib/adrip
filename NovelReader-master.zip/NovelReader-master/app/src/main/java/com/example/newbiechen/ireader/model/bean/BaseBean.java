package com.example.newbiechen.ireader.model.bean;

/**
 * Created by newbiechen on 17-4-20.
 */

public class BaseBean {
  public boolean ok;
}

