package com.example.newbiechen.ireader.event;

/**
 * Created by newbiechen on 17-5-8.
 */

public class RecommendBookEvent {
    public String sex;

    public RecommendBookEvent(String sex){
        this.sex = sex;
    }
}
